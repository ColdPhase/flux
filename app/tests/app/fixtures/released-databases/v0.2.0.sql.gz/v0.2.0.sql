--
-- PostgreSQL database dump
--


-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgboss; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pgboss;


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: job_state; Type: TYPE; Schema: pgboss; Owner: -
--

CREATE TYPE pgboss.job_state AS ENUM (
    'created',
    'retry',
    'active',
    'completed',
    'cancelled',
    'failed'
);


--
-- Name: create_queue(text, jsonb); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.create_queue(queue_name text, options jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $_$
    DECLARE
      tablename varchar := CASE WHEN options->>'partition' = 'true'
                            THEN 'j' || encode(sha224(queue_name::bytea), 'hex')
                            ELSE 'job_common'
                            END;
      queue_created_on timestamptz;
    BEGIN

      WITH q as (
        INSERT INTO pgboss.queue (
          name,
          policy,
          retry_limit,
          retry_delay,
          retry_backoff,
          retry_delay_max,
          expire_seconds,
          retention_seconds,
          deletion_seconds,
          warning_queued,
          dead_letter,
          partition,
          table_name,
          heartbeat_seconds,
          notify,
          created_on,
          updated_on
        )
        VALUES (
          queue_name,
          options->>'policy',
          COALESCE((options->>'retryLimit')::int, 2),
          COALESCE((options->>'retryDelay')::int, 0),
          COALESCE((options->>'retryBackoff')::bool, false),
          (options->>'retryDelayMax')::int,
          COALESCE((options->>'expireInSeconds')::int, 900),
          COALESCE((options->>'retentionSeconds')::int, 1209600),
          COALESCE((options->>'deleteAfterSeconds')::int, 604800),
          COALESCE((options->>'warningQueueSize')::int, 0),
          options->>'deadLetter',
          COALESCE((options->>'partition')::bool, false),
          tablename,
          (options->>'heartbeatSeconds')::int,
          COALESCE((options->>'notify')::bool, false),
          pgboss.job_now(),
          pgboss.job_now()
        )
        ON CONFLICT DO NOTHING
        RETURNING created_on
      )
      SELECT created_on into queue_created_on from q;

      IF queue_created_on IS NULL OR options->>'partition' IS DISTINCT FROM 'true' THEN
        RETURN;
      END IF;

      EXECUTE format('CREATE TABLE pgboss.%I (LIKE pgboss.job INCLUDING DEFAULTS)', tablename);

      EXECUTE pgboss.job_table_format($cmd$ALTER TABLE pgboss.job ADD PRIMARY KEY (name, id)$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$ALTER TABLE pgboss.job ADD CONSTRAINT q_fkey FOREIGN KEY (name) REFERENCES pgboss.queue (name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$ALTER TABLE pgboss.job ADD CONSTRAINT dlq_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue (name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED$cmd$, tablename);

      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i11 ON pgboss.job (name, priority DESC, created_on, start_after) WHERE state < 'active' AND NOT blocked$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i4 ON pgboss.job (name, singleton_on, COALESCE(singleton_key, '')) WHERE state <> 'cancelled' AND singleton_on IS NOT NULL$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i7 ON pgboss.job (name, group_id) WHERE state = 'active' AND group_id IS NOT NULL$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i9 ON pgboss.job (name, id) WHERE blocking AND state = 'completed'$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i12 ON pgboss.job (source_root_id) WHERE source_root_id IS NOT NULL$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i13 ON pgboss.job (name, singleton_key) WHERE state = 'created' AND upsert_by_key$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i14 ON pgboss.job (name, state, blocked, start_after) WHERE state IN ('created', 'retry', 'active', 'failed')$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i15 ON pgboss.job (name, created_on)$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i16 ON pgboss.job (name, completed_on) WHERE completed_on IS NOT NULL$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i17 ON pgboss.job (name, singleton_key, created_on) WHERE state < 'active' AND singleton_key IS NOT NULL$cmd$, tablename);

      IF options->>'policy' = 'short' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i1 ON pgboss.job (name, COALESCE(singleton_key, '')) WHERE state = 'created' AND policy = 'short'$cmd$, tablename);
      ELSIF options->>'policy' = 'singleton' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i2 ON pgboss.job (name, COALESCE(singleton_key, '')) WHERE state = 'active' AND policy = 'singleton'$cmd$, tablename);
      ELSIF options->>'policy' = 'stately' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i3 ON pgboss.job (name, state, COALESCE(singleton_key, '')) WHERE state <= 'active' AND policy = 'stately'$cmd$, tablename);
      ELSIF options->>'policy' = 'exclusive' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i6 ON pgboss.job (name, COALESCE(singleton_key, '')) WHERE state <= 'active' AND policy = 'exclusive'$cmd$, tablename);
      ELSIF options->>'policy' = 'key_strict_fifo' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i8 ON pgboss.job (name, singleton_key) WHERE state IN ('active', 'retry', 'failed') AND policy = 'key_strict_fifo'$cmd$, tablename);
        EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i10 ON pgboss.job (name, singleton_key, state DESC, created_on, id) INCLUDE (start_after) WHERE state < 'active' AND NOT blocked AND policy = 'key_strict_fifo'$cmd$, tablename);
        EXECUTE pgboss.job_table_format($cmd$ALTER TABLE pgboss.job ADD CONSTRAINT job_key_strict_fifo_singleton_key_check CHECK (NOT (policy = 'key_strict_fifo' AND singleton_key IS NULL))$cmd$, tablename);
      END IF;

      EXECUTE format('ALTER TABLE pgboss.%I ADD CONSTRAINT cjc CHECK (name=%L)', tablename, queue_name);
      EXECUTE format('ALTER TABLE pgboss.job ATTACH PARTITION pgboss.%I FOR VALUES IN (%L)', tablename, queue_name);
    END;
    $_$;


--
-- Name: delete_queue(text); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.delete_queue(queue_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      v_table varchar;
      v_partition bool;
    BEGIN
      
      SELECT table_name, partition
      FROM pgboss.queue
      WHERE name = queue_name
      INTO v_table, v_partition;

      IF v_partition THEN
        EXECUTE format('DROP TABLE IF EXISTS pgboss.%I', v_table);
      ELSE
        EXECUTE format('DELETE FROM pgboss.%I WHERE name = %L', v_table, queue_name);
      END IF;
    
      DELETE FROM pgboss.queue WHERE name = queue_name;
    END;
    $$;


--
-- Name: job_now(); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.job_now() RETURNS timestamp with time zone
    LANGUAGE sql STABLE
    AS $$
      SELECT pg_catalog.now();
    $$;


--
-- Name: job_table_format(text, text); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.job_table_format(command text, table_name text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $_$
      SELECT format(
        regexp_replace(
          regexp_replace(command, '\.job\y', '.%1$I', 'g'),
          '\yjob_i(\d+)', '%1$s_i\1', 'g'
        ),
        table_name
      );
    $_$;


--
-- Name: job_table_run(text, text, text); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.job_table_run(command text, tbl_name text DEFAULT NULL::text, queue_name text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      tbl RECORD;
    BEGIN
      IF queue_name IS NOT NULL THEN
        SELECT table_name INTO tbl_name FROM pgboss.queue WHERE name = queue_name;
      END IF;

      IF tbl_name IS NOT NULL THEN
        EXECUTE pgboss.job_table_format(command, tbl_name);
        RETURN;
      END IF;

      EXECUTE pgboss.job_table_format(command, 'job_common');

      FOR tbl IN SELECT table_name FROM pgboss.queue WHERE partition = true
      LOOP
        EXECUTE pgboss.job_table_format(command, tbl.table_name);
      END LOOP;
    END;
    $$;


--
-- Name: job_table_run_async(text, integer, text, text, text); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.job_table_run_async(command_name text, version integer, command text, tbl_name text DEFAULT NULL::text, queue_name text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF queue_name IS NOT NULL THEN
        SELECT table_name INTO tbl_name FROM pgboss.queue WHERE name = queue_name;
      END IF;

      IF tbl_name IS NOT NULL THEN
        INSERT INTO pgboss.bam (name, version, status, queue, table_name, command)
        VALUES (
          command_name,
          version,
          'pending',
          queue_name,
          tbl_name,
          pgboss.job_table_format(command, tbl_name)
        );
        RETURN;
      END IF;

      INSERT INTO pgboss.bam (name, version, status, queue, table_name, command)
      SELECT
        command_name,
        version,
        'pending',
        NULL,
        'job_common',
        pgboss.job_table_format(command, 'job_common')
      UNION ALL
      SELECT
        command_name,
        version,
        'pending',
        queue.name,
        queue.table_name,
        pgboss.job_table_format(command, queue.table_name)
      FROM pgboss.queue
      WHERE partition = true;
    END;
    $$;


--
-- Name: agent_task_events_notify(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_task_events_notify() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  PERFORM pg_notify('flux_agent_tasks', '');
  RETURN NULL;
END $$;


--
-- Name: ai_work_admission(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ai_work_admission() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  pid uuid;
  policy record;
BEGIN
  IF TG_TABLE_NAME = 'assistant_reaction_events' THEN
    SELECT project_id INTO pid FROM assistant_reactions WHERE id = NEW.reaction_id;
  ELSE
    pid := NEW.project_id;
  END IF;
  IF pid IS NULL AND TG_TABLE_NAME = 'personal_runs' THEN
    RETURN NEW;
  END IF;
  SELECT state, epoch INTO policy FROM project_ai_policies WHERE project_id = pid FOR SHARE;
  IF NOT FOUND OR policy.state <> 'allowed' OR NEW.ai_epoch IS DISTINCT FROM policy.epoch THEN
    RAISE EXCEPTION 'AI is turned off in this space' USING ERRCODE = 'FX403', HINT = 'SPACE_AI_OFF';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: auth_account_password_changed(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.auth_account_password_changed() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  -- OLD is the row as it is now, after any update that held the lock first.
  IF NEW.password_version_expected IS NOT NULL AND OLD.password_version IS DISTINCT FROM NEW.password_version_expected THEN
    RAISE EXCEPTION 'flux:password_changed: the password changed after it was checked' USING ERRCODE = 'P0001';
  END IF;
  IF NEW.password IS DISTINCT FROM OLD.password THEN
    NEW.password_version := OLD.password_version + 1;
    IF NEW.password_version_expected IS NULL AND NEW.provider_id = 'credential' THEN
      -- A password written with no check of the old one (a reset) ends every session, here, with the write. Better Auth deletes the sessions
      -- just before it writes, and a session created between the two (it saw the old version, and holds the share lock this write waited
      -- for) would otherwise stay.
      DELETE FROM auth_sessions WHERE user_id = NEW.user_id;
    END IF;
  END IF;
  NEW.password_version_expected := NULL;
  RETURN NEW;
END $$;


--
-- Name: auth_session_password_unchanged(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.auth_session_password_unchanged() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  -- FOR SHARE: a change of the password that comes in meanwhile waits for this insert to commit, and then deletes the session with the others.
  PERFORM 1 FROM auth_accounts a
    WHERE a.user_id = NEW.user_id AND a.provider_id = 'credential' AND a.password_version = NEW.password_version_checked
    FOR SHARE OF a;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'flux:password_changed: the password changed after it was checked' USING ERRCODE = 'P0001';
  END IF;
  NEW.password_version_checked := NULL;
  RETURN NEW;
END $$;


--
-- Name: cowork_stop_connection_units(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cowork_stop_connection_units() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND (NEW.revoked_at IS NULL OR OLD.revoked_at IS NOT NULL) THEN
    RETURN NEW;
  END IF;
  -- The parent connection row is already exclusively locked by UPDATE/DELETE.
  PERFORM connection_id FROM cowork_connection_slots
    WHERE connection_id = OLD.id ORDER BY connection_id FOR UPDATE;
  PERFORM id FROM project_work_items
    WHERE id IN (SELECT work_id FROM cowork_units WHERE assignment_connection_id = OLD.id
      AND state NOT IN ('completed', 'stopped')) ORDER BY id FOR UPDATE;
  PERFORM id FROM cowork_units WHERE assignment_connection_id = OLD.id
    AND state NOT IN ('completed', 'stopped') ORDER BY id FOR UPDATE;
  UPDATE cowork_units SET state = 'stopped', generation = generation + 1, version = version + 1,
    lease_id = NULL, lease_session_id = NULL, lease_expires_at = NULL, updated_at = clock_timestamp()
    WHERE assignment_connection_id = OLD.id AND state NOT IN ('completed', 'stopped');
  IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
  RETURN NEW;
END $$;


--
-- Name: dm_messages_flat_thread(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dm_messages_flat_thread() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.thread_root_id IS NOT NULL AND EXISTS (SELECT 1 FROM dm_messages r WHERE r.id = NEW.thread_root_id AND r.thread_root_id IS NOT NULL) THEN
    RAISE EXCEPTION 'a reply cannot be the root of another thread' USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: flux_event_audience_shape(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_event_audience_shape() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$
BEGIN
  IF NEW.recipient ~ '^(human|agent):[A-Za-z0-9_-]{1,64}$' THEN RETURN NEW; END IF;
  IF NOT EXISTS (SELECT 1 FROM events e WHERE e.id = NEW.event_id AND e.workspace_id IS NOT NULL AND workspace_sealed(e.workspace_id)) THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'An encrypted workspace''s event audience names principals only' USING ERRCODE = 'FX409', HINT = 'EVENT_CONTENT_REFUSED';
END $_$;


--
-- Name: flux_event_data_free(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_event_data_free() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$
DECLARE
  v text;
BEGIN
  IF NEW.workspace_id IS NULL OR NOT workspace_sealed(NEW.workspace_id) THEN RETURN NEW; END IF;
  -- The actor and the kind are shapes, never text (#721 review P3-3).
  IF NEW.actor_id !~ '^(human|agent|fixture):[A-Za-z0-9_-]{1,64}$' OR NEW.kind !~ '^[a-z][a-z_]*(\.[a-z][a-z_]*)+\.v[0-9]+$' THEN
    RAISE EXCEPTION 'An encrypted workspace''s event must be content-free' USING ERRCODE = 'FX409', HINT = 'EVENT_CONTENT_REFUSED';
  END IF;
  FOR v IN SELECT k #>> '{}' FROM jsonb_path_query(NEW.data, 'strict $.** ? (@.type() == "object").keyvalue().key') AS k LOOP
    CONTINUE WHEN v = '$sealed';
    CONTINUE WHEN v ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$';
    CONTINUE WHEN EXISTS (SELECT 1 FROM event_data_keys t WHERE t.key = v);
    RAISE EXCEPTION 'An encrypted workspace''s event must be content-free' USING ERRCODE = 'FX409', HINT = 'EVENT_CONTENT_REFUSED';
  END LOOP;
  FOR v IN SELECT x #>> '{}' FROM jsonb_path_query(NEW.data, 'strict $.**') AS x WHERE jsonb_typeof(x) = 'string' LOOP
    CONTINUE WHEN v ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$';
    CONTINUE WHEN v ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]{1,9})?(Z|[+-][0-9]{2}:[0-9]{2})$';
    CONTINUE WHEN flux_is_sealed(v);
    CONTINUE WHEN EXISTS (SELECT 1 FROM event_data_tokens t WHERE t.token = v);
    CONTINUE WHEN EXISTS (SELECT 1 FROM auth_users u WHERE u.id::text = v);
    CONTINUE WHEN v LIKE 'human:%' AND EXISTS (SELECT 1 FROM auth_users u WHERE u.id::text = substr(v, 7));
    CONTINUE WHEN v LIKE 'agent:%' AND EXISTS (SELECT 1 FROM agents a WHERE a.id::text = substr(v, 7));
    RAISE EXCEPTION 'An encrypted workspace''s event must be content-free' USING ERRCODE = 'FX409', HINT = 'EVENT_CONTENT_REFUSED';
  END LOOP;
  RETURN NEW;
END $_$;


--
-- Name: flux_events_assign_seq(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_events_assign_seq() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('flux.events.seq'));
  NEW.seq := nextval(pg_get_serial_sequence('events', 'seq'));
  RETURN NEW;
END
$$;


--
-- Name: flux_events_notify(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_events_notify() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.workspace_id IS NOT NULL THEN
    PERFORM pg_notify('flux_events', NEW.seq::text);
  END IF;
  RETURN NULL;
END
$$;


--
-- Name: flux_guard_task_creation_history(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_guard_task_creation_history() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.creation_baseline_version IS NOT NULL AND
    (NEW.creation_baseline_version IS DISTINCT FROM OLD.creation_baseline_version OR NEW.creation_baseline IS DISTINCT FROM OLD.creation_baseline OR NEW.creation_origin IS DISTINCT FROM OLD.creation_origin) THEN
    RAISE EXCEPTION 'immutable task creation baseline' USING ERRCODE = 'check_violation';
  END IF;
  IF OLD.first_persisted_use_at IS NOT NULL AND NEW.first_persisted_use_at IS DISTINCT FROM OLD.first_persisted_use_at THEN
    RAISE EXCEPTION 'immutable first task use' USING ERRCODE = 'check_violation';
  END IF;
  -- Every column this migration knows; a later migration's own new column can still be backfilled.
  IF OLD.creation_reverted_at IS NOT NULL AND (ROW(NEW.id, NEW.workspace_id, NEW.project_id, NEW.title, NEW.outcome, NEW.status, NEW.blocker,
      NEW.owner_user_id, NEW.owner_agent_id, NEW.created_by_kind, NEW.created_by_id,
      NEW.client_command_id, NEW.request_fingerprint, NEW.criteria, NEW.version, NEW.created_at, NEW.updated_at,
      NEW.creation_origin, NEW.creation_baseline, NEW.creation_baseline_version, NEW.first_persisted_use_at,
      NEW.creation_reverted_at, NEW.creation_reverted_by_kind, NEW.creation_reverted_by_id, NEW.creation_reversion_notice_id)
    IS DISTINCT FROM ROW(OLD.id, OLD.workspace_id, OLD.project_id, OLD.title, OLD.outcome, OLD.status, OLD.blocker,
      OLD.owner_user_id, OLD.owner_agent_id, OLD.created_by_kind, OLD.created_by_id,
      OLD.client_command_id, OLD.request_fingerprint, OLD.criteria, OLD.version, OLD.created_at, OLD.updated_at,
      OLD.creation_origin, OLD.creation_baseline, OLD.creation_baseline_version, OLD.first_persisted_use_at,
      OLD.creation_reverted_at, OLD.creation_reverted_by_kind, OLD.creation_reverted_by_id, OLD.creation_reversion_notice_id)) THEN
    RAISE EXCEPTION 'reverted task is read only' USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: flux_guard_task_creation_receipt(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_guard_task_creation_receipt() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'immutable task creation Undo receipt' USING ERRCODE = 'check_violation';
END $$;


--
-- Name: flux_is_sealed(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_is_sealed(value jsonb) RETURNS boolean
    LANGUAGE sql IMMUTABLE STRICT
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$
  SELECT coalesce(CASE jsonb_typeof(value)
    WHEN 'string' THEN flux_is_sealed(value #>> '{}')
    WHEN 'object' THEN (SELECT count(*) FROM jsonb_object_keys(value)) = 1 AND jsonb_typeof(value -> '$sealed') = 'string'
      AND flux_is_sealed(value ->> '$sealed')
    ELSE false END, false) $_$;


--
-- Name: flux_is_sealed(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_is_sealed(value text) RETURNS boolean
    LANGUAGE sql IMMUTABLE STRICT
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$ SELECT value ~ '^fx1\.[1-9][0-9]{0,8}\.[A-Za-z0-9_-]{38,}$' $_$;


--
-- Name: flux_max_version(integer[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_max_version(integer[]) RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $_$ SELECT max(v) FROM unnest($1) v $_$;


--
-- Name: flux_notification_content_free(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_notification_content_free() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  ws text;
  sep text;
  who text;
BEGIN
  IF NEW.workspace_id IS NULL OR NOT workspace_sealed(NEW.workspace_id) THEN RETURN NEW; END IF;
  -- A read-state or delivery update keeps the stored text, which was checked when written: a later rename of the
  -- account or the workspace must not make the row impossible to mark read (#712 review P2-1).
  IF TG_OP = 'UPDATE' AND NEW.title IS NOT DISTINCT FROM OLD.title AND NEW.body IS NOT DISTINCT FROM OLD.body
    AND NEW.url IS NOT DISTINCT FROM OLD.url AND NEW.workspace_id = OLD.workspace_id THEN RETURN NEW; END IF;
  -- The link carries ids only: one of the generator's forms with every id replaced (#712 review P3).
  IF NEW.url IS NOT NULL AND regexp_replace(NEW.url, '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}', 'ID', 'g')
    NOT IN ('/inbox', '/projects/ID/conversations/ID#message-ID', '/dm/ID#message-ID', '/projects/ID/tasks?open=work:ID',
      '/projects/ID/tasks?open=decision:ID', '/projects/ID/live/ID?invitation=ID') THEN
    RAISE EXCEPTION 'An encrypted workspace''s notification must be content-free' USING ERRCODE = 'FX409', HINT = 'NOTIFICATION_CONTENT_REFUSED';
  END IF;
  SELECT name INTO ws FROM workspaces WHERE id = NEW.workspace_id;
  IF NEW.body = '' THEN
    IF NEW.title = ws || '''s encryption keys were changed outside Flux. It stays locked.' THEN RETURN NEW; END IF;
    IF NEW.title = ws || '''s key change cannot finish yet. Ask your server''s operator.' THEN RETURN NEW; END IF;
    FOREACH sep IN ARRAY ARRAY[' mentioned you in ', ' asked you in ', ' replied in ', ' sent you a message in ', ' assigned you a task in ',
      ' asked for your review in ', ' invited you to work together in ', ' now has an unlock password for '] LOOP
      IF length(NEW.title) > length(sep || ws) AND right(NEW.title, length(sep || ws)) = sep || ws THEN
        who := left(NEW.title, length(NEW.title) - length(sep || ws));
        IF who IN ('Someone', 'An agent') OR EXISTS (SELECT 1 FROM auth_users u WHERE u.name = who) THEN RETURN NEW; END IF;
      END IF;
    END LOOP;
  END IF;
  RAISE EXCEPTION 'An encrypted workspace''s notification must be content-free' USING ERRCODE = 'FX409', HINT = 'NOTIFICATION_CONTENT_REFUSED';
END $$;


--
-- Name: flux_revoke_live_admissions(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_revoke_live_admissions() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  UPDATE live_admissions SET revoked_at = now()
  WHERE auth_session_id = OLD.id AND revoked_at IS NULL;
  IF FOUND THEN
    PERFORM pg_notify('flux_live_admissions', OLD.id);
  END IF;
  RETURN OLD;
END;
$$;


--
-- Name: flux_sealed_backstop(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_sealed_backstop() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$
DECLARE
  r jsonb := to_jsonb(NEW);
  path text[] := string_to_array(TG_ARGV[0], ':');
  ws uuid;
  v jsonb;
BEGIN
  IF path[1] = 'workspace_id' THEN
    ws := (r ->> 'workspace_id')::uuid;
  ELSIF r ->> path[2] IS NOT NULL THEN
    EXECUTE format('SELECT workspace_id FROM %I WHERE %I = $1', path[3], path[4]) INTO ws USING (r ->> path[2])::uuid;
  END IF;
  IF ws IS NULL OR NOT workspace_sealed(ws) THEN RETURN NEW; END IF;
  FOR i IN 1 .. TG_NARGS - 1 LOOP
    v := r -> TG_ARGV[i];
    CONTINUE WHEN v IS NULL OR v = 'null'::jsonb OR v = '""'::jsonb;
    IF flux_is_sealed(v) IS NOT TRUE THEN
      RAISE EXCEPTION 'An encrypted workspace refuses plaintext in %.%', TG_TABLE_NAME, TG_ARGV[i]
        USING ERRCODE = 'FX409', HINT = 'WORKSPACE_PLAINTEXT_REFUSED';
    END IF;
  END LOOP;
  RETURN NEW;
END $_$;


--
-- Name: flux_sealed_wait_ids_only(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_sealed_wait_ids_only() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$
BEGIN
  IF NEW.queue ~ '^[a-z][a-z0-9_.-]{0,63}$' AND jsonb_typeof(NEW.payload) = 'object' AND NOT EXISTS (SELECT 1 FROM jsonb_each(NEW.payload) p
      WHERE p.key <> 'eventId' OR jsonb_typeof(p.value) <> 'string'
        OR NOT (p.value #>> '{}') ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$') THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'A sealed job wait carries ids only' USING ERRCODE = 'FX409', HINT = 'EVENT_CONTENT_REFUSED';
END $_$;


--
-- Name: flux_task_criteria_valid(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_task_criteria_valid(criteria jsonb) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $$
  SELECT CASE WHEN jsonb_typeof(criteria) <> 'array' THEN false ELSE
    jsonb_array_length(criteria) <= 20
    AND NOT EXISTS (
      SELECT 1 FROM jsonb_array_elements(criteria) AS item
      WHERE jsonb_typeof(item) <> 'string'
        OR length(item #>> '{}') NOT BETWEEN 1 AND 1000
        OR (item #>> '{}') <> btrim(item #>> '{}', E' \t\r\n'))
    AND (SELECT count(DISTINCT item) FROM jsonb_array_elements(criteria) AS item) = jsonb_array_length(criteria)
  END
$$;


--
-- Name: flux_task_dependency_bound(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_task_dependency_bound() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF (SELECT count(*) FROM project_task_dependencies WHERE task_id = NEW.task_id) >= 50 THEN
    RAISE EXCEPTION 'a task has at most 50 prerequisites' USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: flux_task_plan_intent_immutable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_task_plan_intent_immutable() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'task plan intents are immutable' USING ERRCODE = 'check_violation';
END;
$$;


--
-- Name: forbid_material_version_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.forbid_material_version_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'material versions are immutable' USING ERRCODE = 'check_violation';
END;
$$;


--
-- Name: guard_map_live_identity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_map_live_identity() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_TABLE_NAME='map_live_object_versions' THEN
    IF ROW(NEW.kind,NEW.object_id,NEW.sketch_id) IS DISTINCT FROM ROW(OLD.kind,OLD.object_id,OLD.sketch_id) OR NEW.version<=OLD.version THEN
      RAISE EXCEPTION 'immutable map object ownership or non-monotonic version' USING ERRCODE='23514';
    END IF;
  ELSIF TG_TABLE_NAME='map_live_heads' THEN
    IF ROW(NEW.sketch_id,NEW.workspace_id,NEW.generation) IS DISTINCT FROM ROW(OLD.sketch_id,OLD.workspace_id,OLD.generation) OR NEW.sequence<OLD.sequence THEN
      RAISE EXCEPTION 'immutable map room or non-monotonic sequence' USING ERRCODE='23514';
    END IF;
  END IF;
  RETURN NEW;
END $$;


--
-- Name: idempotency_scope_required(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.idempotency_scope_required() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF NEW.workspace_id IS NULL AND NOT EXISTS (SELECT 1 FROM idempotency_account_operations WHERE operation = NEW.operation) THEN
    RAISE EXCEPTION 'An Idempotency-Key response needs the workspace of its command' USING ERRCODE = 'FX409', HINT = 'IDEMPOTENCY_SCOPE_REQUIRED';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: immutable_live_editing_record(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.immutable_live_editing_record() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN RAISE EXCEPTION 'live editing history and receipts are immutable' USING ERRCODE = 'check_violation'; END $$;


--
-- Name: invalidate_runtime_auth_operations(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_runtime_auth_operations() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.state <> 'active' THEN
    UPDATE agent_runtime_auth_operations SET phase = 'uncertain', settled_at = NULL
      WHERE binding_id = NEW.id AND phase = 'active';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: live_replica_ownership_immutable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.live_replica_ownership_immutable() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF (NEW.doc_id,NEW.generation,NEW.replica_id,NEW.owner_kind,NEW.actor_id,NEW.instance_id)
    IS DISTINCT FROM (OLD.doc_id,OLD.generation,OLD.replica_id,OLD.owner_kind,OLD.actor_id,OLD.instance_id) THEN
    RAISE EXCEPTION 'live replica ownership is immutable' USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: live_session_doc_in_space(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.live_session_doc_in_space() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF NEW.doc_id IS NULL OR TG_OP = 'UPDATE' AND NEW.doc_id IS NOT DISTINCT FROM OLD.doc_id
     AND NEW.project_id IS NOT DISTINCT FROM OLD.project_id AND NEW.workspace_id IS NOT DISTINCT FROM OLD.workspace_id THEN
    RETURN NEW;
  END IF;
  PERFORM pm.id FROM project_materials pm
    WHERE pm.id = NEW.doc_id AND pm.kind = 'doc' AND pm.workspace_id = NEW.workspace_id AND pm.project_id = NEW.project_id
    FOR KEY SHARE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'a live session''s page must be a page of its own space'
      USING ERRCODE = 'foreign_key_violation', CONSTRAINT = 'live_sessions_doc_in_space';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: material_agent_doc_stays_doc(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.material_agent_doc_stays_doc() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.kind IS DISTINCT FROM 'doc' AND EXISTS (
    SELECT 1 FROM project_material_versions v WHERE v.material_id = NEW.id AND v.author_agent_id IS NOT NULL) THEN
    RAISE EXCEPTION 'a material with an agent-written version stays a doc'
      USING ERRCODE = 'check_violation', CONSTRAINT = 'project_material_version_agent_doc_parent';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: material_version_agent_doc_parent(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.material_version_agent_doc_parent() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  parent_kind text;
BEGIN
  IF NEW.author_agent_id IS NULL THEN RETURN NEW; END IF;
  SELECT pm.kind INTO parent_kind FROM project_materials pm WHERE pm.id = NEW.material_id FOR SHARE;
  IF parent_kind IS DISTINCT FROM 'doc' THEN
    RAISE EXCEPTION 'only a doc version can have an agent author'
      USING ERRCODE = 'check_violation', CONSTRAINT = 'project_material_version_agent_doc_parent';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: personal_run_private_texts_end(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.personal_run_private_texts_end() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  DELETE FROM personal_run_private_texts WHERE run_id = NEW.id;
  RETURN NULL;
END $$;


--
-- Name: personal_run_task_ended(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.personal_run_task_ended() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  INSERT INTO agent_task_events (kind, work_id, run_id) VALUES ('finished', NEW.work_id, NEW.id);
  RETURN NULL;
END $$;


--
-- Name: personal_run_task_started(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.personal_run_task_started() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  INSERT INTO agent_task_events (kind, work_id, run_id) VALUES ('started', NEW.work_id, NEW.id);
  RETURN NULL;
END $$;


--
-- Name: project_ai_policy_create(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.project_ai_policy_create() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  INSERT INTO project_ai_policies (project_id, state) VALUES (NEW.id, CASE WHEN workspace_sealed(NEW.workspace_id) THEN 'blocked' ELSE 'allowed' END);
  RETURN NEW;
END $$;


--
-- Name: project_ai_policy_encrypted(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.project_ai_policy_encrypted() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF NEW.state = 'allowed' AND workspace_sealed((SELECT p.workspace_id FROM projects p WHERE p.id = NEW.project_id)) THEN
    RAISE EXCEPTION 'AI is always off in an encrypted workspace' USING ERRCODE = 'FX409', HINT = 'WORKSPACE_ENCRYPTED_AI_OFF';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: project_task_sequence(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.project_task_sequence(project uuid) RETURNS regclass
    LANGUAGE sql STABLE
    AS $$
  SELECT to_regclass('project_task_number_' || replace(project::text, '-', ''))
$$;


--
-- Name: project_task_sequence_lifecycle(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.project_task_sequence_lifecycle() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    EXECUTE format('CREATE SEQUENCE %I AS integer', 'project_task_number_' || replace(NEW.id::text, '-', ''));
  ELSE
    EXECUTE format('DROP SEQUENCE IF EXISTS %I', 'project_task_number_' || replace(OLD.id::text, '-', ''));
  END IF;
  RETURN NULL;
END $$;


--
-- Name: project_work_number(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.project_work_number() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  sequence regclass;
BEGIN
  IF TG_OP = 'UPDATE' THEN
    IF NEW.number IS DISTINCT FROM OLD.number THEN
      RAISE EXCEPTION 'a task number never changes' USING ERRCODE = 'restrict_violation';
    END IF;
    -- The number belongs to the project's sequence: a numbered task never moves to another project.
    IF NEW.project_id IS DISTINCT FROM OLD.project_id THEN
      RAISE EXCEPTION 'a numbered task never moves to another project' USING ERRCODE = 'restrict_violation';
    END IF;
    RETURN NEW;
  END IF;
  sequence := project_task_sequence(NEW.project_id);
  IF sequence IS NULL THEN
    RAISE EXCEPTION 'no task numbering for project %', NEW.project_id USING ERRCODE = 'foreign_key_violation';
  END IF;
  NEW.number := nextval(sequence);
  RETURN NEW;
END $$;


--
-- Name: sealed_workspace_no_ai(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sealed_workspace_no_ai() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$
DECLARE
  r jsonb := to_jsonb(NEW);
  uuid_text text := '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$';
  ws uuid;
BEGIN
  IF coalesce(r->>'workspace_id', '') ~* uuid_text THEN
    ws := (r->>'workspace_id')::uuid;
  ELSIF coalesce(r->>'project_id', '') ~* uuid_text THEN
    SELECT workspace_id INTO ws FROM projects WHERE id = (r->>'project_id')::uuid;
  ELSIF coalesce(r->>'agent_id', '') ~* uuid_text THEN
    SELECT workspace_id INTO ws FROM agents WHERE id = (r->>'agent_id')::uuid;
  ELSIF TG_TABLE_NAME LIKE 'agent%' AND coalesce(r->>'connection_id', '') ~* uuid_text THEN
    SELECT workspace_id INTO ws FROM agent_connections WHERE id = (r->>'connection_id')::uuid;
  END IF;
  IF ws IS NOT NULL AND workspace_sealed(ws) THEN
    RAISE EXCEPTION 'AI is always off in an encrypted workspace' USING ERRCODE = 'FX409', HINT = 'WORKSPACE_ENCRYPTED_AI_OFF';
  END IF;
  RETURN NEW;
END $_$;


--
-- Name: sealed_workspace_refused(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sealed_workspace_refused() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$
DECLARE
  r jsonb := to_jsonb(NEW);
  uuid_text text := '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$';
  ws uuid;
BEGIN
  IF coalesce(r ->> 'workspace_id', '') ~* uuid_text THEN
    ws := (r ->> 'workspace_id')::uuid;
  ELSIF coalesce(r ->> 'project_id', '') ~* uuid_text THEN
    SELECT workspace_id INTO ws FROM projects WHERE id = (r ->> 'project_id')::uuid;
  END IF;
  IF ws IS NOT NULL AND workspace_sealed(ws) THEN
    RAISE EXCEPTION 'GitHub is not available in an encrypted workspace' USING ERRCODE = 'FX409', HINT = 'WORKSPACE_ENCRYPTED_UNSUPPORTED';
  END IF;
  RETURN NEW;
END $_$;


--
-- Name: search_change_log(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_change_log() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    IF OLD.sealed THEN INSERT INTO search_changes (workspace_id, doc_key) VALUES (OLD.workspace_id, OLD.doc_key); END IF;
    RETURN OLD;
  END IF;
  IF NEW.sealed THEN INSERT INTO search_changes (workspace_id, doc_key) VALUES (NEW.workspace_id, NEW.doc_key); END IF;
  RETURN NEW;
END $$;


--
-- Name: search_index_decision(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_decision() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN DELETE FROM search_documents WHERE doc_key = 'decision:' || OLD.id; RETURN OLD; END IF;
  PERFORM search_put('decision:' || NEW.id, 'decision', NEW.workspace_id, 'project:' || NEW.project_id, NEW.project_id, NEW.id::text, NULL, NULL,
    NEW.status, NEW.title, NEW.rationale, NEW.proposed_by_kind, NEW.proposed_by_id, NEW.updated_at);
  RETURN NEW;
END $$;


--
-- Name: search_index_dm_message(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_dm_message() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN DELETE FROM search_documents WHERE doc_key = 'dm_message:' || OLD.id; RETURN OLD; END IF;
  IF NEW.kind <> 'text' THEN RETURN NEW; END IF;
  IF NEW.removed_at IS NOT NULL THEN DELETE FROM search_documents WHERE doc_key = 'dm_message:' || NEW.id; RETURN NEW; END IF;
  PERFORM search_put('dm_message:' || NEW.id, 'dm_message', NEW.workspace_id, 'dm:' || NEW.dm_id, NULL, NEW.id::text,
    NEW.dm_id, NULL, NULL, '', NEW.body, 'human', NEW.author_id, NEW.created_at);
  RETURN NEW;
END $$;


--
-- Name: search_index_material_version(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_material_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  material_kind text;
BEGIN
  IF TG_OP = 'DELETE' THEN DELETE FROM search_documents WHERE doc_key = 'material:' || OLD.material_id || ':' || OLD.version; RETURN OLD; END IF;
  SELECT pm.kind INTO material_kind FROM project_materials pm WHERE pm.id = NEW.material_id;
  PERFORM search_put('material:' || NEW.material_id || ':' || NEW.version, coalesce(material_kind, 'material'), NEW.workspace_id, 'project:' || NEW.project_id,
    NEW.project_id, NEW.material_id::text, NULL, NEW.version, NULL, NEW.title, concat_ws(E'\n', NEW.body, NEW.url),
    CASE WHEN NEW.author_id IS NOT NULL THEN 'human' ELSE 'agent' END, coalesce(NEW.author_id, NEW.author_agent_id::text), NEW.created_at);
  RETURN NEW;
END $$;


--
-- Name: search_index_member(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_member() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN DELETE FROM search_documents WHERE doc_key = 'person:' || OLD.workspace_id || ':' || OLD.user_id; RETURN OLD; END IF;
  PERFORM search_put('person:' || NEW.workspace_id || ':' || NEW.user_id, 'person', NEW.workspace_id, 'members:' || NEW.workspace_id, NULL,
    NEW.user_id, NULL, NULL, NEW.role, (SELECT u.name FROM auth_users u WHERE u.id = NEW.user_id), '', NULL, NULL, NEW.created_at);
  RETURN NEW;
END $$;


--
-- Name: search_index_message(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_message() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN DELETE FROM search_documents WHERE doc_key = 'message:' || OLD.id; RETURN OLD; END IF;
  IF NEW.removed_at IS NOT NULL THEN DELETE FROM search_documents WHERE doc_key = 'message:' || NEW.id; RETURN NEW; END IF;
  PERFORM search_put('message:' || NEW.id, 'message', NEW.workspace_id, 'project:' || NEW.project_id, NEW.project_id, NEW.id::text,
    NEW.conversation_id, NULL, NULL, CASE WHEN btrim(NEW.body) = '' THEN 'Attached files' ELSE '' END, NEW.body,
    CASE WHEN NEW.author_id IS NOT NULL THEN 'human' ELSE 'agent' END,
    coalesce(NEW.author_id, NEW.author_agent_id::text), NEW.created_at);
  RETURN NEW;
END $$;


--
-- Name: search_index_project(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_project() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN DELETE FROM search_documents WHERE doc_key = 'project:' || OLD.id; RETURN OLD; END IF;
  PERFORM search_put('project:' || NEW.id, 'project', NEW.workspace_id, 'project:' || NEW.id, NEW.id, NEW.id::text, NULL, NULL,
    NEW.visibility, NEW.name, '', NULL, NULL, NEW.updated_at);
  RETURN NEW;
END $$;


--
-- Name: search_index_sketch(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_sketch() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    DELETE FROM search_documents WHERE doc_key = 'sketch:' || OLD.id;
    RETURN OLD;
  END IF;
  PERFORM search_put('sketch:' || NEW.id, 'sketch', NEW.workspace_id, 'sketch:' || NEW.id, NEW.project_id, NEW.id::text, NULL, NULL,
    NEW.scope, NEW.title, '', CASE WHEN NEW.created_by_user_id IS NOT NULL THEN 'human' WHEN NEW.created_by_agent_id IS NOT NULL THEN 'agent' END,
    coalesce(NEW.created_by_user_id, NEW.created_by_agent_id::text), NEW.updated_at);
  IF TG_OP = 'UPDATE' AND NEW.project_id IS DISTINCT FROM OLD.project_id THEN
    UPDATE search_documents SET project_id = NEW.project_id WHERE parent_id = NEW.id AND kind = 'thought';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: search_index_thought(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_thought() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN DELETE FROM search_documents WHERE doc_key = 'thought:' || OLD.id; RETURN OLD; END IF;
  -- Moving a thought on the map changes nothing that can be searched.
  IF TG_OP = 'UPDATE' AND NEW.text IS NOT DISTINCT FROM OLD.text THEN RETURN NEW; END IF;
  PERFORM search_put('thought:' || NEW.id, 'thought', NEW.workspace_id, 'sketch:' || NEW.sketch_id,
    (SELECT s.project_id FROM sketches s WHERE s.id = NEW.sketch_id), NEW.id::text, NEW.sketch_id, NULL, NULL, NEW.text, '',
    CASE WHEN NEW.created_by_user_id IS NOT NULL THEN 'human' WHEN NEW.created_by_agent_id IS NOT NULL THEN 'agent' END,
    coalesce(NEW.created_by_user_id, NEW.created_by_agent_id::text), NEW.updated_at);
  RETURN NEW;
END $$;


--
-- Name: search_index_user_name(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_user_name() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  UPDATE search_documents SET title = NEW.name WHERE kind = 'person' AND object_id = NEW.id;
  RETURN NEW;
END $$;


--
-- Name: search_index_work(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_work() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN DELETE FROM search_documents WHERE doc_key = 'work:' || OLD.id; RETURN OLD; END IF;
  PERFORM search_put('work:' || NEW.id, 'work', NEW.workspace_id, 'project:' || NEW.project_id, NEW.project_id, NEW.id::text, NULL, NULL,
    NEW.status,
    NEW.title, concat_ws(E'\n', '#' || NEW.number, nullif(NEW.outcome, ''), NEW.blocker), NEW.created_by_kind, NEW.created_by_id, NEW.updated_at);
  RETURN NEW;
END $$;


--
-- Name: search_key(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_key(p_audience text, p_term text) RETURNS bigint
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    AS $$ SELECT hashtextextended(p_audience || '|' || p_term, 0) $$;


--
-- Name: search_keys(text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_keys(p_audience text, p_title text, p_body text) RETURNS bigint[]
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    SET search_path TO 'public', 'pg_catalog'
    AS $$
  SELECT coalesce(array_agg(DISTINCT search_key(p_audience, k)), '{}')
  FROM (
    SELECT prefixes.k
    FROM (SELECT lexeme FROM unnest(to_tsvector('simple', coalesce(p_title, '') || ' ' || left(coalesce(p_body, ''), 100000)))) words,
    LATERAL (VALUES ('1:' || left(words.lexeme, 1)), (CASE WHEN length(words.lexeme) >= 2 THEN '2:' || left(words.lexeme, 2) END),
      (CASE WHEN length(words.lexeme) >= 3 THEN '3:' || left(words.lexeme, 3) END)) AS prefixes(k)
    UNION ALL
    SELECT 't:' || trigram FROM unnest(show_trgm(left(coalesce(p_title, ''), 1000))) AS trigram
  ) keys
  WHERE k IS NOT NULL
$$;


--
-- Name: search_put(text, text, uuid, text, uuid, text, uuid, integer, text, text, text, text, text, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_put(p_key text, p_kind text, p_workspace uuid, p_audience text, p_project uuid, p_object text, p_parent uuid, p_version integer, p_status text, p_title text, p_body text, p_author_kind text, p_author text, p_at timestamp with time zone) RETURNS void
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE placeholder boolean := p_kind <> 'person' AND workspace_sealed(p_workspace);
BEGIN
  INSERT INTO search_documents(doc_key, kind, workspace_id, audience_key, project_id, object_id, parent_id, version, status, title, body, author_kind, author_id, at, sealed)
  VALUES (p_key, p_kind, p_workspace, p_audience, p_project, p_object, p_parent, p_version, p_status,
    CASE WHEN placeholder THEN '' ELSE coalesce(p_title, '') END, CASE WHEN placeholder THEN '' ELSE coalesce(p_body, '') END,
    p_author_kind, p_author, p_at, placeholder)
  ON CONFLICT (doc_key) DO UPDATE SET
    workspace_id = EXCLUDED.workspace_id, audience_key = EXCLUDED.audience_key, project_id = EXCLUDED.project_id,
    parent_id = EXCLUDED.parent_id, version = EXCLUDED.version, status = EXCLUDED.status, title = EXCLUDED.title,
    body = EXCLUDED.body, author_kind = EXCLUDED.author_kind, author_id = EXCLUDED.author_id, at = EXCLUDED.at, sealed = EXCLUDED.sealed;
END $$;


--
-- Name: search_term(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_term(p_lexeme text) RETURNS text
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    AS $$ SELECT least(length(p_lexeme), 3)::text || ':' || left(p_lexeme, 3) $$;


--
-- Name: workspace_company_link_guard(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.workspace_company_link_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.company_workspace_id IS NOT NULL AND EXISTS (SELECT 1 FROM workspaces parent WHERE parent.id = NEW.company_workspace_id AND parent.encrypted) THEN
    RAISE EXCEPTION 'An encrypted space belongs to the company, never to another encrypted space' USING ERRCODE = 'FX409', HINT = 'ENCRYPTED_SPACE_COMPANY_ONLY';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: workspace_encryption_immutable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.workspace_encryption_immutable() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.encrypted IS DISTINCT FROM OLD.encrypted THEN
    RAISE EXCEPTION 'A workspace''s encryption is chosen at creation and cannot change' USING ERRCODE = 'FX409', HINT = 'WORKSPACE_ENCRYPTION_IMMUTABLE';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: workspace_holder_delete_guard(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.workspace_holder_delete_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.kind = 'password' AND EXISTS (SELECT 1 FROM workspaces WHERE id = OLD.workspace_id)
    AND NOT EXISTS (SELECT 1 FROM workspace_holders WHERE workspace_id = OLD.workspace_id AND kind = 'password' AND id <> OLD.id) THEN
    RAISE EXCEPTION 'The workspace needs at least one unlock password' USING ERRCODE = 'FX409', HINT = 'LAST_UNLOCK_PASSWORD';
  END IF;
  RETURN OLD;
END $$;


--
-- Name: workspace_holder_deleted(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.workspace_holder_deleted() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM workspace_keys WHERE workspace_id = OLD.workspace_id) THEN
    INSERT INTO workspace_removed_holders (workspace_id, holder_id, user_id, public_key)
      VALUES (OLD.workspace_id, OLD.id, OLD.user_id, OLD.public_key) ON CONFLICT DO NOTHING;
    UPDATE workspace_keys SET rotation = 'pending', rotation_reason = jsonb_build_object('kind', 'holder_deleted', 'userId', OLD.user_id)
      WHERE workspace_id = OLD.workspace_id AND rotation IN ('none', 'reencrypting');
  END IF;
  RETURN NULL;
END $$;


--
-- Name: workspace_manager_lost(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.workspace_manager_lost() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF OLD.role IN ('owner', 'admin') AND (TG_OP = 'DELETE' OR NEW.role NOT IN ('owner', 'admin'))
    AND EXISTS (SELECT 1 FROM workspaces WHERE id = OLD.workspace_id AND encrypted)
    AND EXISTS (SELECT 1 FROM workspace_keys WHERE workspace_id = OLD.workspace_id) THEN
    DELETE FROM workspace_holders WHERE workspace_id = OLD.workspace_id
      AND (kind = 'recovery' OR (kind = 'password' AND user_id = OLD.user_id));
    UPDATE workspace_keys SET rotation = 'pending',
      rotation_reason = jsonb_build_object('kind', CASE WHEN TG_OP = 'DELETE' THEN 'removed' ELSE 'demoted' END, 'userId', OLD.user_id)
      WHERE workspace_id = OLD.workspace_id;
  END IF;
  RETURN NULL;
END $$;


--
-- Name: workspace_sealed(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.workspace_sealed(uuid) RETURNS boolean
    LANGUAGE sql STABLE
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$ SELECT coalesce((SELECT encrypted FROM workspaces WHERE id = $1), false) $_$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bam; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.bam (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    version integer NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    queue text,
    table_name text NOT NULL,
    command text NOT NULL,
    error text,
    created_on timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    started_on timestamp with time zone,
    completed_on timestamp with time zone
);


--
-- Name: instance; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.instance (
    id uuid NOT NULL,
    name text,
    host text NOT NULL,
    pid integer NOT NULL,
    version text NOT NULL,
    node_version text NOT NULL,
    application_name text,
    heartbeat_seconds integer NOT NULL,
    supervise boolean NOT NULL,
    schedule boolean NOT NULL,
    migrate boolean NOT NULL,
    persist_queue_stats boolean NOT NULL,
    persist_warnings boolean NOT NULL,
    pool_max integer,
    pool_total integer,
    pool_idle integer,
    pool_waiting integer,
    workers jsonb DEFAULT '[]'::jsonb NOT NULL,
    metrics jsonb,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    crash_restarts integer DEFAULT 0 NOT NULL,
    crash_restarts_since timestamp with time zone,
    started_on timestamp with time zone DEFAULT now() NOT NULL,
    heartbeat_on timestamp with time zone DEFAULT now() NOT NULL,
    stopped_on timestamp with time zone
);


--
-- Name: job; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.job (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    data jsonb,
    state pgboss.job_state DEFAULT 'created'::pgboss.job_state NOT NULL,
    retry_limit integer DEFAULT 2 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    retry_delay integer DEFAULT 0 NOT NULL,
    retry_backoff boolean DEFAULT false NOT NULL,
    retry_delay_max integer,
    expire_seconds integer DEFAULT 900 NOT NULL,
    deletion_seconds integer DEFAULT 604800 NOT NULL,
    singleton_key text,
    singleton_on timestamp without time zone,
    group_id text,
    group_tier text,
    start_after timestamp with time zone DEFAULT now() NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    started_on timestamp with time zone,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone DEFAULT (now() + '336:00:00'::interval) NOT NULL,
    output jsonb,
    dead_letter text,
    policy text,
    heartbeat_on timestamp with time zone,
    heartbeat_seconds integer,
    blocked boolean DEFAULT false NOT NULL,
    blocking boolean DEFAULT false NOT NULL,
    pending_dependencies integer DEFAULT 0 NOT NULL,
    source_name text,
    source_id uuid,
    source_created_on timestamp with time zone,
    source_retry_count integer,
    source_output jsonb,
    source_root_id uuid,
    trace_context jsonb,
    upsert_by_key boolean
)
PARTITION BY LIST (name);


--
-- Name: job_common; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.job_common (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT job_id_not_null NOT NULL,
    name text CONSTRAINT job_name_not_null NOT NULL,
    priority integer DEFAULT 0 CONSTRAINT job_priority_not_null NOT NULL,
    data jsonb,
    state pgboss.job_state DEFAULT 'created'::pgboss.job_state CONSTRAINT job_state_not_null NOT NULL,
    retry_limit integer DEFAULT 2 CONSTRAINT job_retry_limit_not_null NOT NULL,
    retry_count integer DEFAULT 0 CONSTRAINT job_retry_count_not_null NOT NULL,
    retry_delay integer DEFAULT 0 CONSTRAINT job_retry_delay_not_null NOT NULL,
    retry_backoff boolean DEFAULT false CONSTRAINT job_retry_backoff_not_null NOT NULL,
    retry_delay_max integer,
    expire_seconds integer DEFAULT 900 CONSTRAINT job_expire_seconds_not_null NOT NULL,
    deletion_seconds integer DEFAULT 604800 CONSTRAINT job_deletion_seconds_not_null NOT NULL,
    singleton_key text,
    singleton_on timestamp without time zone,
    group_id text,
    group_tier text,
    start_after timestamp with time zone DEFAULT now() CONSTRAINT job_start_after_not_null NOT NULL,
    created_on timestamp with time zone DEFAULT now() CONSTRAINT job_created_on_not_null NOT NULL,
    started_on timestamp with time zone,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone DEFAULT (now() + '336:00:00'::interval) CONSTRAINT job_keep_until_not_null NOT NULL,
    output jsonb,
    dead_letter text,
    policy text,
    heartbeat_on timestamp with time zone,
    heartbeat_seconds integer,
    blocked boolean DEFAULT false CONSTRAINT job_blocked_not_null NOT NULL,
    blocking boolean DEFAULT false CONSTRAINT job_blocking_not_null NOT NULL,
    pending_dependencies integer DEFAULT 0 CONSTRAINT job_pending_dependencies_not_null NOT NULL,
    source_name text,
    source_id uuid,
    source_created_on timestamp with time zone,
    source_retry_count integer,
    source_output jsonb,
    source_root_id uuid,
    trace_context jsonb,
    upsert_by_key boolean,
    CONSTRAINT job_key_strict_fifo_singleton_key_check CHECK ((NOT ((policy = 'key_strict_fifo'::text) AND (singleton_key IS NULL))))
);


--
-- Name: job_dependency; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.job_dependency (
    child_name text NOT NULL,
    child_id uuid NOT NULL,
    parent_name text NOT NULL,
    parent_id uuid NOT NULL
);


--
-- Name: queue; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.queue (
    name text NOT NULL,
    policy text NOT NULL,
    retry_limit integer NOT NULL,
    retry_delay integer NOT NULL,
    retry_backoff boolean NOT NULL,
    retry_delay_max integer,
    expire_seconds integer NOT NULL,
    retention_seconds integer NOT NULL,
    deletion_seconds integer NOT NULL,
    dead_letter text,
    partition boolean NOT NULL,
    table_name text NOT NULL,
    deferred_count integer DEFAULT 0 NOT NULL,
    blocked_count integer DEFAULT 0 NOT NULL,
    queued_count integer DEFAULT 0 NOT NULL,
    ready_count integer DEFAULT 0 NOT NULL,
    warning_queued integer DEFAULT 0 NOT NULL,
    active_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    total_count integer DEFAULT 0 NOT NULL,
    retained_count integer,
    retained_on timestamp with time zone,
    created_delta integer DEFAULT 0 NOT NULL,
    completed_delta integer DEFAULT 0 NOT NULL,
    failed_delta integer DEFAULT 0 NOT NULL,
    delta_on timestamp with time zone,
    delta_seconds integer,
    wait_bins integer[],
    run_bins integer[],
    ready_oldest_seconds integer,
    ready_history integer[] DEFAULT '{}'::integer[] NOT NULL,
    heartbeat_seconds integer,
    notify boolean DEFAULT false NOT NULL,
    singletons_active text[],
    monitor_claim_on timestamp with time zone,
    monitor_on timestamp with time zone,
    maintain_on timestamp with time zone,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    updated_on timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT queue_check CHECK ((dead_letter IS DISTINCT FROM name))
);


--
-- Name: queue_stats; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.queue_stats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    deferred_count integer DEFAULT 0 NOT NULL,
    queued_count integer DEFAULT 0 NOT NULL,
    ready_count integer DEFAULT 0 NOT NULL,
    active_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    total_count integer DEFAULT 0 NOT NULL,
    created_delta integer,
    completed_delta integer,
    failed_delta integer,
    delta_seconds integer,
    delta_on timestamp with time zone,
    wait_bins integer[],
    run_bins integer[],
    ready_oldest_seconds integer,
    captured_on timestamp with time zone DEFAULT now() NOT NULL
)
PARTITION BY RANGE (captured_on);


--
-- Name: queue_stats_20261112; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.queue_stats_20261112 (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT queue_stats_id_not_null NOT NULL,
    name text CONSTRAINT queue_stats_name_not_null NOT NULL,
    deferred_count integer DEFAULT 0 CONSTRAINT queue_stats_deferred_count_not_null NOT NULL,
    queued_count integer DEFAULT 0 CONSTRAINT queue_stats_queued_count_not_null NOT NULL,
    ready_count integer DEFAULT 0 CONSTRAINT queue_stats_ready_count_not_null NOT NULL,
    active_count integer DEFAULT 0 CONSTRAINT queue_stats_active_count_not_null NOT NULL,
    failed_count integer DEFAULT 0 CONSTRAINT queue_stats_failed_count_not_null NOT NULL,
    total_count integer DEFAULT 0 CONSTRAINT queue_stats_total_count_not_null NOT NULL,
    created_delta integer,
    completed_delta integer,
    failed_delta integer,
    delta_seconds integer,
    delta_on timestamp with time zone,
    wait_bins integer[],
    run_bins integer[],
    ready_oldest_seconds integer,
    captured_on timestamp with time zone DEFAULT now() CONSTRAINT queue_stats_captured_on_not_null NOT NULL
);


--
-- Name: queue_stats_20261113; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.queue_stats_20261113 (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT queue_stats_id_not_null NOT NULL,
    name text CONSTRAINT queue_stats_name_not_null NOT NULL,
    deferred_count integer DEFAULT 0 CONSTRAINT queue_stats_deferred_count_not_null NOT NULL,
    queued_count integer DEFAULT 0 CONSTRAINT queue_stats_queued_count_not_null NOT NULL,
    ready_count integer DEFAULT 0 CONSTRAINT queue_stats_ready_count_not_null NOT NULL,
    active_count integer DEFAULT 0 CONSTRAINT queue_stats_active_count_not_null NOT NULL,
    failed_count integer DEFAULT 0 CONSTRAINT queue_stats_failed_count_not_null NOT NULL,
    total_count integer DEFAULT 0 CONSTRAINT queue_stats_total_count_not_null NOT NULL,
    created_delta integer,
    completed_delta integer,
    failed_delta integer,
    delta_seconds integer,
    delta_on timestamp with time zone,
    wait_bins integer[],
    run_bins integer[],
    ready_oldest_seconds integer,
    captured_on timestamp with time zone DEFAULT now() CONSTRAINT queue_stats_captured_on_not_null NOT NULL
);


--
-- Name: schedule; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.schedule (
    name text NOT NULL,
    key text DEFAULT ''::text NOT NULL,
    kind text DEFAULT 'cron'::text NOT NULL,
    cron text NOT NULL,
    timezone text DEFAULT 'UTC'::text,
    data jsonb,
    options jsonb,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    updated_on timestamp with time zone DEFAULT now() NOT NULL,
    last_job_id uuid,
    CONSTRAINT schedule_kind_check CHECK ((kind = ANY (ARRAY['cron'::text, 'rrule'::text])))
);


--
-- Name: subscription; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.subscription (
    event text NOT NULL,
    name text NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    updated_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: version; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.version (
    version integer NOT NULL,
    cron_on timestamp with time zone,
    bam_on timestamp with time zone,
    flow_on timestamp with time zone,
    reindex_on timestamp with time zone,
    monitor_backoff_on timestamp with time zone
);


--
-- Name: warning; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.warning (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    type text NOT NULL,
    message text NOT NULL,
    data jsonb,
    created_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_chat_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_chat_messages (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    owner_user_id text NOT NULL,
    run_id uuid,
    key text NOT NULL,
    body text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    schedule jsonb,
    CONSTRAINT agent_chat_messages_body_check CHECK (((char_length(btrim(body)) >= 1) AND (char_length(btrim(body)) <= 100000))),
    CONSTRAINT agent_chat_messages_key_check CHECK (((char_length(key) >= 1) AND (char_length(key) <= 200)))
);


--
-- Name: agent_chat_reads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_chat_reads (
    agent_id uuid NOT NULL,
    read_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_command_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_command_receipts (
    connection_id uuid NOT NULL,
    client_command_id uuid NOT NULL,
    runtime_session_id uuid NOT NULL,
    binding_id uuid NOT NULL,
    binding_generation integer NOT NULL,
    fingerprint text NOT NULL,
    operation text NOT NULL,
    project_id uuid NOT NULL,
    value jsonb NOT NULL,
    postconditions jsonb NOT NULL,
    completed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_command_receipts_binding_generation_check CHECK ((binding_generation > 0)),
    CONSTRAINT agent_command_receipts_fingerprint_check CHECK ((length(fingerprint) = 64)),
    CONSTRAINT agent_command_receipts_postconditions_check CHECK ((jsonb_typeof(postconditions) = 'array'::text))
);


--
-- Name: agent_connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_connections (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    owner_user_id text NOT NULL,
    agent_id uuid NOT NULL,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name text DEFAULT 'External connection'::text NOT NULL,
    client_designation text DEFAULT 'other'::text NOT NULL,
    compute_source text DEFAULT 'user_operated_external_client'::text NOT NULL,
    may_do text DEFAULT 'act'::text NOT NULL,
    CONSTRAINT agent_connections_client_designation_check CHECK ((client_designation = ANY (ARRAY['claude_code'::text, 'codex'::text, 'other'::text]))),
    CONSTRAINT agent_connections_compute_source_check CHECK ((compute_source = ANY (ARRAY['user_operated_claude_code'::text, 'user_operated_external_client'::text, 'owner_assistant'::text]))),
    CONSTRAINT agent_connections_may_do_check CHECK ((may_do = ANY (ARRAY['read'::text, 'act'::text, 'ask'::text]))),
    CONSTRAINT agent_connections_name_check CHECK (((length(btrim(name)) >= 1) AND (length(btrim(name)) <= 120)))
);


--
-- Name: agent_memory_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_memory_items (
    id uuid NOT NULL,
    agent_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    owner_user_id text NOT NULL,
    body text NOT NULL,
    source text DEFAULT 'Added by you'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_memory_items_body_check CHECK (((char_length(body) >= 1) AND (char_length(body) <= 500))),
    CONSTRAINT agent_memory_items_source_check CHECK (((char_length(source) >= 1) AND (char_length(source) <= 160)))
);


--
-- Name: agent_oauth_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_oauth_bindings (
    id uuid NOT NULL,
    owner_user_id text NOT NULL,
    connection_id uuid NOT NULL,
    client_id text NOT NULL,
    generation integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    auth_method text,
    auth_idp_sid text,
    auth_confirmed_at timestamp with time zone,
    CONSTRAINT agent_oauth_bindings_auth_idp_sid_check CHECK (((auth_idp_sid IS NULL) OR ((length(auth_idp_sid) >= 1) AND (length(auth_idp_sid) <= 512)))),
    CONSTRAINT agent_oauth_bindings_auth_method_check CHECK (((auth_method IS NULL) OR ((length(auth_method) >= 1) AND (length(auth_method) <= 200)))),
    CONSTRAINT agent_oauth_bindings_generation_check CHECK ((generation > 0))
);


--
-- Name: agent_playbook_acknowledgments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_playbook_acknowledgments (
    runtime_session_id uuid NOT NULL,
    bundle_id text NOT NULL,
    version text NOT NULL,
    digest text NOT NULL,
    acknowledged_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_playbook_acknowledgments_bundle_id_check CHECK ((bundle_id ~ '^[a-z][a-z0-9.-]{0,63}$'::text)),
    CONSTRAINT agent_playbook_acknowledgments_digest_check CHECK ((digest ~ '^sha256:[0-9a-f]{64}$'::text)),
    CONSTRAINT agent_playbook_acknowledgments_version_check CHECK ((version ~ '^[0-9]{1,4}\.[0-9]{1,4}\.[0-9]{1,4}$'::text))
);


--
-- Name: agent_proposals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_proposals (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    owner_user_id text NOT NULL,
    compute_source text NOT NULL,
    source_material_id uuid NOT NULL,
    source_material_version integer NOT NULL,
    client_command_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    fact text NOT NULL,
    interpretation text NOT NULL,
    suggested_action text NOT NULL,
    status text DEFAULT 'proposed'::text NOT NULL,
    dismissed_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_proposals_compute_source_check CHECK ((compute_source = ANY (ARRAY['user_operated_claude_code'::text, 'user_operated_external_client'::text, 'owner_assistant'::text]))),
    CONSTRAINT agent_proposals_fact_check CHECK (((length(btrim(fact)) >= 1) AND (length(btrim(fact)) <= 10000))),
    CONSTRAINT agent_proposals_interpretation_check CHECK (((length(btrim(interpretation)) >= 1) AND (length(btrim(interpretation)) <= 10000))),
    CONSTRAINT agent_proposals_source_material_version_check CHECK ((source_material_version > 0)),
    CONSTRAINT agent_proposals_status_check CHECK ((status = ANY (ARRAY['proposed'::text, 'dismissed'::text]))),
    CONSTRAINT agent_proposals_suggested_action_check CHECK (((length(btrim(suggested_action)) >= 1) AND (length(btrim(suggested_action)) <= 10000)))
);


--
-- Name: agent_questions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_questions (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    conversation_id uuid NOT NULL,
    message_id uuid NOT NULL,
    task_id uuid,
    agent_id uuid NOT NULL,
    asked_user_id text NOT NULL,
    question text NOT NULL,
    options jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    answered_option integer,
    answer_text text,
    answered_by text,
    answer_message_id uuid,
    answered_at timestamp with time zone,
    CONSTRAINT agent_questions_answer_text_check CHECK (((char_length(answer_text) >= 1) AND (char_length(answer_text) <= 2000))),
    CONSTRAINT agent_questions_answered_option_check CHECK (((answered_option >= 0) AND (answered_option <= 3))),
    CONSTRAINT agent_questions_check CHECK (((answered_at IS NULL) = (answer_text IS NULL))),
    CONSTRAINT agent_questions_check1 CHECK (((answered_option IS NULL) OR (answered_at IS NOT NULL))),
    CONSTRAINT agent_questions_options_check CHECK (((jsonb_typeof(options) = 'array'::text) AND ((jsonb_array_length(options) >= 2) AND (jsonb_array_length(options) <= 4)))),
    CONSTRAINT agent_questions_question_check CHECK (((char_length(question) >= 1) AND (char_length(question) <= 2000)))
);


--
-- Name: agent_runtime_auth_admission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_auth_admission (
    singleton boolean DEFAULT true NOT NULL,
    blocked boolean DEFAULT false NOT NULL,
    purge_id uuid,
    changed_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT agent_runtime_auth_admission_check CHECK ((blocked = (purge_id IS NOT NULL))),
    CONSTRAINT agent_runtime_auth_admission_singleton_check CHECK (singleton)
);


--
-- Name: agent_runtime_auth_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_auth_operations (
    binding_id uuid NOT NULL,
    client text NOT NULL,
    owner_user_id text NOT NULL,
    operation_id uuid NOT NULL,
    revision integer NOT NULL,
    boot_id uuid NOT NULL,
    actor_digest text NOT NULL,
    kind text NOT NULL,
    phase text NOT NULL,
    claimed_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    lease_ends_at timestamp with time zone NOT NULL,
    hard_ends_at timestamp with time zone NOT NULL,
    settled_at timestamp with time zone,
    CONSTRAINT agent_runtime_auth_operations_actor_digest_check CHECK ((actor_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT agent_runtime_auth_operations_check CHECK (((claimed_at < lease_ends_at) AND (lease_ends_at <= hard_ends_at))),
    CONSTRAINT agent_runtime_auth_operations_check1 CHECK (((phase = 'settled'::text) = (settled_at IS NOT NULL))),
    CONSTRAINT agent_runtime_auth_operations_client_check CHECK ((client = ANY (ARRAY['claude_code'::text, 'codex'::text]))),
    CONSTRAINT agent_runtime_auth_operations_kind_check CHECK ((kind = ANY (ARRAY['check'::text, 'logout'::text, 'console'::text]))),
    CONSTRAINT agent_runtime_auth_operations_operation_id_check CHECK (((operation_id)::text ~ '^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'::text)),
    CONSTRAINT agent_runtime_auth_operations_phase_check CHECK ((phase = ANY (ARRAY['active'::text, 'settled'::text, 'uncertain'::text]))),
    CONSTRAINT agent_runtime_auth_operations_revision_check CHECK ((revision > 0))
);


--
-- Name: agent_runtime_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_bindings (
    id uuid NOT NULL,
    owner_user_id text NOT NULL,
    slot text NOT NULL,
    state text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone,
    release_reason text,
    release_requested_at timestamp with time zone,
    released_at timestamp with time zone,
    release_logout_failed boolean,
    CONSTRAINT agent_runtime_bindings_id_check CHECK (((id)::text ~ '^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'::text)),
    CONSTRAINT agent_runtime_bindings_release_check CHECK ((((state = ANY (ARRAY['releasing'::text, 'released'::text])) = (release_reason IS NOT NULL)) AND ((release_reason IS NULL) = (release_requested_at IS NULL)) AND ((state = 'released'::text) = (released_at IS NOT NULL)) AND ((state = 'released'::text) OR (release_logout_failed IS NULL)))),
    CONSTRAINT agent_runtime_bindings_release_reason_check CHECK ((release_reason = ANY (ARRAY['owner'::text, 'operator'::text, 'idle'::text, 'purge'::text, 'bind_failed'::text, 'auth_recovery'::text]))),
    CONSTRAINT agent_runtime_bindings_state_check CHECK ((state = ANY (ARRAY['binding'::text, 'active'::text, 'sign_in_again'::text, 'releasing'::text, 'released'::text])))
);


--
-- Name: agent_runtime_client_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_client_history (
    binding_id uuid NOT NULL,
    client text NOT NULL,
    first_login_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    login_possible boolean DEFAULT true NOT NULL,
    changed_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT agent_runtime_client_history_client_check CHECK ((client = ANY (ARRAY['claude_code'::text, 'codex'::text])))
);


--
-- Name: agent_runtime_connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_connections (
    id uuid NOT NULL,
    owner_user_id text NOT NULL,
    binding_id uuid NOT NULL,
    transport text DEFAULT 'runtime'::text NOT NULL,
    client text NOT NULL,
    state text NOT NULL,
    sign_in_method text,
    auth_method text,
    plan_label text,
    account_label text,
    signed_in_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    account_fingerprint text,
    previous_account_label text,
    account_changed_at timestamp with time zone,
    signed_out_at timestamp with time zone,
    sign_out_failed boolean,
    usage_left_percent smallint,
    usage_window text,
    usage_resets_at timestamp with time zone,
    usage_limit_reached boolean DEFAULT false NOT NULL,
    usage_read_at timestamp with time zone,
    CONSTRAINT agent_runtime_connections_account_label_check CHECK ((account_label ~ '^[A-Za-z0-9*]\*\*\*@[A-Za-z0-9.*-]{1,70}$'::text)),
    CONSTRAINT agent_runtime_connections_auth_method_check CHECK ((auth_method ~ '^[a-z][a-z0-9_.-]{0,31}$'::text)),
    CONSTRAINT agent_runtime_connections_client_check CHECK ((client = ANY (ARRAY['claude_code'::text, 'codex'::text]))),
    CONSTRAINT agent_runtime_connections_codex_method_check CHECK (((client <> 'codex'::text) OR (sign_in_method IS NULL) OR (sign_in_method = ANY (ARRAY['device_code'::text, 'api_key'::text, 'access_token'::text])))),
    CONSTRAINT agent_runtime_connections_fingerprint_check CHECK ((account_fingerprint ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT agent_runtime_connections_method_check CHECK (((client <> 'claude_code'::text) OR (sign_in_method IS NULL) OR (sign_in_method = ANY (ARRAY['claude_account'::text, 'console'::text, 'sso'::text])))),
    CONSTRAINT agent_runtime_connections_notice_check CHECK (((account_changed_at IS NOT NULL) OR (previous_account_label IS NULL))),
    CONSTRAINT agent_runtime_connections_plan_label_check CHECK (((length(plan_label) <= 40) AND (plan_label ~ '^[A-Za-z0-9][A-Za-z0-9 ._+-]*$'::text))),
    CONSTRAINT agent_runtime_connections_previous_label_check CHECK ((previous_account_label ~ '^[A-Za-z0-9*]\*\*\*@[A-Za-z0-9.*-]{1,70}$'::text)),
    CONSTRAINT agent_runtime_connections_revoked_check CHECK (((revoked_at IS NULL) OR (state <> 'signed_in'::text))),
    CONSTRAINT agent_runtime_connections_sign_in_method_check CHECK ((sign_in_method = ANY (ARRAY['claude_account'::text, 'console'::text, 'sso'::text, 'device_code'::text, 'api_key'::text, 'access_token'::text]))),
    CONSTRAINT agent_runtime_connections_sign_out_check CHECK (((signed_out_at IS NULL) = (sign_out_failed IS NULL))),
    CONSTRAINT agent_runtime_connections_signed_in_check CHECK (((state = 'signed_in'::text) = (signed_in_at IS NOT NULL))),
    CONSTRAINT agent_runtime_connections_state_check CHECK ((state = ANY (ARRAY['signed_out'::text, 'signed_in'::text, 'sign_in_again'::text]))),
    CONSTRAINT agent_runtime_connections_transport_check CHECK ((transport = 'runtime'::text)),
    CONSTRAINT agent_runtime_connections_usage_left_percent_check CHECK (((usage_left_percent >= 0) AND (usage_left_percent <= 100))),
    CONSTRAINT agent_runtime_connections_usage_window_check CHECK ((usage_window = ANY (ARRAY['five_hour'::text, 'weekly'::text])))
);


--
-- Name: agent_runtime_console_nonces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_console_nonces (
    nonce_digest text NOT NULL,
    owner_user_id text NOT NULL,
    actor_digest text NOT NULL,
    operation_id uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT agent_runtime_console_nonces_actor_digest_check CHECK ((actor_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT agent_runtime_console_nonces_check CHECK ((consumed_at < expires_at)),
    CONSTRAINT agent_runtime_console_nonces_nonce_digest_check CHECK ((nonce_digest ~ '^[0-9a-f]{64}$'::text))
);


--
-- Name: agent_runtime_operator_statements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_operator_statements (
    statement text NOT NULL,
    agreed_on date NOT NULL,
    recorded_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_runtime_operator_statements_agreed_on_check CHECK ((agreed_on >= '2023-01-01'::date)),
    CONSTRAINT agent_runtime_operator_statements_statement_check CHECK ((statement = 'anthropic_commercial_terms'::text))
);


--
-- Name: agent_runtime_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_sessions (
    id uuid NOT NULL,
    binding_id uuid NOT NULL,
    binding_generation integer NOT NULL,
    client_session_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    connection_id uuid NOT NULL,
    owner_user_id text NOT NULL,
    agent_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT agent_runtime_sessions_binding_generation_check CHECK ((binding_generation > 0))
);


--
-- Name: agent_runtime_slots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_slots (
    slot text NOT NULL,
    state text NOT NULL,
    boot_id uuid,
    out_of_pool_reason text,
    reported_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    capacity smallint,
    CONSTRAINT agent_runtime_slots_capacity_check CHECK (((capacity IS NULL) OR (capacity >= 1))),
    CONSTRAINT agent_runtime_slots_out_of_pool_check CHECK (((state = 'out_of_pool'::text) = (out_of_pool_reason IS NOT NULL))),
    CONSTRAINT agent_runtime_slots_out_of_pool_reason_check CHECK ((out_of_pool_reason = ANY (ARRAY['data_not_empty'::text, 'missing'::text]))),
    CONSTRAINT agent_runtime_slots_slot_check CHECK ((slot ~ '^runtime-[1-9][0-9]{0,2}$'::text)),
    CONSTRAINT agent_runtime_slots_state_check CHECK ((state = ANY (ARRAY['unknown'::text, 'ready'::text, 'out_of_pool'::text])))
);


--
-- Name: agent_stops; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_stops (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    task_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    stopped_by text NOT NULL,
    units_stopped integer NOT NULL,
    stopped_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_stops_units_stopped_check CHECK ((units_stopped >= 0))
);


--
-- Name: agent_task_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_task_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    kind text NOT NULL,
    work_id uuid NOT NULL,
    run_id uuid,
    owner_user_id text,
    owner_agent_id uuid,
    by_kind text,
    by_id text,
    attempts smallint DEFAULT 0 NOT NULL,
    next_try_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    handled_at timestamp with time zone,
    CONSTRAINT agent_task_events_kind_check CHECK ((kind = ANY (ARRAY['assigned'::text, 'started'::text, 'finished'::text, 'released'::text]))),
    CONSTRAINT agent_task_events_owner_check CHECK ((num_nonnulls(owner_user_id, owner_agent_id) <= 1)),
    CONSTRAINT agent_task_events_shape_check CHECK (((kind = ANY (ARRAY['started'::text, 'finished'::text])) = (run_id IS NOT NULL)))
);


--
-- Name: agent_task_taking; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_task_taking (
    owner_user_id text NOT NULL,
    agent_id uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_thread_guard_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agent_thread_guard_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agents (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    name text NOT NULL,
    owner_user_id text NOT NULL,
    created_by text NOT NULL,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agents_name_check CHECK (((length(btrim(name)) >= 1) AND (length(btrim(name)) <= 200)))
);


--
-- Name: assistant_background_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assistant_background_notes (
    owner_user_id text NOT NULL,
    account_key text NOT NULL,
    note_version text NOT NULL,
    accepted_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT assistant_background_notes_account_key_check CHECK (((char_length(account_key) >= 1) AND (char_length(account_key) <= 100))),
    CONSTRAINT assistant_background_notes_note_version_check CHECK (((char_length(note_version) >= 1) AND (char_length(note_version) <= 64)))
);


--
-- Name: assistant_changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assistant_changes (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    run_id uuid,
    owner_user_id text NOT NULL,
    agent_id uuid NOT NULL,
    client_command_id uuid NOT NULL,
    fingerprint text NOT NULL,
    tool text NOT NULL,
    operation text NOT NULL,
    object_type text NOT NULL,
    object_id uuid,
    object_title text DEFAULT ''::text NOT NULL,
    state text NOT NULL,
    wait_reason text,
    authority text,
    prepared_command jsonb,
    before_version integer,
    after_version integer,
    receipt jsonb,
    refusal text,
    other_user_id text,
    decided_by text,
    decided_at timestamp with time zone,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    connection_id uuid,
    conversation_id uuid,
    told_user_id text,
    scope_id uuid,
    CONSTRAINT assistant_changes_after_version_check CHECK ((after_version > 0)),
    CONSTRAINT assistant_changes_after_wait_check CHECK (((state <> 'applied_after_wait'::text) OR (authority = 'owner_approval'::text))),
    CONSTRAINT assistant_changes_applied_authority_check CHECK (((state <> 'applied'::text) OR (authority = 'owner_request'::text))),
    CONSTRAINT assistant_changes_applied_check CHECK (((state <> ALL (ARRAY['applied'::text, 'applied_after_wait'::text, 'undone'::text])) OR ((authority IS NOT NULL) AND (receipt IS NOT NULL)))),
    CONSTRAINT assistant_changes_authority_check CHECK ((authority = ANY (ARRAY['owner_request'::text, 'owner_approval'::text]))),
    CONSTRAINT assistant_changes_before_version_check CHECK ((before_version > 0)),
    CONSTRAINT assistant_changes_decided_check CHECK (((decided_at IS NULL) = (decided_by IS NULL))),
    CONSTRAINT assistant_changes_fingerprint_check CHECK ((fingerprint ~ '^[a-f0-9]{64}$'::text)),
    CONSTRAINT assistant_changes_object_title_check CHECK ((char_length(object_title) <= 300)),
    CONSTRAINT assistant_changes_object_type_check CHECK ((object_type = ANY (ARRAY['work'::text, 'doc'::text, 'map'::text, 'thought'::text, 'link'::text, 'message'::text, 'decision'::text]))),
    CONSTRAINT assistant_changes_operation_check CHECK (((char_length(operation) >= 1) AND (char_length(operation) <= 60))),
    CONSTRAINT assistant_changes_prepared_check CHECK (((state <> 'waiting'::text) OR (prepared_command IS NOT NULL))),
    CONSTRAINT assistant_changes_prepared_command_check CHECK (((prepared_command IS NULL) OR ((jsonb_typeof(prepared_command) = 'object'::text) AND (octet_length((prepared_command)::text) <= 65536)))),
    CONSTRAINT assistant_changes_receipt_check CHECK (((receipt IS NULL) OR ((jsonb_typeof(receipt) = 'object'::text) AND (octet_length((receipt)::text) <= 65536)))),
    CONSTRAINT assistant_changes_refusal_check CHECK (((refusal IS NULL) OR (char_length(refusal) <= 500))),
    CONSTRAINT assistant_changes_source_check CHECK ((num_nonnulls(run_id, connection_id) = 1)),
    CONSTRAINT assistant_changes_state_check CHECK ((state = ANY (ARRAY['applied'::text, 'waiting'::text, 'applied_after_wait'::text, 'skipped'::text, 'undone'::text, 'refused'::text]))),
    CONSTRAINT assistant_changes_tool_check CHECK ((tool ~ '^flux_[a-z_]{1,60}$'::text)),
    CONSTRAINT assistant_changes_version_check CHECK ((version > 0)),
    CONSTRAINT assistant_changes_wait_reason_check CHECK ((wait_reason = ANY (ARRAY['ask'::text, 'removal'::text, 'others'::text, 'tells'::text]))),
    CONSTRAINT assistant_changes_waiting_check CHECK (((state = 'waiting'::text) = (wait_reason IS NOT NULL)))
);


--
-- Name: assistant_job_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assistant_job_runs (
    id uuid NOT NULL,
    job_id uuid NOT NULL,
    owner_user_id text NOT NULL,
    fired_at timestamp with time zone NOT NULL,
    fired_by text NOT NULL,
    run_id uuid,
    state text NOT NULL,
    result_line text DEFAULT ''::text NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    CONSTRAINT assistant_job_runs_finished_check CHECK (((state = 'running'::text) = (finished_at IS NULL))),
    CONSTRAINT assistant_job_runs_fired_by_check CHECK ((fired_by = ANY (ARRAY['schedule'::text, 'now'::text]))),
    CONSTRAINT assistant_job_runs_result_line_check CHECK ((char_length(result_line) <= 300)),
    CONSTRAINT assistant_job_runs_state_check CHECK ((state = ANY (ARRAY['running'::text, 'done'::text, 'skipped'::text, 'failed'::text])))
);


--
-- Name: assistant_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assistant_jobs (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    owner_user_id text NOT NULL,
    title text NOT NULL,
    text text NOT NULL,
    schedule_kind text NOT NULL,
    schedule jsonb NOT NULL,
    time_zone text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    prepared boolean DEFAULT false NOT NULL,
    prepared_run_id uuid,
    next_run_at timestamp with time zone,
    last_run_at timestamp with time zone,
    deleted_at timestamp with time zone,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    agent_id uuid NOT NULL,
    CONSTRAINT assistant_jobs_due_check CHECK (((next_run_at IS NULL) OR enabled)),
    CONSTRAINT assistant_jobs_schedule_check CHECK (((jsonb_typeof(schedule) = 'object'::text) AND (octet_length((schedule)::text) <= 1000))),
    CONSTRAINT assistant_jobs_schedule_kind_check CHECK ((schedule_kind = ANY (ARRAY['daily'::text, 'weekdays'::text, 'weekly'::text, 'hourly'::text, 'cron'::text, 'once'::text]))),
    CONSTRAINT assistant_jobs_text_check CHECK (((char_length(text) >= 1) AND (char_length(text) <= 4000))),
    CONSTRAINT assistant_jobs_time_zone_check CHECK (((char_length(time_zone) >= 1) AND (char_length(time_zone) <= 64))),
    CONSTRAINT assistant_jobs_title_check CHECK (((char_length(title) >= 1) AND (char_length(title) <= 60))),
    CONSTRAINT assistant_jobs_version_check CHECK ((version > 0))
);


--
-- Name: assistant_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assistant_settings (
    workspace_id uuid NOT NULL,
    owner_user_id text NOT NULL,
    agent_id uuid NOT NULL,
    connection_id uuid NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    instructions text DEFAULT ''::text NOT NULL,
    colour text DEFAULT 'ink'::text NOT NULL,
    engine text NOT NULL,
    api_key_id uuid,
    provider text NOT NULL,
    model text,
    CONSTRAINT assistant_settings_colour_check CHECK ((colour = ANY (ARRAY['ink'::text, 'clay'::text, 'ochre'::text, 'sage'::text, 'teal'::text, 'indigo'::text, 'plum'::text, 'rose'::text]))),
    CONSTRAINT assistant_settings_engine_check CHECK ((engine = ANY (ARRAY['server'::text, 'runtime'::text]))),
    CONSTRAINT assistant_settings_instructions_check CHECK ((char_length(instructions) <= 4000)),
    CONSTRAINT assistant_settings_key_check CHECK (((engine = 'server'::text) = (api_key_id IS NOT NULL))),
    CONSTRAINT assistant_settings_model_check CHECK (((model IS NULL) OR (model ~ '^[A-Za-z0-9][A-Za-z0-9._:/@+-]{0,199}$'::text))),
    CONSTRAINT assistant_settings_provider_check CHECK ((provider = ANY (ARRAY['anthropic'::text, 'openai'::text, 'openrouter'::text, 'gemini'::text, 'openai_compatible'::text]))),
    CONSTRAINT assistant_settings_version_check CHECK ((version > 0))
);


--
-- Name: auth_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_accounts (
    id text NOT NULL,
    user_id text NOT NULL,
    account_id text NOT NULL,
    provider_id text NOT NULL,
    access_token text,
    refresh_token text,
    id_token text,
    access_token_expires_at timestamp with time zone,
    refresh_token_expires_at timestamp with time zone,
    scope text,
    password text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    confirmed_at timestamp with time zone,
    password_version integer DEFAULT 0 NOT NULL,
    password_version_expected integer
);


--
-- Name: auth_email_claims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_email_claims (
    id text NOT NULL,
    token_hash text NOT NULL,
    provider_id text NOT NULL,
    subject text NOT NULL,
    email text NOT NULL,
    held_by text NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    claimed_at timestamp with time zone,
    released_email text,
    CONSTRAINT auth_email_claims_provider_id_check CHECK (((length(provider_id) >= 1) AND (length(provider_id) <= 200))),
    CONSTRAINT auth_email_claims_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'claimed'::text]))),
    CONSTRAINT auth_email_claims_subject_check CHECK (((length(subject) >= 1) AND (length(subject) <= 512)))
);


--
-- Name: auth_identity_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_identity_audit (
    id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    action text NOT NULL,
    user_id text NOT NULL,
    provider_id text NOT NULL,
    old_subject text,
    new_subject text,
    actor text NOT NULL,
    reason text NOT NULL,
    mode text NOT NULL,
    old_issuer text,
    new_issuer text,
    CONSTRAINT auth_identity_audit_action_check CHECK ((action = ANY (ARRAY['rekey'::text, 'unlink'::text]))),
    CONSTRAINT auth_identity_audit_actor_check CHECK (((length(actor) >= 1) AND (length(actor) <= 200))),
    CONSTRAINT auth_identity_audit_mode_check CHECK ((mode = ANY (ARRAY['prepare'::text, 'sso'::text]))),
    CONSTRAINT auth_identity_audit_new_issuer_check CHECK (((new_issuer IS NULL) OR ((length(new_issuer) >= 1) AND (length(new_issuer) <= 2000)))),
    CONSTRAINT auth_identity_audit_old_issuer_check CHECK (((old_issuer IS NULL) OR ((length(old_issuer) >= 1) AND (length(old_issuer) <= 2000)))),
    CONSTRAINT auth_identity_audit_provider_id_check CHECK (((length(provider_id) >= 1) AND (length(provider_id) <= 200))),
    CONSTRAINT auth_identity_audit_reason_check CHECK (((length(reason) >= 1) AND (length(reason) <= 500)))
);


--
-- Name: auth_idp_standing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_idp_standing (
    user_id text NOT NULL,
    provider_id text NOT NULL,
    state text DEFAULT 'ok'::text NOT NULL,
    reason text,
    refresh_token_enc text,
    confirmed_at timestamp with time zone,
    state_changed_at timestamp with time zone DEFAULT now() NOT NULL,
    last_check_at timestamp with time zone,
    last_outcome text,
    next_check_at timestamp with time zone DEFAULT now() NOT NULL,
    lease_id text,
    lease_until timestamp with time zone,
    refresh_token_sid text,
    CONSTRAINT auth_idp_standing_last_outcome_check CHECK (((last_outcome IS NULL) OR (last_outcome = ANY (ARRAY['success'::text, 'sign_in_required'::text, 'unknown'::text])))),
    CONSTRAINT auth_idp_standing_provider_id_check CHECK (((length(provider_id) >= 1) AND (length(provider_id) <= 200))),
    CONSTRAINT auth_idp_standing_reason_check CHECK (((reason IS NULL) OR (length(reason) <= 100))),
    CONSTRAINT auth_idp_standing_refresh_token_enc_check CHECK (((refresh_token_enc IS NULL) OR (length(refresh_token_enc) <= 16384))),
    CONSTRAINT auth_idp_standing_refresh_token_sid_check CHECK (((refresh_token_sid IS NULL) OR ((length(refresh_token_sid) >= 1) AND (length(refresh_token_sid) <= 512)))),
    CONSTRAINT auth_idp_standing_state_check CHECK ((state = ANY (ARRAY['ok'::text, 'sign_in_required'::text])))
);


--
-- Name: auth_link_intents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_link_intents (
    id text NOT NULL,
    token_hash text NOT NULL,
    user_id text NOT NULL,
    session_id text NOT NULL,
    provider_id text NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    CONSTRAINT auth_link_intents_provider_id_check CHECK (((length(provider_id) >= 1) AND (length(provider_id) <= 200))),
    CONSTRAINT auth_link_intents_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'used'::text])))
);


--
-- Name: auth_logout_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_logout_tokens (
    provider_id text NOT NULL,
    jti text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT auth_logout_tokens_jti_check CHECK (((length(jti) >= 1) AND (length(jti) <= 512))),
    CONSTRAINT auth_logout_tokens_provider_id_check CHECK (((length(provider_id) >= 1) AND (length(provider_id) <= 200)))
);


--
-- Name: auth_rate_limits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_rate_limits (
    id text NOT NULL,
    key text NOT NULL,
    count integer NOT NULL,
    last_request bigint NOT NULL
);


--
-- Name: auth_session_identities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_session_identities (
    session_id text NOT NULL,
    method text NOT NULL,
    idp_sid text,
    confirmed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT auth_session_identities_idp_sid_check CHECK (((idp_sid IS NULL) OR ((length(idp_sid) >= 1) AND (length(idp_sid) <= 512)))),
    CONSTRAINT auth_session_identities_method_check CHECK (((length(method) >= 1) AND (length(method) <= 200)))
);


--
-- Name: auth_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_sessions (
    id text NOT NULL,
    user_id text NOT NULL,
    token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    ip_address text,
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    password_version_checked integer
);


--
-- Name: auth_sign_in_throttle; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_sign_in_throttle (
    account_hash text NOT NULL,
    failures integer NOT NULL,
    last_failure_at timestamp with time zone NOT NULL,
    locked_until timestamp with time zone
);


--
-- Name: auth_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_users (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    email_verified boolean DEFAULT false NOT NULL,
    image text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    verification_required boolean DEFAULT false NOT NULL,
    device_generation integer DEFAULT 0 NOT NULL,
    time_zone text DEFAULT 'UTC'::text NOT NULL
);


--
-- Name: auth_verifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_verifications (
    id text NOT NULL,
    identifier text NOT NULL,
    value text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: background_compute_connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.background_compute_connections (
    id uuid NOT NULL,
    owner_user_id text NOT NULL,
    provider text NOT NULL,
    model text NOT NULL,
    encrypted_key text,
    key_last_four text NOT NULL,
    key_fingerprint text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    base_url text,
    input_price_micros_per_mtok integer,
    output_price_micros_per_mtok integer,
    price_source text,
    price_checked_on date,
    name text NOT NULL,
    daily_budget_cents integer NOT NULL,
    time_zone text DEFAULT 'UTC'::text NOT NULL,
    CONSTRAINT background_compute_connectio_output_price_micros_per_mtok_check CHECK (((output_price_micros_per_mtok >= 0) AND (output_price_micros_per_mtok <= 1000000000))),
    CONSTRAINT background_compute_connection_input_price_micros_per_mtok_check CHECK (((input_price_micros_per_mtok >= 0) AND (input_price_micros_per_mtok <= 1000000000))),
    CONSTRAINT background_compute_connections_base_url_check CHECK ((((provider = 'openai_compatible'::text) = (base_url IS NOT NULL)) AND ((base_url IS NULL) OR ((length(base_url) <= 2048) AND (base_url ~ '^https?://[^[:space:]@?#]+$'::text))))),
    CONSTRAINT background_compute_connections_check1 CHECK (((encrypted_key IS NOT NULL) = (revoked_at IS NULL))),
    CONSTRAINT background_compute_connections_daily_budget_cents_check CHECK (((daily_budget_cents >= 10) AND (daily_budget_cents <= 100000))),
    CONSTRAINT background_compute_connections_key_fingerprint_check CHECK ((length(key_fingerprint) = 16)),
    CONSTRAINT background_compute_connections_key_last_four_check CHECK ((length(key_last_four) = 4)),
    CONSTRAINT background_compute_connections_model_check CHECK ((model ~ '^[A-Za-z0-9][A-Za-z0-9._:/@+-]{0,199}$'::text)),
    CONSTRAINT background_compute_connections_name_check CHECK ((((length(btrim(name)) >= 1) AND (length(btrim(name)) <= 80)) AND (name = btrim(name)))),
    CONSTRAINT background_compute_connections_price_check CHECK ((((input_price_micros_per_mtok IS NULL) = (price_source IS NULL)) AND ((output_price_micros_per_mtok IS NULL) = (price_source IS NULL)) AND ((price_checked_on IS NULL) = ((price_source IS NULL) OR (price_source = 'owner'::text))))),
    CONSTRAINT background_compute_connections_price_source_check CHECK ((price_source = ANY (ARRAY['table'::text, 'owner'::text]))),
    CONSTRAINT background_compute_connections_provider_check CHECK ((provider = ANY (ARRAY['anthropic'::text, 'openai'::text, 'openrouter'::text, 'gemini'::text, 'openai_compatible'::text]))),
    CONSTRAINT background_compute_connections_time_zone_check CHECK (((length(time_zone) >= 1) AND (length(time_zone) <= 64)))
);


--
-- Name: cowork_checkpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cowork_checkpoints (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    unit_id uuid NOT NULL,
    connection_id uuid NOT NULL,
    runtime_session_id text NOT NULL,
    generation integer NOT NULL,
    progress jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT cowork_checkpoints_generation_check CHECK ((generation > 0)),
    CONSTRAINT cowork_checkpoints_progress_check CHECK (((jsonb_typeof(progress) = 'object'::text) AND (octet_length((progress)::text) <= 16384))),
    CONSTRAINT cowork_checkpoints_runtime_session_id_check CHECK (((length(runtime_session_id) >= 1) AND (length(runtime_session_id) <= 255)))
);


--
-- Name: cowork_connection_slots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cowork_connection_slots (
    connection_id uuid NOT NULL,
    workspace_id uuid NOT NULL
);


--
-- Name: cowork_units; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cowork_units (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    work_id uuid NOT NULL,
    lineage_work_id uuid NOT NULL,
    run_id uuid NOT NULL,
    unit_key text NOT NULL,
    role text NOT NULL,
    assignment_connection_id uuid NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    generation integer DEFAULT 0 NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    lease_id uuid,
    lease_session_id text,
    lease_expires_at timestamp with time zone,
    checkpoint_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    outcome_ref jsonb,
    transferred_from_connection_id uuid,
    ai_epoch bigint NOT NULL,
    CONSTRAINT cowork_units_check CHECK ((((state = 'claimed'::text) AND (generation > 0) AND (lease_id IS NOT NULL) AND (lease_session_id IS NOT NULL) AND ((length(lease_session_id) >= 1) AND (length(lease_session_id) <= 255)) AND (lease_expires_at IS NOT NULL)) OR ((state <> 'claimed'::text) AND (lease_id IS NULL) AND (lease_session_id IS NULL) AND (lease_expires_at IS NULL)))),
    CONSTRAINT cowork_units_generation_check CHECK ((generation >= 0)),
    CONSTRAINT cowork_units_outcome_check CHECK (((outcome_ref IS NULL) OR ((state = 'completed'::text) AND (jsonb_typeof(outcome_ref) = 'object'::text) AND ((outcome_ref ->> 'type'::text) = ANY (ARRAY['message'::text, 'material'::text, 'doc'::text, 'work'::text, 'thought'::text])) AND (octet_length((outcome_ref)::text) <= 1024)))),
    CONSTRAINT cowork_units_role_check CHECK ((role = ANY (ARRAY['execute'::text, 'review'::text, 'plan'::text]))),
    CONSTRAINT cowork_units_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'claimed'::text, 'paused'::text, 'completed'::text, 'stopped'::text]))),
    CONSTRAINT cowork_units_unit_key_check CHECK (((length(unit_key) >= 1) AND (length(unit_key) <= 200))),
    CONSTRAINT cowork_units_version_check CHECK ((version > 0))
);


--
-- Name: dm_message_observations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dm_message_observations (
    workspace_id uuid NOT NULL,
    dm_id uuid NOT NULL,
    message_id uuid NOT NULL,
    viewer_id text NOT NULL,
    observed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dm_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dm_messages (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    dm_id uuid NOT NULL,
    author_id text NOT NULL,
    client_message_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    sequence integer NOT NULL,
    body text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    thread_root_id uuid,
    via text,
    kind text DEFAULT 'text'::text NOT NULL,
    edited_at timestamp with time zone,
    removed_at timestamp with time zone,
    CONSTRAINT dm_messages_ai_used_check CHECK (((kind = 'text'::text) OR ((via IS NULL) AND (thread_root_id IS NULL)))),
    CONSTRAINT dm_messages_body_check CHECK ((public.flux_is_sealed(body) OR ((length(btrim(body)) >= 1) AND (length(btrim(body)) <= 100000)))),
    CONSTRAINT dm_messages_kind_check CHECK ((kind = ANY (ARRAY['text'::text, 'ai_used'::text]))),
    CONSTRAINT dm_messages_sequence_check CHECK ((sequence > 0)),
    CONSTRAINT dm_messages_thread_root_not_self CHECK (((thread_root_id IS NULL) OR (thread_root_id <> id))),
    CONSTRAINT dm_messages_via_check CHECK (((via IS NULL) OR ((char_length(via) >= 1) AND (char_length(via) <= 80))))
);


--
-- Name: dm_participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dm_participants (
    workspace_id uuid NOT NULL,
    dm_id uuid NOT NULL,
    user_id text NOT NULL,
    joined_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dms (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    kind text NOT NULL,
    pair_key text,
    title text,
    created_by text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    next_sequence integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_message_at timestamp with time zone,
    CONSTRAINT dms_check CHECK (((kind = 'pair'::text) = (pair_key IS NOT NULL))),
    CONSTRAINT dms_check1 CHECK (((kind = 'group'::text) OR (title IS NULL))),
    CONSTRAINT dms_kind_check CHECK ((kind = ANY (ARRAY['pair'::text, 'group'::text]))),
    CONSTRAINT dms_next_sequence_check CHECK ((next_sequence > 0)),
    CONSTRAINT dms_title_check CHECK ((public.flux_is_sealed(title) OR ((title IS NULL) OR ((length(btrim(title)) >= 1) AND (length(btrim(title)) <= 80))))),
    CONSTRAINT dms_version_check CHECK ((version >= 1))
);


--
-- Name: doc_live_archives; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_live_archives (
    doc_id uuid NOT NULL,
    generation uuid NOT NULL,
    sequence bigint NOT NULL,
    body text NOT NULL,
    hash text NOT NULL,
    saved_version integer NOT NULL,
    saved_sequence bigint NOT NULL,
    codec_state jsonb,
    retired_at timestamp with time zone DEFAULT now() NOT NULL,
    snapshot_sequence bigint,
    CONSTRAINT doc_live_archive_body CHECK ((public.flux_is_sealed(body) OR (char_length(body) <= 100000))),
    CONSTRAINT doc_live_archive_codec_bytes CHECK (((codec_state IS NULL) OR (octet_length((codec_state)::text) <= 8388608))),
    CONSTRAINT doc_live_archive_hash CHECK ((public.flux_is_sealed(hash) OR (hash ~ '^[a-f0-9]{64}$'::text))),
    CONSTRAINT doc_live_archive_sequence CHECK ((((sequence >= 0) AND (sequence <= '9007199254740991'::bigint)) AND ((saved_sequence >= 0) AND (saved_sequence <= sequence)))),
    CONSTRAINT doc_live_archive_snapshot CHECK (((snapshot_sequence IS NULL) OR ((snapshot_sequence >= 0) AND (snapshot_sequence <= sequence))))
);


--
-- Name: doc_live_heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_live_heads (
    doc_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    generation uuid NOT NULL,
    sequence bigint DEFAULT 0 NOT NULL,
    body text NOT NULL,
    hash text NOT NULL,
    saved_version integer NOT NULL,
    saved_sequence bigint DEFAULT 0 NOT NULL,
    codec_state jsonb,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    snapshot_sequence bigint DEFAULT 0 NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT doc_live_head_body CHECK ((public.flux_is_sealed(body) OR (char_length(body) <= 100000))),
    CONSTRAINT doc_live_head_codec_bytes CHECK (((codec_state IS NULL) OR (octet_length((codec_state)::text) <= 8388608))),
    CONSTRAINT doc_live_head_hash CHECK ((public.flux_is_sealed(hash) OR (hash ~ '^[a-f0-9]{64}$'::text))),
    CONSTRAINT doc_live_head_sequence CHECK ((((sequence >= 0) AND (sequence <= '9007199254740991'::bigint)) AND ((saved_sequence >= 0) AND (saved_sequence <= sequence)))),
    CONSTRAINT doc_live_head_snapshot CHECK ((((snapshot_sequence >= 0) AND (snapshot_sequence <= sequence)) AND ((revision >= 0) AND (revision <= '9007199254740991'::bigint))))
);


--
-- Name: doc_live_presence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_live_presence (
    connection_id uuid NOT NULL,
    doc_id uuid NOT NULL,
    generation uuid NOT NULL,
    actor_id text NOT NULL,
    session_id text NOT NULL,
    cursor jsonb NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    slot smallint DEFAULT 0 NOT NULL,
    CONSTRAINT doc_live_presence_cursor CHECK (((jsonb_typeof(cursor) = 'object'::text) AND (octet_length((cursor)::text) <= 4096))),
    CONSTRAINT doc_live_presence_slot_check CHECK (((slot >= 0) AND (slot < 128)))
);


--
-- Name: doc_live_replicas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_live_replicas (
    doc_id uuid NOT NULL,
    generation uuid NOT NULL,
    replica_id bigint NOT NULL,
    owner_kind text DEFAULT 'human'::text NOT NULL,
    actor_id text,
    instance_id uuid NOT NULL,
    connection_id uuid,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT doc_live_replica_id CHECK (((replica_id >= 0) AND (replica_id <= '9007199254740991'::bigint))),
    CONSTRAINT doc_live_replica_owner CHECK ((((owner_kind = 'human'::text) AND (actor_id IS NOT NULL)) OR ((owner_kind = 'server'::text) AND (actor_id IS NULL))))
);


--
-- Name: doc_live_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_live_snapshots (
    doc_id uuid NOT NULL,
    version integer NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    generation uuid NOT NULL,
    from_sequence bigint NOT NULL,
    to_sequence bigint NOT NULL,
    hash text NOT NULL,
    contributors jsonb NOT NULL,
    CONSTRAINT doc_live_snapshot_contributors CHECK (((jsonb_typeof(contributors) = 'array'::text) AND (octet_length((contributors)::text) <= 8388608))),
    CONSTRAINT doc_live_snapshot_hash CHECK ((public.flux_is_sealed(hash) OR (hash ~ '^[a-f0-9]{64}$'::text))),
    CONSTRAINT doc_live_snapshot_interval CHECK ((((from_sequence >= 0) AND (from_sequence <= to_sequence)) AND (to_sequence <= '9007199254740991'::bigint)))
);


--
-- Name: doc_live_updates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_live_updates (
    doc_id uuid NOT NULL,
    generation uuid NOT NULL,
    sequence bigint NOT NULL,
    actor_id text NOT NULL,
    command_id uuid NOT NULL,
    fingerprint text NOT NULL,
    bytes text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    ledger jsonb,
    CONSTRAINT doc_live_update_bytes CHECK ((public.flux_is_sealed(bytes) OR (octet_length(bytes) <= 11184812))),
    CONSTRAINT doc_live_update_fingerprint CHECK ((public.flux_is_sealed(fingerprint) OR (fingerprint ~ '^[a-f0-9]{64}$'::text))),
    CONSTRAINT doc_live_update_ledger CHECK (((ledger IS NULL) OR ((jsonb_typeof(ledger) = 'object'::text) AND (octet_length((ledger)::text) <= 8388608)))),
    CONSTRAINT doc_live_update_sequence CHECK (((sequence >= 1) AND (sequence <= '9007199254740991'::bigint)))
);


--
-- Name: encrypted_workspace_creations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.encrypted_workspace_creations (
    id uuid NOT NULL,
    user_id text NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: event_audience; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_audience (
    recipient text NOT NULL,
    seq bigint NOT NULL,
    event_id uuid NOT NULL
);


--
-- Name: event_data_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_data_keys (
    key text NOT NULL
);


--
-- Name: event_data_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_data_tokens (
    token text NOT NULL
);


--
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.events (
    id uuid NOT NULL,
    kind text NOT NULL,
    object_id uuid NOT NULL,
    actor_id text NOT NULL,
    data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    workspace_id uuid,
    seq bigint NOT NULL
);


--
-- Name: events_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.events_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: events_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.events_seq_seq OWNED BY public.events.seq;


--
-- Name: file_garbage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_garbage (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: flux_schema_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flux_schema_version (
    version integer NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: github_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_bindings (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    host text DEFAULT 'github.com'::text NOT NULL,
    installation_id text NOT NULL,
    repository_id text NOT NULL,
    owner text NOT NULL,
    name text NOT NULL,
    private boolean NOT NULL,
    url text NOT NULL,
    author_user_id text,
    author_github_user_id text NOT NULL,
    app_id text NOT NULL,
    authorization_generation uuid NOT NULL,
    state text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT github_bindings_host_check CHECK ((host = 'github.com'::text)),
    CONSTRAINT github_bindings_installation_id_check CHECK ((installation_id ~ '^[1-9][0-9]*$'::text)),
    CONSTRAINT github_bindings_repository_id_check CHECK ((repository_id ~ '^[1-9][0-9]*$'::text)),
    CONSTRAINT github_bindings_state_check CHECK ((state = ANY (ARRAY['active'::text, 'disconnected'::text, 'revoked'::text])))
);


--
-- Name: github_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_credentials (
    user_id text NOT NULL,
    host text DEFAULT 'github.com'::text NOT NULL,
    generation uuid NOT NULL,
    github_user_id text NOT NULL,
    app_id text NOT NULL,
    encrypted_tokens text,
    expires_at timestamp with time zone,
    refresh_expires_at timestamp with time zone,
    state text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT github_credentials_app_id_check CHECK ((app_id ~ '^[1-9][0-9]*$'::text)),
    CONSTRAINT github_credentials_github_user_id_check CHECK ((github_user_id ~ '^[1-9][0-9]*$'::text)),
    CONSTRAINT github_credentials_host_check CHECK ((host = 'github.com'::text)),
    CONSTRAINT github_credentials_state_check CHECK ((state = ANY (ARRAY['active'::text, 'refreshing'::text, 'uncertain'::text, 'revoked'::text])))
);


--
-- Name: github_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_deliveries (
    id text NOT NULL,
    app_id text NOT NULL,
    digest text NOT NULL,
    event text NOT NULL,
    payload jsonb NOT NULL,
    installation_id text,
    repository_id text,
    provider_object_id text,
    target_binding_id uuid,
    origin text NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT github_deliveries_origin_check CHECK ((origin = ANY (ARRAY['webhook'::text, 'reconcile'::text])))
);


--
-- Name: github_oauth_flows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_oauth_flows (
    state_hash text NOT NULL,
    id uuid NOT NULL,
    user_id text NOT NULL,
    session_id text NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    purpose text NOT NULL,
    encrypted_verifier text,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone,
    CONSTRAINT github_oauth_flows_purpose_check CHECK ((purpose = ANY (ARRAY['authorize'::text, 'install'::text])))
);


--
-- Name: github_processing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_processing (
    delivery_id text NOT NULL,
    binding_id uuid NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    error_code text,
    CONSTRAINT github_processing_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'completed'::text])))
);


--
-- Name: github_rule_defaults; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_rule_defaults (
    project_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    mode text,
    set_by_user_id text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT github_rule_defaults_mode_check CHECK ((mode = ANY (ARRAY['complete'::text, 'ready'::text])))
);


--
-- Name: github_task_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_task_links (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    task_id uuid NOT NULL,
    binding_id uuid NOT NULL,
    pull_id text NOT NULL,
    role text NOT NULL,
    facts jsonb NOT NULL,
    verified_at timestamp with time zone DEFAULT now() NOT NULL,
    state text DEFAULT 'current'::text NOT NULL,
    CONSTRAINT github_task_links_pull_id_check CHECK ((pull_id ~ '^[1-9][0-9]*$'::text)),
    CONSTRAINT github_task_links_role_check CHECK ((role = ANY (ARRAY['required_output'::text, 'related'::text]))),
    CONSTRAINT github_task_links_state_check CHECK ((state = ANY (ARRAY['current'::text, 'stale'::text, 'unavailable'::text])))
);


--
-- Name: github_task_rule_changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_task_rule_changes (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    task_id uuid NOT NULL,
    code text NOT NULL,
    from_status text NOT NULL,
    to_status text NOT NULL,
    blocker text,
    ready_to_close boolean NOT NULL,
    author_user_id text,
    link_id uuid,
    pull_number integer,
    head_sha text,
    check_name text,
    delivery_id text,
    binding_id uuid NOT NULL,
    origin text NOT NULL,
    task_version integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT github_task_rule_changes_check CHECK (((origin = 'binding'::text) = (delivery_id IS NULL))),
    CONSTRAINT github_task_rule_changes_check_name_check CHECK ((char_length(check_name) <= 200)),
    CONSTRAINT github_task_rule_changes_code_check CHECK ((code = ANY (ARRAY['pull_open'::text, 'pull_reopened'::text, 'check_failed'::text, 'checks_passed'::text, 'pull_closed'::text, 'merged_done'::text, 'merged_ready'::text, 'suspended_manual'::text, 'suspended_access'::text, 'suspended_repository'::text]))),
    CONSTRAINT github_task_rule_changes_from_status_check CHECK ((from_status = ANY (ARRAY['open'::text, 'in_progress'::text, 'blocked'::text, 'done'::text]))),
    CONSTRAINT github_task_rule_changes_head_sha_check CHECK ((head_sha ~ '^[a-f0-9]{40}([a-f0-9]{24})?$'::text)),
    CONSTRAINT github_task_rule_changes_origin_check CHECK ((origin = ANY (ARRAY['webhook'::text, 'reconcile'::text, 'binding'::text]))),
    CONSTRAINT github_task_rule_changes_pull_number_check CHECK ((pull_number >= 1)),
    CONSTRAINT github_task_rule_changes_task_version_check CHECK ((task_version >= 1)),
    CONSTRAINT github_task_rule_changes_to_status_check CHECK ((to_status = ANY (ARRAY['open'::text, 'in_progress'::text, 'blocked'::text, 'done'::text])))
);


--
-- Name: github_task_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_task_rules (
    task_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    mode text NOT NULL,
    state text NOT NULL,
    suspended_reason text,
    author_user_id text,
    author_github_user_id text NOT NULL,
    author_generation uuid NOT NULL,
    app_id text NOT NULL,
    expected_version integer NOT NULL,
    expected_status text NOT NULL,
    expected_blocker text,
    blocked_by text,
    ready_to_close boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    CONSTRAINT github_task_rules_app_id_check CHECK ((app_id ~ '^[1-9][0-9]*$'::text)),
    CONSTRAINT github_task_rules_author_github_user_id_check CHECK ((author_github_user_id ~ '^[1-9][0-9]*$'::text)),
    CONSTRAINT github_task_rules_blocked_by_check CHECK ((blocked_by = ANY (ARRAY['check'::text, 'closed'::text]))),
    CONSTRAINT github_task_rules_check CHECK (((state = 'suspended'::text) = (suspended_reason IS NOT NULL))),
    CONSTRAINT github_task_rules_expected_status_check CHECK ((expected_status = ANY (ARRAY['open'::text, 'in_progress'::text, 'blocked'::text, 'done'::text]))),
    CONSTRAINT github_task_rules_expected_version_check CHECK ((expected_version >= 1)),
    CONSTRAINT github_task_rules_mode_check CHECK ((mode = ANY (ARRAY['complete'::text, 'ready'::text]))),
    CONSTRAINT github_task_rules_revision_check CHECK ((revision >= 1)),
    CONSTRAINT github_task_rules_state_check CHECK ((state = ANY (ARRAY['active'::text, 'suspended'::text, 'off'::text]))),
    CONSTRAINT github_task_rules_suspended_reason_check CHECK ((suspended_reason = ANY (ARRAY['manual_change'::text, 'author_access'::text, 'repository_unavailable'::text])))
);


--
-- Name: idempotency_account_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idempotency_account_operations (
    operation text NOT NULL
);


--
-- Name: idempotency_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idempotency_keys (
    id uuid NOT NULL,
    principal text NOT NULL,
    workspace_id uuid,
    operation text NOT NULL,
    key text NOT NULL,
    request_hash text NOT NULL,
    response_status integer NOT NULL,
    response_body jsonb,
    response_etag text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT idempotency_keys_key_check CHECK (((length(key) >= 1) AND (length(key) <= 255)))
);


--
-- Name: jwks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jwks (
    id text NOT NULL,
    public_key text NOT NULL,
    private_key text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone,
    alg text,
    crv text
);


--
-- Name: live_access_fences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.live_access_fences (
    scope_key text NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT live_access_fences_check CHECK ((((project_id IS NULL) AND (scope_key = ('w:'::text || (workspace_id)::text))) OR ((project_id IS NOT NULL) AND (scope_key = ('p:'::text || (project_id)::text)))))
);


--
-- Name: live_admissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.live_admissions (
    id text NOT NULL,
    live_session_id uuid NOT NULL,
    user_id text NOT NULL,
    auth_session_id text NOT NULL,
    issued_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT live_admissions_id_check CHECK ((id ~ '^[A-Za-z0-9_-]{22}$'::text))
);


--
-- Name: live_editing_intents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.live_editing_intents (
    actor_id text NOT NULL,
    command_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    kind text NOT NULL,
    resource_id uuid NOT NULL,
    generation uuid NOT NULL,
    operation text NOT NULL,
    fingerprint text NOT NULL,
    byte_length integer NOT NULL,
    receipt jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT live_editing_intent_bytes CHECK (((byte_length >= 0) AND (byte_length <= 8388608))),
    CONSTRAINT live_editing_intent_fingerprint CHECK ((public.flux_is_sealed(fingerprint) OR (fingerprint ~ '^[a-f0-9]{64}$'::text))),
    CONSTRAINT live_editing_intent_kind CHECK ((kind = ANY (ARRAY['wiki'::text, 'map'::text]))),
    CONSTRAINT live_editing_intent_receipt CHECK (((jsonb_typeof(receipt) = 'object'::text) AND (octet_length((receipt)::text) <= 8388608)))
);


--
-- Name: live_invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.live_invitations (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    session_id uuid NOT NULL,
    inviter_id text NOT NULL,
    recipient_id text NOT NULL,
    response text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    responded_at timestamp with time zone,
    CONSTRAINT live_invitations_check CHECK ((inviter_id <> recipient_id)),
    CONSTRAINT live_invitations_check1 CHECK (((response = 'pending'::text) = (responded_at IS NULL))),
    CONSTRAINT live_invitations_response_check CHECK ((response = ANY (ARRAY['pending'::text, 'later'::text, 'text'::text])))
);


--
-- Name: live_presentations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.live_presentations (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    session_id uuid NOT NULL,
    generation integer NOT NULL,
    created_by text NOT NULL,
    client_event_id uuid NOT NULL,
    ref_type text NOT NULL,
    ref_id uuid NOT NULL,
    ref_version integer NOT NULL,
    selected_thought_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT live_presentations_check CHECK (((ref_type = 'sketch'::text) OR (cardinality(selected_thought_ids) = 0))),
    CONSTRAINT live_presentations_generation_check CHECK ((generation > 0)),
    CONSTRAINT live_presentations_ref_type_check CHECK ((ref_type = ANY (ARRAY['message'::text, 'material'::text, 'work'::text, 'sketch'::text]))),
    CONSTRAINT live_presentations_ref_version_check CHECK ((ref_version > 0)),
    CONSTRAINT live_presentations_selected_thought_ids_check CHECK ((cardinality(selected_thought_ids) <= 100))
);


--
-- Name: live_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.live_sessions (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    conversation_id uuid,
    work_id uuid,
    sketch_id uuid,
    doc_id uuid,
    created_by text NOT NULL,
    client_session_id uuid NOT NULL,
    state text DEFAULT 'available'::text NOT NULL,
    generation integer DEFAULT 1 NOT NULL,
    room_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    empty_since timestamp with time zone,
    last_grant_at timestamp with time zone,
    connected_once boolean DEFAULT false NOT NULL,
    ended_at timestamp with time zone,
    CONSTRAINT live_sessions_check CHECK ((num_nonnulls(conversation_id, work_id, sketch_id, doc_id) = 1)),
    CONSTRAINT live_sessions_generation_check CHECK ((generation > 0)),
    CONSTRAINT live_sessions_room_id_check CHECK (((length(room_id) >= 16) AND (length(room_id) <= 128))),
    CONSTRAINT live_sessions_state_check CHECK ((state = ANY (ARRAY['available'::text, 'rotating'::text, 'ending'::text, 'ended'::text])))
);


--
-- Name: live_webhook_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.live_webhook_events (
    event_id text NOT NULL,
    session_id uuid NOT NULL,
    generation integer NOT NULL,
    room_id text NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT live_webhook_events_generation_check CHECK ((generation > 0))
);


--
-- Name: map_live_gestures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.map_live_gestures (
    lease_id uuid NOT NULL,
    sketch_id uuid NOT NULL,
    generation uuid NOT NULL,
    gesture_id uuid NOT NULL,
    actor_id text NOT NULL,
    session_id text NOT NULL,
    connection_id uuid,
    sequence bigint DEFAULT 0 NOT NULL,
    thoughts jsonb NOT NULL,
    positions jsonb DEFAULT '[]'::jsonb NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT map_live_gestures_positions_check CHECK (((jsonb_typeof(positions) = 'array'::text) AND (jsonb_array_length(positions) <= 200) AND (octet_length((positions)::text) <= 65536))),
    CONSTRAINT map_live_gestures_sequence_check CHECK (((sequence >= 0) AND (sequence <= '9007199254740991'::bigint))),
    CONSTRAINT map_live_gestures_thoughts_check CHECK (((jsonb_typeof(thoughts) = 'array'::text) AND ((jsonb_array_length(thoughts) >= 1) AND (jsonb_array_length(thoughts) <= 200)) AND (octet_length((thoughts)::text) <= 65536)))
);


--
-- Name: map_live_heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.map_live_heads (
    sketch_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    generation uuid NOT NULL,
    sequence bigint DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT map_live_heads_sequence_check CHECK (((sequence >= 0) AND (sequence <= '9007199254740991'::bigint)))
);


--
-- Name: map_live_journal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.map_live_journal (
    sketch_id uuid NOT NULL,
    generation uuid NOT NULL,
    sequence bigint NOT NULL,
    actor_kind text NOT NULL,
    actor_id text NOT NULL,
    command_id uuid NOT NULL,
    fingerprint text NOT NULL,
    change jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT map_live_journal_actor_kind_check CHECK ((actor_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT map_live_journal_change_check CHECK (((jsonb_typeof(change) = 'object'::text) AND (octet_length((change)::text) <= 8388608))),
    CONSTRAINT map_live_journal_fingerprint_check CHECK ((public.flux_is_sealed(fingerprint) OR (fingerprint ~ '^[a-f0-9]{64}$'::text))),
    CONSTRAINT map_live_journal_sequence_check CHECK (((sequence >= 1) AND (sequence <= '9007199254740991'::bigint)))
);


--
-- Name: map_live_object_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.map_live_object_versions (
    kind text NOT NULL,
    object_id uuid NOT NULL,
    sketch_id uuid NOT NULL,
    version bigint NOT NULL,
    CONSTRAINT map_live_object_versions_kind_check CHECK ((kind = ANY (ARRAY['thought'::text, 'link'::text]))),
    CONSTRAINT map_live_object_versions_version_check CHECK (((version >= 1) AND (version <= '9007199254740991'::bigint)))
);


--
-- Name: map_live_presence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.map_live_presence (
    connection_id uuid NOT NULL,
    sketch_id uuid NOT NULL,
    generation uuid NOT NULL,
    actor_id text NOT NULL,
    session_id text NOT NULL,
    selected jsonb NOT NULL,
    cursor jsonb,
    expires_at timestamp with time zone NOT NULL,
    slot smallint DEFAULT 0 NOT NULL,
    CONSTRAINT map_live_presence_cursor_check CHECK (((cursor IS NULL) OR ((jsonb_typeof(cursor) = 'object'::text) AND (octet_length((cursor)::text) <= 256)))),
    CONSTRAINT map_live_presence_selected_check CHECK (((jsonb_typeof(selected) = 'array'::text) AND (jsonb_array_length(selected) <= 16))),
    CONSTRAINT map_live_presence_slot_check CHECK (((slot >= 0) AND (slot < 128)))
);


--
-- Name: map_live_undone; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.map_live_undone (
    sketch_id uuid NOT NULL,
    generation uuid NOT NULL,
    original_sequence bigint NOT NULL,
    inverse_sequence bigint NOT NULL
);


--
-- Name: message_references; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_references (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    project_message_id uuid,
    dm_message_id uuid,
    "position" smallint NOT NULL,
    kind text NOT NULL,
    target_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT message_references_kind CHECK ((kind = ANY (ARRAY['thought'::text, 'message'::text]))),
    CONSTRAINT message_references_one_owner CHECK ((num_nonnulls(project_message_id, dm_message_id) = 1)),
    CONSTRAINT message_references_position CHECK ((("position" >= 0) AND ("position" <= 3)))
);


--
-- Name: native_command_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.native_command_receipts (
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    actor_kind text NOT NULL,
    actor_id text NOT NULL,
    operation text NOT NULL,
    client_command_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    work_id uuid NOT NULL,
    work_version integer NOT NULL,
    message_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT native_command_receipts_actor_kind_check CHECK ((actor_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT native_command_receipts_operation_check CHECK ((operation = 'work.update'::text)),
    CONSTRAINT native_command_receipts_work_version_check CHECK (((work_version IS NULL) OR (work_version >= 1)))
);


--
-- Name: needs_you_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.needs_you_states (
    user_id text NOT NULL,
    item_key text NOT NULL,
    state text NOT NULL,
    until timestamp with time zone,
    until_work_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT needs_you_states_check CHECK (((state = 'snoozed'::text) OR ((until IS NULL) AND (until_work_id IS NULL)))),
    CONSTRAINT needs_you_states_check1 CHECK (((state <> 'snoozed'::text) OR ((until IS NOT NULL) <> (until_work_id IS NOT NULL)))),
    CONSTRAINT needs_you_states_item_key_check CHECK (((char_length(item_key) >= 1) AND (char_length(item_key) <= 100))),
    CONSTRAINT needs_you_states_state_check CHECK ((state = ANY (ARRAY['done'::text, 'declined'::text, 'snoozed'::text])))
);


--
-- Name: notification_address_sends; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_address_sends (
    address_hash text NOT NULL,
    window_start timestamp with time zone NOT NULL,
    sent integer NOT NULL,
    last_sent_at timestamp with time zone NOT NULL
);


--
-- Name: notification_address_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_address_tokens (
    token_hash text NOT NULL,
    address_id uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notification_addresses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_addresses (
    id uuid NOT NULL,
    user_id text NOT NULL,
    email text NOT NULL,
    verified_at timestamp with time zone,
    last_sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    CONSTRAINT notification_addresses_email_check CHECK (((length(email) >= 3) AND (length(email) <= 254)))
);


--
-- Name: notification_cursor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_cursor (
    id text NOT NULL,
    seq bigint NOT NULL,
    CONSTRAINT notification_cursor_seq_check CHECK ((seq >= 0))
);


--
-- Name: notification_emails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_emails (
    id uuid NOT NULL,
    notification_id uuid NOT NULL,
    user_id text NOT NULL,
    address_kind text NOT NULL,
    address text,
    status text DEFAULT 'queued'::text NOT NULL,
    skip_reason text,
    attempts integer DEFAULT 0 NOT NULL,
    unsubscribe_hash text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    sent_at timestamp with time zone,
    last_error text,
    last_error_at timestamp with time zone,
    address_id uuid,
    CONSTRAINT notification_emails_address_kind_check CHECK ((address_kind = ANY (ARRAY['account'::text, 'extra'::text]))),
    CONSTRAINT notification_emails_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'sending'::text, 'sent'::text, 'skipped'::text])))
);


--
-- Name: notification_generation_failures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_generation_failures (
    event_id uuid NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    dead_at timestamp with time zone
);


--
-- Name: notification_mutes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_mutes (
    user_id text NOT NULL,
    source_type text NOT NULL,
    source_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT notification_mutes_source_type_check CHECK ((source_type = ANY (ARRAY['project'::text, 'dm'::text])))
);


--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_preferences (
    user_id text NOT NULL,
    quiet_enabled boolean DEFAULT false NOT NULL,
    quiet_start smallint DEFAULT 1320 NOT NULL,
    quiet_end smallint DEFAULT 420 NOT NULL,
    time_zone text DEFAULT 'UTC'::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    level text DEFAULT 'needsYou'::text NOT NULL,
    email_me boolean DEFAULT true NOT NULL,
    account_enabled boolean DEFAULT true NOT NULL,
    CONSTRAINT notification_preferences_level_check CHECK ((level = ANY (ARRAY['needsYou'::text, 'everything'::text, 'nothing'::text]))),
    CONSTRAINT notification_preferences_quiet_end_check CHECK (((quiet_end >= 0) AND (quiet_end <= 1439))),
    CONSTRAINT notification_preferences_quiet_start_check CHECK (((quiet_start >= 0) AND (quiet_start <= 1439))),
    CONSTRAINT notification_preferences_time_zone_check CHECK (((length(time_zone) >= 1) AND (length(time_zone) <= 64)))
);


--
-- Name: notification_verification_sends; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_verification_sends (
    user_id text NOT NULL,
    window_start timestamp with time zone NOT NULL,
    sent integer NOT NULL,
    last_sent_at timestamp with time zone NOT NULL,
    CONSTRAINT notification_verification_sends_sent_check CHECK ((sent >= 0))
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    user_id text NOT NULL,
    workspace_id uuid NOT NULL,
    source_type text NOT NULL,
    source_id uuid NOT NULL,
    title text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    url text,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    reason text,
    event_id uuid,
    in_inbox boolean DEFAULT true NOT NULL,
    ai_origin boolean NOT NULL,
    CONSTRAINT notifications_reason_check CHECK ((reason = ANY (ARRAY['mention'::text, 'question'::text, 'reply'::text, 'dm'::text, 'assigned'::text, 'review'::text, 'invitation'::text, 'security'::text, 'approval'::text]))),
    CONSTRAINT notifications_source_type_check CHECK ((source_type = ANY (ARRAY['workspace'::text, 'project'::text, 'dm'::text]))),
    CONSTRAINT notifications_workspace_source_check CHECK (((source_type <> 'workspace'::text) OR (source_id = workspace_id)))
);


--
-- Name: oauth_access_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_access_token (
    id text NOT NULL,
    token text NOT NULL,
    client_id text NOT NULL,
    session_id text,
    user_id text,
    reference_id text,
    authorization_code_id text,
    resources text[],
    requested_user_info_claims text[],
    refresh_id text,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL,
    revoked timestamp with time zone,
    confirmation jsonb,
    scopes text[] NOT NULL
);


--
-- Name: oauth_client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_client (
    id text NOT NULL,
    client_id text NOT NULL,
    client_secret text,
    client_discovery_id text,
    disabled boolean DEFAULT false,
    skip_consent boolean,
    enable_end_session boolean,
    subject_type text,
    scopes text[],
    client_credentials_scopes text[] DEFAULT '{}'::text[],
    user_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name text,
    uri text,
    icon text,
    contacts text[],
    tos text,
    policy text,
    software_id text,
    software_version text,
    software_statement text,
    redirect_uris text[] NOT NULL,
    post_logout_redirect_uris text[],
    backchannel_logout_uri text,
    backchannel_logout_session_required boolean,
    token_endpoint_auth_method text,
    application_type text,
    jwks text,
    jwks_uri text,
    grant_types text[],
    response_types text[],
    require_pkce boolean,
    dpop_bound_access_tokens boolean DEFAULT false,
    reference_id text,
    metadata jsonb
);


--
-- Name: oauth_client_assertion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_client_assertion (
    id text NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: oauth_client_resource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_client_resource (
    id text NOT NULL,
    client_id text NOT NULL,
    resource_id text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone
);


--
-- Name: oauth_consent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_consent (
    id text NOT NULL,
    client_id text NOT NULL,
    user_id text,
    reference_id text,
    resources text[],
    requested_user_info_claims text[],
    scopes text[] NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: oauth_grant_authentication; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_grant_authentication (
    authorization_code_id text NOT NULL,
    user_id text NOT NULL,
    reference_id text NOT NULL,
    auth_method text NOT NULL,
    auth_idp_sid text,
    auth_confirmed_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT oauth_grant_authentication_auth_idp_sid_check CHECK (((auth_idp_sid IS NULL) OR ((length(auth_idp_sid) >= 1) AND (length(auth_idp_sid) <= 512)))),
    CONSTRAINT oauth_grant_authentication_auth_method_check CHECK (((length(auth_method) >= 1) AND (length(auth_method) <= 200)))
);


--
-- Name: oauth_refresh_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_refresh_token (
    id text NOT NULL,
    token text NOT NULL,
    client_id text NOT NULL,
    session_id text,
    user_id text NOT NULL,
    reference_id text,
    authorization_code_id text,
    resources text[],
    requested_user_info_claims text[],
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL,
    revoked timestamp with time zone,
    rotated_at timestamp with time zone,
    rotation_replay_response text,
    rotation_replay_expires_at timestamp with time zone,
    auth_time timestamp with time zone,
    confirmation jsonb,
    scopes text[] NOT NULL
);


--
-- Name: oauth_resource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_resource (
    id text NOT NULL,
    identifier text NOT NULL,
    name text NOT NULL,
    access_token_ttl integer,
    refresh_token_ttl integer,
    signing_algorithm text,
    signing_key_id text,
    allowed_scopes text[],
    custom_claims jsonb,
    dpop_bound_access_tokens_required boolean DEFAULT false,
    disabled boolean DEFAULT false,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    policy_version integer DEFAULT 1,
    metadata jsonb
);


--
-- Name: outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outbox (
    id uuid NOT NULL,
    event_id uuid NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: password_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_attempts (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    user_id text NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: personal_run_private_texts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.personal_run_private_texts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid NOT NULL,
    body text NOT NULL,
    addresses text[] DEFAULT '{}'::text[] NOT NULL,
    read_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: personal_run_web_reads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.personal_run_web_reads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid NOT NULL,
    url text NOT NULL,
    final_url text NOT NULL,
    title text,
    read_at timestamp with time zone DEFAULT now() NOT NULL,
    outcome text DEFAULT 'read'::text NOT NULL,
    writable boolean DEFAULT false NOT NULL,
    CONSTRAINT personal_run_web_reads_outcome_check CHECK ((outcome = ANY (ARRAY['asked'::text, 'read'::text, 'redirected'::text, 'blocked'::text, 'unreachable'::text, 'timeout'::text, 'status'::text, 'type'::text, 'redirects'::text, 'invalid'::text, 'empty'::text]))),
    CONSTRAINT personal_run_web_reads_title_check CHECK (((title IS NULL) OR (char_length(title) <= 300))),
    CONSTRAINT personal_run_web_reads_url_check CHECK (((char_length(url) <= 2048) AND (char_length(final_url) <= 2048)))
);


--
-- Name: personal_run_web_searches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.personal_run_web_searches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid NOT NULL,
    queries text[] DEFAULT '{}'::text[] NOT NULL,
    results text[] DEFAULT '{}'::text[] NOT NULL,
    cited text[] DEFAULT '{}'::text[] NOT NULL,
    searched_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT personal_run_web_searches_size_check CHECK (((cardinality(queries) <= 10) AND (cardinality(results) <= 100) AND (cardinality(cited) <= 100)))
);


--
-- Name: personal_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.personal_runs (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid,
    conversation_id uuid,
    owner_user_id text NOT NULL,
    agent_id uuid NOT NULL,
    connection_id uuid,
    client_run_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    kind text NOT NULL,
    prompt text NOT NULL,
    target_sketch_id uuid,
    target_thought_id uuid,
    continues_run_id uuid,
    retry_of_run_id uuid,
    status text DEFAULT 'queued'::text NOT NULL,
    stopped_at_stage text,
    stop_requested_at timestamp with time zone,
    cost_state text DEFAULT 'reserved'::text NOT NULL,
    reserved_micros integer NOT NULL,
    charged_micros integer DEFAULT 0 NOT NULL,
    input_tokens integer,
    output_tokens integer,
    model text NOT NULL,
    answer_body text,
    answer_truncated boolean DEFAULT false NOT NULL,
    answer_sources jsonb DEFAULT '[]'::jsonb NOT NULL,
    committed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    dispatched_at timestamp with time zone,
    completed_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    provider text NOT NULL,
    engine text DEFAULT 'server'::text NOT NULL,
    end_reason text,
    plan_limit_resets_at timestamp with time zone,
    stop_acknowledged_at timestamp with time zone,
    answer_redacted boolean DEFAULT false NOT NULL,
    run_token_nonce_hash text,
    run_token_jti uuid,
    run_token_expires_at timestamp with time zone,
    run_token_closed_at timestamp with time zone,
    run_tools text[] DEFAULT '{}'::text[] NOT NULL,
    mcp_result_bytes integer DEFAULT 0 NOT NULL,
    mcp_limit text,
    authority text DEFAULT 'owner_request'::text NOT NULL,
    background_label text,
    ai_epoch bigint,
    resume_at timestamp with time zone,
    reserved_at timestamp with time zone DEFAULT now() NOT NULL,
    largest_request_micros integer,
    work_id uuid,
    stop_requested_by text,
    asked_by_run_id uuid,
    exchange_turn smallint DEFAULT 0 NOT NULL,
    dm_id uuid,
    shown_at timestamp with time zone,
    dismissed_at timestamp with time zone,
    dm_thread_root_id uuid,
    CONSTRAINT personal_runs_anchor_check CHECK (((kind = ANY (ARRAY['ask'::text, 'summarize'::text, 'map_thought'::text])) OR (conversation_id IS NOT NULL) OR ((kind = 'scheduled'::text) AND (project_id IS NULL) AND (dm_id IS NULL)))),
    CONSTRAINT personal_runs_answer_body_check CHECK (((answer_body IS NULL) OR (length(answer_body) <= 100000))),
    CONSTRAINT personal_runs_authority_check CHECK ((authority = ANY (ARRAY['owner_request'::text, 'owner_schedule'::text]))),
    CONSTRAINT personal_runs_authority_label_check CHECK (((authority = 'owner_request'::text) = (background_label IS NULL))),
    CONSTRAINT personal_runs_background_label_check CHECK (((background_label IS NULL) OR ((char_length(background_label) >= 1) AND (char_length(background_label) <= 80)))),
    CONSTRAINT personal_runs_charged_micros_check CHECK ((charged_micros >= 0)),
    CONSTRAINT personal_runs_check CHECK (((target_sketch_id IS NULL) = (target_thought_id IS NULL))),
    CONSTRAINT personal_runs_check1 CHECK (((answer_body IS NULL) = (committed_at IS NULL))),
    CONSTRAINT personal_runs_cost_state_check CHECK ((cost_state = ANY (ARRAY['reserved'::text, 'released'::text, 'observed'::text, 'unknown'::text]))),
    CONSTRAINT personal_runs_dm_thread_check CHECK (((dm_thread_root_id IS NULL) OR (dm_id IS NOT NULL))),
    CONSTRAINT personal_runs_end_reason_check CHECK ((end_reason = ANY (ARRAY['sign_in_again'::text, 'plan_limit'::text, 'wall_clock'::text, 'no_event'::text, 'crashed'::text, 'answer_too_large'::text, 'mcp_results_too_large'::text, 'local_tool'::text, 'slot_busy'::text, 'unknown'::text, 'max_turns'::text, 'refused'::text, 'model_unavailable'::text, 'ai_off'::text, 'budget'::text, 'credits'::text, 'no_room'::text]))),
    CONSTRAINT personal_runs_engine_check CHECK ((engine = ANY (ARRAY['server'::text, 'runtime'::text]))),
    CONSTRAINT personal_runs_exchange_turn_check CHECK ((exchange_turn >= 0)),
    CONSTRAINT personal_runs_input_tokens_check CHECK ((input_tokens >= 0)),
    CONSTRAINT personal_runs_kind_check CHECK ((kind = ANY (ARRAY['ask'::text, 'summarize'::text, 'map_thought'::text, 'scheduled'::text, 'task'::text, 'task_answer'::text]))),
    CONSTRAINT personal_runs_largest_request_micros_check CHECK ((largest_request_micros >= 0)),
    CONSTRAINT personal_runs_mcp_limit_check CHECK ((mcp_limit = ANY (ARRAY['call'::text, 'run'::text]))),
    CONSTRAINT personal_runs_mcp_result_bytes_check CHECK ((mcp_result_bytes >= 0)),
    CONSTRAINT personal_runs_output_tokens_check CHECK ((output_tokens >= 0)),
    CONSTRAINT personal_runs_place_check CHECK ((((conversation_id IS NULL) OR (project_id IS NOT NULL)) AND ((dm_id IS NULL) OR (project_id IS NULL)) AND ((project_id IS NOT NULL) = (ai_epoch IS NOT NULL)))),
    CONSTRAINT personal_runs_plan_limit_check CHECK (((plan_limit_resets_at IS NULL) OR (end_reason = 'plan_limit'::text))),
    CONSTRAINT personal_runs_prompt_check CHECK (((length(btrim(prompt)) >= 1) AND (length(btrim(prompt)) <= 4000))),
    CONSTRAINT personal_runs_provider_check CHECK ((provider = ANY (ARRAY['anthropic'::text, 'openai'::text, 'openrouter'::text, 'gemini'::text, 'openai_compatible'::text]))),
    CONSTRAINT personal_runs_put_away_check CHECK (((shown_at IS NULL) OR (dismissed_at IS NULL))),
    CONSTRAINT personal_runs_reserved_micros_check CHECK ((reserved_micros >= 0)),
    CONSTRAINT personal_runs_resume_check CHECK (((resume_at IS NULL) OR (status = ANY (ARRAY['queued'::text, 'stopped'::text, 'paused'::text, 'revoked'::text, 'denied'::text, 'unavailable'::text])))),
    CONSTRAINT personal_runs_run_token_check CHECK (((run_token_jti IS NULL) = (run_token_expires_at IS NULL))),
    CONSTRAINT personal_runs_run_token_nonce_hash_check CHECK ((run_token_nonce_hash ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT personal_runs_run_tools_check CHECK ((cardinality(run_tools) <= 64)),
    CONSTRAINT personal_runs_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'reading'::text, 'dispatching'::text, 'completed'::text, 'truncated'::text, 'stopped'::text, 'denied'::text, 'paused'::text, 'revoked'::text, 'cap_reached'::text, 'unavailable'::text, 'input_too_large'::text, 'provider_failed'::text]))),
    CONSTRAINT personal_runs_stopped_at_stage_check CHECK ((stopped_at_stage = ANY (ARRAY['before_read'::text, 'before_dispatch'::text, 'before_commit'::text]))),
    CONSTRAINT personal_runs_task_check CHECK (((kind = ANY (ARRAY['task'::text, 'task_answer'::text])) = (work_id IS NOT NULL)))
);


--
-- Name: project_ai_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_ai_policies (
    project_id uuid NOT NULL,
    state text NOT NULL,
    epoch bigint DEFAULT 1 NOT NULL,
    changed_by text,
    changed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_ai_policies_epoch_check CHECK ((epoch >= 1)),
    CONSTRAINT project_ai_policies_state_check CHECK ((state = ANY (ARRAY['allowed'::text, 'blocked'::text])))
);


--
-- Name: project_conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_conversations (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    created_by text,
    next_sequence integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by_agent_id uuid,
    CONSTRAINT project_conversation_exact_actor CHECK ((num_nonnulls(created_by, created_by_agent_id) = 1)),
    CONSTRAINT project_conversations_next_sequence_check CHECK ((next_sequence > 0))
);


--
-- Name: project_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_decisions (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    title text NOT NULL,
    rationale text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'proposed'::text NOT NULL,
    proposed_by_kind text NOT NULL,
    proposed_by_id text NOT NULL,
    decided_by text,
    decided_at timestamp with time zone,
    supersedes_id uuid,
    superseded_by_id uuid,
    superseded_at timestamp with time zone,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_decisions_check CHECK (((status = 'proposed'::text) = (decided_by IS NULL))),
    CONSTRAINT project_decisions_check1 CHECK (((decided_by IS NULL) = (decided_at IS NULL))),
    CONSTRAINT project_decisions_check2 CHECK (((status = 'superseded'::text) = (superseded_by_id IS NOT NULL))),
    CONSTRAINT project_decisions_check3 CHECK (((superseded_by_id IS NULL) = (superseded_at IS NULL))),
    CONSTRAINT project_decisions_check4 CHECK (((supersedes_id IS NULL) OR (supersedes_id <> id))),
    CONSTRAINT project_decisions_proposed_by_kind_check CHECK ((proposed_by_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT project_decisions_rationale_check CHECK ((public.flux_is_sealed(rationale) OR (length(rationale) <= 20000))),
    CONSTRAINT project_decisions_status_check CHECK ((status = ANY (ARRAY['proposed'::text, 'accepted'::text, 'superseded'::text]))),
    CONSTRAINT project_decisions_title_check CHECK ((public.flux_is_sealed(title) OR ((length(btrim(title)) >= 1) AND (length(btrim(title)) <= 200)))),
    CONSTRAINT project_decisions_version_check CHECK ((version > 0))
);


--
-- Name: project_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_files (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    uploader_id text,
    uploader_agent_id uuid,
    upload_id uuid NOT NULL,
    replay_of uuid,
    name text NOT NULL,
    state text NOT NULL,
    reserved_bytes integer NOT NULL,
    size integer,
    sha256 text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    ready_at timestamp with time zone,
    expires_at timestamp with time zone,
    message_id uuid,
    "position" smallint,
    published_at timestamp with time zone,
    thought_id uuid,
    key_version integer,
    page_count integer,
    row_count integer,
    duration_ms integer,
    CONSTRAINT project_file_exact_uploader CHECK ((num_nonnulls(uploader_id, uploader_agent_id) = 1)),
    CONSTRAINT project_file_publication CHECK ((((message_id IS NULL) = ("position" IS NULL)) AND (num_nonnulls(message_id, thought_id) <= 1) AND ((num_nonnulls(message_id, thought_id) = 1) = (published_at IS NOT NULL)))),
    CONSTRAINT project_file_published_ready CHECK (((published_at IS NULL) OR ((state = 'ready'::text) AND (expires_at IS NULL)))),
    CONSTRAINT project_file_ready_identity CHECK (((state = 'ready'::text) = ((size IS NOT NULL) AND (sha256 IS NOT NULL) AND (ready_at IS NOT NULL)))),
    CONSTRAINT project_file_replay_receiving CHECK (((replay_of IS NULL) OR ((state = 'receiving'::text) AND (published_at IS NULL)))),
    CONSTRAINT project_file_unpublished_expires CHECK (((published_at IS NOT NULL) OR (expires_at IS NOT NULL))),
    CONSTRAINT project_files_check CHECK ((((reserved_bytes >= 0) AND (reserved_bytes <= 5242880)) AND ((reserved_bytes > 0) OR (replay_of IS NOT NULL)))),
    CONSTRAINT project_files_duration_ms_check CHECK (((duration_ms IS NULL) OR (duration_ms >= 0))),
    CONSTRAINT project_files_key_version_check CHECK (((key_version IS NULL) OR (key_version >= 1))),
    CONSTRAINT project_files_name_check CHECK ((public.flux_is_sealed(name) OR ((char_length(name) >= 1) AND (char_length(name) <= 200)))),
    CONSTRAINT project_files_page_count_check CHECK (((page_count IS NULL) OR (page_count >= 0))),
    CONSTRAINT project_files_position_check CHECK ((("position" >= 0) AND ("position" <= 9))),
    CONSTRAINT project_files_row_count_check CHECK (((row_count IS NULL) OR (row_count >= 0))),
    CONSTRAINT project_files_sha256_check CHECK ((public.flux_is_sealed(sha256) OR (sha256 ~ '^[0-9a-f]{64}$'::text))),
    CONSTRAINT project_files_size_check CHECK (((size >= 1) AND (size <= 5242880))),
    CONSTRAINT project_files_state_check CHECK ((state = ANY (ARRAY['receiving'::text, 'ready'::text])))
);


--
-- Name: project_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_grants (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    user_id text NOT NULL,
    role text NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_grants_manager_person CHECK (((role <> 'manager'::text) OR (user_id IS NOT NULL))),
    CONSTRAINT project_grants_role_check CHECK ((role = ANY (ARRAY['manager'::text, 'contributor'::text])))
);


--
-- Name: project_material_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_material_versions (
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    material_id uuid NOT NULL,
    version integer NOT NULL,
    title text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    url text,
    author_id text,
    client_mutation_id uuid,
    request_fingerprint text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    reason text DEFAULT ''::text NOT NULL,
    author_agent_id uuid,
    CONSTRAINT project_material_version_exact_actor CHECK ((num_nonnulls(author_id, author_agent_id) = 1)),
    CONSTRAINT project_material_versions_body_check CHECK ((public.flux_is_sealed(body) OR (length(body) <= 100000))),
    CONSTRAINT project_material_versions_check1 CHECK (((client_mutation_id IS NULL) = (request_fingerprint IS NULL))),
    CONSTRAINT project_material_versions_reason_check CHECK ((public.flux_is_sealed(reason) OR (length(reason) <= 500))),
    CONSTRAINT project_material_versions_title_check CHECK ((public.flux_is_sealed(title) OR ((length(btrim(title)) >= 1) AND (length(btrim(title)) <= 200)))),
    CONSTRAINT project_material_versions_version_check CHECK ((version > 0))
);


--
-- Name: project_materials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_materials (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    created_by text,
    client_mutation_id uuid,
    request_fingerprint text,
    current_version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    kind text DEFAULT 'material'::text NOT NULL,
    created_by_agent_id uuid,
    CONSTRAINT project_material_agent_doc CHECK (((created_by_agent_id IS NULL) OR (kind = 'doc'::text))),
    CONSTRAINT project_material_exact_actor CHECK ((num_nonnulls(created_by, created_by_agent_id) = 1)),
    CONSTRAINT project_materials_client_mutation_check CHECK (((kind = 'doc'::text) OR ((client_mutation_id IS NOT NULL) AND (request_fingerprint IS NOT NULL)))),
    CONSTRAINT project_materials_current_version_check CHECK ((current_version > 0)),
    CONSTRAINT project_materials_kind_check CHECK ((kind = ANY (ARRAY['material'::text, 'doc'::text])))
);


--
-- Name: project_message_observations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_message_observations (
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    message_id uuid NOT NULL,
    viewer_id text NOT NULL,
    observed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: project_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_messages (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    conversation_id uuid NOT NULL,
    author_id text,
    client_message_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    sequence integer NOT NULL,
    body text NOT NULL,
    source_material_id uuid,
    source_material_version integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    author_agent_id uuid,
    contribution_kind text DEFAULT 'text'::text NOT NULL,
    attachment_count smallint DEFAULT 0 NOT NULL,
    removed_at timestamp with time zone,
    via text,
    edited_at timestamp with time zone,
    source_deleted boolean DEFAULT false NOT NULL,
    by_flux boolean DEFAULT false NOT NULL,
    CONSTRAINT project_message_attachment_count CHECK (((attachment_count >= 0) AND (attachment_count <= 10))),
    CONSTRAINT project_message_body_or_attachments CHECK ((public.flux_is_sealed(body) OR ((length(btrim(body)) <= 100000) AND ((length(btrim(body)) >= 1) OR (attachment_count > 0))))),
    CONSTRAINT project_message_by_flux_agent CHECK (((NOT by_flux) OR (author_agent_id IS NOT NULL))),
    CONSTRAINT project_message_contribution_kind CHECK ((contribution_kind = ANY (ARRAY['text'::text, 'blocker'::text, 'handoff'::text, 'came_of_it'::text]))),
    CONSTRAINT project_message_exact_actor CHECK ((num_nonnulls(author_id, author_agent_id) = 1)),
    CONSTRAINT project_message_source_deleted CHECK (((NOT source_deleted) OR ((source_material_id IS NULL) AND (source_material_version IS NULL)))),
    CONSTRAINT project_messages_check CHECK (((source_material_id IS NULL) = (source_material_version IS NULL))),
    CONSTRAINT project_messages_sequence_check CHECK ((sequence > 0)),
    CONSTRAINT project_messages_via_check CHECK (((via IS NULL) OR ((author_id IS NOT NULL) AND ((char_length(via) >= 1) AND (char_length(via) <= 80)))))
);


--
-- Name: project_object_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_object_links (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    role text NOT NULL,
    from_type text NOT NULL,
    from_id uuid NOT NULL,
    to_type text NOT NULL,
    to_id uuid NOT NULL,
    to_version integer,
    created_by_kind text NOT NULL,
    created_by_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_object_links_check CHECK (((to_type = 'material'::text) = (to_version IS NOT NULL))),
    CONSTRAINT project_object_links_check1 CHECK ((NOT ((from_type = to_type) AND (from_id = to_id)))),
    CONSTRAINT project_object_links_created_by_kind_check CHECK ((created_by_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT project_object_links_from_type_check CHECK ((from_type = ANY (ARRAY['work'::text, 'decision'::text, 'doc'::text]))),
    CONSTRAINT project_object_links_role_check CHECK ((role = ANY (ARRAY['source'::text, 'affects'::text, 'related'::text, 'mentions'::text, 'part_of'::text]))),
    CONSTRAINT project_object_links_to_type_check CHECK ((to_type = ANY (ARRAY['message'::text, 'thought'::text, 'material'::text, 'work'::text, 'decision'::text, 'doc'::text, 'sketch'::text]))),
    CONSTRAINT project_object_links_to_version_check CHECK (((to_version IS NULL) OR (to_version > 0)))
);


--
-- Name: project_task_activity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_task_activity (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    work_id uuid NOT NULL,
    kind text NOT NULL,
    actor_kind text NOT NULL,
    actor_id text NOT NULL,
    detail jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_task_activity_actor_kind_check CHECK ((actor_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT project_task_activity_kind_check CHECK ((kind = ANY (ARRAY['status'::text, 'owner'::text, 'due'::text, 'title'::text])))
);


--
-- Name: project_task_dependencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_task_dependencies (
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    task_id uuid NOT NULL,
    prerequisite_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_task_dependency_not_self CHECK ((task_id <> prerequisite_id))
);


--
-- Name: project_task_discussions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_task_discussions (
    work_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    conversation_id uuid NOT NULL,
    root_message_id uuid NOT NULL,
    root_sequence integer DEFAULT 1 NOT NULL,
    CONSTRAINT project_task_discussions_root_sequence_check CHECK ((root_sequence = 1))
);


--
-- Name: project_task_notices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_task_notices (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    work_id uuid NOT NULL,
    kind text NOT NULL,
    created_by_kind text NOT NULL,
    created_by_id text NOT NULL,
    sources jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT project_task_notices_created_by_kind_check CHECK ((created_by_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT project_task_notices_kind_check CHECK ((kind = ANY (ARRAY['task.created'::text, 'task.creation_reverted'::text]))),
    CONSTRAINT project_task_notices_sources_check CHECK ((jsonb_typeof(sources) = 'array'::text))
);


--
-- Name: project_task_number_3af3641b26784b5094731f9dab519167; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_task_number_3af3641b26784b5094731f9dab519167
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_task_number_4ec1e811c87f4d039b19a9b1457b033d; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_task_number_4ec1e811c87f4d039b19a9b1457b033d
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_task_number_a2ac3b939f524192a6b6762a3e63aec4; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_task_number_a2ac3b939f524192a6b6762a3e63aec4
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_task_number_ceffd77004894afd8f95837ba85efb04; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_task_number_ceffd77004894afd8f95837ba85efb04
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_task_plan_intents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_task_plan_intents (
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    material_id uuid NOT NULL,
    material_version integer NOT NULL,
    intent_key text NOT NULL,
    task_id uuid NOT NULL,
    creation_fingerprint text NOT NULL,
    task_version integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_task_plan_intent_key CHECK ((((length(intent_key) >= 1) AND (length(intent_key) <= 120)) AND (intent_key = btrim(intent_key, ' 	
'::text)))),
    CONSTRAINT project_task_plan_intents_creation_fingerprint_check CHECK ((public.flux_is_sealed(creation_fingerprint) OR (creation_fingerprint ~ '^[0-9a-f]{64}$'::text))),
    CONSTRAINT project_task_plan_intents_material_version_check CHECK ((material_version > 0)),
    CONSTRAINT project_task_plan_intents_task_version_check CHECK ((task_version > 0))
);


--
-- Name: project_task_updates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_task_updates (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    work_id uuid NOT NULL,
    kind text NOT NULL,
    created_by_kind text NOT NULL,
    created_by_id text NOT NULL,
    waiting_for_user_id text,
    reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_task_updates_created_by_kind_check CHECK ((created_by_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT project_task_updates_kind_check CHECK ((kind = ANY (ARRAY['task.blocked'::text, 'task.unblocked'::text, 'task.resumed'::text])))
);


--
-- Name: project_work_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_work_items (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    title text NOT NULL,
    outcome text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    blocker text,
    owner_user_id text,
    owner_agent_id uuid,
    created_by_kind text NOT NULL,
    created_by_id text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    client_command_id uuid,
    request_fingerprint text,
    criteria jsonb DEFAULT '[]'::jsonb NOT NULL,
    creation_origin text,
    creation_baseline jsonb,
    creation_baseline_version integer,
    first_persisted_use_at timestamp with time zone,
    creation_reverted_at timestamp with time zone,
    creation_reverted_by_kind text,
    creation_reverted_by_id text,
    creation_reversion_notice_id uuid,
    number integer NOT NULL,
    waiting_for_user_id text,
    due_on date,
    waiting_for_decision_id uuid,
    waiting_for_work_id uuid,
    dropped boolean DEFAULT false NOT NULL,
    came_of_it text,
    CONSTRAINT project_work_command_pair CHECK (((client_command_id IS NULL) = (request_fingerprint IS NULL))),
    CONSTRAINT project_work_criteria_bounded CHECK ((public.flux_is_sealed(criteria) OR public.flux_task_criteria_valid(criteria))),
    CONSTRAINT project_work_items_came_of_it_length CHECK (((came_of_it IS NULL) OR (length(came_of_it) <= 20000))),
    CONSTRAINT project_work_items_check CHECK (((blocker IS NULL) OR ((status = 'blocked'::text) AND (public.flux_is_sealed(blocker) OR (length(blocker) <= 2000))))),
    CONSTRAINT project_work_items_check1 CHECK (((owner_user_id IS NULL) OR (owner_agent_id IS NULL))),
    CONSTRAINT project_work_items_created_by_kind_check CHECK ((created_by_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT project_work_items_creation_baseline_version_check CHECK ((creation_baseline_version > 0)),
    CONSTRAINT project_work_items_creation_origin_check CHECK ((creation_origin = ANY (ARRAY['native_agent'::text, 'ai_proposal'::text, 'human'::text]))),
    CONSTRAINT project_work_items_creation_reverted_by_kind_check CHECK ((creation_reverted_by_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT project_work_items_due_on_range CHECK (((due_on IS NULL) OR ((due_on >= '1970-01-01'::date) AND (due_on <= '9999-12-31'::date)))),
    CONSTRAINT project_work_items_not_waiting_for_itself CHECK ((waiting_for_work_id IS DISTINCT FROM id)),
    CONSTRAINT project_work_items_note_only_done CHECK ((((NOT dropped) AND (came_of_it IS NULL)) OR (status = 'done'::text))),
    CONSTRAINT project_work_items_one_wait CHECK ((num_nonnulls(waiting_for_user_id, waiting_for_decision_id, waiting_for_work_id) <= 1)),
    CONSTRAINT project_work_items_outcome_check CHECK ((public.flux_is_sealed(outcome) OR (length(outcome) <= 4000))),
    CONSTRAINT project_work_items_status_check CHECK ((status = ANY (ARRAY['open'::text, 'in_progress'::text, 'blocked'::text, 'done'::text]))),
    CONSTRAINT project_work_items_title_check CHECK ((public.flux_is_sealed(title) OR ((length(btrim(title)) >= 1) AND (length(btrim(title)) <= 200)))),
    CONSTRAINT project_work_items_version_check CHECK ((version > 0)),
    CONSTRAINT project_work_items_wait_only_blocked CHECK ((((waiting_for_decision_id IS NULL) AND (waiting_for_work_id IS NULL)) OR (status = 'blocked'::text))),
    CONSTRAINT task_creation_baseline_origin CHECK ((((creation_baseline_version IS NULL) = (creation_origin IS NULL)) AND ((creation_baseline IS NULL) = (creation_origin IS NULL)))),
    CONSTRAINT task_creation_reversion_shape CHECK ((((creation_reverted_at IS NULL) AND (creation_reverted_by_kind IS NULL) AND (creation_reverted_by_id IS NULL) AND (creation_reversion_notice_id IS NULL)) OR ((creation_reverted_at IS NOT NULL) AND (creation_reverted_by_kind IS NOT NULL) AND (creation_reverted_by_id IS NOT NULL) AND (creation_reversion_notice_id IS NOT NULL) AND (creation_baseline_version IS NOT NULL) AND (creation_origin = ANY (ARRAY['native_agent'::text, 'ai_proposal'::text, 'human'::text])) AND (first_persisted_use_at IS NULL))))
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    name text NOT NULL,
    visibility text DEFAULT 'workspace'::text NOT NULL,
    created_by text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT projects_name_check CHECK ((public.flux_is_sealed(name) OR ((length(btrim(name)) >= 1) AND (length(btrim(name)) <= 200)))),
    CONSTRAINT projects_version_check CHECK ((version >= 1)),
    CONSTRAINT projects_visibility_check CHECK ((visibility = ANY (ARRAY['workspace'::text, 'restricted'::text])))
);


--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_subscriptions (
    id uuid NOT NULL,
    user_id text NOT NULL,
    session_id text NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    expiration_time timestamp with time zone,
    device_label text,
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_success_at timestamp with time zone,
    last_failure_at timestamp with time zone,
    last_failure_status integer
);


--
-- Name: return_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.return_points (
    user_id text NOT NULL,
    place_key text NOT NULL,
    place_type text NOT NULL,
    project_id uuid,
    conversation_id uuid,
    seq bigint NOT NULL,
    saved_at timestamp with time zone DEFAULT now() NOT NULL,
    previous_seq bigint,
    previous_saved_at timestamp with time zone,
    CONSTRAINT return_points_check CHECK (((previous_seq IS NULL) = (previous_saved_at IS NULL))),
    CONSTRAINT return_points_check1 CHECK (((place_type = 'home'::text) = (project_id IS NULL))),
    CONSTRAINT return_points_check2 CHECK (((place_type = 'conversation'::text) = (conversation_id IS NOT NULL))),
    CONSTRAINT return_points_check3 CHECK ((place_key =
CASE place_type
    WHEN 'home'::text THEN 'home'::text
    WHEN 'project'::text THEN ('project:'::text || (project_id)::text)
    ELSE ('conversation:'::text || (conversation_id)::text)
END)),
    CONSTRAINT return_points_place_type_check CHECK ((place_type = ANY (ARRAY['home'::text, 'project'::text, 'conversation'::text]))),
    CONSTRAINT return_points_previous_seq_check CHECK (((previous_seq IS NULL) OR (previous_seq >= 0))),
    CONSTRAINT return_points_seq_check CHECK ((seq >= 0))
);


--
-- Name: sample_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sample_results (
    sample_id uuid NOT NULL,
    processed_at timestamp with time zone DEFAULT now() NOT NULL,
    worker_id text NOT NULL
);


--
-- Name: samples; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.samples (
    id uuid NOT NULL,
    title text NOT NULL,
    created_by text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sealed_job_waits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sealed_job_waits (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    queue text NOT NULL,
    payload jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    attempts integer DEFAULT 0 NOT NULL
);


--
-- Name: search_changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.search_changes (
    seq bigint NOT NULL,
    workspace_id uuid NOT NULL,
    doc_key text NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL,
    xid xid8 DEFAULT pg_current_xact_id() NOT NULL
);


--
-- Name: search_changes_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.search_changes_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: search_changes_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.search_changes_seq_seq OWNED BY public.search_changes.seq;


--
-- Name: search_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.search_documents (
    id bigint NOT NULL,
    doc_key text NOT NULL,
    kind text NOT NULL,
    workspace_id uuid NOT NULL,
    audience_key text NOT NULL,
    project_id uuid,
    object_id text NOT NULL,
    parent_id uuid,
    version integer,
    status text,
    title text DEFAULT ''::text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    author_kind text,
    author_id text,
    at timestamp with time zone NOT NULL,
    tsv tsvector GENERATED ALWAYS AS ((setweight(to_tsvector('simple'::regconfig, title), 'A'::"char") || setweight(to_tsvector('simple'::regconfig, "left"(body, 100000)), 'B'::"char"))) STORED,
    keys bigint[] GENERATED ALWAYS AS (public.search_keys(audience_key, title, body)) STORED,
    sealed boolean DEFAULT false NOT NULL,
    CONSTRAINT search_documents_author_kind_check CHECK ((author_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT search_documents_kind_check CHECK ((kind = ANY (ARRAY['project'::text, 'message'::text, 'dm_message'::text, 'material'::text, 'doc'::text, 'work'::text, 'decision'::text, 'sketch'::text, 'thought'::text, 'person'::text]))),
    CONSTRAINT search_documents_sealed_placeholder CHECK (((NOT sealed) OR ((title = ''::text) AND (body = ''::text))))
);


--
-- Name: search_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.search_documents ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.search_documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sketch_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sketch_links (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    sketch_id uuid NOT NULL,
    from_id uuid NOT NULL,
    to_id uuid NOT NULL,
    label text,
    created_by_user_id text,
    created_by_agent_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT sketch_links_check CHECK ((from_id <> to_id)),
    CONSTRAINT sketch_links_check1 CHECK (((created_by_user_id IS NULL) <> (created_by_agent_id IS NULL))),
    CONSTRAINT sketch_links_label_check CHECK ((public.flux_is_sealed(label) OR ((label IS NULL) OR ((length(btrim(label)) >= 1) AND (length(btrim(label)) <= 80)))))
);


--
-- Name: sketch_thoughts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sketch_thoughts (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    sketch_id uuid NOT NULL,
    text text NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    width integer DEFAULT 184 NOT NULL,
    height integer DEFAULT 72 NOT NULL,
    shape text DEFAULT 'card'::text NOT NULL,
    created_by_user_id text,
    created_by_agent_id uuid,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    source_author_id text,
    source_author_name text,
    source_sent_at timestamp with time zone,
    source_author_agent_id uuid,
    source_project_message_id uuid,
    edited_by text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT sketch_thoughts_check1 CHECK (((created_by_user_id IS NULL) <> (created_by_agent_id IS NULL))),
    CONSTRAINT sketch_thoughts_height_check CHECK (((height >= 40) AND (height <= 800))),
    CONSTRAINT sketch_thoughts_shape_check CHECK ((shape = ANY (ARRAY['card'::text, 'pill'::text, 'circle'::text]))),
    CONSTRAINT sketch_thoughts_source_author_kind_check CHECK ((num_nonnulls(source_author_id, source_author_agent_id) = ANY (ARRAY[0, 1]))),
    CONSTRAINT sketch_thoughts_source_presence_check CHECK ((((source_sent_at IS NULL) = (source_author_name IS NULL)) AND ((source_sent_at IS NULL) = (num_nonnulls(source_author_id, source_author_agent_id) = 0)))),
    CONSTRAINT sketch_thoughts_source_project_message_check CHECK (((source_project_message_id IS NULL) OR ((source_sent_at IS NOT NULL) AND (num_nonnulls(source_author_id, source_author_agent_id) = 1)))),
    CONSTRAINT sketch_thoughts_text_check CHECK ((public.flux_is_sealed(text) OR ((length(btrim(text)) >= 1) AND (length(btrim(text)) <= 1000)))),
    CONSTRAINT sketch_thoughts_version_check CHECK ((version >= 1)),
    CONSTRAINT sketch_thoughts_width_check CHECK (((width >= 80) AND (width <= 800))),
    CONSTRAINT sketch_thoughts_x_check CHECK (((x >= '-100000'::integer) AND (x <= 100000))),
    CONSTRAINT sketch_thoughts_y_check CHECK (((y >= '-100000'::integer) AND (y <= 100000)))
);


--
-- Name: sketches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sketches (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    scope text NOT NULL,
    project_id uuid,
    title text NOT NULL,
    created_by_user_id text,
    created_by_agent_id uuid,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    edited_by text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT sketches_check CHECK (((scope = 'project'::text) = (project_id IS NOT NULL))),
    CONSTRAINT sketches_check1 CHECK (((scope <> 'private'::text) OR (created_by_user_id IS NOT NULL))),
    CONSTRAINT sketches_check2 CHECK (((created_by_user_id IS NULL) <> (created_by_agent_id IS NULL))),
    CONSTRAINT sketches_dm_person_check CHECK (((scope <> 'dm'::text) OR (created_by_user_id IS NOT NULL))),
    CONSTRAINT sketches_scope_check CHECK ((scope = ANY (ARRAY['project'::text, 'private'::text]))),
    CONSTRAINT sketches_title_check CHECK ((public.flux_is_sealed(title) OR ((length(btrim(title)) >= 1) AND (length(btrim(title)) <= 200)))),
    CONSTRAINT sketches_version_check CHECK ((version >= 1))
);


--
-- Name: task_creation_undo_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_creation_undo_receipts (
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    actor_kind text NOT NULL,
    actor_id text NOT NULL,
    client_command_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    work_id uuid NOT NULL,
    notice_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT task_creation_undo_receipts_actor_kind_check CHECK ((actor_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT task_creation_undo_receipts_request_fingerprint_check CHECK ((public.flux_is_sealed(request_fingerprint) OR (request_fingerprint ~ '^[a-f0-9]{64}$'::text)))
);


--
-- Name: workspace_dek_wraps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_dek_wraps (
    holder_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    key_version integer NOT NULL,
    ephemeral_public text NOT NULL,
    sealed_dek text NOT NULL,
    confirm text,
    CONSTRAINT workspace_dek_wraps_key_version_check CHECK ((key_version >= 1))
);


--
-- Name: workspace_holders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_holders (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    kind text NOT NULL,
    user_id text,
    kdf jsonb NOT NULL,
    public_key text NOT NULL,
    wrapped_private text NOT NULL,
    holder_mac text NOT NULL,
    holder_mac_version integer NOT NULL,
    secret_check text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    confirmed_versions integer[] DEFAULT '{}'::integer[] NOT NULL,
    pin text,
    CONSTRAINT workspace_holders_check CHECK (((kind = 'recovery'::text) = (user_id IS NULL))),
    CONSTRAINT workspace_holders_holder_mac_version_check CHECK ((holder_mac_version >= 1)),
    CONSTRAINT workspace_holders_kdf_check CHECK ((jsonb_typeof(kdf) = 'object'::text)),
    CONSTRAINT workspace_holders_kind_check CHECK ((kind = ANY (ARRAY['password'::text, 'recovery'::text])))
);


--
-- Name: workspace_invites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_invites (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    role text NOT NULL,
    email text,
    token_hash text NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    revoked_by text,
    accepted_at timestamp with time zone,
    accepted_by text,
    CONSTRAINT workspace_invites_check CHECK ((expires_at > created_at)),
    CONSTRAINT workspace_invites_check1 CHECK (((revoked_at IS NULL) OR (accepted_at IS NULL))),
    CONSTRAINT workspace_invites_email_check CHECK (((email IS NULL) OR ((email = lower(email)) AND ((length(email) >= 3) AND (length(email) <= 320))))),
    CONSTRAINT workspace_invites_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'member'::text, 'guest'::text]))),
    CONSTRAINT workspace_invites_token_hash_check CHECK ((token_hash ~ '^[0-9a-f]{64}$'::text))
);


--
-- Name: workspace_key_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_key_versions (
    workspace_id uuid NOT NULL,
    key_version integer NOT NULL,
    commitment text,
    check_value text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    pin text,
    CONSTRAINT workspace_key_versions_check CHECK (((key_version = 1) = (commitment IS NULL))),
    CONSTRAINT workspace_key_versions_key_version_check CHECK ((key_version >= 1))
);


--
-- Name: workspace_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_keys (
    workspace_id uuid NOT NULL,
    current_version integer DEFAULT 1 NOT NULL,
    live_versions integer[] DEFAULT '{1}'::integer[] NOT NULL,
    rotation text DEFAULT 'none'::text NOT NULL,
    rotation_reason jsonb,
    tampered_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    removal_head text,
    key_change_reason jsonb,
    CONSTRAINT workspace_keys_check CHECK (((cardinality(live_versions) >= 1) AND (current_version = public.flux_max_version(live_versions)))),
    CONSTRAINT workspace_keys_current_version_check CHECK ((current_version >= 1)),
    CONSTRAINT workspace_keys_key_change_reason_check CHECK (((key_change_reason IS NULL) OR (jsonb_typeof(key_change_reason) = 'object'::text))),
    CONSTRAINT workspace_keys_rotation_check CHECK ((rotation = ANY (ARRAY['none'::text, 'pending'::text, 'reencrypting'::text]))),
    CONSTRAINT workspace_keys_rotation_reason_check CHECK (((rotation_reason IS NULL) OR (jsonb_typeof(rotation_reason) = 'object'::text)))
);


--
-- Name: workspace_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_members (
    workspace_id uuid NOT NULL,
    user_id text NOT NULL,
    role text NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT workspace_members_role_check CHECK ((role = ANY (ARRAY['owner'::text, 'admin'::text, 'member'::text, 'guest'::text])))
);


--
-- Name: workspace_removals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_removals (
    workspace_id uuid NOT NULL,
    seq integer NOT NULL,
    holder_id uuid NOT NULL,
    user_id text,
    public_key text NOT NULL,
    removed_version integer NOT NULL,
    pin text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT workspace_removals_removed_version_check CHECK ((removed_version >= 1)),
    CONSTRAINT workspace_removals_seq_check CHECK ((seq >= 1))
);


--
-- Name: workspace_removed_holders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_removed_holders (
    workspace_id uuid NOT NULL,
    holder_id uuid NOT NULL,
    user_id text,
    public_key text NOT NULL,
    removed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workspace_removed_people; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_removed_people (
    workspace_id uuid NOT NULL,
    user_id text NOT NULL,
    removed_by text NOT NULL,
    removed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workspace_rotation_progress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_rotation_progress (
    workspace_id uuid NOT NULL,
    target_version integer NOT NULL,
    step text NOT NULL,
    cursor jsonb,
    rows_done bigint DEFAULT 0 NOT NULL,
    rows_estimate bigint DEFAULT 0 NOT NULL,
    passes integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    stalled_on text,
    stalled_at timestamp with time zone,
    pass_changes bigint DEFAULT 0 NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workspace_unlocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_unlocks (
    workspace_id uuid NOT NULL,
    key_version integer NOT NULL,
    boot_id uuid NOT NULL,
    sealed_dek text NOT NULL,
    unlocked_by text,
    unlocked_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT workspace_unlocks_key_version_check CHECK ((key_version >= 1))
);


--
-- Name: workspace_wrap_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_wrap_grants (
    workspace_id uuid NOT NULL,
    user_id text NOT NULL,
    granted_by text NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: workspaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspaces (
    id uuid NOT NULL,
    name text NOT NULL,
    created_by text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    encrypted boolean DEFAULT false NOT NULL,
    creation_id uuid,
    company boolean DEFAULT false NOT NULL,
    company_workspace_id uuid,
    CONSTRAINT workspaces_company_workspace_check CHECK (((company_workspace_id IS NULL) OR (encrypted AND (company_workspace_id <> id)))),
    CONSTRAINT workspaces_name_check CHECK (((length(btrim(name)) >= 1) AND (length(btrim(name)) <= 200))),
    CONSTRAINT workspaces_version_check CHECK ((version >= 1))
);


--
-- Name: job_common; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job ATTACH PARTITION pgboss.job_common DEFAULT;


--
-- Name: queue_stats_20261112; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats ATTACH PARTITION pgboss.queue_stats_20261112 FOR VALUES FROM ('2026-11-12 00:00:00+00') TO ('2026-11-13 00:00:00+00');


--
-- Name: queue_stats_20261113; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats ATTACH PARTITION pgboss.queue_stats_20261113 FOR VALUES FROM ('2026-11-13 00:00:00+00') TO ('2026-11-14 00:00:00+00');


--
-- Name: search_changes seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_changes ALTER COLUMN seq SET DEFAULT nextval('public.search_changes_seq_seq'::regclass);


--
-- Data for Name: bam; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: instance; Type: TABLE DATA; Schema: pgboss; Owner: -
--

INSERT INTO pgboss.instance VALUES ('d0d193c3-2073-4d19-a5ea-361587ab34da', NULL, '78dbcb9ea223', 1, '12.38.1', 'v24.22.2', 'pgboss:d0d193c3', 30, true, true, true, false, false, 10, 2, 1, 1, '[]', '{"cpu": null, "rss": 325853184, "cgroup": 2, "cpuLimit": 24, "heapUsed": 30146128, "heapLimit": 4496293888, "loopDelay": null, "memoryUsed": null, "memoryLimit": 66457141248, "cpuThrottled": null, "loopDelayMax": null, "loopUtilization": null}', '{"adapter": "pg", "backend": "postgres", "migrate": true, "reindex": true, "schedule": true, "supervise": true, "createSchema": true, "useListenNotify": false, "bamIntervalSeconds": 60, "flowIntervalSeconds": 5, "warningRetentionDays": 365, "monitorIntervalSeconds": 60, "queueStatRetentionDays": 7, "reindexIntervalSeconds": 86400, "instanceHeartbeatSeconds": 30, "superviseIntervalSeconds": 60, "cronWorkerIntervalSeconds": 5, "queueCacheIntervalSeconds": 60, "cronMonitorIntervalSeconds": 30, "maintenanceIntervalSeconds": 86400, "clockMonitorIntervalSeconds": 600}', 0, NULL, '2026-11-12 15:18:32.991257+00', '2026-11-12 15:18:32.991257+00', '2026-11-12 15:18:33.455934+00');
INSERT INTO pgboss.instance VALUES ('ba7e8caa-4773-450e-9582-1d59a90a2bc6', NULL, 'b8d9898288e0', 1, '12.38.1', 'v24.22.2', 'pgboss:ba7e8caa', 300, true, true, false, false, false, 10, 2, 1, 1, '[]', '{"cpu": null, "rss": 101720064, "cgroup": 2, "cpuLimit": 24, "heapUsed": 29484008, "heapLimit": 271581184, "loopDelay": null, "memoryUsed": 50843648, "memoryLimit": 536870912, "cpuThrottled": null, "loopDelayMax": null, "loopUtilization": null}', '{"adapter": "pg", "backend": "postgres", "migrate": false, "reindex": true, "schedule": true, "supervise": true, "createSchema": true, "useListenNotify": true, "bamIntervalSeconds": 60, "flowIntervalSeconds": 120, "warningRetentionDays": 365, "monitorIntervalSeconds": 60, "queueStatRetentionDays": 7, "reindexIntervalSeconds": 86400, "instanceHeartbeatSeconds": 300, "superviseIntervalSeconds": 60, "cronWorkerIntervalSeconds": 15, "queueCacheIntervalSeconds": 300, "cronMonitorIntervalSeconds": 30, "maintenanceIntervalSeconds": 86400, "clockMonitorIntervalSeconds": 600}', 0, NULL, '2026-11-12 15:18:35.769787+00', '2026-11-12 15:18:35.769787+00', NULL);
INSERT INTO pgboss.instance VALUES ('9124f1c4-f2f3-4d8e-836c-a58779c1d84e', NULL, '1c3732295267', 1, '12.38.1', 'v24.22.2', 'pgboss:9124f1c4', 300, false, false, false, false, false, 10, 1, 1, 0, '[]', '{"cpu": null, "rss": 277602304, "cgroup": 2, "cpuLimit": 24, "heapUsed": 79548320, "heapLimit": 905969664, "loopDelay": null, "memoryUsed": 231702528, "memoryLimit": 1610612736, "cpuThrottled": null, "loopDelayMax": null, "loopUtilization": null}', '{"adapter": "pg", "backend": "postgres", "migrate": false, "reindex": true, "schedule": false, "supervise": false, "createSchema": true, "useListenNotify": false, "bamIntervalSeconds": 60, "flowIntervalSeconds": 5, "warningRetentionDays": 365, "monitorIntervalSeconds": 60, "queueStatRetentionDays": 7, "reindexIntervalSeconds": 86400, "instanceHeartbeatSeconds": 300, "superviseIntervalSeconds": 60, "cronWorkerIntervalSeconds": 5, "queueCacheIntervalSeconds": 60, "cronMonitorIntervalSeconds": 30, "maintenanceIntervalSeconds": 86400, "clockMonitorIntervalSeconds": 600}', 0, NULL, '2026-11-12 15:18:36.560779+00', '2026-11-12 15:18:36.560779+00', NULL);


--
-- Data for Name: job_common; Type: TABLE DATA; Schema: pgboss; Owner: -
--

INSERT INTO pgboss.job_common VALUES ('caa92a6f-a74e-4984-9947-f73461f3044a', 'personal-run.dispatch.v1', 0, '{"runId": "dc0d8004-d3fd-401c-917d-6503a961a939"}', 'completed', 0, 0, 0, false, NULL, 4200, 604800, NULL, NULL, NULL, NULL, '2026-11-12 15:18:40.677272+00', '2026-11-12 15:18:40.677272+00', '2026-11-12 15:18:40.729329+00', '2026-11-12 15:18:40.749802+00', '2026-11-26 15:18:40.677272+00', NULL, NULL, 'standard', '2026-11-12 15:18:40.729329+00', NULL, false, false, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);


--
-- Data for Name: job_dependency; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: queue; Type: TABLE DATA; Schema: pgboss; Owner: -
--

INSERT INTO pgboss.queue VALUES ('__pgboss__send-it', 'standard', 2, 0, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, false, NULL, NULL, NULL, NULL, '2026-11-12 15:18:32.965222+00', '2026-11-12 15:18:32.965222+00');
INSERT INTO pgboss.queue VALUES ('sample.process', 'standard', 2, 0, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-12 15:18:33.054594+00', '2026-11-12 15:18:33.091269+00');
INSERT INTO pgboss.queue VALUES ('draft.summarize.v1', 'standard', 2, 0, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-12 15:18:33.108671+00', '2026-11-12 15:18:33.126716+00');
INSERT INTO pgboss.queue VALUES ('idempotency.cleanup.v1', 'standard', 2, 0, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-12 15:18:33.14651+00', '2026-11-12 15:18:33.164637+00');
INSERT INTO pgboss.queue VALUES ('push.send', 'standard', 5, 10, true, 600, 60, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-12 15:18:33.184861+00', '2026-11-12 15:18:33.20352+00');
INSERT INTO pgboss.queue VALUES ('notification.email.v1', 'standard', 5, 30, true, 900, 120, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-12 15:18:33.22322+00', '2026-11-12 15:18:33.242098+00');
INSERT INTO pgboss.queue VALUES ('personal-run.dispatch.v1', 'standard', 0, 0, false, NULL, 4200, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-12 15:18:33.26192+00', '2026-11-12 15:18:33.281441+00');
INSERT INTO pgboss.queue VALUES ('assistant.background.tick.v1', 'singleton', 0, 0, false, NULL, 300, 1209600, 86400, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', 30, true, NULL, NULL, NULL, NULL, '2026-11-12 15:18:33.300259+00', '2026-11-12 15:18:33.320171+00');
INSERT INTO pgboss.queue VALUES ('space-ai.sweep.v1', 'standard', 5, 5, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-12 15:18:33.338684+00', '2026-11-12 15:18:33.35887+00');
INSERT INTO pgboss.queue VALUES ('workspace-encryption.resume.v1', 'standard', 5, 5, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-12 15:18:33.376997+00', '2026-11-12 15:18:33.396573+00');
INSERT INTO pgboss.queue VALUES ('search-changes.cleanup.v1', 'standard', 2, 0, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-12 15:18:33.415331+00', '2026-11-12 15:18:33.435466+00');


--
-- Data for Name: queue_stats_20261112; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: queue_stats_20261113; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: schedule; Type: TABLE DATA; Schema: pgboss; Owner: -
--

INSERT INTO pgboss.schedule VALUES ('assistant.background.tick.v1', '', 'cron', '* * * * *', 'UTC', NULL, '{}', '2026-11-12 15:18:35.831128+00', '2026-11-12 15:18:35.831128+00', NULL);
INSERT INTO pgboss.schedule VALUES ('idempotency.cleanup.v1', '', 'cron', '17 * * * *', 'UTC', NULL, '{}', '2026-11-12 15:18:35.863083+00', '2026-11-12 15:18:35.863083+00', NULL);
INSERT INTO pgboss.schedule VALUES ('search-changes.cleanup.v1', '', 'cron', '37 * * * *', 'UTC', NULL, '{}', '2026-11-12 15:18:35.901164+00', '2026-11-12 15:18:35.901164+00', NULL);


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: version; Type: TABLE DATA; Schema: pgboss; Owner: -
--

INSERT INTO pgboss.version VALUES (46, '2026-11-12 15:18:32.989733+00', '2026-11-12 15:18:32.989652+00', '2026-11-12 15:18:32.968862+00', NULL, NULL);


--
-- Data for Name: warning; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: agent_chat_messages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_chat_reads; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_command_receipts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_connections; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.agent_connections VALUES ('b6835b2d-479f-4517-9bd4-ff126a9ed761', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '9d34944a-d131-4acb-9091-873fa03b5764', NULL, '2026-11-12 15:18:40.504769+00', '2026-11-12 15:18:40.504769+00', 'Assistant', 'other', 'owner_assistant', 'act');
INSERT INTO public.agent_connections VALUES ('c2abbaf3-77b3-4096-afe8-9384774f6583', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'b8a60e4b-1a7d-4bbd-b7b1-946d2fcc9697', NULL, '2026-11-12 15:18:40.544375+00', '2026-11-12 15:18:40.544375+00', 'Planner 7e3c66b9', 'other', 'owner_assistant', 'act');


--
-- Data for Name: agent_memory_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.agent_memory_items VALUES ('49b1d1d7-5fb7-4c6a-a39d-6f5a99592782', 'b8a60e4b-1a7d-4bbd-b7b1-946d2fcc9697', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'The garden is on the north side (7e3c66b9)', 'Added by you', '2026-11-12 15:18:40.57742+00', '2026-11-12 15:18:40.57742+00');
INSERT INTO public.agent_memory_items VALUES ('45282a08-1e6d-45dc-90d1-9d50722e7f77', 'b8a60e4b-1a7d-4bbd-b7b1-946d2fcc9697', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'Water on Mondays (7e3c66b9)', 'Added by you', '2026-11-12 15:18:40.61401+00', '2026-11-12 15:18:40.61401+00');


--
-- Data for Name: agent_oauth_bindings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_playbook_acknowledgments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_proposals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_questions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_runtime_auth_admission; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.agent_runtime_auth_admission VALUES (true, false, NULL, '2026-11-12 15:18:30.962904+00');


--
-- Data for Name: agent_runtime_auth_operations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_runtime_bindings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_runtime_client_history; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_runtime_connections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_runtime_console_nonces; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_runtime_operator_statements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_runtime_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_runtime_slots; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_stops; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_task_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_task_taking; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.agents VALUES ('9d34944a-d131-4acb-9091-873fa03b5764', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'Assistant', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, '2026-11-12 15:18:40.504769+00', '2026-11-12 15:18:40.504769+00');
INSERT INTO public.agents VALUES ('b8a60e4b-1a7d-4bbd-b7b1-946d2fcc9697', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'Planner 7e3c66b9', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, '2026-11-12 15:18:40.544375+00', '2026-11-12 15:18:40.544375+00');


--
-- Data for Name: assistant_background_notes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: assistant_changes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: assistant_job_runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: assistant_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.assistant_jobs VALUES ('8930d028-21f9-404e-8191-3ac8cd1258f2', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'Weekly summary 7e3c66b9', 'Summarise what changed in Garden', 'weekly', '{"at": "09:00", "kind": "weekly", "weekday": 1}', 'Europe/Warsaw', true, false, NULL, '2026-11-16 08:00:00+00', NULL, NULL, 1, '2026-11-12 15:18:40.635778+00', '2026-11-12 15:18:40.635778+00', 'b8a60e4b-1a7d-4bbd-b7b1-946d2fcc9697');
INSERT INTO public.assistant_jobs VALUES ('eba222b5-9452-464f-b739-19e18ee52cb1', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'Daily check 7e3c66b9', 'Look at the garden tasks', 'daily', '{"at": "07:30", "kind": "daily"}', 'Europe/Warsaw', false, false, NULL, NULL, NULL, NULL, 1, '2026-11-12 15:18:40.65956+00', '2026-11-12 15:18:40.65956+00', 'b8a60e4b-1a7d-4bbd-b7b1-946d2fcc9697');


--
-- Data for Name: assistant_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.assistant_settings VALUES ('db2917d2-9c76-4600-979b-62cde4a8a63b', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '9d34944a-d131-4acb-9091-873fa03b5764', 'b6835b2d-479f-4517-9bd4-ff126a9ed761', 1, '2026-11-12 15:18:40.504769+00', '2026-11-12 15:18:40.504769+00', '', 'ink', 'server', 'a5218913-f285-4952-b6a2-ff89035d81cd', 'openai_compatible', 'upgrade-check-model');
INSERT INTO public.assistant_settings VALUES ('db2917d2-9c76-4600-979b-62cde4a8a63b', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'b8a60e4b-1a7d-4bbd-b7b1-946d2fcc9697', 'c2abbaf3-77b3-4096-afe8-9384774f6583', 1, '2026-11-12 15:18:40.544375+00', '2026-11-12 15:18:40.544375+00', 'Plan the garden work, 7e3c66b9.', 'clay', 'server', 'a5218913-f285-4952-b6a2-ff89035d81cd', 'openai_compatible', 'upgrade-check-model');


--
-- Data for Name: auth_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.auth_accounts VALUES ('c413eb6b-e0fe-4e56-9a88-8d9a83984430', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'credential', NULL, NULL, NULL, NULL, NULL, NULL, 'c6d98fe731c1079047cab8e48100ffde:68a1d69b6705201473526e326b28bbafc846970a389f51c8bc0351aabfe2d405e8c0949f87c3ca2ec54f20f498ef6c062dd20e90196614e80bc47140472c9368', '2026-11-12 15:18:37.982+00', '2026-11-12 15:18:37.982+00', NULL, 0, NULL);
INSERT INTO public.auth_accounts VALUES ('1392ba76-d7c4-49c1-b240-02a3d22ed829', '02f26b99-2df5-45f8-8529-1f662cde58d1', '02f26b99-2df5-45f8-8529-1f662cde58d1', 'credential', NULL, NULL, NULL, NULL, NULL, NULL, 'c0a6835fa776b6610ff194a7c32d1d35:4b97b24fcf946e10adc40687b8967229ee6e1038d843346df25936898326a4cc8bb0bd7e10ea8af5e6b803e0c1f73620c67d0a74fd0197eea72bbce3b1919363', '2026-11-12 15:18:38.736+00', '2026-11-12 15:18:38.736+00', NULL, 0, NULL);
INSERT INTO public.auth_accounts VALUES ('321a52a0-6fb6-4894-bbe1-0bc4cf973220', '7521935a-427b-4baf-b0ae-1072ddb9959c', '7521935a-427b-4baf-b0ae-1072ddb9959c', 'credential', NULL, NULL, NULL, NULL, NULL, NULL, 'b720539e6376a754dc53bb7adc03290c:6f3f6f76d861d6561fb951c433232d9ed4278ab296735b005cf5bfe3bd88e62c2b6f115af314854529170dd509e293d9be5b28da5e9962f1ab2aa292cde60e1d', '2026-11-12 15:18:39.112+00', '2026-11-12 15:18:39.112+00', NULL, 0, NULL);


--
-- Data for Name: auth_email_claims; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: auth_identity_audit; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: auth_idp_standing; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: auth_link_intents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: auth_logout_tokens; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: auth_rate_limits; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.auth_rate_limits VALUES ('725bd4c5-766f-4f44-aae1-1d573d60dc34', '172.16.224.1|/sign-up/email', 3, 1794496718877);
INSERT INTO public.auth_rate_limits VALUES ('4ca45a67-13a5-4a60-905b-c0ded500b401', '127.0.0.1|/jwks', 1, 1794496720881);
INSERT INTO public.auth_rate_limits VALUES ('e21412b7-f47c-4bc8-b9e8-770549f2b73a', '172.16.224.1|/sign-in/email', 1, 1794496721747);


--
-- Data for Name: auth_session_identities; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.auth_session_identities VALUES ('2e56e242-eed8-455f-8be7-72089576c6e8', 'password', NULL, '2026-11-12 15:18:38.047726+00');
INSERT INTO public.auth_session_identities VALUES ('5eeb7098-c1cb-4b3a-80bf-2feb7aae5822', 'password', NULL, '2026-11-12 15:18:38.789042+00');
INSERT INTO public.auth_session_identities VALUES ('ccd6d920-46a6-43bf-abbb-7a0be058eb6b', 'password', NULL, '2026-11-12 15:18:39.152453+00');
INSERT INTO public.auth_session_identities VALUES ('87bd4f50-e7bd-454c-bace-2d72ec46f789', 'password', NULL, '2026-11-12 15:18:41.839914+00');


--
-- Data for Name: auth_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.auth_sessions VALUES ('2e56e242-eed8-455f-8be7-72089576c6e8', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'WnGn4J8vZuOyyZIom0hj0ZCQhibeInFp', '2026-11-19 15:18:38+00', '172.16.224.1', 'Python-urllib/3.13', '2026-11-12 15:18:38+00', '2026-11-12 15:18:38+00', NULL);
INSERT INTO public.auth_sessions VALUES ('5eeb7098-c1cb-4b3a-80bf-2feb7aae5822', '02f26b99-2df5-45f8-8529-1f662cde58d1', '2TCS8RS8GCWvXMX1q2gnF5j3iOccKnDl', '2026-11-19 15:18:38.755+00', '172.16.224.1', 'Python-urllib/3.13', '2026-11-12 15:18:38.755+00', '2026-11-12 15:18:38.755+00', NULL);
INSERT INTO public.auth_sessions VALUES ('ccd6d920-46a6-43bf-abbb-7a0be058eb6b', '7521935a-427b-4baf-b0ae-1072ddb9959c', '0mwhxIFP8xnaupQ2Gkl979nmv7B8vTQL', '2026-11-19 15:18:39.132+00', '172.16.224.1', 'Python-urllib/3.13', '2026-11-12 15:18:39.132+00', '2026-11-12 15:18:39.132+00', NULL);
INSERT INTO public.auth_sessions VALUES ('87bd4f50-e7bd-454c-bace-2d72ec46f789', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '9spIIUZXag76MqO9v2qBwxhnrUPKgXm0', '2026-11-19 15:18:41.829+00', '172.16.224.1', 'Python-urllib/3.13', '2026-11-12 15:18:41.829+00', '2026-11-12 15:18:41.829+00', NULL);


--
-- Data for Name: auth_sign_in_throttle; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: auth_users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.auth_users VALUES ('64d60389-a836-4818-b7b8-4e0abb5b65b7', 'Release smoke user', 'release-a419cfb5f819aab1@example.test', false, NULL, '2026-11-12 15:18:37.969+00', '2026-11-12 15:18:37.969+00', false, 0, 'UTC');
INSERT INTO public.auth_users VALUES ('02f26b99-2df5-45f8-8529-1f662cde58d1', 'Ben Member', 'ben-7e3c66b9-fea0e2807649@example.test', false, NULL, '2026-11-12 15:18:38.726+00', '2026-11-12 15:18:38.726+00', false, 0, 'UTC');
INSERT INTO public.auth_users VALUES ('7521935a-427b-4baf-b0ae-1072ddb9959c', 'Gina Guest', 'gina-7e3c66b9-4c302d6f553a@example.test', false, NULL, '2026-11-12 15:18:39.1+00', '2026-11-12 15:18:39.1+00', false, 0, 'UTC');


--
-- Data for Name: auth_verifications; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: background_compute_connections; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.background_compute_connections VALUES ('a5218913-f285-4952-b6a2-ff89035d81cd', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'openai_compatible', 'upgrade-check-model', 'v1.TO25VmPnYCBt3YOW.OsJXvUT4zpg0wpAyAwOM8Q.DEJRHcXG9d79yb4io-0_zLv9v3jnJ_UW8AymIBGuSaaYxKIg_Ih1SbU', '0094', '18cd79e323d42f0a', '2026-11-12 15:18:40.480692+00', NULL, 'http://provider-mock:8091/v1', 0, 0, 'owner', NULL, 'Mock key 7e3c66b9', 500, 'UTC');


--
-- Data for Name: cowork_checkpoints; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: cowork_connection_slots; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: cowork_units; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: dm_message_observations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: dm_messages; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.dm_messages VALUES ('54f3c21e-d3f7-400f-8d9f-583b09c6d6f5', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'ffd70895-f293-4edf-af57-e19ad0a448a8', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '3f255135-6f6f-4b3e-9eed-0475f1781f20', '2d47ab508fb1973e84e0fde35422ac2028ca772db5989c7bfa43fb8fab98efd6', 1, 'DM-hello-7e3c66b9', '2026-11-12 15:18:39.57304+00', NULL, NULL, 'text', NULL, NULL);
INSERT INTO public.dm_messages VALUES ('bd14e24a-1549-4bc1-90fb-c7829aff3b87', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'ffd70895-f293-4edf-af57-e19ad0a448a8', '02f26b99-2df5-45f8-8529-1f662cde58d1', '4787f2bb-07ac-4c50-8872-2e9fdfbd6eda', 'd11a6d03657e6d271746e273a1f8bc4d711ef7de1550163eea95b7138653a051', 2, 'DM-reply-7e3c66b9', '2026-11-12 15:18:39.599915+00', '54f3c21e-d3f7-400f-8d9f-583b09c6d6f5', NULL, 'text', NULL, NULL);
INSERT INTO public.dm_messages VALUES ('ca3c7aae-a703-4f9a-a142-edc8dc7f1bbd', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '72fe8726-9409-49d1-be95-94314d79337b', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '6e1215cd-ae9c-43b0-9694-3af2b4d74d9a', '3b23e514209852bc4886c647419e3cd8c74b0862f5637a2df542a09482ec743c', 1, 'GROUP-hello-7e3c66b9', '2026-11-12 15:18:39.670741+00', NULL, NULL, 'text', NULL, NULL);


--
-- Data for Name: dm_participants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.dm_participants VALUES ('db2917d2-9c76-4600-979b-62cde4a8a63b', 'ffd70895-f293-4edf-af57-e19ad0a448a8', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:39.543308+00');
INSERT INTO public.dm_participants VALUES ('db2917d2-9c76-4600-979b-62cde4a8a63b', 'ffd70895-f293-4edf-af57-e19ad0a448a8', '02f26b99-2df5-45f8-8529-1f662cde58d1', '2026-11-12 15:18:39.543308+00');
INSERT INTO public.dm_participants VALUES ('db2917d2-9c76-4600-979b-62cde4a8a63b', '72fe8726-9409-49d1-be95-94314d79337b', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:39.635946+00');
INSERT INTO public.dm_participants VALUES ('db2917d2-9c76-4600-979b-62cde4a8a63b', '72fe8726-9409-49d1-be95-94314d79337b', '02f26b99-2df5-45f8-8529-1f662cde58d1', '2026-11-12 15:18:39.635946+00');
INSERT INTO public.dm_participants VALUES ('db2917d2-9c76-4600-979b-62cde4a8a63b', '72fe8726-9409-49d1-be95-94314d79337b', '7521935a-427b-4baf-b0ae-1072ddb9959c', '2026-11-12 15:18:39.635946+00');


--
-- Data for Name: dms; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.dms VALUES ('ffd70895-f293-4edf-af57-e19ad0a448a8', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'pair', '02f26b99-2df5-45f8-8529-1f662cde58d1:64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, '64d60389-a836-4818-b7b8-4e0abb5b65b7', 1, 3, '2026-11-12 15:18:39.543308+00', '2026-11-12 15:18:39.599915+00');
INSERT INTO public.dms VALUES ('72fe8726-9409-49d1-be95-94314d79337b', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'group', NULL, 'Garden crew 7e3c66b9', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 1, 2, '2026-11-12 15:18:39.635946+00', '2026-11-12 15:18:39.670741+00');


--
-- Data for Name: doc_live_archives; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: doc_live_heads; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: doc_live_presence; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: doc_live_replicas; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: doc_live_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: doc_live_updates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: encrypted_workspace_creations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.encrypted_workspace_creations VALUES ('d081627e-3f0e-4080-a227-afbc8f78de18', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:40.198773+00');


--
-- Data for Name: event_audience; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 1, 'e25c3909-8af2-4942-bccc-d475b0f3c595');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 2, '99697d6e-6c68-41a8-8a15-de72a9e6948b');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 3, 'f3b70a21-bf10-449f-babf-347c144bca3a');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 4, '13738e61-0306-42c6-9d1b-22e190c83637');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 5, '6049bc27-8308-45de-baef-07c9267c10a4');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 6, '09f6e164-2afe-4643-b054-ed443283c45f');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 7, '327eb1b8-bed3-4669-a921-3ab3ee5de0eb');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 8, '84f608cc-2037-4bbe-a475-62514330586f');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 9, '36b2fca2-e312-4543-85bd-8ef68a8a5495');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 10, '710f05c7-3f7c-4d1e-a2b8-34d2305f43f0');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 11, '9ea1d370-5957-46fe-8273-a43621c38afa');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 12, '3588bd6a-b263-4ac1-93d0-53c5b30079bc');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 12, '3588bd6a-b263-4ac1-93d0-53c5b30079bc');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 13, '02cef4e2-7b69-47d0-8d5b-1b55e4c0da11');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 13, '02cef4e2-7b69-47d0-8d5b-1b55e4c0da11');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 14, '89bcd377-2a2c-4ddb-9965-b5d21c76084f');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 14, '89bcd377-2a2c-4ddb-9965-b5d21c76084f');
INSERT INTO public.event_audience VALUES ('human:7521935a-427b-4baf-b0ae-1072ddb9959c', 14, '89bcd377-2a2c-4ddb-9965-b5d21c76084f');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 15, '9c5a050c-4cf9-47c6-bbe7-b8adbb98d09f');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 15, '9c5a050c-4cf9-47c6-bbe7-b8adbb98d09f');
INSERT INTO public.event_audience VALUES ('human:7521935a-427b-4baf-b0ae-1072ddb9959c', 15, '9c5a050c-4cf9-47c6-bbe7-b8adbb98d09f');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 16, '43c45cb8-6de5-42cd-bcb1-0734524773d0');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 16, '43c45cb8-6de5-42cd-bcb1-0734524773d0');
INSERT INTO public.event_audience VALUES ('human:7521935a-427b-4baf-b0ae-1072ddb9959c', 16, '43c45cb8-6de5-42cd-bcb1-0734524773d0');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 17, 'd502ba4c-241a-4f26-9183-2c4b6adb78e3');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 17, 'd502ba4c-241a-4f26-9183-2c4b6adb78e3');
INSERT INTO public.event_audience VALUES ('human:7521935a-427b-4baf-b0ae-1072ddb9959c', 17, 'd502ba4c-241a-4f26-9183-2c4b6adb78e3');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 18, 'd2936d26-95ee-422f-9e77-4e5b33735550');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 18, 'd2936d26-95ee-422f-9e77-4e5b33735550');
INSERT INTO public.event_audience VALUES ('human:7521935a-427b-4baf-b0ae-1072ddb9959c', 18, 'd2936d26-95ee-422f-9e77-4e5b33735550');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 19, 'b108c5cf-b657-42ea-85a5-8230cc97fa7a');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 19, 'b108c5cf-b657-42ea-85a5-8230cc97fa7a');
INSERT INTO public.event_audience VALUES ('human:7521935a-427b-4baf-b0ae-1072ddb9959c', 19, 'b108c5cf-b657-42ea-85a5-8230cc97fa7a');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 20, 'f5aedde3-3e74-493b-89d8-e1e27927a696');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 20, 'f5aedde3-3e74-493b-89d8-e1e27927a696');
INSERT INTO public.event_audience VALUES ('human:7521935a-427b-4baf-b0ae-1072ddb9959c', 20, 'f5aedde3-3e74-493b-89d8-e1e27927a696');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 21, 'f329bc4d-a348-40ce-9298-012317be66a7');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 21, 'f329bc4d-a348-40ce-9298-012317be66a7');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 22, '2c11d8cc-5f77-4d99-acc1-7fc86e094f63');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 22, '2c11d8cc-5f77-4d99-acc1-7fc86e094f63');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 23, 'bd25c703-993f-462d-ac63-70418cad71d9');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 23, 'bd25c703-993f-462d-ac63-70418cad71d9');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 24, 'fae13e56-b8b2-4246-9069-4aa9928733c9');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 24, 'fae13e56-b8b2-4246-9069-4aa9928733c9');
INSERT INTO public.event_audience VALUES ('human:7521935a-427b-4baf-b0ae-1072ddb9959c', 24, 'fae13e56-b8b2-4246-9069-4aa9928733c9');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 25, '1b297cf2-5007-4aed-8b74-8f188f3d3d9f');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 25, '1b297cf2-5007-4aed-8b74-8f188f3d3d9f');
INSERT INTO public.event_audience VALUES ('human:7521935a-427b-4baf-b0ae-1072ddb9959c', 25, '1b297cf2-5007-4aed-8b74-8f188f3d3d9f');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 26, 'b4a89eef-411b-483d-8096-d86a5e98c021');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 26, 'b4a89eef-411b-483d-8096-d86a5e98c021');
INSERT INTO public.event_audience VALUES ('human:7521935a-427b-4baf-b0ae-1072ddb9959c', 26, 'b4a89eef-411b-483d-8096-d86a5e98c021');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 27, '507e04e8-63a7-46d8-8417-8463dfaaaaf8');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 27, '507e04e8-63a7-46d8-8417-8463dfaaaaf8');
INSERT INTO public.event_audience VALUES ('human:7521935a-427b-4baf-b0ae-1072ddb9959c', 27, '507e04e8-63a7-46d8-8417-8463dfaaaaf8');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 28, 'cf27cfcc-f57b-4d93-b59d-e1f9d160c129');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 28, 'cf27cfcc-f57b-4d93-b59d-e1f9d160c129');
INSERT INTO public.event_audience VALUES ('human:7521935a-427b-4baf-b0ae-1072ddb9959c', 28, 'cf27cfcc-f57b-4d93-b59d-e1f9d160c129');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 29, '2ae9f565-302f-42ee-94bc-0b34ba8bcd11');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 29, '2ae9f565-302f-42ee-94bc-0b34ba8bcd11');
INSERT INTO public.event_audience VALUES ('human:7521935a-427b-4baf-b0ae-1072ddb9959c', 29, '2ae9f565-302f-42ee-94bc-0b34ba8bcd11');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 30, '3be32f0a-a406-4fd9-afd8-079223422cda');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 30, '3be32f0a-a406-4fd9-afd8-079223422cda');
INSERT INTO public.event_audience VALUES ('human:7521935a-427b-4baf-b0ae-1072ddb9959c', 30, '3be32f0a-a406-4fd9-afd8-079223422cda');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 31, '66b3817d-fbbe-4b7d-add1-883c664159ec');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 31, '66b3817d-fbbe-4b7d-add1-883c664159ec');
INSERT INTO public.event_audience VALUES ('human:7521935a-427b-4baf-b0ae-1072ddb9959c', 31, '66b3817d-fbbe-4b7d-add1-883c664159ec');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 32, '495a7e59-26ea-4782-8a1f-396a1603d5ab');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 32, '495a7e59-26ea-4782-8a1f-396a1603d5ab');
INSERT INTO public.event_audience VALUES ('human:7521935a-427b-4baf-b0ae-1072ddb9959c', 32, '495a7e59-26ea-4782-8a1f-396a1603d5ab');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 33, '6715454e-b3c2-4422-a003-2340a4a046e0');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 33, '6715454e-b3c2-4422-a003-2340a4a046e0');
INSERT INTO public.event_audience VALUES ('human:7521935a-427b-4baf-b0ae-1072ddb9959c', 33, '6715454e-b3c2-4422-a003-2340a4a046e0');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 34, 'b3514b6a-6cdd-4699-ac4c-0d40d10add04');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 34, 'b3514b6a-6cdd-4699-ac4c-0d40d10add04');
INSERT INTO public.event_audience VALUES ('human:7521935a-427b-4baf-b0ae-1072ddb9959c', 34, 'b3514b6a-6cdd-4699-ac4c-0d40d10add04');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 35, 'a07f5e4b-66c9-4ab5-a9d7-69279b3154ba');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 35, 'a07f5e4b-66c9-4ab5-a9d7-69279b3154ba');
INSERT INTO public.event_audience VALUES ('human:7521935a-427b-4baf-b0ae-1072ddb9959c', 35, 'a07f5e4b-66c9-4ab5-a9d7-69279b3154ba');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 36, 'd700e729-4241-49e3-835f-acae6ff903d6');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 37, '8b825966-b202-409f-9573-d8787f47c1c9');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 38, 'df2eee02-f432-4ee4-a16f-954da92d6a81');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 39, 'bb61a29d-1f7e-4331-9d5e-11fab9345643');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 40, 'fa99921c-81ce-417d-88a6-22196ba12af9');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 41, 'cb2d3710-4b29-437b-a2dd-de00b567ac1a');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 41, 'cb2d3710-4b29-437b-a2dd-de00b567ac1a');
INSERT INTO public.event_audience VALUES ('agent:9d34944a-d131-4acb-9091-873fa03b5764', 41, 'cb2d3710-4b29-437b-a2dd-de00b567ac1a');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 42, '380ecbd4-52ef-4242-803e-18f57fefdb35');
INSERT INTO public.event_audience VALUES ('human:02f26b99-2df5-45f8-8529-1f662cde58d1', 42, '380ecbd4-52ef-4242-803e-18f57fefdb35');
INSERT INTO public.event_audience VALUES ('agent:b8a60e4b-1a7d-4bbd-b7b1-946d2fcc9697', 42, '380ecbd4-52ef-4242-803e-18f57fefdb35');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 43, 'b89818af-020a-43c4-825e-eea33af1089f');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 44, 'f028cca5-9107-4f09-a929-ad42b68e20ca');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 45, '19f14d93-08d9-442a-a2e6-48e586f109fd');
INSERT INTO public.event_audience VALUES ('human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 46, '0bb04fbd-f89d-4574-b0c9-8fefb68ecbca');


--
-- Data for Name: event_data_keys; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.event_data_keys VALUES ('access');
INSERT INTO public.event_data_keys VALUES ('actor');
INSERT INTO public.event_data_keys VALUES ('actorId');
INSERT INTO public.event_data_keys VALUES ('additionalProperties');
INSERT INTO public.event_data_keys VALUES ('agentId');
INSERT INTO public.event_data_keys VALUES ('agentIds');
INSERT INTO public.event_data_keys VALUES ('ai');
INSERT INTO public.event_data_keys VALUES ('assignedTo');
INSERT INTO public.event_data_keys VALUES ('at');
INSERT INTO public.event_data_keys VALUES ('audience');
INSERT INTO public.event_data_keys VALUES ('author');
INSERT INTO public.event_data_keys VALUES ('automation');
INSERT INTO public.event_data_keys VALUES ('body');
INSERT INTO public.event_data_keys VALUES ('boundary');
INSERT INTO public.event_data_keys VALUES ('by');
INSERT INTO public.event_data_keys VALUES ('canCreateProject');
INSERT INTO public.event_data_keys VALUES ('caps');
INSERT INTO public.event_data_keys VALUES ('changed');
INSERT INTO public.event_data_keys VALUES ('changes');
INSERT INTO public.event_data_keys VALUES ('clientCommandId');
INSERT INTO public.event_data_keys VALUES ('clientMessageId');
INSERT INTO public.event_data_keys VALUES ('code');
INSERT INTO public.event_data_keys VALUES ('columns');
INSERT INTO public.event_data_keys VALUES ('command');
INSERT INTO public.event_data_keys VALUES ('commandId');
INSERT INTO public.event_data_keys VALUES ('contentIdentity');
INSERT INTO public.event_data_keys VALUES ('conversationId');
INSERT INTO public.event_data_keys VALUES ('createdAt');
INSERT INTO public.event_data_keys VALUES ('createdBy');
INSERT INTO public.event_data_keys VALUES ('data');
INSERT INTO public.event_data_keys VALUES ('decisionId');
INSERT INTO public.event_data_keys VALUES ('dm');
INSERT INTO public.event_data_keys VALUES ('dmId');
INSERT INTO public.event_data_keys VALUES ('docId');
INSERT INTO public.event_data_keys VALUES ('email');
INSERT INTO public.event_data_keys VALUES ('end');
INSERT INTO public.event_data_keys VALUES ('error');
INSERT INTO public.event_data_keys VALUES ('eventId');
INSERT INTO public.event_data_keys VALUES ('events');
INSERT INTO public.event_data_keys VALUES ('evidenceRef');
INSERT INTO public.event_data_keys VALUES ('expected');
INSERT INTO public.event_data_keys VALUES ('expiresAt');
INSERT INTO public.event_data_keys VALUES ('fence');
INSERT INTO public.event_data_keys VALUES ('file');
INSERT INTO public.event_data_keys VALUES ('fileId');
INSERT INTO public.event_data_keys VALUES ('fingerprint');
INSERT INTO public.event_data_keys VALUES ('firstMessageBody');
INSERT INTO public.event_data_keys VALUES ('from');
INSERT INTO public.event_data_keys VALUES ('fromTitle');
INSERT INTO public.event_data_keys VALUES ('goal');
INSERT INTO public.event_data_keys VALUES ('goalId');
INSERT INTO public.event_data_keys VALUES ('grantId');
INSERT INTO public.event_data_keys VALUES ('hasMoreBefore');
INSERT INTO public.event_data_keys VALUES ('height');
INSERT INTO public.event_data_keys VALUES ('holders');
INSERT INTO public.event_data_keys VALUES ('id');
INSERT INTO public.event_data_keys VALUES ('ids');
INSERT INTO public.event_data_keys VALUES ('inbox');
INSERT INTO public.event_data_keys VALUES ('index');
INSERT INTO public.event_data_keys VALUES ('input');
INSERT INTO public.event_data_keys VALUES ('intent');
INSERT INTO public.event_data_keys VALUES ('intents');
INSERT INTO public.event_data_keys VALUES ('interpretation');
INSERT INTO public.event_data_keys VALUES ('invitationId');
INSERT INTO public.event_data_keys VALUES ('inviteId');
INSERT INTO public.event_data_keys VALUES ('items');
INSERT INTO public.event_data_keys VALUES ('keys');
INSERT INTO public.event_data_keys VALUES ('kind');
INSERT INTO public.event_data_keys VALUES ('level');
INSERT INTO public.event_data_keys VALUES ('lifecycle');
INSERT INTO public.event_data_keys VALUES ('limit');
INSERT INTO public.event_data_keys VALUES ('link');
INSERT INTO public.event_data_keys VALUES ('linkId');
INSERT INTO public.event_data_keys VALUES ('linkIds');
INSERT INTO public.event_data_keys VALUES ('lock');
INSERT INTO public.event_data_keys VALUES ('materialId');
INSERT INTO public.event_data_keys VALUES ('maxLength');
INSERT INTO public.event_data_keys VALUES ('message');
INSERT INTO public.event_data_keys VALUES ('messageId');
INSERT INTO public.event_data_keys VALUES ('messageIds');
INSERT INTO public.event_data_keys VALUES ('messagePage');
INSERT INTO public.event_data_keys VALUES ('messages');
INSERT INTO public.event_data_keys VALUES ('myName');
INSERT INTO public.event_data_keys VALUES ('name');
INSERT INTO public.event_data_keys VALUES ('nextBeforeSequence');
INSERT INTO public.event_data_keys VALUES ('noticeId');
INSERT INTO public.event_data_keys VALUES ('objectId');
INSERT INTO public.event_data_keys VALUES ('observed');
INSERT INTO public.event_data_keys VALUES ('ok');
INSERT INTO public.event_data_keys VALUES ('op');
INSERT INTO public.event_data_keys VALUES ('operation');
INSERT INTO public.event_data_keys VALUES ('outcome');
INSERT INTO public.event_data_keys VALUES ('owner');
INSERT INTO public.event_data_keys VALUES ('ownerUserId');
INSERT INTO public.event_data_keys VALUES ('pairKey');
INSERT INTO public.event_data_keys VALUES ('participantIds');
INSERT INTO public.event_data_keys VALUES ('password');
INSERT INTO public.event_data_keys VALUES ('postconditions');
INSERT INTO public.event_data_keys VALUES ('principal');
INSERT INTO public.event_data_keys VALUES ('project');
INSERT INTO public.event_data_keys VALUES ('projectId');
INSERT INTO public.event_data_keys VALUES ('prompt');
INSERT INTO public.event_data_keys VALUES ('provider');
INSERT INTO public.event_data_keys VALUES ('query');
INSERT INTO public.event_data_keys VALUES ('questionId');
INSERT INTO public.event_data_keys VALUES ('queue');
INSERT INTO public.event_data_keys VALUES ('reason');
INSERT INTO public.event_data_keys VALUES ('recipientId');
INSERT INTO public.event_data_keys VALUES ('recipients');
INSERT INTO public.event_data_keys VALUES ('record');
INSERT INTO public.event_data_keys VALUES ('recoveryCode');
INSERT INTO public.event_data_keys VALUES ('replayed');
INSERT INTO public.event_data_keys VALUES ('requestId');
INSERT INTO public.event_data_keys VALUES ('requestedQuestion');
INSERT INTO public.event_data_keys VALUES ('required');
INSERT INTO public.event_data_keys VALUES ('results');
INSERT INTO public.event_data_keys VALUES ('resume');
INSERT INTO public.event_data_keys VALUES ('retained');
INSERT INTO public.event_data_keys VALUES ('retryDelay');
INSERT INTO public.event_data_keys VALUES ('retryLimit');
INSERT INTO public.event_data_keys VALUES ('retryable');
INSERT INTO public.event_data_keys VALUES ('reviewerConnectionId');
INSERT INTO public.event_data_keys VALUES ('reviewerOwnerId');
INSERT INTO public.event_data_keys VALUES ('revision');
INSERT INTO public.event_data_keys VALUES ('role');
INSERT INTO public.event_data_keys VALUES ('rootId');
INSERT INTO public.event_data_keys VALUES ('rootMessageId');
INSERT INTO public.event_data_keys VALUES ('row');
INSERT INTO public.event_data_keys VALUES ('runId');
INSERT INTO public.event_data_keys VALUES ('runToken');
INSERT INTO public.event_data_keys VALUES ('runtime');
INSERT INTO public.event_data_keys VALUES ('sampleId');
INSERT INTO public.event_data_keys VALUES ('scope');
INSERT INTO public.event_data_keys VALUES ('session');
INSERT INTO public.event_data_keys VALUES ('sessionId');
INSERT INTO public.event_data_keys VALUES ('sketch');
INSERT INTO public.event_data_keys VALUES ('sketchId');
INSERT INTO public.event_data_keys VALUES ('source');
INSERT INTO public.event_data_keys VALUES ('sources');
INSERT INTO public.event_data_keys VALUES ('stage');
INSERT INTO public.event_data_keys VALUES ('state');
INSERT INTO public.event_data_keys VALUES ('status');
INSERT INTO public.event_data_keys VALUES ('step');
INSERT INTO public.event_data_keys VALUES ('stop');
INSERT INTO public.event_data_keys VALUES ('stopId');
INSERT INTO public.event_data_keys VALUES ('stopped');
INSERT INTO public.event_data_keys VALUES ('sweep');
INSERT INTO public.event_data_keys VALUES ('task');
INSERT INTO public.event_data_keys VALUES ('taskId');
INSERT INTO public.event_data_keys VALUES ('taskIds');
INSERT INTO public.event_data_keys VALUES ('taskNoticeId');
INSERT INTO public.event_data_keys VALUES ('tell');
INSERT INTO public.event_data_keys VALUES ('text');
INSERT INTO public.event_data_keys VALUES ('thought');
INSERT INTO public.event_data_keys VALUES ('thoughtId');
INSERT INTO public.event_data_keys VALUES ('thoughtIds');
INSERT INTO public.event_data_keys VALUES ('thoughts');
INSERT INTO public.event_data_keys VALUES ('title');
INSERT INTO public.event_data_keys VALUES ('to');
INSERT INTO public.event_data_keys VALUES ('toTitle');
INSERT INTO public.event_data_keys VALUES ('tool');
INSERT INTO public.event_data_keys VALUES ('tools');
INSERT INTO public.event_data_keys VALUES ('total');
INSERT INTO public.event_data_keys VALUES ('type');
INSERT INTO public.event_data_keys VALUES ('userId');
INSERT INTO public.event_data_keys VALUES ('value');
INSERT INTO public.event_data_keys VALUES ('verdict');
INSERT INTO public.event_data_keys VALUES ('version');
INSERT INTO public.event_data_keys VALUES ('view');
INSERT INTO public.event_data_keys VALUES ('visibility');
INSERT INTO public.event_data_keys VALUES ('waitingFor');
INSERT INTO public.event_data_keys VALUES ('width');
INSERT INTO public.event_data_keys VALUES ('window');
INSERT INTO public.event_data_keys VALUES ('work');
INSERT INTO public.event_data_keys VALUES ('workId');
INSERT INTO public.event_data_keys VALUES ('workerId');
INSERT INTO public.event_data_keys VALUES ('workspace');
INSERT INTO public.event_data_keys VALUES ('workspaceId');
INSERT INTO public.event_data_keys VALUES ('resumedFor');


--
-- Data for Name: event_data_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.event_data_tokens VALUES ('accepted');
INSERT INTO public.event_data_tokens VALUES ('admin');
INSERT INTO public.event_data_tokens VALUES ('affects');
INSERT INTO public.event_data_tokens VALUES ('agent');
INSERT INTO public.event_data_tokens VALUES ('assigned');
INSERT INTO public.event_data_tokens VALUES ('blocked');
INSERT INTO public.event_data_tokens VALUES ('contributor');
INSERT INTO public.event_data_tokens VALUES ('conversation');
INSERT INTO public.event_data_tokens VALUES ('creation_reverted');
INSERT INTO public.event_data_tokens VALUES ('decision');
INSERT INTO public.event_data_tokens VALUES ('denied');
INSERT INTO public.event_data_tokens VALUES ('dm');
INSERT INTO public.event_data_tokens VALUES ('doc');
INSERT INTO public.event_data_tokens VALUES ('done');
INSERT INTO public.event_data_tokens VALUES ('group');
INSERT INTO public.event_data_tokens VALUES ('guest');
INSERT INTO public.event_data_tokens VALUES ('human');
INSERT INTO public.event_data_tokens VALUES ('in_progress');
INSERT INTO public.event_data_tokens VALUES ('invitation');
INSERT INTO public.event_data_tokens VALUES ('left');
INSERT INTO public.event_data_tokens VALUES ('link_added');
INSERT INTO public.event_data_tokens VALUES ('link_removed');
INSERT INTO public.event_data_tokens VALUES ('link_updated');
INSERT INTO public.event_data_tokens VALUES ('map');
INSERT INTO public.event_data_tokens VALUES ('material');
INSERT INTO public.event_data_tokens VALUES ('member');
INSERT INTO public.event_data_tokens VALUES ('mention');
INSERT INTO public.event_data_tokens VALUES ('mentions');
INSERT INTO public.event_data_tokens VALUES ('message');
INSERT INTO public.event_data_tokens VALUES ('open');
INSERT INTO public.event_data_tokens VALUES ('owner');
INSERT INTO public.event_data_tokens VALUES ('pair');
INSERT INTO public.event_data_tokens VALUES ('password');
INSERT INTO public.event_data_tokens VALUES ('person');
INSERT INTO public.event_data_tokens VALUES ('private');
INSERT INTO public.event_data_tokens VALUES ('project');
INSERT INTO public.event_data_tokens VALUES ('proposed');
INSERT INTO public.event_data_tokens VALUES ('question');
INSERT INTO public.event_data_tokens VALUES ('recovery');
INSERT INTO public.event_data_tokens VALUES ('rejoined');
INSERT INTO public.event_data_tokens VALUES ('related');
INSERT INTO public.event_data_tokens VALUES ('renamed');
INSERT INTO public.event_data_tokens VALUES ('reply');
INSERT INTO public.event_data_tokens VALUES ('restart');
INSERT INTO public.event_data_tokens VALUES ('restricted');
INSERT INTO public.event_data_tokens VALUES ('review');
INSERT INTO public.event_data_tokens VALUES ('self');
INSERT INTO public.event_data_tokens VALUES ('sketch');
INSERT INTO public.event_data_tokens VALUES ('source');
INSERT INTO public.event_data_tokens VALUES ('superseded');
INSERT INTO public.event_data_tokens VALUES ('thought');
INSERT INTO public.event_data_tokens VALUES ('thought_added');
INSERT INTO public.event_data_tokens VALUES ('thought_removed');
INSERT INTO public.event_data_tokens VALUES ('thought_updated');
INSERT INTO public.event_data_tokens VALUES ('thoughts_moved');
INSERT INTO public.event_data_tokens VALUES ('wiki');
INSERT INTO public.event_data_tokens VALUES ('work');
INSERT INTO public.event_data_tokens VALUES ('workspace');
INSERT INTO public.event_data_tokens VALUES ('manager');


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.events VALUES ('e25c3909-8af2-4942-bccc-d475b0f3c595', 'workspace.created.v1', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{}', '2026-11-12 15:18:38.012485+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 1);
INSERT INTO public.events VALUES ('99697d6e-6c68-41a8-8a15-de72a9e6948b', 'project.created.v1', 'ceffd770-0489-4afd-8f95-837ba85efb04', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"visibility": "workspace"}', '2026-11-12 15:18:38.012485+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 2);
INSERT INTO public.events VALUES ('f3b70a21-bf10-449f-babf-347c144bca3a', 'workspace.renamed.v1', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{}', '2026-11-12 15:18:38.073426+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 3);
INSERT INTO public.events VALUES ('13738e61-0306-42c6-9d1b-22e190c83637', 'project.created.v1', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"visibility": "restricted"}', '2026-11-12 15:18:38.097328+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 4);
INSERT INTO public.events VALUES ('6049bc27-8308-45de-baef-07c9267c10a4', 'project.conversation_created.v1', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"messageId": "2bbf8af8-7fd7-47f5-bbc5-58cbebd7a0f1", "conversationId": "27728f1d-e825-4f1d-804f-0ddc3ce4f6c2"}', '2026-11-12 15:18:38.270003+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 5);
INSERT INTO public.events VALUES ('09f6e164-2afe-4643-b054-ed443283c45f', 'project.message_sent.v1', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"messageId": "68195a26-5cb5-4986-8462-162586cc6cf7", "conversationId": "27728f1d-e825-4f1d-804f-0ddc3ce4f6c2"}', '2026-11-12 15:18:38.305236+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 6);
INSERT INTO public.events VALUES ('327eb1b8-bed3-4669-a921-3ab3ee5de0eb', 'project.doc_created.v1', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"docId": "929c52fc-c9c0-4270-8be8-0ce47dfd5a02", "version": 1}', '2026-11-12 15:18:38.358374+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 7);
INSERT INTO public.events VALUES ('84f608cc-2037-4bbe-a475-62514330586f', 'project.doc_updated.v1', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"docId": "929c52fc-c9c0-4270-8be8-0ce47dfd5a02", "version": 2}', '2026-11-12 15:18:38.393062+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 8);
INSERT INTO public.events VALUES ('36b2fca2-e312-4543-85bd-8ef68a8a5495', 'project.work_created.v1', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"workId": "a8066141-6e45-4b46-8922-27378b6cda77"}', '2026-11-12 15:18:38.422879+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 9);
INSERT INTO public.events VALUES ('710f05c7-3f7c-4d1e-a2b8-34d2305f43f0', 'sketch.created.v1', '0cd01a9b-400b-49f6-927d-579196ecca3e', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"scope": "private", "thoughtIds": []}', '2026-11-12 15:18:38.454474+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 10);
INSERT INTO public.events VALUES ('9ea1d370-5957-46fe-8273-a43621c38afa', 'workspace.invite_created.v1', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"role": "member", "inviteId": "741dcf5f-9b5a-42f7-86be-6d03a358c8f3"}', '2026-11-12 15:18:38.813704+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 11);
INSERT INTO public.events VALUES ('3588bd6a-b263-4ac1-93d0-53c5b30079bc', 'workspace.member_added.v1', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'human:02f26b99-2df5-45f8-8529-1f662cde58d1', '{"role": "member", "userId": "02f26b99-2df5-45f8-8529-1f662cde58d1", "inviteId": "741dcf5f-9b5a-42f7-86be-6d03a358c8f3"}', '2026-11-12 15:18:38.838271+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 12);
INSERT INTO public.events VALUES ('02cef4e2-7b69-47d0-8d5b-1b55e4c0da11', 'workspace.invite_created.v1', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"role": "guest", "inviteId": "08d6544d-0033-4c07-b9b5-8f7366cbd26c"}', '2026-11-12 15:18:39.1787+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 13);
INSERT INTO public.events VALUES ('89bcd377-2a2c-4ddb-9965-b5d21c76084f', 'workspace.member_added.v1', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'human:7521935a-427b-4baf-b0ae-1072ddb9959c', '{"role": "guest", "userId": "7521935a-427b-4baf-b0ae-1072ddb9959c", "inviteId": "08d6544d-0033-4c07-b9b5-8f7366cbd26c"}', '2026-11-12 15:18:39.199808+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 14);
INSERT INTO public.events VALUES ('9c5a050c-4cf9-47c6-bbe7-b8adbb98d09f', 'project.created.v1', '3af3641b-2678-4b50-9473-1f9dab519167', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"visibility": "restricted"}', '2026-11-12 15:18:39.27492+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 15);
INSERT INTO public.events VALUES ('43c45cb8-6de5-42cd-bcb1-0734524773d0', 'project.grant_set.v1', '3af3641b-2678-4b50-9473-1f9dab519167', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"role": "contributor", "grantId": "2de9f729-8327-419e-9623-cc7e2e321127", "principal": {"id": "02f26b99-2df5-45f8-8529-1f662cde58d1", "kind": "human"}}', '2026-11-12 15:18:39.27492+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 16);
INSERT INTO public.events VALUES ('d502ba4c-241a-4f26-9183-2c4b6adb78e3', 'project.grant_set.v1', '3af3641b-2678-4b50-9473-1f9dab519167', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"role": "contributor", "grantId": "190349d3-bfe5-447e-911d-dd6d19b1ba05", "principal": {"id": "7521935a-427b-4baf-b0ae-1072ddb9959c", "kind": "human"}}', '2026-11-12 15:18:39.27492+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 17);
INSERT INTO public.events VALUES ('d2936d26-95ee-422f-9e77-4e5b33735550', 'project.conversation_created.v1', '3af3641b-2678-4b50-9473-1f9dab519167', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"messageId": "6d845243-829f-453c-93da-97018821ca86", "conversationId": "4704a97c-3d92-411a-9702-28c55321e47a"}', '2026-11-12 15:18:39.449591+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 18);
INSERT INTO public.events VALUES ('b108c5cf-b657-42ea-85a5-8230cc97fa7a', 'project.message_sent.v1', '3af3641b-2678-4b50-9473-1f9dab519167', 'human:02f26b99-2df5-45f8-8529-1f662cde58d1', '{"messageId": "58df9be6-7df7-4a9e-ae20-50a542ff9c84", "conversationId": "4704a97c-3d92-411a-9702-28c55321e47a"}', '2026-11-12 15:18:39.475787+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 19);
INSERT INTO public.events VALUES ('f5aedde3-3e74-493b-89d8-e1e27927a696', 'project.message_sent.v1', '3af3641b-2678-4b50-9473-1f9dab519167', 'human:7521935a-427b-4baf-b0ae-1072ddb9959c', '{"messageId": "ba61b29d-f1fc-42a2-81c8-d019554990d7", "conversationId": "4704a97c-3d92-411a-9702-28c55321e47a"}', '2026-11-12 15:18:39.512059+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 20);
INSERT INTO public.events VALUES ('f329bc4d-a348-40ce-9298-012317be66a7', 'dm.created.v1', 'ffd70895-f293-4edf-af57-e19ad0a448a8', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"kind": "pair"}', '2026-11-12 15:18:39.543308+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 21);
INSERT INTO public.events VALUES ('2c11d8cc-5f77-4d99-acc1-7fc86e094f63', 'dm.message_sent.v1', 'ffd70895-f293-4edf-af57-e19ad0a448a8', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"messageId": "54f3c21e-d3f7-400f-8d9f-583b09c6d6f5"}', '2026-11-12 15:18:39.57304+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 22);
INSERT INTO public.events VALUES ('bd25c703-993f-462d-ac63-70418cad71d9', 'dm.message_sent.v1', 'ffd70895-f293-4edf-af57-e19ad0a448a8', 'human:02f26b99-2df5-45f8-8529-1f662cde58d1', '{"rootId": "54f3c21e-d3f7-400f-8d9f-583b09c6d6f5", "messageId": "bd14e24a-1549-4bc1-90fb-c7829aff3b87"}', '2026-11-12 15:18:39.599915+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 23);
INSERT INTO public.events VALUES ('fae13e56-b8b2-4246-9069-4aa9928733c9', 'dm.created.v1', '72fe8726-9409-49d1-be95-94314d79337b', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"kind": "group"}', '2026-11-12 15:18:39.635946+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 24);
INSERT INTO public.events VALUES ('1b297cf2-5007-4aed-8b74-8f188f3d3d9f', 'dm.message_sent.v1', '72fe8726-9409-49d1-be95-94314d79337b', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"messageId": "ca3c7aae-a703-4f9a-a142-edc8dc7f1bbd"}', '2026-11-12 15:18:39.670741+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 25);
INSERT INTO public.events VALUES ('b4a89eef-411b-483d-8096-d86a5e98c021', 'project.doc_created.v1', '3af3641b-2678-4b50-9473-1f9dab519167', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"docId": "45babf5f-b0da-416e-a412-38b63f4358e9", "version": 1}', '2026-11-12 15:18:39.708786+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 26);
INSERT INTO public.events VALUES ('507e04e8-63a7-46d8-8417-8463dfaaaaf8', 'project.doc_updated.v1', '3af3641b-2678-4b50-9473-1f9dab519167', 'human:02f26b99-2df5-45f8-8529-1f662cde58d1', '{"docId": "45babf5f-b0da-416e-a412-38b63f4358e9", "version": 2}', '2026-11-12 15:18:39.742034+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 27);
INSERT INTO public.events VALUES ('cf27cfcc-f57b-4d93-b59d-e1f9d160c129', 'project.doc_updated.v1', '3af3641b-2678-4b50-9473-1f9dab519167', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"docId": "45babf5f-b0da-416e-a412-38b63f4358e9", "version": 3}', '2026-11-12 15:18:39.774958+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 28);
INSERT INTO public.events VALUES ('2ae9f565-302f-42ee-94bc-0b34ba8bcd11', 'sketch.created.v1', '0f67c50c-96ed-4b83-87cc-ec6c76ce69f0', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"scope": "project", "thoughtIds": []}', '2026-11-12 15:18:39.841484+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 29);
INSERT INTO public.events VALUES ('3be32f0a-a406-4fd9-afd8-079223422cda', 'sketch.changed.v1', '0f67c50c-96ed-4b83-87cc-ec6c76ce69f0', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"op": "thought_added", "linkIds": [], "thoughtIds": ["3c198cdd-d5b7-40b5-b8af-cbb74d44f49b"]}', '2026-11-12 15:18:39.885186+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 30);
INSERT INTO public.events VALUES ('66b3817d-fbbe-4b7d-add1-883c664159ec', 'sketch.changed.v1', '0f67c50c-96ed-4b83-87cc-ec6c76ce69f0', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"op": "thought_added", "linkIds": ["3b1e677f-9b75-4f9a-b397-73d3aec2abfd"], "thoughtIds": ["dd519e65-3a03-4e13-9a4d-41dd83140c8f"]}', '2026-11-12 15:18:39.920762+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 31);
INSERT INTO public.events VALUES ('495a7e59-26ea-4782-8a1f-396a1603d5ab', 'sketch.changed.v1', '0f67c50c-96ed-4b83-87cc-ec6c76ce69f0', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"op": "thought_added", "linkIds": ["97306fa8-4c57-49eb-8fce-36f4a86d5c77"], "thoughtIds": ["1701e9fb-1213-4cd8-a575-46451e40a2fb"]}', '2026-11-12 15:18:39.955783+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 32);
INSERT INTO public.events VALUES ('6715454e-b3c2-4422-a003-2340a4a046e0', 'project.work_created.v1', '3af3641b-2678-4b50-9473-1f9dab519167', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"workId": "f1c5e0e8-f071-4bbe-a1c5-e87df6093c35", "assignedTo": "02f26b99-2df5-45f8-8529-1f662cde58d1"}', '2026-11-12 15:18:39.994218+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 33);
INSERT INTO public.events VALUES ('b3514b6a-6cdd-4699-ac4c-0d40d10add04', 'project.work_created.v1', '3af3641b-2678-4b50-9473-1f9dab519167', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"workId": "9313f031-a292-4711-b014-2acc8d3ea870"}', '2026-11-12 15:18:40.031682+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 34);
INSERT INTO public.events VALUES ('a07f5e4b-66c9-4ab5-a9d7-69279b3154ba', 'project.work_created.v1', '3af3641b-2678-4b50-9473-1f9dab519167', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"workId": "b9f4af8b-ce89-4512-939c-c48f5bc34ffd", "waitingFor": "02f26b99-2df5-45f8-8529-1f662cde58d1"}', '2026-11-12 15:18:40.086222+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 35);
INSERT INTO public.events VALUES ('d700e729-4241-49e3-835f-acae6ff903d6', 'workspace.created.v1', 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{}', '2026-11-12 15:18:40.348084+00', 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', 36);
INSERT INTO public.events VALUES ('8b825966-b202-409f-9573-d8787f47c1c9', 'workspace.unlocked.v1', 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"by": "64d60389-a836-4818-b7b8-4e0abb5b65b7"}', '2026-11-12 15:18:40.348084+00', 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', 37);
INSERT INTO public.events VALUES ('df2eee02-f432-4ee4-a16f-954da92d6a81', 'project.created.v1', '4ec1e811-c87f-4d03-9b19-a9b1457b033d', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"visibility": "workspace"}', '2026-11-12 15:18:40.379685+00', 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', 38);
INSERT INTO public.events VALUES ('bb61a29d-1f7e-4331-9d5e-11fab9345643', 'project.conversation_created.v1', '4ec1e811-c87f-4d03-9b19-a9b1457b033d', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"messageId": "1e2b1ed2-96ef-4e4d-a3c5-cbf298aa94af", "conversationId": "17302516-a644-4408-9a44-22b99ffb270d"}', '2026-11-12 15:18:40.427611+00', 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', 39);
INSERT INTO public.events VALUES ('fa99921c-81ce-417d-88a6-22196ba12af9', 'workspace.locked.v1', 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"reason": "person"}', '2026-11-12 15:18:40.453188+00', 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', 40);
INSERT INTO public.events VALUES ('cb2d3710-4b29-437b-a2dd-de00b567ac1a', 'agent.created.v1', '9d34944a-d131-4acb-9091-873fa03b5764', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"owner": "self"}', '2026-11-12 15:18:40.504769+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 41);
INSERT INTO public.events VALUES ('380ecbd4-52ef-4242-803e-18f57fefdb35', 'agent.created.v1', 'b8a60e4b-1a7d-4bbd-b7b1-946d2fcc9697', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"owner": "self"}', '2026-11-12 15:18:40.544375+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 42);
INSERT INTO public.events VALUES ('b89818af-020a-43c4-825e-eea33af1089f', 'assistant_run.changed.v1', 'dc0d8004-d3fd-401c-917d-6503a961a939', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"status": "queued"}', '2026-11-12 15:18:40.677272+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 43);
INSERT INTO public.events VALUES ('f028cca5-9107-4f09-a929-ad42b68e20ca', 'assistant_run.changed.v1', 'dc0d8004-d3fd-401c-917d-6503a961a939', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"status": "reading"}', '2026-11-12 15:18:40.751975+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 44);
INSERT INTO public.events VALUES ('19f14d93-08d9-442a-a2e6-48e586f109fd', 'assistant_run.changed.v1', 'dc0d8004-d3fd-401c-917d-6503a961a939', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"status": "dispatching"}', '2026-11-12 15:18:40.984889+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 45);
INSERT INTO public.events VALUES ('0bb04fbd-f89d-4574-b0c9-8fefb68ecbca', 'assistant_run.changed.v1', 'dc0d8004-d3fd-401c-917d-6503a961a939', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"status": "completed"}', '2026-11-12 15:18:41.038074+00', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 46);


--
-- Data for Name: file_garbage; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: flux_schema_version; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.flux_schema_version VALUES (1, '2026-11-12 15:18:30.696728+00');
INSERT INTO public.flux_schema_version VALUES (2, '2026-11-12 15:18:31.505972+00');
INSERT INTO public.flux_schema_version VALUES (3, '2026-11-12 15:18:31.552745+00');
INSERT INTO public.flux_schema_version VALUES (4, '2026-11-12 15:18:31.618393+00');
INSERT INTO public.flux_schema_version VALUES (5, '2026-11-12 15:18:31.662595+00');
INSERT INTO public.flux_schema_version VALUES (6, '2026-11-12 15:18:31.690118+00');
INSERT INTO public.flux_schema_version VALUES (7, '2026-11-12 15:18:31.710509+00');
INSERT INTO public.flux_schema_version VALUES (8, '2026-11-12 15:18:31.739202+00');
INSERT INTO public.flux_schema_version VALUES (9, '2026-11-12 15:18:31.755802+00');
INSERT INTO public.flux_schema_version VALUES (10, '2026-11-12 15:18:31.784338+00');
INSERT INTO public.flux_schema_version VALUES (11, '2026-11-12 15:18:31.801497+00');
INSERT INTO public.flux_schema_version VALUES (12, '2026-11-12 15:18:31.828484+00');
INSERT INTO public.flux_schema_version VALUES (13, '2026-11-12 15:18:31.84701+00');
INSERT INTO public.flux_schema_version VALUES (14, '2026-11-12 15:18:31.865595+00');
INSERT INTO public.flux_schema_version VALUES (15, '2026-11-12 15:18:31.903238+00');
INSERT INTO public.flux_schema_version VALUES (16, '2026-11-12 15:18:31.933084+00');
INSERT INTO public.flux_schema_version VALUES (17, '2026-11-12 15:18:32.008055+00');
INSERT INTO public.flux_schema_version VALUES (18, '2026-11-12 15:18:32.026399+00');
INSERT INTO public.flux_schema_version VALUES (19, '2026-11-12 15:18:32.044529+00');
INSERT INTO public.flux_schema_version VALUES (20, '2026-11-12 15:18:32.062906+00');
INSERT INTO public.flux_schema_version VALUES (21, '2026-11-12 15:18:32.085777+00');
INSERT INTO public.flux_schema_version VALUES (22, '2026-11-12 15:18:32.106743+00');
INSERT INTO public.flux_schema_version VALUES (23, '2026-11-12 15:18:32.164772+00');
INSERT INTO public.flux_schema_version VALUES (24, '2026-11-12 15:18:32.183195+00');
INSERT INTO public.flux_schema_version VALUES (25, '2026-11-12 15:18:32.212112+00');
INSERT INTO public.flux_schema_version VALUES (26, '2026-11-12 15:18:32.243673+00');
INSERT INTO public.flux_schema_version VALUES (27, '2026-11-12 15:18:32.280572+00');
INSERT INTO public.flux_schema_version VALUES (28, '2026-11-12 15:18:32.328358+00');
INSERT INTO public.flux_schema_version VALUES (29, '2026-11-12 15:18:32.368003+00');
INSERT INTO public.flux_schema_version VALUES (30, '2026-11-12 15:18:32.384791+00');
INSERT INTO public.flux_schema_version VALUES (31, '2026-11-12 15:18:32.402092+00');
INSERT INTO public.flux_schema_version VALUES (32, '2026-11-12 15:18:32.421033+00');
INSERT INTO public.flux_schema_version VALUES (35, '2026-11-12 15:18:32.439743+00');
INSERT INTO public.flux_schema_version VALUES (36, '2026-11-12 15:18:32.469745+00');
INSERT INTO public.flux_schema_version VALUES (37, '2026-11-12 15:18:32.488662+00');
INSERT INTO public.flux_schema_version VALUES (38, '2026-11-12 15:18:32.53547+00');
INSERT INTO public.flux_schema_version VALUES (39, '2026-11-12 15:18:32.553673+00');
INSERT INTO public.flux_schema_version VALUES (40, '2026-11-12 15:18:32.5729+00');
INSERT INTO public.flux_schema_version VALUES (41, '2026-11-12 15:18:32.625579+00');
INSERT INTO public.flux_schema_version VALUES (42, '2026-11-12 15:18:32.643254+00');
INSERT INTO public.flux_schema_version VALUES (43, '2026-11-12 15:18:32.660415+00');
INSERT INTO public.flux_schema_version VALUES (44, '2026-11-12 15:18:32.679704+00');
INSERT INTO public.flux_schema_version VALUES (46, '2026-11-12 15:18:32.717667+00');
INSERT INTO public.flux_schema_version VALUES (47, '2026-11-12 15:18:32.735853+00');
INSERT INTO public.flux_schema_version VALUES (48, '2026-11-12 15:18:32.758205+00');
INSERT INTO public.flux_schema_version VALUES (49, '2026-11-12 15:18:32.773834+00');
INSERT INTO public.flux_schema_version VALUES (50, '2026-11-12 15:18:32.791067+00');
INSERT INTO public.flux_schema_version VALUES (51, '2026-11-12 15:18:32.809903+00');
INSERT INTO public.flux_schema_version VALUES (52, '2026-11-12 15:18:32.829987+00');
INSERT INTO public.flux_schema_version VALUES (53, '2026-11-12 15:18:32.849309+00');


--
-- Data for Name: github_bindings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: github_credentials; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: github_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: github_oauth_flows; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: github_processing; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: github_rule_defaults; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: github_task_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: github_task_rule_changes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: github_task_rules; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: idempotency_account_operations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/agent-questions/:questionId/answer');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/assistant-runs/:runId/retry');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/assistant-runs/:runId/stop');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/conversations/:conversationId/assistant-runs');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/workspaces');
INSERT INTO public.idempotency_account_operations VALUES ('PUT /api/v1/personal-assistant/model');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/my-agents');
INSERT INTO public.idempotency_account_operations VALUES ('PATCH /api/v1/my-agents/:agentId');
INSERT INTO public.idempotency_account_operations VALUES ('DELETE /api/v1/my-agents/:agentId');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/my-agents/:agentId/memory');
INSERT INTO public.idempotency_account_operations VALUES ('PATCH /api/v1/my-agents/:agentId/memory/:itemId');
INSERT INTO public.idempotency_account_operations VALUES ('DELETE /api/v1/my-agents/:agentId/memory/:itemId');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/projects/:projectId/assistant-runs');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/dms/:dmId/assistant-runs');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/my-agents/:agentId/assistant-runs');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/assistant-runs/:runId/show');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/assistant-runs/:runId/dismiss');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/dms/:dmId/threads/:rootId/assistant-runs');


--
-- Data for Name: idempotency_keys; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.idempotency_keys VALUES ('3061b3b8-82bf-4b4d-a1ab-9b4615a63ca7', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'POST /api/v1/projects/:projectId/docs', '45ee3efe-ecee-4e4f-82f1-bb9059884c12', '6afbd596054ac9351e5eb28cef1ccaf7e3aa47d17c3e3f675e80bf669064cc42', 201, '{"id": "929c52fc-c9c0-4270-8be8-0ce47dfd5a02", "body": "RELEASE-doc-7e3c66b9-v1", "html": "<p>RELEASE-doc-7e3c66b9-v1</p>\n", "docId": "929c52fc-c9c0-4270-8be8-0ce47dfd5a02", "links": [], "title": "RELEASE-doc-7e3c66b9", "author": {"id": "64d60389-a836-4818-b7b8-4e0abb5b65b7", "kind": "human", "name": "Release smoke user"}, "reason": "Started the page", "version": 1, "audience": {"kind": "project", "projectId": "a2ac3b93-9f52-4192-a6b6-762a3e63aec4"}, "mentions": [], "createdAt": "2026-11-12T15:18:38.358Z", "createdBy": {"id": "64d60389-a836-4818-b7b8-4e0abb5b65b7", "kind": "human", "name": "Release smoke user"}, "projectId": "a2ac3b93-9f52-4192-a6b6-762a3e63aec4", "startedAt": "2026-11-12T15:18:38.358Z", "workspaceId": "db2917d2-9c76-4600-979b-62cde4a8a63b"}', '"1"', '2026-11-12 15:18:38.358374+00', '2026-11-13 15:18:38.358374+00');
INSERT INTO public.idempotency_keys VALUES ('b816b87f-d586-4032-b0a4-77d7c1539108', 'human:64d60389-a836-4818-b7b8-4e0abb5b65b7', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'POST /api/v1/projects/:projectId/docs', 'f6acb3c7-5338-4d6d-bef4-c5f5f7e54b75', '607db986d5a7b0fe97ed024ba791c570d90f8b7be361c28ef7373d182590024f', 201, '{"id": "45babf5f-b0da-416e-a412-38b63f4358e9", "body": "GARDEN-wiki-7e3c66b9-v1", "html": "<p>GARDEN-wiki-7e3c66b9-v1</p>\n", "docId": "45babf5f-b0da-416e-a412-38b63f4358e9", "links": [], "title": "GARDEN-wiki-7e3c66b9", "author": {"id": "64d60389-a836-4818-b7b8-4e0abb5b65b7", "kind": "human", "name": "Release smoke user"}, "reason": "Started the page", "version": 1, "audience": {"kind": "project", "projectId": "3af3641b-2678-4b50-9473-1f9dab519167"}, "mentions": [], "createdAt": "2026-11-12T15:18:39.708Z", "createdBy": {"id": "64d60389-a836-4818-b7b8-4e0abb5b65b7", "kind": "human", "name": "Release smoke user"}, "projectId": "3af3641b-2678-4b50-9473-1f9dab519167", "startedAt": "2026-11-12T15:18:39.708Z", "workspaceId": "db2917d2-9c76-4600-979b-62cde4a8a63b"}', '"1"', '2026-11-12 15:18:39.708786+00', '2026-11-13 15:18:39.708786+00');


--
-- Data for Name: jwks; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.jwks VALUES ('3b797910-d84c-4720-9266-ba758bcc20b5', '{"kty":"OKP","crv":"Ed25519","x":"ZqenD8ETNcSDbNzCo6OdTxN8O3typdlcElMG4JM1X5Y"}', '"791cf9958c9a0ee88cc009668ac09f5f0114c46a58eb28684656af3ff6a7d5996cc625ce15094082e051b3bf66c18ac7a7663381a3c0b3caa36e4c68e237c80c6f232754063048799269a70b03e73575ce433cace4a4fe34a4775c769e5a6993b5c28b89e1233d25d04c709d40125184925afd2aa8572f42b7cd7865ee4c0c97591cd67df3b6415f28a1e17e4783ed0674ce54ec53be1916e4bd55eeffbf278d34c125f77b9c80e74a"', '2026-11-12 15:18:40.859+00', NULL, 'EdDSA', 'Ed25519');


--
-- Data for Name: live_access_fences; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: live_admissions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: live_editing_intents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: live_invitations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: live_presentations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: live_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: live_webhook_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: map_live_gestures; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: map_live_heads; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: map_live_journal; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: map_live_object_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: map_live_presence; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: map_live_undone; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: message_references; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: native_command_receipts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: needs_you_states; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notification_address_sends; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notification_address_tokens; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notification_addresses; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notification_cursor; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.notification_cursor VALUES ('generator', 46);


--
-- Data for Name: notification_emails; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notification_generation_failures; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notification_mutes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.notification_mutes VALUES ('64d60389-a836-4818-b7b8-4e0abb5b65b7', 'project', '3af3641b-2678-4b50-9473-1f9dab519167', '2026-11-12 15:18:40.163004+00');


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.notification_preferences VALUES ('64d60389-a836-4818-b7b8-4e0abb5b65b7', true, 1320, 420, 'Europe/Warsaw', '2026-11-12 15:18:40.133+00', 'everything', true, true);


--
-- Data for Name: notification_verification_sends; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.notifications VALUES ('e8e118ac-2620-4616-9934-09a02b28b535', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'workspace', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'Ben Member joined Release restore probe', 'They are in Everyone now. Add them to other spaces in each space’s settings.', '/settings/company', NULL, '2026-11-12 15:18:38.838271+00', NULL, NULL, true, false);
INSERT INTO public.notifications VALUES ('090fe0bd-d309-4765-a539-9fa45b85dbb9', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'workspace', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'Gina Guest joined Release restore probe', 'They are a guest: they see only the spaces you add them to, in each space’s settings.', '/settings/company', NULL, '2026-11-12 15:18:39.199808+00', NULL, NULL, true, false);
INSERT INTO public.notifications VALUES ('da90b30b-f40d-4b50-a2fa-c474e5e2ecdc', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project', '3af3641b-2678-4b50-9473-1f9dab519167', 'Ben Member replied in “GARDEN-root-7e3c66b9”', 'GARDEN-ben-7e3c66b9', '/projects/3af3641b-2678-4b50-9473-1f9dab519167/conversations/4704a97c-3d92-411a-9702-28c55321e47a#message-58df9be6-7df7-4a9e-ae20-50a542ff9c84', NULL, '2026-11-12 15:18:39.508933+00', 'reply', 'b108c5cf-b657-42ea-85a5-8230cc97fa7a', true, false);
INSERT INTO public.notifications VALUES ('5097c87b-2845-4fda-9d34-6cefe2a44458', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project', '3af3641b-2678-4b50-9473-1f9dab519167', 'Gina Guest replied in “GARDEN-root-7e3c66b9”', 'GARDEN-gina-7e3c66b9', '/projects/3af3641b-2678-4b50-9473-1f9dab519167/conversations/4704a97c-3d92-411a-9702-28c55321e47a#message-ba61b29d-f1fc-42a2-81c8-d019554990d7', NULL, '2026-11-12 15:18:39.553534+00', 'reply', 'f5aedde3-3e74-493b-89d8-e1e27927a696', true, false);
INSERT INTO public.notifications VALUES ('6863345e-1964-4f15-a9be-e3522d4c0a5f', '02f26b99-2df5-45f8-8529-1f662cde58d1', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project', '3af3641b-2678-4b50-9473-1f9dab519167', 'Gina Guest replied in “GARDEN-root-7e3c66b9”', 'GARDEN-gina-7e3c66b9', '/projects/3af3641b-2678-4b50-9473-1f9dab519167/conversations/4704a97c-3d92-411a-9702-28c55321e47a#message-ba61b29d-f1fc-42a2-81c8-d019554990d7', NULL, '2026-11-12 15:18:39.553534+00', 'reply', 'f5aedde3-3e74-493b-89d8-e1e27927a696', true, false);
INSERT INTO public.notifications VALUES ('5f2a0152-aec0-4d8f-8ac3-4a80df69548f', '02f26b99-2df5-45f8-8529-1f662cde58d1', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'dm', 'ffd70895-f293-4edf-af57-e19ad0a448a8', 'Release smoke user sent you a message', 'DM-hello-7e3c66b9', '/dm/ffd70895-f293-4edf-af57-e19ad0a448a8#message-54f3c21e-d3f7-400f-8d9f-583b09c6d6f5', NULL, '2026-11-12 15:18:39.613485+00', 'dm', '2c11d8cc-5f77-4d99-acc1-7fc86e094f63', true, false);
INSERT INTO public.notifications VALUES ('8213a94b-3214-4d3f-ab6d-3822a32a37e6', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'dm', 'ffd70895-f293-4edf-af57-e19ad0a448a8', 'Ben Member sent you a message', 'DM-reply-7e3c66b9', '/dm/ffd70895-f293-4edf-af57-e19ad0a448a8#message-bd14e24a-1549-4bc1-90fb-c7829aff3b87', NULL, '2026-11-12 15:18:39.649316+00', 'dm', 'bd25c703-993f-462d-ac63-70418cad71d9', true, false);
INSERT INTO public.notifications VALUES ('42a6fd33-880e-4c05-ae33-6b3e455e42ab', '02f26b99-2df5-45f8-8529-1f662cde58d1', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'dm', '72fe8726-9409-49d1-be95-94314d79337b', 'Release smoke user in “Garden crew 7e3c66b9”', 'GROUP-hello-7e3c66b9', '/dm/72fe8726-9409-49d1-be95-94314d79337b#message-ca3c7aae-a703-4f9a-a142-edc8dc7f1bbd', NULL, '2026-11-12 15:18:39.719259+00', 'dm', '1b297cf2-5007-4aed-8b74-8f188f3d3d9f', true, false);
INSERT INTO public.notifications VALUES ('cbb2fc81-b7a6-433f-a426-25ee4cb6a8e2', '7521935a-427b-4baf-b0ae-1072ddb9959c', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'dm', '72fe8726-9409-49d1-be95-94314d79337b', 'Release smoke user in “Garden crew 7e3c66b9”', 'GROUP-hello-7e3c66b9', '/dm/72fe8726-9409-49d1-be95-94314d79337b#message-ca3c7aae-a703-4f9a-a142-edc8dc7f1bbd', NULL, '2026-11-12 15:18:39.719259+00', 'dm', '1b297cf2-5007-4aed-8b74-8f188f3d3d9f', true, false);
INSERT INTO public.notifications VALUES ('04a94bf3-7463-4d27-b64b-c564aff3341f', '02f26b99-2df5-45f8-8529-1f662cde58d1', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project', '3af3641b-2678-4b50-9473-1f9dab519167', 'Release smoke user assigned you “GARDEN-calibrate-7e3c66b9”', 'Work in Garden space', '/projects/3af3641b-2678-4b50-9473-1f9dab519167/tasks?open=work:f1c5e0e8-f071-4bbe-a1c5-e87df6093c35', NULL, '2026-11-12 15:18:40.027464+00', 'assigned', '6715454e-b3c2-4422-a003-2340a4a046e0', true, false);
INSERT INTO public.notifications VALUES ('77143f18-49d6-45fa-9108-2f1b2465e764', '02f26b99-2df5-45f8-8529-1f662cde58d1', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project', '3af3641b-2678-4b50-9473-1f9dab519167', 'Release smoke user is waiting for you: #3 GARDEN-approve-7e3c66b9', 'needs a decision of the owner', '/projects/3af3641b-2678-4b50-9473-1f9dab519167/tasks?open=work:b9f4af8b-ce89-4512-939c-c48f5bc34ffd', NULL, '2026-11-12 15:18:40.119594+00', 'assigned', 'a07f5e4b-66c9-4ab5-a9d7-69279b3154ba', true, false);


--
-- Data for Name: oauth_access_token; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: oauth_client; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: oauth_client_assertion; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: oauth_client_resource; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: oauth_consent; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: oauth_grant_authentication; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: oauth_refresh_token; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: oauth_resource; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.oauth_resource VALUES ('7bcf7407-b44a-491a-b129-98f723408edb', 'http://127.0.0.1:25801/mcp', 'http://127.0.0.1:25801/mcp', NULL, NULL, NULL, NULL, NULL, NULL, false, false, '2026-11-12 15:18:36.594+00', '2026-11-12 15:18:36.594+00', 1, NULL);


--
-- Data for Name: outbox; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: password_attempts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: personal_run_private_texts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: personal_run_web_reads; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: personal_run_web_searches; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: personal_runs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.personal_runs VALUES ('dc0d8004-d3fd-401c-917d-6503a961a939', 'db2917d2-9c76-4600-979b-62cde4a8a63b', NULL, NULL, '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'b8a60e4b-1a7d-4bbd-b7b1-946d2fcc9697', 'a5218913-f285-4952-b6a2-ff89035d81cd', 'dc3ad31a-0a5e-4f56-a872-56446a1051cd', '58404308468ee1445c4ee47de4c9769294ad7be7fe8ef1bd5cc5d5ad185cd6ee', 'ask', 'What is the garden plan? (7e3c66b9)', NULL, NULL, NULL, NULL, 'completed', NULL, NULL, 'observed', 0, 0, 12, 8, 'upgrade-check-model', 'UPGRADE-CHECK-ANSWER: the provider mock answered.', false, '[]', '2026-11-12 15:18:41.047+00', '2026-11-12 15:18:40.677272+00', '2026-11-12 15:18:41+00', '2026-11-12 15:18:41.047+00', '2026-11-12 15:18:41.059+00', 'openai_compatible', 'server', NULL, NULL, NULL, false, NULL, '77de3cd1-5f72-421c-864f-4bb8035f7513', '2026-11-12 16:23:40.84+00', '2026-11-12 15:18:41.059481+00', '{flux_changes_since,flux_get_conversation,flux_get_decision,flux_get_doc,flux_get_map,flux_get_task_discussion,flux_get_work,flux_list_contexts,flux_list_conversations,flux_list_decisions,flux_list_docs,flux_list_maps,flux_list_materials,flux_list_work,flux_project_orientation,flux_read_material,flux_read_web,flux_search_project}', 0, NULL, 'owner_request', NULL, NULL, NULL, '2026-11-12 15:18:40.77+00', 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL);


--
-- Data for Name: project_ai_policies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_ai_policies VALUES ('ceffd770-0489-4afd-8f95-837ba85efb04', 'allowed', 1, NULL, '2026-11-12 15:18:38.012485+00');
INSERT INTO public.project_ai_policies VALUES ('a2ac3b93-9f52-4192-a6b6-762a3e63aec4', 'allowed', 1, NULL, '2026-11-12 15:18:38.097328+00');
INSERT INTO public.project_ai_policies VALUES ('3af3641b-2678-4b50-9473-1f9dab519167', 'allowed', 1, NULL, '2026-11-12 15:18:39.27492+00');
INSERT INTO public.project_ai_policies VALUES ('4ec1e811-c87f-4d03-9b19-a9b1457b033d', 'blocked', 1, NULL, '2026-11-12 15:18:40.379685+00');


--
-- Data for Name: project_conversations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_conversations VALUES ('27728f1d-e825-4f1d-804f-0ddc3ce4f6c2', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 3, '2026-11-12 15:18:38.270003+00', NULL);
INSERT INTO public.project_conversations VALUES ('4704a97c-3d92-411a-9702-28c55321e47a', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '3af3641b-2678-4b50-9473-1f9dab519167', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 4, '2026-11-12 15:18:39.449591+00', NULL);
INSERT INTO public.project_conversations VALUES ('17302516-a644-4408-9a44-22b99ffb270d', 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', '4ec1e811-c87f-4d03-9b19-a9b1457b033d', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 2, '2026-11-12 15:18:40.427611+00', NULL);


--
-- Data for Name: project_decisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_files; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_files VALUES ('90706e9c-a74a-4e2c-a606-d207b6cc0e1a', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, 'd609b8a9-a5da-49ad-96f9-4b76a4df34e1', NULL, 'release-probe.bin', 'ready', 5242880, 10, '5ee4e165e7030255912f6de8535b4234fecd9c37bcbac2c5dc818c72869d4e35', '2026-11-12 15:18:38.134122+00', '2026-11-12 15:18:38.248+00', NULL, '2bbf8af8-7fd7-47f5-bbc5-58cbebd7a0f1', 0, '2026-11-12 15:18:38.27+00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.project_files VALUES ('b5ba9455-5149-49f2-873c-fe48edabbb9f', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '3af3641b-2678-4b50-9473-1f9dab519167', '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, '12d1c82a-3983-47f7-bc70-72df74468dde', NULL, 'garden-notes.bin', 'ready', 5242880, 10, 'd1a66b4ab73f44e941a304d24c48a33e5f8b2d576ee05820686e366cc65d01ff', '2026-11-12 15:18:39.31019+00', '2026-11-12 15:18:39.428+00', NULL, '6d845243-829f-453c-93da-97018821ca86', 0, '2026-11-12 15:18:39.449+00', NULL, NULL, NULL, NULL, NULL);


--
-- Data for Name: project_grants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_grants VALUES ('4102b16f-b367-4790-95da-9376c1fba849', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'ceffd770-0489-4afd-8f95-837ba85efb04', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'manager', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:38.012485+00', '2026-11-12 15:18:38.012485+00');
INSERT INTO public.project_grants VALUES ('906d4f78-a530-4ff5-a56f-2b865fd8c711', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'manager', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:38.097328+00', '2026-11-12 15:18:38.097328+00');
INSERT INTO public.project_grants VALUES ('a1bc23cf-01f6-4fe5-8d3c-2e083f38ab20', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '3af3641b-2678-4b50-9473-1f9dab519167', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'manager', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:39.27492+00', '2026-11-12 15:18:39.27492+00');
INSERT INTO public.project_grants VALUES ('2de9f729-8327-419e-9623-cc7e2e321127', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '3af3641b-2678-4b50-9473-1f9dab519167', '02f26b99-2df5-45f8-8529-1f662cde58d1', 'contributor', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:39.27492+00', '2026-11-12 15:18:39.27492+00');
INSERT INTO public.project_grants VALUES ('190349d3-bfe5-447e-911d-dd6d19b1ba05', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '3af3641b-2678-4b50-9473-1f9dab519167', '7521935a-427b-4baf-b0ae-1072ddb9959c', 'contributor', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:39.27492+00', '2026-11-12 15:18:39.27492+00');
INSERT INTO public.project_grants VALUES ('f3450702-f7ad-4a30-953e-305de83342b0', 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', '4ec1e811-c87f-4d03-9b19-a9b1457b033d', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'manager', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:40.379685+00', '2026-11-12 15:18:40.379685+00');


--
-- Data for Name: project_material_versions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_material_versions VALUES ('db2917d2-9c76-4600-979b-62cde4a8a63b', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', '929c52fc-c9c0-4270-8be8-0ce47dfd5a02', 1, 'RELEASE-doc-7e3c66b9', 'RELEASE-doc-7e3c66b9-v1', NULL, '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, NULL, '2026-11-12 15:18:38.358374+00', 'Started the page', NULL);
INSERT INTO public.project_material_versions VALUES ('db2917d2-9c76-4600-979b-62cde4a8a63b', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', '929c52fc-c9c0-4270-8be8-0ce47dfd5a02', 2, 'RELEASE-doc-7e3c66b9', 'RELEASE-doc-7e3c66b9-v2', NULL, '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, NULL, '2026-11-12 15:18:38.393062+00', 'Edited the text', NULL);
INSERT INTO public.project_material_versions VALUES ('db2917d2-9c76-4600-979b-62cde4a8a63b', '3af3641b-2678-4b50-9473-1f9dab519167', '45babf5f-b0da-416e-a412-38b63f4358e9', 1, 'GARDEN-wiki-7e3c66b9', 'GARDEN-wiki-7e3c66b9-v1', NULL, '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, NULL, '2026-11-12 15:18:39.708786+00', 'Started the page', NULL);
INSERT INTO public.project_material_versions VALUES ('db2917d2-9c76-4600-979b-62cde4a8a63b', '3af3641b-2678-4b50-9473-1f9dab519167', '45babf5f-b0da-416e-a412-38b63f4358e9', 2, 'GARDEN-wiki-7e3c66b9', 'GARDEN-wiki-7e3c66b9-v2', NULL, '02f26b99-2df5-45f8-8529-1f662cde58d1', NULL, NULL, '2026-11-12 15:18:39.742034+00', 'Edited the text', NULL);
INSERT INTO public.project_material_versions VALUES ('db2917d2-9c76-4600-979b-62cde4a8a63b', '3af3641b-2678-4b50-9473-1f9dab519167', '45babf5f-b0da-416e-a412-38b63f4358e9', 3, 'GARDEN-wiki-7e3c66b9', 'GARDEN-wiki-7e3c66b9-v3', NULL, '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, NULL, '2026-11-12 15:18:39.774958+00', 'Edited the text', NULL);


--
-- Data for Name: project_materials; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_materials VALUES ('929c52fc-c9c0-4270-8be8-0ce47dfd5a02', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, NULL, 2, '2026-11-12 15:18:38.358374+00', '2026-11-12 15:18:38.398+00', 'doc', NULL);
INSERT INTO public.project_materials VALUES ('45babf5f-b0da-416e-a412-38b63f4358e9', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '3af3641b-2678-4b50-9473-1f9dab519167', '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, NULL, 3, '2026-11-12 15:18:39.708786+00', '2026-11-12 15:18:39.779+00', 'doc', NULL);


--
-- Data for Name: project_message_observations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_messages; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_messages VALUES ('2bbf8af8-7fd7-47f5-bbc5-58cbebd7a0f1', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', '27728f1d-e825-4f1d-804f-0ddc3ce4f6c2', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'bf9a756b-5840-4082-b6ee-1bfde23eb090', '5fbc5661ba330bfb595dff2d74590c85a19b3397c604dfdfde024ac783448e6e', 1, 'RELEASE-message-7e3c66b9', NULL, NULL, '2026-11-12 15:18:38.270003+00', NULL, 'text', 1, NULL, NULL, NULL, false, false);
INSERT INTO public.project_messages VALUES ('68195a26-5cb5-4986-8462-162586cc6cf7', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', '27728f1d-e825-4f1d-804f-0ddc3ce4f6c2', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'd7f3e526-f7a3-43a7-bda2-781b37f1b822', '343ec23981d903ad0096ee9b5aba9d2695709aa15b50f8e7f24bfe69ede9d52b', 2, 'RELEASE-reply-7e3c66b9', NULL, NULL, '2026-11-12 15:18:38.305236+00', NULL, 'text', 0, NULL, NULL, NULL, false, false);
INSERT INTO public.project_messages VALUES ('6d845243-829f-453c-93da-97018821ca86', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '3af3641b-2678-4b50-9473-1f9dab519167', '4704a97c-3d92-411a-9702-28c55321e47a', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'c861c37d-1705-4262-a353-fd3609d25cb9', '448c7243e1999c80bbce65283420cdc9bf207316d15dd8eb6e6defa63641fbfb', 1, 'GARDEN-root-7e3c66b9', NULL, NULL, '2026-11-12 15:18:39.449591+00', NULL, 'text', 1, NULL, NULL, NULL, false, false);
INSERT INTO public.project_messages VALUES ('58df9be6-7df7-4a9e-ae20-50a542ff9c84', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '3af3641b-2678-4b50-9473-1f9dab519167', '4704a97c-3d92-411a-9702-28c55321e47a', '02f26b99-2df5-45f8-8529-1f662cde58d1', '79a012f0-1291-4184-9c55-85244fd0cd96', '01abaf8a83d2b48c4f6d130f5dc6c758f44477625dab0627b8215fd1d3a30ff3', 2, 'GARDEN-ben-7e3c66b9', NULL, NULL, '2026-11-12 15:18:39.475787+00', NULL, 'text', 0, NULL, NULL, NULL, false, false);
INSERT INTO public.project_messages VALUES ('ba61b29d-f1fc-42a2-81c8-d019554990d7', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '3af3641b-2678-4b50-9473-1f9dab519167', '4704a97c-3d92-411a-9702-28c55321e47a', '7521935a-427b-4baf-b0ae-1072ddb9959c', 'd12d89c9-e926-46ab-b200-0a968c300640', '08dcd5e60f0223ec8e6e1a7c613399c689ccfc443e7571896c41552727070bb4', 3, 'GARDEN-gina-7e3c66b9', NULL, NULL, '2026-11-12 15:18:39.512059+00', NULL, 'text', 0, NULL, NULL, NULL, false, false);
INSERT INTO public.project_messages VALUES ('1e2b1ed2-96ef-4e4d-a3c5-cbf298aa94af', 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', '4ec1e811-c87f-4d03-9b19-a9b1457b033d', '17302516-a644-4408-9a44-22b99ffb270d', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '7d4f907d-a975-4fb5-bd4c-04cc67e9d30b', 'fx1.1.aY0ueBRqqGzYoS1q-HSOkECpo-swyO1cvpmdNY3RIYZ04ttqcA7bLTfW_DyevwLL35Iehr_edEzZ55n3ci7QY5ReWNqZqp93NOMdozwZZM9CF-QGjy-Mi0rPtd8', 1, 'fx1.1.MvrkXgE_nGg0hscFT15Kb-XLJqqXQaopo0CszpDLpfdLAzSqKCA6CnLaETm5-SBh8A', NULL, NULL, '2026-11-12 15:18:40.427611+00', NULL, 'text', 0, NULL, NULL, NULL, false, false);


--
-- Data for Name: project_object_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_task_activity; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_task_dependencies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_task_dependencies VALUES ('db2917d2-9c76-4600-979b-62cde4a8a63b', '3af3641b-2678-4b50-9473-1f9dab519167', '9313f031-a292-4711-b014-2acc8d3ea870', 'f1c5e0e8-f071-4bbe-a1c5-e87df6093c35', '2026-11-12 15:18:40.031682+00');


--
-- Data for Name: project_task_discussions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_task_notices; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_task_notices VALUES ('7952c16f-1ada-483d-a953-af81096c6967', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', 'a8066141-6e45-4b46-8922-27378b6cda77', 'task.created', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '[]', '2026-11-12 15:18:38.422+00');
INSERT INTO public.project_task_notices VALUES ('6cacb448-eabb-49ca-8e73-efa38b7dd7f2', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '3af3641b-2678-4b50-9473-1f9dab519167', 'f1c5e0e8-f071-4bbe-a1c5-e87df6093c35', 'task.created', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '[]', '2026-11-12 15:18:39.994+00');
INSERT INTO public.project_task_notices VALUES ('558c7683-8aa0-40b2-af20-e2ca87cb6f80', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '3af3641b-2678-4b50-9473-1f9dab519167', '9313f031-a292-4711-b014-2acc8d3ea870', 'task.created', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '[]', '2026-11-12 15:18:40.031+00');
INSERT INTO public.project_task_notices VALUES ('0b191aca-d004-4882-a3eb-7c3c3dac8d41', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '3af3641b-2678-4b50-9473-1f9dab519167', 'b9f4af8b-ce89-4512-939c-c48f5bc34ffd', 'task.created', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '[]', '2026-11-12 15:18:40.086+00');


--
-- Data for Name: project_task_plan_intents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_task_updates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_work_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_work_items VALUES ('a8066141-6e45-4b46-8922-27378b6cda77', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', 'RELEASE-work-7e3c66b9', '', 'open', NULL, '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 1, '2026-11-12 15:18:38.422879+00', '2026-11-12 15:18:38.422879+00', NULL, NULL, '[]', 'human', '{"title": "RELEASE-work-7e3c66b9", "status": "open", "blocker": null, "outcome": "", "criteria": [], "ownerUserId": "64d60389-a836-4818-b7b8-4e0abb5b65b7", "ownerAgentId": null}', 1, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, false, NULL);
INSERT INTO public.project_work_items VALUES ('f1c5e0e8-f071-4bbe-a1c5-e87df6093c35', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '3af3641b-2678-4b50-9473-1f9dab519167', 'GARDEN-calibrate-7e3c66b9', '', 'open', NULL, '02f26b99-2df5-45f8-8529-1f662cde58d1', NULL, 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 1, '2026-11-12 15:18:39.994218+00', '2026-11-12 15:18:39.994218+00', NULL, NULL, '[]', 'human', '{"title": "GARDEN-calibrate-7e3c66b9", "status": "open", "blocker": null, "outcome": "", "criteria": [], "ownerUserId": "02f26b99-2df5-45f8-8529-1f662cde58d1", "ownerAgentId": null}', 1, '2026-11-12 15:18:40.048044+00', NULL, NULL, NULL, NULL, 1, NULL, '2027-03-01', NULL, NULL, false, NULL);
INSERT INTO public.project_work_items VALUES ('9313f031-a292-4711-b014-2acc8d3ea870', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '3af3641b-2678-4b50-9473-1f9dab519167', 'GARDEN-ship-7e3c66b9', '', 'blocked', 'needs calibration', NULL, NULL, 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 1, '2026-11-12 15:18:40.031682+00', '2026-11-12 15:18:40.031682+00', NULL, NULL, '[]', 'human', '{"title": "GARDEN-ship-7e3c66b9", "status": "blocked", "blocker": "needs calibration", "outcome": "", "criteria": [], "ownerUserId": null, "ownerAgentId": null}', 1, NULL, NULL, NULL, NULL, NULL, 2, NULL, '2027-03-15', NULL, 'f1c5e0e8-f071-4bbe-a1c5-e87df6093c35', false, NULL);
INSERT INTO public.project_work_items VALUES ('b9f4af8b-ce89-4512-939c-c48f5bc34ffd', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '3af3641b-2678-4b50-9473-1f9dab519167', 'GARDEN-approve-7e3c66b9', '', 'blocked', 'needs a decision of the owner', NULL, NULL, 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 1, '2026-11-12 15:18:40.086222+00', '2026-11-12 15:18:40.086222+00', NULL, NULL, '[]', 'human', '{"title": "GARDEN-approve-7e3c66b9", "status": "blocked", "blocker": "needs a decision of the owner", "outcome": "", "criteria": [], "ownerUserId": null, "ownerAgentId": null}', 1, NULL, NULL, NULL, NULL, NULL, 3, '02f26b99-2df5-45f8-8529-1f662cde58d1', '2027-04-01', NULL, NULL, false, NULL);


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.projects VALUES ('ceffd770-0489-4afd-8f95-837ba85efb04', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'Everyone', 'workspace', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 1, '2026-11-12 15:18:38.012485+00', '2026-11-12 15:18:38.012485+00');
INSERT INTO public.projects VALUES ('a2ac3b93-9f52-4192-a6b6-762a3e63aec4', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'Release project', 'restricted', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 1, '2026-11-12 15:18:38.097328+00', '2026-11-12 15:18:38.097328+00');
INSERT INTO public.projects VALUES ('3af3641b-2678-4b50-9473-1f9dab519167', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'Garden space', 'restricted', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 1, '2026-11-12 15:18:39.27492+00', '2026-11-12 15:18:39.27492+00');
INSERT INTO public.projects VALUES ('4ec1e811-c87f-4d03-9b19-a9b1457b033d', 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', 'fx1.1.TAxMyrcPKP5oxU119YIv-TqI4xrkW67sRtM5Fyd1iOnKFQvadRUvE4k', 'workspace', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 1, '2026-11-12 15:18:40.379685+00', '2026-11-12 15:18:40.379685+00');


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: return_points; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sample_results; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: samples; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sealed_job_waits; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: search_changes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.search_changes VALUES (1, 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', 'project:4ec1e811-c87f-4d03-9b19-a9b1457b033d', '2026-11-12 15:18:40.379685+00', '946');
INSERT INTO public.search_changes VALUES (2, 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', 'message:1e2b1ed2-96ef-4e4d-a3c5-cbf298aa94af', '2026-11-12 15:18:40.427611+00', '949');


--
-- Data for Name: search_documents; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (1, 'person:db2917d2-9c76-4600-979b-62cde4a8a63b:64d60389-a836-4818-b7b8-4e0abb5b65b7', 'person', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'members:db2917d2-9c76-4600-979b-62cde4a8a63b', NULL, '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, NULL, 'owner', 'Release smoke user', '', NULL, NULL, '2026-11-12 15:18:38.012485+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (2, 'project:ceffd770-0489-4afd-8f95-837ba85efb04', 'project', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project:ceffd770-0489-4afd-8f95-837ba85efb04', 'ceffd770-0489-4afd-8f95-837ba85efb04', 'ceffd770-0489-4afd-8f95-837ba85efb04', NULL, NULL, 'workspace', 'Everyone', '', NULL, NULL, '2026-11-12 15:18:38.012485+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (3, 'project:a2ac3b93-9f52-4192-a6b6-762a3e63aec4', 'project', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project:a2ac3b93-9f52-4192-a6b6-762a3e63aec4', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', NULL, NULL, 'restricted', 'Release project', '', NULL, NULL, '2026-11-12 15:18:38.097328+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (4, 'message:2bbf8af8-7fd7-47f5-bbc5-58cbebd7a0f1', 'message', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project:a2ac3b93-9f52-4192-a6b6-762a3e63aec4', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', '2bbf8af8-7fd7-47f5-bbc5-58cbebd7a0f1', '27728f1d-e825-4f1d-804f-0ddc3ce4f6c2', NULL, NULL, '', 'RELEASE-message-7e3c66b9', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:38.270003+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (5, 'message:68195a26-5cb5-4986-8462-162586cc6cf7', 'message', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project:a2ac3b93-9f52-4192-a6b6-762a3e63aec4', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', '68195a26-5cb5-4986-8462-162586cc6cf7', '27728f1d-e825-4f1d-804f-0ddc3ce4f6c2', NULL, NULL, '', 'RELEASE-reply-7e3c66b9', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:38.305236+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (6, 'material:929c52fc-c9c0-4270-8be8-0ce47dfd5a02:1', 'doc', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project:a2ac3b93-9f52-4192-a6b6-762a3e63aec4', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', '929c52fc-c9c0-4270-8be8-0ce47dfd5a02', NULL, 1, NULL, 'RELEASE-doc-7e3c66b9', 'RELEASE-doc-7e3c66b9-v1', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:38.358374+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (7, 'material:929c52fc-c9c0-4270-8be8-0ce47dfd5a02:2', 'doc', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project:a2ac3b93-9f52-4192-a6b6-762a3e63aec4', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', '929c52fc-c9c0-4270-8be8-0ce47dfd5a02', NULL, 2, NULL, 'RELEASE-doc-7e3c66b9', 'RELEASE-doc-7e3c66b9-v2', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:38.393062+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (8, 'work:a8066141-6e45-4b46-8922-27378b6cda77', 'work', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project:a2ac3b93-9f52-4192-a6b6-762a3e63aec4', 'a2ac3b93-9f52-4192-a6b6-762a3e63aec4', 'a8066141-6e45-4b46-8922-27378b6cda77', NULL, NULL, 'open', 'RELEASE-work-7e3c66b9', '#1', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:38.422879+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (10, 'sketch:0cd01a9b-400b-49f6-927d-579196ecca3e', 'sketch', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'sketch:0cd01a9b-400b-49f6-927d-579196ecca3e', NULL, '0cd01a9b-400b-49f6-927d-579196ecca3e', NULL, NULL, 'private', 'RELEASE-private-map-7e3c66b9', '', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:38.454474+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (11, 'person:db2917d2-9c76-4600-979b-62cde4a8a63b:02f26b99-2df5-45f8-8529-1f662cde58d1', 'person', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'members:db2917d2-9c76-4600-979b-62cde4a8a63b', NULL, '02f26b99-2df5-45f8-8529-1f662cde58d1', NULL, NULL, 'member', 'Ben Member', '', NULL, NULL, '2026-11-12 15:18:38.838271+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (12, 'person:db2917d2-9c76-4600-979b-62cde4a8a63b:7521935a-427b-4baf-b0ae-1072ddb9959c', 'person', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'members:db2917d2-9c76-4600-979b-62cde4a8a63b', NULL, '7521935a-427b-4baf-b0ae-1072ddb9959c', NULL, NULL, 'guest', 'Gina Guest', '', NULL, NULL, '2026-11-12 15:18:39.199808+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (13, 'project:3af3641b-2678-4b50-9473-1f9dab519167', 'project', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project:3af3641b-2678-4b50-9473-1f9dab519167', '3af3641b-2678-4b50-9473-1f9dab519167', '3af3641b-2678-4b50-9473-1f9dab519167', NULL, NULL, 'restricted', 'Garden space', '', NULL, NULL, '2026-11-12 15:18:39.27492+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (14, 'message:6d845243-829f-453c-93da-97018821ca86', 'message', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project:3af3641b-2678-4b50-9473-1f9dab519167', '3af3641b-2678-4b50-9473-1f9dab519167', '6d845243-829f-453c-93da-97018821ca86', '4704a97c-3d92-411a-9702-28c55321e47a', NULL, NULL, '', 'GARDEN-root-7e3c66b9', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:39.449591+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (15, 'message:58df9be6-7df7-4a9e-ae20-50a542ff9c84', 'message', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project:3af3641b-2678-4b50-9473-1f9dab519167', '3af3641b-2678-4b50-9473-1f9dab519167', '58df9be6-7df7-4a9e-ae20-50a542ff9c84', '4704a97c-3d92-411a-9702-28c55321e47a', NULL, NULL, '', 'GARDEN-ben-7e3c66b9', 'human', '02f26b99-2df5-45f8-8529-1f662cde58d1', '2026-11-12 15:18:39.475787+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (16, 'message:ba61b29d-f1fc-42a2-81c8-d019554990d7', 'message', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project:3af3641b-2678-4b50-9473-1f9dab519167', '3af3641b-2678-4b50-9473-1f9dab519167', 'ba61b29d-f1fc-42a2-81c8-d019554990d7', '4704a97c-3d92-411a-9702-28c55321e47a', NULL, NULL, '', 'GARDEN-gina-7e3c66b9', 'human', '7521935a-427b-4baf-b0ae-1072ddb9959c', '2026-11-12 15:18:39.512059+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (17, 'dm_message:54f3c21e-d3f7-400f-8d9f-583b09c6d6f5', 'dm_message', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'dm:ffd70895-f293-4edf-af57-e19ad0a448a8', NULL, '54f3c21e-d3f7-400f-8d9f-583b09c6d6f5', 'ffd70895-f293-4edf-af57-e19ad0a448a8', NULL, NULL, '', 'DM-hello-7e3c66b9', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:39.57304+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (18, 'dm_message:bd14e24a-1549-4bc1-90fb-c7829aff3b87', 'dm_message', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'dm:ffd70895-f293-4edf-af57-e19ad0a448a8', NULL, 'bd14e24a-1549-4bc1-90fb-c7829aff3b87', 'ffd70895-f293-4edf-af57-e19ad0a448a8', NULL, NULL, '', 'DM-reply-7e3c66b9', 'human', '02f26b99-2df5-45f8-8529-1f662cde58d1', '2026-11-12 15:18:39.599915+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (19, 'dm_message:ca3c7aae-a703-4f9a-a142-edc8dc7f1bbd', 'dm_message', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'dm:72fe8726-9409-49d1-be95-94314d79337b', NULL, 'ca3c7aae-a703-4f9a-a142-edc8dc7f1bbd', '72fe8726-9409-49d1-be95-94314d79337b', NULL, NULL, '', 'GROUP-hello-7e3c66b9', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:39.670741+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (20, 'material:45babf5f-b0da-416e-a412-38b63f4358e9:1', 'doc', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project:3af3641b-2678-4b50-9473-1f9dab519167', '3af3641b-2678-4b50-9473-1f9dab519167', '45babf5f-b0da-416e-a412-38b63f4358e9', NULL, 1, NULL, 'GARDEN-wiki-7e3c66b9', 'GARDEN-wiki-7e3c66b9-v1', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:39.708786+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (21, 'material:45babf5f-b0da-416e-a412-38b63f4358e9:2', 'doc', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project:3af3641b-2678-4b50-9473-1f9dab519167', '3af3641b-2678-4b50-9473-1f9dab519167', '45babf5f-b0da-416e-a412-38b63f4358e9', NULL, 2, NULL, 'GARDEN-wiki-7e3c66b9', 'GARDEN-wiki-7e3c66b9-v2', 'human', '02f26b99-2df5-45f8-8529-1f662cde58d1', '2026-11-12 15:18:39.742034+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (22, 'material:45babf5f-b0da-416e-a412-38b63f4358e9:3', 'doc', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project:3af3641b-2678-4b50-9473-1f9dab519167', '3af3641b-2678-4b50-9473-1f9dab519167', '45babf5f-b0da-416e-a412-38b63f4358e9', NULL, 3, NULL, 'GARDEN-wiki-7e3c66b9', 'GARDEN-wiki-7e3c66b9-v3', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:39.774958+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (24, 'thought:3c198cdd-d5b7-40b5-b8af-cbb74d44f49b', 'thought', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'sketch:0f67c50c-96ed-4b83-87cc-ec6c76ce69f0', '3af3641b-2678-4b50-9473-1f9dab519167', '3c198cdd-d5b7-40b5-b8af-cbb74d44f49b', '0f67c50c-96ed-4b83-87cc-ec6c76ce69f0', NULL, NULL, 'Soil', '', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:39.885186+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (23, 'sketch:0f67c50c-96ed-4b83-87cc-ec6c76ce69f0', 'sketch', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'sketch:0f67c50c-96ed-4b83-87cc-ec6c76ce69f0', '3af3641b-2678-4b50-9473-1f9dab519167', '0f67c50c-96ed-4b83-87cc-ec6c76ce69f0', NULL, NULL, 'project', 'Garden map 7e3c66b9', '', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:39.963224+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (26, 'thought:dd519e65-3a03-4e13-9a4d-41dd83140c8f', 'thought', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'sketch:0f67c50c-96ed-4b83-87cc-ec6c76ce69f0', '3af3641b-2678-4b50-9473-1f9dab519167', 'dd519e65-3a03-4e13-9a4d-41dd83140c8f', '0f67c50c-96ed-4b83-87cc-ec6c76ce69f0', NULL, NULL, 'Water', '', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:39.920762+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (28, 'thought:1701e9fb-1213-4cd8-a575-46451e40a2fb', 'thought', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'sketch:0f67c50c-96ed-4b83-87cc-ec6c76ce69f0', '3af3641b-2678-4b50-9473-1f9dab519167', '1701e9fb-1213-4cd8-a575-46451e40a2fb', '0f67c50c-96ed-4b83-87cc-ec6c76ce69f0', NULL, NULL, 'Shade', '', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:39.955783+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (30, 'work:f1c5e0e8-f071-4bbe-a1c5-e87df6093c35', 'work', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project:3af3641b-2678-4b50-9473-1f9dab519167', '3af3641b-2678-4b50-9473-1f9dab519167', 'f1c5e0e8-f071-4bbe-a1c5-e87df6093c35', NULL, NULL, 'open', 'GARDEN-calibrate-7e3c66b9', '#1', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:39.994218+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (32, 'work:9313f031-a292-4711-b014-2acc8d3ea870', 'work', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project:3af3641b-2678-4b50-9473-1f9dab519167', '3af3641b-2678-4b50-9473-1f9dab519167', '9313f031-a292-4711-b014-2acc8d3ea870', NULL, NULL, 'blocked', 'GARDEN-ship-7e3c66b9', '#2
needs calibration', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:40.031682+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (35, 'work:b9f4af8b-ce89-4512-939c-c48f5bc34ffd', 'work', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project:3af3641b-2678-4b50-9473-1f9dab519167', '3af3641b-2678-4b50-9473-1f9dab519167', 'b9f4af8b-ce89-4512-939c-c48f5bc34ffd', NULL, NULL, 'blocked', 'GARDEN-approve-7e3c66b9', '#3
needs a decision of the owner', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:40.086222+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (37, 'person:f9065079-9ba2-4df8-9cac-4a1d056d10d7:64d60389-a836-4818-b7b8-4e0abb5b65b7', 'person', 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', 'members:f9065079-9ba2-4df8-9cac-4a1d056d10d7', NULL, '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, NULL, 'owner', 'Release smoke user', '', NULL, NULL, '2026-11-12 15:18:40.348084+00', DEFAULT, DEFAULT, false);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (38, 'project:4ec1e811-c87f-4d03-9b19-a9b1457b033d', 'project', 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', 'project:4ec1e811-c87f-4d03-9b19-a9b1457b033d', '4ec1e811-c87f-4d03-9b19-a9b1457b033d', '4ec1e811-c87f-4d03-9b19-a9b1457b033d', NULL, NULL, 'workspace', '', '', NULL, NULL, '2026-11-12 15:18:40.379685+00', DEFAULT, DEFAULT, true);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (39, 'message:1e2b1ed2-96ef-4e4d-a3c5-cbf298aa94af', 'message', 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', 'project:4ec1e811-c87f-4d03-9b19-a9b1457b033d', '4ec1e811-c87f-4d03-9b19-a9b1457b033d', '1e2b1ed2-96ef-4e4d-a3c5-cbf298aa94af', '17302516-a644-4408-9a44-22b99ffb270d', NULL, NULL, '', '', 'human', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:40.427611+00', DEFAULT, DEFAULT, true);


--
-- Data for Name: sketch_links; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sketch_links VALUES ('3b1e677f-9b75-4f9a-b397-73d3aec2abfd', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '0f67c50c-96ed-4b83-87cc-ec6c76ce69f0', '3c198cdd-d5b7-40b5-b8af-cbb74d44f49b', 'dd519e65-3a03-4e13-9a4d-41dd83140c8f', 'needs', '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, '2026-11-12 15:18:39.920762+00');
INSERT INTO public.sketch_links VALUES ('97306fa8-4c57-49eb-8fce-36f4a86d5c77', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '0f67c50c-96ed-4b83-87cc-ec6c76ce69f0', 'dd519e65-3a03-4e13-9a4d-41dd83140c8f', '1701e9fb-1213-4cd8-a575-46451e40a2fb', 'next to', '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, '2026-11-12 15:18:39.955783+00');


--
-- Data for Name: sketch_thoughts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sketch_thoughts VALUES ('3c198cdd-d5b7-40b5-b8af-cbb74d44f49b', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '0f67c50c-96ed-4b83-87cc-ec6c76ce69f0', 'Soil', 10, 10, 184, 72, 'card', '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, 1, '2026-11-12 15:18:39.885186+00', '2026-11-12 15:18:39.885186+00', NULL, NULL, NULL, NULL, NULL, '{}');
INSERT INTO public.sketch_thoughts VALUES ('dd519e65-3a03-4e13-9a4d-41dd83140c8f', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '0f67c50c-96ed-4b83-87cc-ec6c76ce69f0', 'Water', 220, 10, 184, 72, 'card', '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, 1, '2026-11-12 15:18:39.920762+00', '2026-11-12 15:18:39.920762+00', NULL, NULL, NULL, NULL, NULL, '{}');
INSERT INTO public.sketch_thoughts VALUES ('1701e9fb-1213-4cd8-a575-46451e40a2fb', 'db2917d2-9c76-4600-979b-62cde4a8a63b', '0f67c50c-96ed-4b83-87cc-ec6c76ce69f0', 'Shade', 220, 120, 184, 72, 'card', '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, 1, '2026-11-12 15:18:39.955783+00', '2026-11-12 15:18:39.955783+00', NULL, NULL, NULL, NULL, NULL, '{}');


--
-- Data for Name: sketches; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sketches VALUES ('0cd01a9b-400b-49f6-927d-579196ecca3e', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'private', NULL, 'RELEASE-private-map-7e3c66b9', '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, 1, '2026-11-12 15:18:38.454474+00', '2026-11-12 15:18:38.454474+00', '{}');
INSERT INTO public.sketches VALUES ('0f67c50c-96ed-4b83-87cc-ec6c76ce69f0', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'project', '3af3641b-2678-4b50-9473-1f9dab519167', 'Garden map 7e3c66b9', '64d60389-a836-4818-b7b8-4e0abb5b65b7', NULL, 1, '2026-11-12 15:18:39.841484+00', '2026-11-12 15:18:39.963224+00', '{human:64d60389-a836-4818-b7b8-4e0abb5b65b7}');


--
-- Data for Name: task_creation_undo_receipts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspace_dek_wraps; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspace_dek_wraps VALUES ('71ca76c4-337c-4f83-80a4-795531ac4c5f', 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', 1, 'F8Br3dLJ_jJfQz0Umnaiv3MiV1eGNZj-VlqBLupafGE', 'R1M2pBDauKrfwm81HSJxe2fRyYkkr99e99oF2OhMweRLetfIXvaXXNoxC22zTh6pLAckvOsC84GE55zT', 'H8U2qv5bNAuv2uuNUTwdznZxVfpNH8UyWoVP2MOc06k');
INSERT INTO public.workspace_dek_wraps VALUES ('cd3d9655-7d15-4ff3-a63b-9b18a4a40099', 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', 1, 'UJMkGuYXBIS1_BhK-ZjFMFmpCpcUZewtX4X676aQfm8', 'A997CffXT6Hw1j8gAu4HZFPNLbR6LF8i1GaO2D1jBv7riGJJAXKcqhAz7P8EkE2ToEqGTSwH01TDVuty', 'ImFBGQBaH_yF4EL-I7-9Y3gQTCvncboWirvYw3si4ZA');


--
-- Data for Name: workspace_holders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspace_holders VALUES ('71ca76c4-337c-4f83-80a4-795531ac4c5f', 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', 'password', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '{"m": 65536, "p": 4, "t": 3, "v": 19, "alg": "argon2id", "salt": "n944BiMcRaGTSKrnlKZTpg"}', 'YYZpuSCd0_VTH8PpwgddgeVgVfbpT_0gkqErdS73nkA', 'eucN1AR9_NECfxLVlWWNnkudep3UI9S8hPqJTzdCfeKfa5qqWA_irs0XjirLiFtzkvTxPucYcXZXGPgmEyGKQXaLiQcalZe_DigIqg', 'mLS3HgmCLvkX1qAebMypu7l2YiWiG_2z91cNMLHtnwc', 1, 'qrVxVdSqle5L1vE-h7_GQP59WY69MXlU1yRHmNUU7Ow', '2026-11-12 15:18:40.348084+00', '2026-11-12 15:18:40.348084+00', '{1}', 'X5DU6hDFgG49XbeJ7mRoQWAxUDQgPa-EGrCUVYWMnw8');
INSERT INTO public.workspace_holders VALUES ('cd3d9655-7d15-4ff3-a63b-9b18a4a40099', 'f9065079-9ba2-4df8-9cac-4a1d056d10d7', 'recovery', NULL, '{"m": 65536, "p": 4, "t": 3, "v": 19, "alg": "argon2id", "salt": "lcQLlf7lywDMyi7sGWtzxg"}', 'pFYBdKJei7jxXsqPWQI-LZ-xA24s4-kHEM35TDtN3gE', '7_BOJ7p3MTwaclP2vqmS03GpRFW5B3LQiYx8ZWwiKw36TgfmRU6T-t7FMQjHsw2O7W78vGARhf0RgcOCDGxKhg0eHOYGPMro_no_AA', 'KNlliku9GHke6GyVFWXt90NUF_x0avLFvqi_JnJmCUU', 1, '2E3HfD0k6svOdJOwGx86ivEM0jPGN-5jLSD2JlXlvQ4', '2026-11-12 15:18:40.348084+00', '2026-11-12 15:18:40.348084+00', '{1}', 'gkGYdsZrlKw_y9WDKluhWd1gS-Us2EhMYexEyE2fMBI');


--
-- Data for Name: workspace_invites; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspace_invites VALUES ('741dcf5f-9b5a-42f7-86be-6d03a358c8f3', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'member', NULL, 'de11735db5130a321c8384228065f6a756915eb707acbc4abba1a92261d820a5', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:38.813704+00', '2026-11-19 15:18:38.813+00', NULL, NULL, '2026-11-12 15:18:38.837+00', '02f26b99-2df5-45f8-8529-1f662cde58d1');
INSERT INTO public.workspace_invites VALUES ('08d6544d-0033-4c07-b9b5-8f7366cbd26c', 'db2917d2-9c76-4600-979b-62cde4a8a63b', 'guest', NULL, '656eee2c1a7c626078309a8913a54eb70038b6d2b6e60b55278addc1621290ae', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:39.1787+00', '2026-11-19 15:18:39.178+00', NULL, NULL, '2026-11-12 15:18:39.199+00', '7521935a-427b-4baf-b0ae-1072ddb9959c');


--
-- Data for Name: workspace_key_versions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspace_key_versions VALUES ('f9065079-9ba2-4df8-9cac-4a1d056d10d7', 1, NULL, 'fx1.1.IWme6Q9Z5jEpIx5IAOzbHejsJnjFhx_mYfFFhKxmCZcc_uC_rLHoPzMRzo5V', '2026-11-12 15:18:40.348084+00', 'FvvZAjtR7n5dMrSN7pUQCkggdYPK2fGVmgkghqPbhko');


--
-- Data for Name: workspace_keys; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspace_keys VALUES ('f9065079-9ba2-4df8-9cac-4a1d056d10d7', 1, '{1}', 'none', NULL, NULL, '2026-11-12 15:18:40.348084+00', NULL, NULL);


--
-- Data for Name: workspace_members; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspace_members VALUES ('db2917d2-9c76-4600-979b-62cde4a8a63b', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'owner', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:38.012485+00', '2026-11-12 15:18:38.012485+00');
INSERT INTO public.workspace_members VALUES ('db2917d2-9c76-4600-979b-62cde4a8a63b', '02f26b99-2df5-45f8-8529-1f662cde58d1', 'member', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:38.838271+00', '2026-11-12 15:18:38.838271+00');
INSERT INTO public.workspace_members VALUES ('db2917d2-9c76-4600-979b-62cde4a8a63b', '7521935a-427b-4baf-b0ae-1072ddb9959c', 'guest', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:39.199808+00', '2026-11-12 15:18:39.199808+00');
INSERT INTO public.workspace_members VALUES ('f9065079-9ba2-4df8-9cac-4a1d056d10d7', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 'owner', '64d60389-a836-4818-b7b8-4e0abb5b65b7', '2026-11-12 15:18:40.348084+00', '2026-11-12 15:18:40.348084+00');


--
-- Data for Name: workspace_removals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspace_removed_holders; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspace_removed_people; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspace_rotation_progress; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspace_unlocks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspace_wrap_grants; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspaces; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspaces VALUES ('db2917d2-9c76-4600-979b-62cde4a8a63b', 'Release restore probe', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 2, '2026-11-12 15:18:38.012485+00', '2026-11-12 15:18:38.074+00', false, NULL, true, NULL);
INSERT INTO public.workspaces VALUES ('f9065079-9ba2-4df8-9cac-4a1d056d10d7', 'Release vault', '64d60389-a836-4818-b7b8-4e0abb5b65b7', 1, '2026-11-12 15:18:40.348084+00', '2026-11-12 15:18:40.348084+00', true, '53e882cd-c1e8-4c7a-827f-6aa94f931e32', false, 'db2917d2-9c76-4600-979b-62cde4a8a63b');


--
-- Name: agent_thread_guard_sequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_thread_guard_sequence', 1, false);


--
-- Name: events_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.events_seq_seq', 46, true);


--
-- Name: project_task_number_3af3641b26784b5094731f9dab519167; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_task_number_3af3641b26784b5094731f9dab519167', 3, true);


--
-- Name: project_task_number_4ec1e811c87f4d039b19a9b1457b033d; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_task_number_4ec1e811c87f4d039b19a9b1457b033d', 1, false);


--
-- Name: project_task_number_a2ac3b939f524192a6b6762a3e63aec4; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_task_number_a2ac3b939f524192a6b6762a3e63aec4', 1, true);


--
-- Name: project_task_number_ceffd77004894afd8f95837ba85efb04; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_task_number_ceffd77004894afd8f95837ba85efb04', 1, false);


--
-- Name: search_changes_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.search_changes_seq_seq', 2, true);


--
-- Name: search_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.search_documents_id_seq', 39, true);


--
-- Name: bam bam_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.bam
    ADD CONSTRAINT bam_pkey PRIMARY KEY (id);


--
-- Name: instance instance_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.instance
    ADD CONSTRAINT instance_pkey PRIMARY KEY (id);


--
-- Name: job job_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job
    ADD CONSTRAINT job_pkey PRIMARY KEY (name, id);


--
-- Name: job_common job_common_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job_common
    ADD CONSTRAINT job_common_pkey PRIMARY KEY (name, id);


--
-- Name: job_dependency job_dependency_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job_dependency
    ADD CONSTRAINT job_dependency_pkey PRIMARY KEY (child_name, child_id, parent_name, parent_id);


--
-- Name: queue queue_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue
    ADD CONSTRAINT queue_pkey PRIMARY KEY (name);


--
-- Name: queue_stats queue_stats_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats
    ADD CONSTRAINT queue_stats_pkey PRIMARY KEY (id, captured_on);


--
-- Name: queue_stats_20261112 queue_stats_20261112_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats_20261112
    ADD CONSTRAINT queue_stats_20261112_pkey PRIMARY KEY (id, captured_on);


--
-- Name: queue_stats_20261113 queue_stats_20261113_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats_20261113
    ADD CONSTRAINT queue_stats_20261113_pkey PRIMARY KEY (id, captured_on);


--
-- Name: schedule schedule_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.schedule
    ADD CONSTRAINT schedule_pkey PRIMARY KEY (name, key);


--
-- Name: subscription subscription_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.subscription
    ADD CONSTRAINT subscription_pkey PRIMARY KEY (event, name);


--
-- Name: version version_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.version
    ADD CONSTRAINT version_pkey PRIMARY KEY (version);


--
-- Name: warning warning_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.warning
    ADD CONSTRAINT warning_pkey PRIMARY KEY (id);


--
-- Name: agent_chat_messages agent_chat_messages_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat_messages
    ADD CONSTRAINT agent_chat_messages_key_key UNIQUE (agent_id, key);


--
-- Name: agent_chat_messages agent_chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat_messages
    ADD CONSTRAINT agent_chat_messages_pkey PRIMARY KEY (id);


--
-- Name: agent_chat_reads agent_chat_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat_reads
    ADD CONSTRAINT agent_chat_reads_pkey PRIMARY KEY (agent_id);


--
-- Name: agent_command_receipts agent_command_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_command_receipts
    ADD CONSTRAINT agent_command_receipts_pkey PRIMARY KEY (connection_id, client_command_id);


--
-- Name: agent_connections agent_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_connections
    ADD CONSTRAINT agent_connections_pkey PRIMARY KEY (id);


--
-- Name: agent_connections agent_connections_workspace_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_connections
    ADD CONSTRAINT agent_connections_workspace_id_id_key UNIQUE (workspace_id, id);


--
-- Name: agent_memory_items agent_memory_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_memory_items
    ADD CONSTRAINT agent_memory_items_pkey PRIMARY KEY (id);


--
-- Name: agent_oauth_bindings agent_oauth_bindings_owner_user_id_connection_id_client_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_oauth_bindings
    ADD CONSTRAINT agent_oauth_bindings_owner_user_id_connection_id_client_id_key UNIQUE (owner_user_id, connection_id, client_id);


--
-- Name: agent_oauth_bindings agent_oauth_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_oauth_bindings
    ADD CONSTRAINT agent_oauth_bindings_pkey PRIMARY KEY (id);


--
-- Name: agent_playbook_acknowledgments agent_playbook_acknowledgments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_playbook_acknowledgments
    ADD CONSTRAINT agent_playbook_acknowledgments_pkey PRIMARY KEY (runtime_session_id);


--
-- Name: agent_proposals agent_proposals_agent_id_project_id_client_command_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_proposals
    ADD CONSTRAINT agent_proposals_agent_id_project_id_client_command_id_key UNIQUE (agent_id, project_id, client_command_id);


--
-- Name: agent_proposals agent_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_proposals
    ADD CONSTRAINT agent_proposals_pkey PRIMARY KEY (id);


--
-- Name: agent_questions agent_questions_message_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_questions
    ADD CONSTRAINT agent_questions_message_id_key UNIQUE (message_id);


--
-- Name: agent_questions agent_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_questions
    ADD CONSTRAINT agent_questions_pkey PRIMARY KEY (id);


--
-- Name: agent_runtime_auth_admission agent_runtime_auth_admission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_auth_admission
    ADD CONSTRAINT agent_runtime_auth_admission_pkey PRIMARY KEY (singleton);


--
-- Name: agent_runtime_auth_operations agent_runtime_auth_operations_operation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_auth_operations
    ADD CONSTRAINT agent_runtime_auth_operations_operation_id_key UNIQUE (operation_id);


--
-- Name: agent_runtime_auth_operations agent_runtime_auth_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_auth_operations
    ADD CONSTRAINT agent_runtime_auth_operations_pkey PRIMARY KEY (binding_id, client);


--
-- Name: agent_runtime_bindings agent_runtime_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_bindings
    ADD CONSTRAINT agent_runtime_bindings_pkey PRIMARY KEY (id);


--
-- Name: agent_runtime_client_history agent_runtime_client_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_client_history
    ADD CONSTRAINT agent_runtime_client_history_pkey PRIMARY KEY (binding_id, client);


--
-- Name: agent_runtime_connections agent_runtime_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_connections
    ADD CONSTRAINT agent_runtime_connections_pkey PRIMARY KEY (id);


--
-- Name: agent_runtime_console_nonces agent_runtime_console_nonces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_console_nonces
    ADD CONSTRAINT agent_runtime_console_nonces_pkey PRIMARY KEY (nonce_digest);


--
-- Name: agent_runtime_operator_statements agent_runtime_operator_statements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_operator_statements
    ADD CONSTRAINT agent_runtime_operator_statements_pkey PRIMARY KEY (statement, agreed_on);


--
-- Name: agent_runtime_sessions agent_runtime_sessions_binding_id_client_session_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_sessions
    ADD CONSTRAINT agent_runtime_sessions_binding_id_client_session_id_key UNIQUE (binding_id, client_session_id);


--
-- Name: agent_runtime_sessions agent_runtime_sessions_connection_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_sessions
    ADD CONSTRAINT agent_runtime_sessions_connection_id_id_key UNIQUE (connection_id, id);


--
-- Name: agent_runtime_sessions agent_runtime_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_sessions
    ADD CONSTRAINT agent_runtime_sessions_pkey PRIMARY KEY (id);


--
-- Name: agent_runtime_slots agent_runtime_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_slots
    ADD CONSTRAINT agent_runtime_slots_pkey PRIMARY KEY (slot);


--
-- Name: agent_stops agent_stops_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_stops
    ADD CONSTRAINT agent_stops_pkey PRIMARY KEY (id);


--
-- Name: agent_task_events agent_task_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_task_events
    ADD CONSTRAINT agent_task_events_pkey PRIMARY KEY (id);


--
-- Name: agent_task_taking agent_task_taking_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_task_taking
    ADD CONSTRAINT agent_task_taking_pkey PRIMARY KEY (owner_user_id);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: agents agents_workspace_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_workspace_id_id_key UNIQUE (workspace_id, id);


--
-- Name: assistant_background_notes assistant_background_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_background_notes
    ADD CONSTRAINT assistant_background_notes_pkey PRIMARY KEY (owner_user_id, account_key);


--
-- Name: assistant_changes assistant_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_pkey PRIMARY KEY (id);


--
-- Name: assistant_changes assistant_changes_run_id_client_command_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_run_id_client_command_id_key UNIQUE (run_id, client_command_id);


--
-- Name: assistant_job_runs assistant_job_runs_job_id_fired_at_fired_by_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_job_runs
    ADD CONSTRAINT assistant_job_runs_job_id_fired_at_fired_by_key UNIQUE (job_id, fired_at, fired_by);


--
-- Name: assistant_job_runs assistant_job_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_job_runs
    ADD CONSTRAINT assistant_job_runs_pkey PRIMARY KEY (id);


--
-- Name: assistant_jobs assistant_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_jobs
    ADD CONSTRAINT assistant_jobs_pkey PRIMARY KEY (id);


--
-- Name: assistant_settings assistant_settings_connection_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_settings
    ADD CONSTRAINT assistant_settings_connection_id_key UNIQUE (connection_id);


--
-- Name: assistant_settings assistant_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_settings
    ADD CONSTRAINT assistant_settings_pkey PRIMARY KEY (agent_id);


--
-- Name: auth_accounts auth_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_accounts
    ADD CONSTRAINT auth_accounts_pkey PRIMARY KEY (id);


--
-- Name: auth_email_claims auth_email_claims_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_email_claims
    ADD CONSTRAINT auth_email_claims_pkey PRIMARY KEY (id);


--
-- Name: auth_email_claims auth_email_claims_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_email_claims
    ADD CONSTRAINT auth_email_claims_token_hash_key UNIQUE (token_hash);


--
-- Name: auth_identity_audit auth_identity_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_identity_audit
    ADD CONSTRAINT auth_identity_audit_pkey PRIMARY KEY (id);


--
-- Name: auth_idp_standing auth_idp_standing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_idp_standing
    ADD CONSTRAINT auth_idp_standing_pkey PRIMARY KEY (user_id, provider_id);


--
-- Name: auth_link_intents auth_link_intents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_link_intents
    ADD CONSTRAINT auth_link_intents_pkey PRIMARY KEY (id);


--
-- Name: auth_link_intents auth_link_intents_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_link_intents
    ADD CONSTRAINT auth_link_intents_token_hash_key UNIQUE (token_hash);


--
-- Name: auth_logout_tokens auth_logout_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_logout_tokens
    ADD CONSTRAINT auth_logout_tokens_pkey PRIMARY KEY (provider_id, jti);


--
-- Name: auth_rate_limits auth_rate_limits_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_rate_limits
    ADD CONSTRAINT auth_rate_limits_key_key UNIQUE (key);


--
-- Name: auth_rate_limits auth_rate_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_rate_limits
    ADD CONSTRAINT auth_rate_limits_pkey PRIMARY KEY (id);


--
-- Name: auth_session_identities auth_session_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_session_identities
    ADD CONSTRAINT auth_session_identities_pkey PRIMARY KEY (session_id);


--
-- Name: auth_sessions auth_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_pkey PRIMARY KEY (id);


--
-- Name: auth_sessions auth_sessions_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_token_key UNIQUE (token);


--
-- Name: auth_sign_in_throttle auth_sign_in_throttle_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sign_in_throttle
    ADD CONSTRAINT auth_sign_in_throttle_pkey PRIMARY KEY (account_hash);


--
-- Name: auth_users auth_users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_users
    ADD CONSTRAINT auth_users_email_key UNIQUE (email);


--
-- Name: auth_users auth_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_users
    ADD CONSTRAINT auth_users_pkey PRIMARY KEY (id);


--
-- Name: auth_verifications auth_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_verifications
    ADD CONSTRAINT auth_verifications_pkey PRIMARY KEY (id);


--
-- Name: background_compute_connections background_compute_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.background_compute_connections
    ADD CONSTRAINT background_compute_connections_pkey PRIMARY KEY (id);


--
-- Name: cowork_checkpoints cowork_checkpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_checkpoints
    ADD CONSTRAINT cowork_checkpoints_pkey PRIMARY KEY (id);


--
-- Name: cowork_checkpoints cowork_checkpoints_workspace_id_project_id_unit_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_checkpoints
    ADD CONSTRAINT cowork_checkpoints_workspace_id_project_id_unit_id_id_key UNIQUE (workspace_id, project_id, unit_id, id);


--
-- Name: cowork_connection_slots cowork_connection_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_connection_slots
    ADD CONSTRAINT cowork_connection_slots_pkey PRIMARY KEY (connection_id);


--
-- Name: cowork_units cowork_units_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_units
    ADD CONSTRAINT cowork_units_pkey PRIMARY KEY (id);


--
-- Name: cowork_units cowork_units_workspace_id_project_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_units
    ADD CONSTRAINT cowork_units_workspace_id_project_id_id_key UNIQUE (workspace_id, project_id, id);


--
-- Name: cowork_units cowork_units_workspace_id_project_id_work_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_units
    ADD CONSTRAINT cowork_units_workspace_id_project_id_work_id_id_key UNIQUE (workspace_id, project_id, work_id, id);


--
-- Name: cowork_units cowork_units_workspace_id_project_id_work_id_run_id_unit_ke_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_units
    ADD CONSTRAINT cowork_units_workspace_id_project_id_work_id_run_id_unit_ke_key UNIQUE (workspace_id, project_id, work_id, run_id, unit_key);


--
-- Name: dm_message_observations dm_message_observations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_message_observations
    ADD CONSTRAINT dm_message_observations_pkey PRIMARY KEY (message_id, viewer_id);


--
-- Name: dm_messages dm_messages_dm_id_author_id_client_message_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_messages
    ADD CONSTRAINT dm_messages_dm_id_author_id_client_message_id_key UNIQUE (dm_id, author_id, client_message_id);


--
-- Name: dm_messages dm_messages_dm_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_messages
    ADD CONSTRAINT dm_messages_dm_id_id_key UNIQUE (dm_id, id);


--
-- Name: dm_messages dm_messages_dm_id_sequence_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_messages
    ADD CONSTRAINT dm_messages_dm_id_sequence_key UNIQUE (dm_id, sequence);


--
-- Name: dm_messages dm_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_messages
    ADD CONSTRAINT dm_messages_pkey PRIMARY KEY (id);


--
-- Name: dm_participants dm_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_participants
    ADD CONSTRAINT dm_participants_pkey PRIMARY KEY (dm_id, user_id);


--
-- Name: dms dms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dms
    ADD CONSTRAINT dms_pkey PRIMARY KEY (id);


--
-- Name: dms dms_workspace_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dms
    ADD CONSTRAINT dms_workspace_id_id_key UNIQUE (workspace_id, id);


--
-- Name: dms dms_workspace_id_pair_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dms
    ADD CONSTRAINT dms_workspace_id_pair_key_key UNIQUE (workspace_id, pair_key);


--
-- Name: doc_live_archives doc_live_archives_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_archives
    ADD CONSTRAINT doc_live_archives_pkey PRIMARY KEY (doc_id, generation);


--
-- Name: doc_live_heads doc_live_heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_heads
    ADD CONSTRAINT doc_live_heads_pkey PRIMARY KEY (doc_id);


--
-- Name: doc_live_presence doc_live_presence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_presence
    ADD CONSTRAINT doc_live_presence_pkey PRIMARY KEY (connection_id);


--
-- Name: doc_live_replicas doc_live_replicas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_replicas
    ADD CONSTRAINT doc_live_replicas_pkey PRIMARY KEY (doc_id, generation, replica_id);


--
-- Name: doc_live_snapshots doc_live_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_snapshots
    ADD CONSTRAINT doc_live_snapshots_pkey PRIMARY KEY (doc_id, version);


--
-- Name: doc_live_updates doc_live_updates_actor_id_command_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_updates
    ADD CONSTRAINT doc_live_updates_actor_id_command_id_key UNIQUE (actor_id, command_id);


--
-- Name: doc_live_updates doc_live_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_updates
    ADD CONSTRAINT doc_live_updates_pkey PRIMARY KEY (doc_id, generation, sequence);


--
-- Name: encrypted_workspace_creations encrypted_workspace_creations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encrypted_workspace_creations
    ADD CONSTRAINT encrypted_workspace_creations_pkey PRIMARY KEY (id);


--
-- Name: event_audience event_audience_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_audience
    ADD CONSTRAINT event_audience_pkey PRIMARY KEY (recipient, seq);


--
-- Name: event_data_keys event_data_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_data_keys
    ADD CONSTRAINT event_data_keys_pkey PRIMARY KEY (key);


--
-- Name: event_data_tokens event_data_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_data_tokens
    ADD CONSTRAINT event_data_tokens_pkey PRIMARY KEY (token);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: file_garbage file_garbage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_garbage
    ADD CONSTRAINT file_garbage_pkey PRIMARY KEY (id);


--
-- Name: flux_schema_version flux_schema_version_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flux_schema_version
    ADD CONSTRAINT flux_schema_version_pkey PRIMARY KEY (version);


--
-- Name: github_bindings github_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_bindings
    ADD CONSTRAINT github_bindings_pkey PRIMARY KEY (id);


--
-- Name: github_bindings github_bindings_project_id_host_repository_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_bindings
    ADD CONSTRAINT github_bindings_project_id_host_repository_id_key UNIQUE (project_id, host, repository_id);


--
-- Name: github_bindings github_bindings_workspace_id_project_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_bindings
    ADD CONSTRAINT github_bindings_workspace_id_project_id_id_key UNIQUE (workspace_id, project_id, id);


--
-- Name: github_credentials github_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_credentials
    ADD CONSTRAINT github_credentials_pkey PRIMARY KEY (user_id, host);


--
-- Name: github_deliveries github_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_deliveries
    ADD CONSTRAINT github_deliveries_pkey PRIMARY KEY (id);


--
-- Name: github_oauth_flows github_oauth_flows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_oauth_flows
    ADD CONSTRAINT github_oauth_flows_pkey PRIMARY KEY (state_hash);


--
-- Name: github_processing github_processing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_processing
    ADD CONSTRAINT github_processing_pkey PRIMARY KEY (delivery_id, binding_id);


--
-- Name: github_rule_defaults github_rule_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_rule_defaults
    ADD CONSTRAINT github_rule_defaults_pkey PRIMARY KEY (project_id);


--
-- Name: github_task_links github_task_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_links
    ADD CONSTRAINT github_task_links_pkey PRIMARY KEY (id);


--
-- Name: github_task_links github_task_links_task_id_binding_id_pull_id_role_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_links
    ADD CONSTRAINT github_task_links_task_id_binding_id_pull_id_role_key UNIQUE (task_id, binding_id, pull_id, role);


--
-- Name: github_task_rule_changes github_task_rule_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_rule_changes
    ADD CONSTRAINT github_task_rule_changes_pkey PRIMARY KEY (id);


--
-- Name: github_task_rule_changes github_task_rule_changes_task_id_delivery_id_binding_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_rule_changes
    ADD CONSTRAINT github_task_rule_changes_task_id_delivery_id_binding_id_key UNIQUE (task_id, delivery_id, binding_id);


--
-- Name: github_task_rules github_task_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_rules
    ADD CONSTRAINT github_task_rules_pkey PRIMARY KEY (task_id);


--
-- Name: idempotency_account_operations idempotency_account_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_account_operations
    ADD CONSTRAINT idempotency_account_operations_pkey PRIMARY KEY (operation);


--
-- Name: idempotency_keys idempotency_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_pkey PRIMARY KEY (id);


--
-- Name: jwks jwks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jwks
    ADD CONSTRAINT jwks_pkey PRIMARY KEY (id);


--
-- Name: live_access_fences live_access_fences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_access_fences
    ADD CONSTRAINT live_access_fences_pkey PRIMARY KEY (scope_key);


--
-- Name: live_admissions live_admissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_admissions
    ADD CONSTRAINT live_admissions_pkey PRIMARY KEY (id);


--
-- Name: live_editing_intents live_editing_intents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_editing_intents
    ADD CONSTRAINT live_editing_intents_pkey PRIMARY KEY (actor_id, command_id);


--
-- Name: live_invitations live_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_invitations
    ADD CONSTRAINT live_invitations_pkey PRIMARY KEY (id);


--
-- Name: live_invitations live_invitations_session_id_recipient_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_invitations
    ADD CONSTRAINT live_invitations_session_id_recipient_id_key UNIQUE (session_id, recipient_id);


--
-- Name: live_presentations live_presentations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_presentations
    ADD CONSTRAINT live_presentations_pkey PRIMARY KEY (id);


--
-- Name: live_presentations live_presentations_session_id_created_by_client_event_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_presentations
    ADD CONSTRAINT live_presentations_session_id_created_by_client_event_id_key UNIQUE (session_id, created_by, client_event_id);


--
-- Name: live_sessions live_sessions_created_by_client_session_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_created_by_client_session_id_key UNIQUE (created_by, client_session_id);


--
-- Name: live_sessions live_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_pkey PRIMARY KEY (id);


--
-- Name: live_sessions live_sessions_room_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_room_id_key UNIQUE (room_id);


--
-- Name: live_sessions live_sessions_workspace_id_project_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_workspace_id_project_id_id_key UNIQUE (workspace_id, project_id, id);


--
-- Name: live_webhook_events live_webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_webhook_events
    ADD CONSTRAINT live_webhook_events_pkey PRIMARY KEY (event_id);


--
-- Name: map_live_gestures map_live_gestures_actor_id_session_id_sketch_id_generation__key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_gestures
    ADD CONSTRAINT map_live_gestures_actor_id_session_id_sketch_id_generation__key UNIQUE (actor_id, session_id, sketch_id, generation, gesture_id);


--
-- Name: map_live_gestures map_live_gestures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_gestures
    ADD CONSTRAINT map_live_gestures_pkey PRIMARY KEY (lease_id);


--
-- Name: map_live_heads map_live_heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_heads
    ADD CONSTRAINT map_live_heads_pkey PRIMARY KEY (sketch_id);


--
-- Name: map_live_heads map_live_heads_sketch_id_generation_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_heads
    ADD CONSTRAINT map_live_heads_sketch_id_generation_key UNIQUE (sketch_id, generation);


--
-- Name: map_live_journal map_live_journal_actor_kind_actor_id_command_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_journal
    ADD CONSTRAINT map_live_journal_actor_kind_actor_id_command_id_key UNIQUE (actor_kind, actor_id, command_id);


--
-- Name: map_live_journal map_live_journal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_journal
    ADD CONSTRAINT map_live_journal_pkey PRIMARY KEY (sketch_id, generation, sequence);


--
-- Name: map_live_object_versions map_live_object_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_object_versions
    ADD CONSTRAINT map_live_object_versions_pkey PRIMARY KEY (kind, object_id);


--
-- Name: map_live_presence map_live_presence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_presence
    ADD CONSTRAINT map_live_presence_pkey PRIMARY KEY (connection_id);


--
-- Name: map_live_undone map_live_undone_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_undone
    ADD CONSTRAINT map_live_undone_pkey PRIMARY KEY (sketch_id, generation, original_sequence);


--
-- Name: message_references message_references_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_references
    ADD CONSTRAINT message_references_pkey PRIMARY KEY (id);


--
-- Name: native_command_receipts native_command_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.native_command_receipts
    ADD CONSTRAINT native_command_receipts_pkey PRIMARY KEY (project_id, actor_kind, actor_id, operation, client_command_id);


--
-- Name: needs_you_states needs_you_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.needs_you_states
    ADD CONSTRAINT needs_you_states_pkey PRIMARY KEY (user_id, item_key);


--
-- Name: notification_address_sends notification_address_sends_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_address_sends
    ADD CONSTRAINT notification_address_sends_pkey PRIMARY KEY (address_hash);


--
-- Name: notification_address_tokens notification_address_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_address_tokens
    ADD CONSTRAINT notification_address_tokens_pkey PRIMARY KEY (token_hash);


--
-- Name: notification_addresses notification_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_addresses
    ADD CONSTRAINT notification_addresses_pkey PRIMARY KEY (id);


--
-- Name: notification_cursor notification_cursor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_cursor
    ADD CONSTRAINT notification_cursor_pkey PRIMARY KEY (id);


--
-- Name: notification_emails notification_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_emails
    ADD CONSTRAINT notification_emails_pkey PRIMARY KEY (id);


--
-- Name: notification_emails notification_emails_unsubscribe_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_emails
    ADD CONSTRAINT notification_emails_unsubscribe_hash_key UNIQUE (unsubscribe_hash);


--
-- Name: notification_generation_failures notification_generation_failures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_generation_failures
    ADD CONSTRAINT notification_generation_failures_pkey PRIMARY KEY (event_id);


--
-- Name: notification_mutes notification_mutes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_mutes
    ADD CONSTRAINT notification_mutes_pkey PRIMARY KEY (user_id, source_type, source_id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (user_id);


--
-- Name: notification_verification_sends notification_verification_sends_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_verification_sends
    ADD CONSTRAINT notification_verification_sends_pkey PRIMARY KEY (user_id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_token oauth_access_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_token
    ADD CONSTRAINT oauth_access_token_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_token oauth_access_token_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_token
    ADD CONSTRAINT oauth_access_token_token_unique UNIQUE (token);


--
-- Name: oauth_client_assertion oauth_client_assertion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_assertion
    ADD CONSTRAINT oauth_client_assertion_pkey PRIMARY KEY (id);


--
-- Name: oauth_client oauth_client_client_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client
    ADD CONSTRAINT oauth_client_client_id_unique UNIQUE (client_id);


--
-- Name: oauth_client oauth_client_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client
    ADD CONSTRAINT oauth_client_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_resource oauth_client_resource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_resource
    ADD CONSTRAINT oauth_client_resource_pkey PRIMARY KEY (id);


--
-- Name: oauth_consent oauth_consent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_consent
    ADD CONSTRAINT oauth_consent_pkey PRIMARY KEY (id);


--
-- Name: oauth_grant_authentication oauth_grant_authentication_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_grant_authentication
    ADD CONSTRAINT oauth_grant_authentication_pkey PRIMARY KEY (authorization_code_id);


--
-- Name: oauth_refresh_token oauth_refresh_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_refresh_token
    ADD CONSTRAINT oauth_refresh_token_pkey PRIMARY KEY (id);


--
-- Name: oauth_refresh_token oauth_refresh_token_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_refresh_token
    ADD CONSTRAINT oauth_refresh_token_token_unique UNIQUE (token);


--
-- Name: oauth_resource oauth_resource_identifier_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_resource
    ADD CONSTRAINT oauth_resource_identifier_unique UNIQUE (identifier);


--
-- Name: oauth_resource oauth_resource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_resource
    ADD CONSTRAINT oauth_resource_pkey PRIMARY KEY (id);


--
-- Name: outbox outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbox
    ADD CONSTRAINT outbox_pkey PRIMARY KEY (id);


--
-- Name: password_attempts password_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_attempts
    ADD CONSTRAINT password_attempts_pkey PRIMARY KEY (id);


--
-- Name: personal_run_private_texts personal_run_private_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_run_private_texts
    ADD CONSTRAINT personal_run_private_texts_pkey PRIMARY KEY (id);


--
-- Name: personal_run_web_reads personal_run_web_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_run_web_reads
    ADD CONSTRAINT personal_run_web_reads_pkey PRIMARY KEY (id);


--
-- Name: personal_run_web_searches personal_run_web_searches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_run_web_searches
    ADD CONSTRAINT personal_run_web_searches_pkey PRIMARY KEY (id);


--
-- Name: personal_runs personal_runs_owner_user_id_client_run_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_owner_user_id_client_run_id_key UNIQUE (owner_user_id, client_run_id);


--
-- Name: personal_runs personal_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_pkey PRIMARY KEY (id);


--
-- Name: personal_runs personal_runs_workspace_id_project_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_workspace_id_project_id_id_key UNIQUE (workspace_id, project_id, id);


--
-- Name: project_ai_policies project_ai_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_ai_policies
    ADD CONSTRAINT project_ai_policies_pkey PRIMARY KEY (project_id);


--
-- Name: project_conversations project_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_conversations
    ADD CONSTRAINT project_conversations_pkey PRIMARY KEY (id);


--
-- Name: project_conversations project_conversations_workspace_id_project_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_conversations
    ADD CONSTRAINT project_conversations_workspace_id_project_id_id_key UNIQUE (workspace_id, project_id, id);


--
-- Name: project_decisions project_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decisions
    ADD CONSTRAINT project_decisions_pkey PRIMARY KEY (id);


--
-- Name: project_decisions project_decisions_workspace_id_project_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decisions
    ADD CONSTRAINT project_decisions_workspace_id_project_id_id_key UNIQUE (workspace_id, project_id, id);


--
-- Name: project_files project_files_message_id_position_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_files
    ADD CONSTRAINT project_files_message_id_position_key UNIQUE (message_id, "position");


--
-- Name: project_files project_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_files
    ADD CONSTRAINT project_files_pkey PRIMARY KEY (id);


--
-- Name: project_grants project_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_grants
    ADD CONSTRAINT project_grants_pkey PRIMARY KEY (id);


--
-- Name: project_material_versions project_material_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_material_versions
    ADD CONSTRAINT project_material_versions_pkey PRIMARY KEY (material_id, version);


--
-- Name: project_material_versions project_material_versions_workspace_id_project_id_material__key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_material_versions
    ADD CONSTRAINT project_material_versions_workspace_id_project_id_material__key UNIQUE (workspace_id, project_id, material_id, version);


--
-- Name: project_materials project_materials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_materials
    ADD CONSTRAINT project_materials_pkey PRIMARY KEY (id);


--
-- Name: project_materials project_materials_project_id_created_by_client_mutation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_materials
    ADD CONSTRAINT project_materials_project_id_created_by_client_mutation_id_key UNIQUE (project_id, created_by, client_mutation_id);


--
-- Name: project_materials project_materials_workspace_id_project_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_materials
    ADD CONSTRAINT project_materials_workspace_id_project_id_id_key UNIQUE (workspace_id, project_id, id);


--
-- Name: project_message_observations project_message_observations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_message_observations
    ADD CONSTRAINT project_message_observations_pkey PRIMARY KEY (message_id, viewer_id);


--
-- Name: project_messages project_messages_conversation_id_sequence_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_messages
    ADD CONSTRAINT project_messages_conversation_id_sequence_key UNIQUE (conversation_id, sequence);


--
-- Name: project_messages project_messages_file_identity; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_messages
    ADD CONSTRAINT project_messages_file_identity UNIQUE (workspace_id, project_id, id);


--
-- Name: project_messages project_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_messages
    ADD CONSTRAINT project_messages_pkey PRIMARY KEY (id);


--
-- Name: project_messages project_messages_project_id_author_id_client_message_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_messages
    ADD CONSTRAINT project_messages_project_id_author_id_client_message_id_key UNIQUE (project_id, author_id, client_message_id);


--
-- Name: project_messages project_messages_root_identity; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_messages
    ADD CONSTRAINT project_messages_root_identity UNIQUE (conversation_id, id, sequence);


--
-- Name: project_object_links project_object_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_object_links
    ADD CONSTRAINT project_object_links_pkey PRIMARY KEY (id);


--
-- Name: project_task_activity project_task_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_activity
    ADD CONSTRAINT project_task_activity_pkey PRIMARY KEY (id);


--
-- Name: project_task_dependencies project_task_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_dependencies
    ADD CONSTRAINT project_task_dependencies_pkey PRIMARY KEY (project_id, task_id, prerequisite_id);


--
-- Name: project_task_discussions project_task_discussions_conversation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_discussions
    ADD CONSTRAINT project_task_discussions_conversation_id_key UNIQUE (conversation_id);


--
-- Name: project_task_discussions project_task_discussions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_discussions
    ADD CONSTRAINT project_task_discussions_pkey PRIMARY KEY (work_id);


--
-- Name: project_task_discussions project_task_discussions_root_message_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_discussions
    ADD CONSTRAINT project_task_discussions_root_message_id_key UNIQUE (root_message_id);


--
-- Name: project_task_notices project_task_notices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_notices
    ADD CONSTRAINT project_task_notices_pkey PRIMARY KEY (id);


--
-- Name: project_task_notices project_task_notices_work_id_kind_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_notices
    ADD CONSTRAINT project_task_notices_work_id_kind_key UNIQUE (work_id, kind);


--
-- Name: project_task_plan_intents project_task_plan_intents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_plan_intents
    ADD CONSTRAINT project_task_plan_intents_pkey PRIMARY KEY (project_id, material_id, material_version, intent_key);


--
-- Name: project_task_plan_intents project_task_plan_intents_task_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_plan_intents
    ADD CONSTRAINT project_task_plan_intents_task_id_key UNIQUE (task_id);


--
-- Name: project_task_updates project_task_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_updates
    ADD CONSTRAINT project_task_updates_pkey PRIMARY KEY (id);


--
-- Name: project_work_items project_work_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_work_items
    ADD CONSTRAINT project_work_items_pkey PRIMARY KEY (id);


--
-- Name: project_work_items project_work_items_workspace_id_project_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_work_items
    ADD CONSTRAINT project_work_items_workspace_id_project_id_id_key UNIQUE (workspace_id, project_id, id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: projects projects_workspace_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_workspace_id_id_key UNIQUE (workspace_id, id);


--
-- Name: push_subscriptions push_subscriptions_endpoint_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_endpoint_key UNIQUE (endpoint);


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: return_points return_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_points
    ADD CONSTRAINT return_points_pkey PRIMARY KEY (user_id, place_key);


--
-- Name: sample_results sample_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sample_results
    ADD CONSTRAINT sample_results_pkey PRIMARY KEY (sample_id);


--
-- Name: samples samples_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.samples
    ADD CONSTRAINT samples_pkey PRIMARY KEY (id);


--
-- Name: sealed_job_waits sealed_job_waits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sealed_job_waits
    ADD CONSTRAINT sealed_job_waits_pkey PRIMARY KEY (id);


--
-- Name: search_changes search_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_changes
    ADD CONSTRAINT search_changes_pkey PRIMARY KEY (seq);


--
-- Name: search_documents search_documents_doc_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_documents
    ADD CONSTRAINT search_documents_doc_key_key UNIQUE (doc_key);


--
-- Name: search_documents search_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_documents
    ADD CONSTRAINT search_documents_pkey PRIMARY KEY (id);


--
-- Name: sketch_links sketch_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_links
    ADD CONSTRAINT sketch_links_pkey PRIMARY KEY (id);


--
-- Name: sketch_thoughts sketch_thoughts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_thoughts
    ADD CONSTRAINT sketch_thoughts_pkey PRIMARY KEY (id);


--
-- Name: sketch_thoughts sketch_thoughts_sketch_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_thoughts
    ADD CONSTRAINT sketch_thoughts_sketch_id_id_key UNIQUE (sketch_id, id);


--
-- Name: sketches sketches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketches
    ADD CONSTRAINT sketches_pkey PRIMARY KEY (id);


--
-- Name: sketches sketches_workspace_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketches
    ADD CONSTRAINT sketches_workspace_id_id_key UNIQUE (workspace_id, id);


--
-- Name: sketches sketches_workspace_project_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketches
    ADD CONSTRAINT sketches_workspace_project_id_unique UNIQUE (workspace_id, project_id, id);


--
-- Name: task_creation_undo_receipts task_creation_undo_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_creation_undo_receipts
    ADD CONSTRAINT task_creation_undo_receipts_pkey PRIMARY KEY (project_id, actor_kind, actor_id, client_command_id);


--
-- Name: project_task_notices task_notice_scope_identity; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_notices
    ADD CONSTRAINT task_notice_scope_identity UNIQUE (workspace_id, project_id, work_id, id);


--
-- Name: workspace_dek_wraps workspace_dek_wraps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_dek_wraps
    ADD CONSTRAINT workspace_dek_wraps_pkey PRIMARY KEY (holder_id, key_version);


--
-- Name: workspace_holders workspace_holders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_holders
    ADD CONSTRAINT workspace_holders_pkey PRIMARY KEY (id);


--
-- Name: workspace_invites workspace_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invites
    ADD CONSTRAINT workspace_invites_pkey PRIMARY KEY (id);


--
-- Name: workspace_invites workspace_invites_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invites
    ADD CONSTRAINT workspace_invites_token_hash_key UNIQUE (token_hash);


--
-- Name: workspace_key_versions workspace_key_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_key_versions
    ADD CONSTRAINT workspace_key_versions_pkey PRIMARY KEY (workspace_id, key_version);


--
-- Name: workspace_keys workspace_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_keys
    ADD CONSTRAINT workspace_keys_pkey PRIMARY KEY (workspace_id);


--
-- Name: workspace_members workspace_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_members
    ADD CONSTRAINT workspace_members_pkey PRIMARY KEY (workspace_id, user_id);


--
-- Name: workspace_removals workspace_removals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_removals
    ADD CONSTRAINT workspace_removals_pkey PRIMARY KEY (workspace_id, seq);


--
-- Name: workspace_removed_holders workspace_removed_holders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_removed_holders
    ADD CONSTRAINT workspace_removed_holders_pkey PRIMARY KEY (workspace_id, holder_id);


--
-- Name: workspace_removed_people workspace_removed_people_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_removed_people
    ADD CONSTRAINT workspace_removed_people_pkey PRIMARY KEY (workspace_id, user_id);


--
-- Name: workspace_rotation_progress workspace_rotation_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_rotation_progress
    ADD CONSTRAINT workspace_rotation_progress_pkey PRIMARY KEY (workspace_id);


--
-- Name: workspace_unlocks workspace_unlocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_unlocks
    ADD CONSTRAINT workspace_unlocks_pkey PRIMARY KEY (workspace_id, key_version);


--
-- Name: workspace_wrap_grants workspace_wrap_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_wrap_grants
    ADD CONSTRAINT workspace_wrap_grants_pkey PRIMARY KEY (workspace_id, user_id);


--
-- Name: workspaces workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_pkey PRIMARY KEY (id);


--
-- Name: job_common_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i1 ON pgboss.job_common USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'created'::pgboss.job_state) AND (policy = 'short'::text));


--
-- Name: job_common_i10; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i10 ON pgboss.job_common USING btree (name, singleton_key, state DESC, created_on, id) INCLUDE (start_after) WHERE ((state < 'active'::pgboss.job_state) AND (NOT blocked) AND (policy = 'key_strict_fifo'::text));


--
-- Name: job_common_i11; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i11 ON pgboss.job_common USING btree (name, priority DESC, created_on, start_after) WHERE ((state < 'active'::pgboss.job_state) AND (NOT blocked));


--
-- Name: job_common_i12; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i12 ON pgboss.job_common USING btree (source_root_id) WHERE (source_root_id IS NOT NULL);


--
-- Name: job_common_i13; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i13 ON pgboss.job_common USING btree (name, singleton_key) WHERE ((state = 'created'::pgboss.job_state) AND upsert_by_key);


--
-- Name: job_common_i14; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i14 ON pgboss.job_common USING btree (name, state, blocked, start_after) WHERE (state = ANY (ARRAY['created'::pgboss.job_state, 'retry'::pgboss.job_state, 'active'::pgboss.job_state, 'failed'::pgboss.job_state]));


--
-- Name: job_common_i15; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i15 ON pgboss.job_common USING btree (name, created_on);


--
-- Name: job_common_i16; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i16 ON pgboss.job_common USING btree (name, completed_on) WHERE (completed_on IS NOT NULL);


--
-- Name: job_common_i17; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i17 ON pgboss.job_common USING btree (name, singleton_key, created_on) WHERE ((state < 'active'::pgboss.job_state) AND (singleton_key IS NOT NULL));


--
-- Name: job_common_i2; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i2 ON pgboss.job_common USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'active'::pgboss.job_state) AND (policy = 'singleton'::text));


--
-- Name: job_common_i3; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i3 ON pgboss.job_common USING btree (name, state, COALESCE(singleton_key, ''::text)) WHERE ((state <= 'active'::pgboss.job_state) AND (policy = 'stately'::text));


--
-- Name: job_common_i4; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i4 ON pgboss.job_common USING btree (name, singleton_on, COALESCE(singleton_key, ''::text)) WHERE ((state <> 'cancelled'::pgboss.job_state) AND (singleton_on IS NOT NULL));


--
-- Name: job_common_i6; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i6 ON pgboss.job_common USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state <= 'active'::pgboss.job_state) AND (policy = 'exclusive'::text));


--
-- Name: job_common_i7; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i7 ON pgboss.job_common USING btree (name, group_id) WHERE ((state = 'active'::pgboss.job_state) AND (group_id IS NOT NULL));


--
-- Name: job_common_i8; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i8 ON pgboss.job_common USING btree (name, singleton_key) WHERE ((state = ANY (ARRAY['active'::pgboss.job_state, 'retry'::pgboss.job_state, 'failed'::pgboss.job_state])) AND (policy = 'key_strict_fifo'::text));


--
-- Name: job_common_i9; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i9 ON pgboss.job_common USING btree (name, id) WHERE (blocking AND (state = 'completed'::pgboss.job_state));


--
-- Name: job_dep_parent_idx; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_dep_parent_idx ON pgboss.job_dependency USING btree (parent_name, parent_id);


--
-- Name: queue_stats_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX queue_stats_i1 ON ONLY pgboss.queue_stats USING btree (name, captured_on DESC) INCLUDE (deferred_count, queued_count, ready_count, active_count, failed_count, total_count);


--
-- Name: queue_stats_20261112_name_captured_on_deferred_count_queued_idx; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX queue_stats_20261112_name_captured_on_deferred_count_queued_idx ON pgboss.queue_stats_20261112 USING btree (name, captured_on DESC) INCLUDE (deferred_count, queued_count, ready_count, active_count, failed_count, total_count);


--
-- Name: queue_stats_20261113_name_captured_on_deferred_count_queued_idx; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX queue_stats_20261113_name_captured_on_deferred_count_queued_idx ON pgboss.queue_stats_20261113 USING btree (name, captured_on DESC) INCLUDE (deferred_count, queued_count, ready_count, active_count, failed_count, total_count);


--
-- Name: warning_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX warning_i1 ON pgboss.warning USING btree (created_on DESC);


--
-- Name: agent_chat_messages_agent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_chat_messages_agent_idx ON public.agent_chat_messages USING btree (agent_id, created_at DESC, id DESC);


--
-- Name: agent_command_receipts_activity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_command_receipts_activity_idx ON public.agent_command_receipts USING btree (connection_id, project_id, completed_at DESC);


--
-- Name: agent_connections_assistant_agent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX agent_connections_assistant_agent_idx ON public.agent_connections USING btree (agent_id) WHERE (compute_source = 'owner_assistant'::text);


--
-- Name: agent_connections_owner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_connections_owner_idx ON public.agent_connections USING btree (owner_user_id, created_at DESC, id);


--
-- Name: agent_memory_items_agent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_memory_items_agent_idx ON public.agent_memory_items USING btree (agent_id, created_at, id);


--
-- Name: agent_proposals_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_proposals_project_idx ON public.agent_proposals USING btree (project_id, created_at DESC, id DESC);


--
-- Name: agent_questions_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_questions_project_idx ON public.agent_questions USING btree (project_id, created_at DESC);


--
-- Name: agent_runtime_auth_expiry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_runtime_auth_expiry_idx ON public.agent_runtime_auth_operations USING btree (lease_ends_at) WHERE (phase = 'active'::text);


--
-- Name: agent_runtime_bindings_owner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_runtime_bindings_owner_idx ON public.agent_runtime_bindings USING btree (owner_user_id, created_at DESC, id);


--
-- Name: agent_runtime_bindings_owner_live_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX agent_runtime_bindings_owner_live_idx ON public.agent_runtime_bindings USING btree (owner_user_id) WHERE (state <> 'released'::text);


--
-- Name: agent_runtime_bindings_slot_live_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_runtime_bindings_slot_live_idx ON public.agent_runtime_bindings USING btree (slot) WHERE (state <> 'released'::text);


--
-- Name: agent_runtime_connections_owner_client_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX agent_runtime_connections_owner_client_idx ON public.agent_runtime_connections USING btree (owner_user_id, client) WHERE (revoked_at IS NULL);


--
-- Name: agent_runtime_sessions_connection_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_runtime_sessions_connection_idx ON public.agent_runtime_sessions USING btree (connection_id, expires_at);


--
-- Name: agent_stops_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_stops_project_idx ON public.agent_stops USING btree (project_id, stopped_at DESC);


--
-- Name: agent_task_events_handled_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_task_events_handled_idx ON public.agent_task_events USING btree (handled_at) WHERE (handled_at IS NOT NULL);


--
-- Name: agent_task_events_pending_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_task_events_pending_idx ON public.agent_task_events USING btree (created_at, id) WHERE (handled_at IS NULL);


--
-- Name: assistant_changes_connection_command_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX assistant_changes_connection_command_idx ON public.assistant_changes USING btree (connection_id, client_command_id) WHERE (connection_id IS NOT NULL);


--
-- Name: assistant_changes_connection_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_changes_connection_idx ON public.assistant_changes USING btree (connection_id, created_at) WHERE (connection_id IS NOT NULL);


--
-- Name: assistant_changes_conversation_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_changes_conversation_idx ON public.assistant_changes USING btree (conversation_id, created_at) WHERE (conversation_id IS NOT NULL);


--
-- Name: assistant_changes_owner_waiting_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_changes_owner_waiting_idx ON public.assistant_changes USING btree (owner_user_id, created_at) WHERE (state = 'waiting'::text);


--
-- Name: assistant_changes_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_changes_run_idx ON public.assistant_changes USING btree (run_id, created_at);


--
-- Name: assistant_changes_scope_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_changes_scope_idx ON public.assistant_changes USING btree (project_id, scope_id, created_at) WHERE (scope_id IS NOT NULL);


--
-- Name: assistant_job_runs_history_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_job_runs_history_idx ON public.assistant_job_runs USING btree (job_id, fired_at DESC);


--
-- Name: assistant_job_runs_one_running_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX assistant_job_runs_one_running_idx ON public.assistant_job_runs USING btree (job_id) WHERE (state = 'running'::text);


--
-- Name: assistant_job_runs_owner_day_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_job_runs_owner_day_idx ON public.assistant_job_runs USING btree (owner_user_id, started_at) WHERE (state <> 'skipped'::text);


--
-- Name: assistant_job_runs_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_job_runs_run_idx ON public.assistant_job_runs USING btree (run_id) WHERE (run_id IS NOT NULL);


--
-- Name: assistant_jobs_agent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_jobs_agent_idx ON public.assistant_jobs USING btree (agent_id, created_at, id) WHERE (deleted_at IS NULL);


--
-- Name: assistant_jobs_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_jobs_due_idx ON public.assistant_jobs USING btree (next_run_at) WHERE (enabled AND (deleted_at IS NULL));


--
-- Name: assistant_jobs_owner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_jobs_owner_idx ON public.assistant_jobs USING btree (owner_user_id, created_at, id) WHERE (deleted_at IS NULL);


--
-- Name: assistant_settings_owner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_settings_owner_idx ON public.assistant_settings USING btree (owner_user_id, created_at, agent_id);


--
-- Name: auth_accounts_provider_account_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX auth_accounts_provider_account_idx ON public.auth_accounts USING btree (provider_id, account_id);


--
-- Name: auth_accounts_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_accounts_user_id_idx ON public.auth_accounts USING btree (user_id);


--
-- Name: auth_email_claims_held_by_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_email_claims_held_by_idx ON public.auth_email_claims USING btree (held_by);


--
-- Name: auth_identity_audit_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_identity_audit_user_idx ON public.auth_identity_audit USING btree (user_id);


--
-- Name: auth_idp_standing_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_idp_standing_due_idx ON public.auth_idp_standing USING btree (next_check_at) WHERE (refresh_token_enc IS NOT NULL);


--
-- Name: auth_idp_standing_refused_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_idp_standing_refused_idx ON public.auth_idp_standing USING btree (user_id) WHERE (state = 'sign_in_required'::text);


--
-- Name: auth_link_intents_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_link_intents_user_idx ON public.auth_link_intents USING btree (user_id);


--
-- Name: auth_logout_tokens_expires_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_logout_tokens_expires_idx ON public.auth_logout_tokens USING btree (expires_at);


--
-- Name: auth_rate_limits_last_request_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_rate_limits_last_request_idx ON public.auth_rate_limits USING btree (last_request);


--
-- Name: auth_session_identities_idp_sid_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_session_identities_idp_sid_idx ON public.auth_session_identities USING btree (method, idp_sid) WHERE (idp_sid IS NOT NULL);


--
-- Name: auth_sessions_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_sessions_user_id_idx ON public.auth_sessions USING btree (user_id);


--
-- Name: auth_sign_in_throttle_last_failure_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_sign_in_throttle_last_failure_idx ON public.auth_sign_in_throttle USING btree (last_failure_at);


--
-- Name: auth_verifications_identifier_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_verifications_identifier_idx ON public.auth_verifications USING btree (identifier);


--
-- Name: background_compute_connections_owner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX background_compute_connections_owner_idx ON public.background_compute_connections USING btree (owner_user_id, created_at DESC, id);


--
-- Name: cowork_units_connection_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cowork_units_connection_idx ON public.cowork_units USING btree (assignment_connection_id, state, lease_expires_at);


--
-- Name: cowork_units_work_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cowork_units_work_idx ON public.cowork_units USING btree (workspace_id, project_id, work_id);


--
-- Name: dm_message_observations_viewer_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dm_message_observations_viewer_idx ON public.dm_message_observations USING btree (dm_id, viewer_id);


--
-- Name: dm_messages_roots_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dm_messages_roots_idx ON public.dm_messages USING btree (dm_id, sequence) WHERE (thread_root_id IS NULL);


--
-- Name: dm_messages_thread_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dm_messages_thread_idx ON public.dm_messages USING btree (thread_root_id, sequence) WHERE (thread_root_id IS NOT NULL);


--
-- Name: dm_participants_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dm_participants_user_idx ON public.dm_participants USING btree (workspace_id, user_id, dm_id);


--
-- Name: dms_workspace_activity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dms_workspace_activity_idx ON public.dms USING btree (workspace_id, COALESCE(last_message_at, created_at) DESC, id);


--
-- Name: doc_live_presence_room; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX doc_live_presence_room ON public.doc_live_presence USING btree (doc_id, generation, expires_at);


--
-- Name: encrypted_workspace_creations_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX encrypted_workspace_creations_person ON public.encrypted_workspace_creations USING btree (user_id, at);


--
-- Name: event_audience_event_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX event_audience_event_idx ON public.event_audience USING btree (event_id);


--
-- Name: events_seq_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX events_seq_idx ON public.events USING btree (seq);


--
-- Name: events_workspace_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX events_workspace_idx ON public.events USING btree (workspace_id, created_at) WHERE (workspace_id IS NOT NULL);


--
-- Name: github_processing_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX github_processing_due_idx ON public.github_processing USING btree (state, next_attempt_at);


--
-- Name: github_task_rule_changes_task_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX github_task_rule_changes_task_idx ON public.github_task_rule_changes USING btree (task_id, created_at DESC, id DESC);


--
-- Name: idempotency_keys_expiry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idempotency_keys_expiry_idx ON public.idempotency_keys USING btree (expires_at);


--
-- Name: idempotency_keys_scope_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idempotency_keys_scope_idx ON public.idempotency_keys USING btree (principal, COALESCE(workspace_id, '00000000-0000-0000-0000-000000000000'::uuid), operation, key);


--
-- Name: live_access_fences_workspace_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX live_access_fences_workspace_idx ON public.live_access_fences USING btree (workspace_id);


--
-- Name: live_admissions_auth_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX live_admissions_auth_session_idx ON public.live_admissions USING btree (auth_session_id) WHERE (revoked_at IS NULL);


--
-- Name: live_admissions_revoked_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX live_admissions_revoked_idx ON public.live_admissions USING btree (revoked_at) WHERE (revoked_at IS NOT NULL);


--
-- Name: live_admissions_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX live_admissions_session_idx ON public.live_admissions USING btree (live_session_id, user_id, issued_at DESC);


--
-- Name: live_invitations_recipient_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX live_invitations_recipient_idx ON public.live_invitations USING btree (recipient_id, response, created_at DESC, id DESC);


--
-- Name: live_presentations_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX live_presentations_session_idx ON public.live_presentations USING btree (session_id, created_at, id);


--
-- Name: live_sessions_lifecycle_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX live_sessions_lifecycle_idx ON public.live_sessions USING btree (state, updated_at, id);


--
-- Name: live_sessions_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX live_sessions_project_idx ON public.live_sessions USING btree (project_id, created_at DESC, id DESC);


--
-- Name: live_webhook_events_received_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX live_webhook_events_received_idx ON public.live_webhook_events USING btree (received_at);


--
-- Name: map_live_gestures_room; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX map_live_gestures_room ON public.map_live_gestures USING btree (sketch_id, generation, expires_at);


--
-- Name: map_live_presence_room; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX map_live_presence_room ON public.map_live_presence USING btree (sketch_id, generation, expires_at);


--
-- Name: message_references_dm_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX message_references_dm_position_idx ON public.message_references USING btree (dm_message_id, "position") WHERE (dm_message_id IS NOT NULL);


--
-- Name: message_references_project_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX message_references_project_position_idx ON public.message_references USING btree (project_message_id, "position") WHERE (project_message_id IS NOT NULL);


--
-- Name: message_references_target_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX message_references_target_idx ON public.message_references USING btree (target_id);


--
-- Name: notification_address_sends_last_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notification_address_sends_last_idx ON public.notification_address_sends USING btree (last_sent_at);


--
-- Name: notification_address_tokens_address_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notification_address_tokens_address_idx ON public.notification_address_tokens USING btree (address_id);


--
-- Name: notification_addresses_user_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notification_addresses_user_created_idx ON public.notification_addresses USING btree (user_id, created_at);


--
-- Name: notification_addresses_user_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX notification_addresses_user_email_idx ON public.notification_addresses USING btree (user_id, lower(email));


--
-- Name: notification_emails_account_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX notification_emails_account_idx ON public.notification_emails USING btree (notification_id) WHERE (address_kind = 'account'::text);


--
-- Name: notification_emails_extra_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX notification_emails_extra_idx ON public.notification_emails USING btree (notification_id, address_id) WHERE ((address_kind = 'extra'::text) AND (address_id IS NOT NULL));


--
-- Name: notification_emails_user_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notification_emails_user_created_idx ON public.notification_emails USING btree (user_id, created_at DESC);


--
-- Name: notifications_recipient_event_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX notifications_recipient_event_idx ON public.notifications USING btree (user_id, event_id) WHERE (event_id IS NOT NULL);


--
-- Name: notifications_source_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_source_idx ON public.notifications USING btree (source_type, source_id);


--
-- Name: notifications_user_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_user_created_idx ON public.notifications USING btree (user_id, created_at DESC);


--
-- Name: oauthAccessToken_authorizationCodeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthAccessToken_authorizationCodeId_idx" ON public.oauth_access_token USING btree (authorization_code_id);


--
-- Name: oauthAccessToken_clientId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthAccessToken_clientId_idx" ON public.oauth_access_token USING btree (client_id);


--
-- Name: oauthAccessToken_refreshId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthAccessToken_refreshId_idx" ON public.oauth_access_token USING btree (refresh_id);


--
-- Name: oauthAccessToken_sessionId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthAccessToken_sessionId_idx" ON public.oauth_access_token USING btree (session_id);


--
-- Name: oauthAccessToken_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthAccessToken_userId_idx" ON public.oauth_access_token USING btree (user_id);


--
-- Name: oauthClientResource_clientId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthClientResource_clientId_idx" ON public.oauth_client_resource USING btree (client_id);


--
-- Name: oauthClientResource_clientId_resourceId_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "oauthClientResource_clientId_resourceId_uidx" ON public.oauth_client_resource USING btree (client_id, resource_id);


--
-- Name: oauthClientResource_resourceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthClientResource_resourceId_idx" ON public.oauth_client_resource USING btree (resource_id);


--
-- Name: oauthClient_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthClient_userId_idx" ON public.oauth_client USING btree (user_id);


--
-- Name: oauthConsent_clientId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthConsent_clientId_idx" ON public.oauth_consent USING btree (client_id);


--
-- Name: oauthConsent_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthConsent_userId_idx" ON public.oauth_consent USING btree (user_id);


--
-- Name: oauthRefreshToken_authorizationCodeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthRefreshToken_authorizationCodeId_idx" ON public.oauth_refresh_token USING btree (authorization_code_id);


--
-- Name: oauthRefreshToken_clientId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthRefreshToken_clientId_idx" ON public.oauth_refresh_token USING btree (client_id);


--
-- Name: oauthRefreshToken_sessionId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthRefreshToken_sessionId_idx" ON public.oauth_refresh_token USING btree (session_id);


--
-- Name: oauthRefreshToken_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthRefreshToken_userId_idx" ON public.oauth_refresh_token USING btree (user_id);


--
-- Name: oauth_grant_authentication_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX oauth_grant_authentication_user_idx ON public.oauth_grant_authentication USING btree (user_id);


--
-- Name: password_attempts_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX password_attempts_person ON public.password_attempts USING btree (workspace_id, user_id, at);


--
-- Name: personal_run_private_texts_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_run_private_texts_run_idx ON public.personal_run_private_texts USING btree (run_id);


--
-- Name: personal_run_web_reads_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_run_web_reads_run_idx ON public.personal_run_web_reads USING btree (run_id, read_at);


--
-- Name: personal_run_web_searches_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_run_web_searches_run_idx ON public.personal_run_web_searches USING btree (run_id, searched_at);


--
-- Name: personal_runs_answers_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_runs_answers_idx ON public.personal_runs USING btree (conversation_id, committed_at, id) WHERE (committed_at IS NOT NULL);


--
-- Name: personal_runs_chat_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_runs_chat_idx ON public.personal_runs USING btree (agent_id, created_at DESC) WHERE ((project_id IS NULL) AND (dm_id IS NULL));


--
-- Name: personal_runs_dm_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_runs_dm_idx ON public.personal_runs USING btree (dm_id, created_at DESC) WHERE (dm_id IS NOT NULL);


--
-- Name: personal_runs_dm_thread_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_runs_dm_thread_idx ON public.personal_runs USING btree (dm_thread_root_id, created_at DESC) WHERE (dm_thread_root_id IS NOT NULL);


--
-- Name: personal_runs_key_day_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_runs_key_day_idx ON public.personal_runs USING btree (connection_id, reserved_at) WHERE (engine = 'server'::text);


--
-- Name: personal_runs_one_working_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX personal_runs_one_working_idx ON public.personal_runs USING btree (owner_user_id) WHERE (status = ANY (ARRAY['reading'::text, 'dispatching'::text]));


--
-- Name: personal_runs_owner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_runs_owner_idx ON public.personal_runs USING btree (owner_user_id, created_at DESC, id DESC);


--
-- Name: personal_runs_queued_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_runs_queued_idx ON public.personal_runs USING btree (((authority <> 'owner_request'::text)), created_at, id) WHERE (status = 'queued'::text);


--
-- Name: personal_runs_resume_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_runs_resume_idx ON public.personal_runs USING btree (resume_at) WHERE ((status = 'queued'::text) AND (resume_at IS NOT NULL));


--
-- Name: personal_runs_work_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_runs_work_idx ON public.personal_runs USING btree (work_id, created_at DESC) WHERE (work_id IS NOT NULL);


--
-- Name: project_conversations_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_conversations_project_idx ON public.project_conversations USING btree (project_id, created_at DESC, id DESC);


--
-- Name: project_decisions_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_decisions_project_idx ON public.project_decisions USING btree (project_id, created_at DESC, id DESC);


--
-- Name: project_files_agent_upload_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_files_agent_upload_idx ON public.project_files USING btree (project_id, uploader_agent_id, upload_id) WHERE (uploader_agent_id IS NOT NULL);


--
-- Name: project_files_expiry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_files_expiry_idx ON public.project_files USING btree (expires_at) WHERE (published_at IS NULL);


--
-- Name: project_files_human_upload_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_files_human_upload_idx ON public.project_files USING btree (project_id, uploader_id, upload_id) WHERE (uploader_id IS NOT NULL);


--
-- Name: project_files_replay_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_files_replay_idx ON public.project_files USING btree (replay_of) WHERE (replay_of IS NOT NULL);


--
-- Name: project_files_thought_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_files_thought_idx ON public.project_files USING btree (thought_id) WHERE (thought_id IS NOT NULL);


--
-- Name: project_grants_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_grants_user_idx ON public.project_grants USING btree (project_id, user_id) WHERE (user_id IS NOT NULL);


--
-- Name: project_grants_user_lookup_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_grants_user_lookup_idx ON public.project_grants USING btree (user_id) WHERE (user_id IS NOT NULL);


--
-- Name: project_material_edit_retry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_material_edit_retry_idx ON public.project_material_versions USING btree (material_id, author_id, client_mutation_id) WHERE (client_mutation_id IS NOT NULL);


--
-- Name: project_materials_docs_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_materials_docs_idx ON public.project_materials USING btree (project_id, updated_at DESC, id DESC) WHERE (kind = 'doc'::text);


--
-- Name: project_materials_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_materials_project_idx ON public.project_materials USING btree (project_id, created_at DESC, id DESC);


--
-- Name: project_message_agent_command_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_message_agent_command_idx ON public.project_messages USING btree (project_id, author_agent_id, client_message_id) WHERE (author_agent_id IS NOT NULL);


--
-- Name: project_message_observations_viewer_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_message_observations_viewer_idx ON public.project_message_observations USING btree (project_id, viewer_id);


--
-- Name: project_messages_conversation_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_messages_conversation_idx ON public.project_messages USING btree (conversation_id, sequence);


--
-- Name: project_object_links_from_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_object_links_from_idx ON public.project_object_links USING btree (from_id);


--
-- Name: project_object_links_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_object_links_project_idx ON public.project_object_links USING btree (project_id);


--
-- Name: project_object_links_to_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_object_links_to_idx ON public.project_object_links USING btree (to_id);


--
-- Name: project_object_links_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_object_links_unique_idx ON public.project_object_links USING btree (from_id, role, to_type, to_id, COALESCE(to_version, 0));


--
-- Name: project_task_activity_work_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_task_activity_work_idx ON public.project_task_activity USING btree (work_id, created_at DESC, id DESC);


--
-- Name: project_task_dependencies_prerequisite_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_task_dependencies_prerequisite_idx ON public.project_task_dependencies USING btree (prerequisite_id, task_id);


--
-- Name: project_task_dependencies_task_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_task_dependencies_task_idx ON public.project_task_dependencies USING btree (task_id, prerequisite_id);


--
-- Name: project_task_notices_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_task_notices_project_idx ON public.project_task_notices USING btree (project_id, created_at DESC, id DESC);


--
-- Name: project_task_updates_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_task_updates_project_idx ON public.project_task_updates USING btree (project_id, created_at DESC, id DESC);


--
-- Name: project_work_creation_command_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_work_creation_command_idx ON public.project_work_items USING btree (project_id, created_by_kind, created_by_id, client_command_id) WHERE (client_command_id IS NOT NULL);


--
-- Name: project_work_items_owner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_work_items_owner_idx ON public.project_work_items USING btree (workspace_id, owner_user_id) WHERE (owner_user_id IS NOT NULL);


--
-- Name: project_work_items_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_work_items_project_idx ON public.project_work_items USING btree (project_id, created_at DESC, id DESC);


--
-- Name: project_work_items_waiting_decision_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_work_items_waiting_decision_idx ON public.project_work_items USING btree (waiting_for_decision_id) WHERE (waiting_for_decision_id IS NOT NULL);


--
-- Name: project_work_items_waiting_for_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_work_items_waiting_for_idx ON public.project_work_items USING btree (workspace_id, waiting_for_user_id) WHERE (waiting_for_user_id IS NOT NULL);


--
-- Name: project_work_items_waiting_work_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_work_items_waiting_work_idx ON public.project_work_items USING btree (waiting_for_work_id) WHERE (waiting_for_work_id IS NOT NULL);


--
-- Name: project_work_number_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_work_number_idx ON public.project_work_items USING btree (project_id, number);


--
-- Name: push_subscriptions_session_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_subscriptions_session_id_idx ON public.push_subscriptions USING btree (session_id);


--
-- Name: push_subscriptions_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_subscriptions_user_id_idx ON public.push_subscriptions USING btree (user_id);


--
-- Name: return_points_conversation_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX return_points_conversation_idx ON public.return_points USING btree (conversation_id) WHERE (conversation_id IS NOT NULL);


--
-- Name: return_points_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX return_points_project_idx ON public.return_points USING btree (project_id) WHERE (project_id IS NOT NULL);


--
-- Name: sealed_job_waits_workspace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sealed_job_waits_workspace ON public.sealed_job_waits USING btree (workspace_id, created_at);


--
-- Name: search_changes_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_changes_at_idx ON public.search_changes USING btree (at);


--
-- Name: search_changes_workspace_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_changes_workspace_idx ON public.search_changes USING btree (workspace_id, seq);


--
-- Name: search_changes_xid_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_changes_xid_idx ON public.search_changes USING btree (workspace_id, xid);


--
-- Name: search_documents_keys_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_documents_keys_idx ON public.search_documents USING gin (keys) WITH (fastupdate=off);


--
-- Name: search_documents_parent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_documents_parent_idx ON public.search_documents USING btree (parent_id) WHERE (parent_id IS NOT NULL);


--
-- Name: search_documents_person_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_documents_person_idx ON public.search_documents USING btree (object_id) WHERE (kind = 'person'::text);


--
-- Name: search_documents_sealed_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_documents_sealed_idx ON public.search_documents USING btree (workspace_id, id) WHERE sealed;


--
-- Name: sketch_links_pair_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sketch_links_pair_idx ON public.sketch_links USING btree (sketch_id, LEAST(from_id, to_id), GREATEST(from_id, to_id));


--
-- Name: sketch_links_to_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sketch_links_to_idx ON public.sketch_links USING btree (sketch_id, to_id);


--
-- Name: sketch_thoughts_sketch_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sketch_thoughts_sketch_idx ON public.sketch_thoughts USING btree (sketch_id, created_at, id);


--
-- Name: sketches_one_private_map_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sketches_one_private_map_idx ON public.sketches USING btree (workspace_id, created_by_user_id) WHERE (scope = 'private'::text);


--
-- Name: sketches_private_owner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sketches_private_owner_idx ON public.sketches USING btree (workspace_id, created_by_user_id) WHERE (scope = 'private'::text);


--
-- Name: sketches_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sketches_project_idx ON public.sketches USING btree (project_id) WHERE (project_id IS NOT NULL);


--
-- Name: sketches_workspace_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sketches_workspace_idx ON public.sketches USING btree (workspace_id, updated_at DESC, id);


--
-- Name: workspace_dek_wraps_workspace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_dek_wraps_workspace ON public.workspace_dek_wraps USING btree (workspace_id, key_version);


--
-- Name: workspace_holders_person; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspace_holders_person ON public.workspace_holders USING btree (workspace_id, user_id) WHERE (kind = 'password'::text);


--
-- Name: workspace_holders_recovery; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspace_holders_recovery ON public.workspace_holders USING btree (workspace_id) WHERE (kind = 'recovery'::text);


--
-- Name: workspace_holders_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_holders_user ON public.workspace_holders USING btree (user_id) WHERE (user_id IS NOT NULL);


--
-- Name: workspace_invites_pending_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_invites_pending_idx ON public.workspace_invites USING btree (workspace_id, created_at DESC) WHERE ((revoked_at IS NULL) AND (accepted_at IS NULL));


--
-- Name: workspace_members_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_members_user_idx ON public.workspace_members USING btree (user_id);


--
-- Name: workspace_unlocks_boot; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_unlocks_boot ON public.workspace_unlocks USING btree (boot_id);


--
-- Name: workspaces_company_workspace_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspaces_company_workspace_idx ON public.workspaces USING btree (company_workspace_id) WHERE (company_workspace_id IS NOT NULL);


--
-- Name: workspaces_creation; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspaces_creation ON public.workspaces USING btree (created_by, creation_id) WHERE (creation_id IS NOT NULL);


--
-- Name: workspaces_one_company; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspaces_one_company ON public.workspaces USING btree ((true)) WHERE company;


--
-- Name: job_common_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.job_pkey ATTACH PARTITION pgboss.job_common_pkey;


--
-- Name: queue_stats_20261112_name_captured_on_deferred_count_queued_idx; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.queue_stats_i1 ATTACH PARTITION pgboss.queue_stats_20261112_name_captured_on_deferred_count_queued_idx;


--
-- Name: queue_stats_20261112_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.queue_stats_pkey ATTACH PARTITION pgboss.queue_stats_20261112_pkey;


--
-- Name: queue_stats_20261113_name_captured_on_deferred_count_queued_idx; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.queue_stats_i1 ATTACH PARTITION pgboss.queue_stats_20261113_name_captured_on_deferred_count_queued_idx;


--
-- Name: queue_stats_20261113_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.queue_stats_pkey ATTACH PARTITION pgboss.queue_stats_20261113_pkey;


--
-- Name: idempotency_keys a_idempotency_scope_required; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_idempotency_scope_required BEFORE INSERT ON public.idempotency_keys FOR EACH ROW EXECUTE FUNCTION public.idempotency_scope_required();


--
-- Name: event_audience a_sealed_event_audience; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_event_audience BEFORE INSERT OR UPDATE ON public.event_audience FOR EACH ROW EXECUTE FUNCTION public.flux_event_audience_shape();


--
-- Name: events a_sealed_event_data; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_event_data BEFORE INSERT OR UPDATE ON public.events FOR EACH ROW EXECUTE FUNCTION public.flux_event_data_free();


--
-- Name: sealed_job_waits a_sealed_wait_ids_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_wait_ids_only BEFORE INSERT OR UPDATE ON public.sealed_job_waits FOR EACH ROW EXECUTE FUNCTION public.flux_sealed_wait_ids_only();


--
-- Name: agent_chat_messages a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_chat_messages FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_chat_reads a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_chat_reads FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_command_receipts a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_command_receipts FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_connections a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_connections FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_memory_items a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_memory_items FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_oauth_bindings a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_oauth_bindings FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_proposals a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_proposals FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_questions a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_questions FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_runtime_sessions a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_runtime_sessions FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_stops a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_stops FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_task_taking a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_task_taking FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agents a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agents FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: assistant_changes a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.assistant_changes FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: assistant_jobs a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.assistant_jobs FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: assistant_settings a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.assistant_settings FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: cowork_checkpoints a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.cowork_checkpoints FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: cowork_connection_slots a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.cowork_connection_slots FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: cowork_units a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.cowork_units FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: personal_runs a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.personal_runs FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: github_bindings a_sealed_workspace_refused; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_refused BEFORE INSERT ON public.github_bindings FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_refused();


--
-- Name: github_rule_defaults a_sealed_workspace_refused; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_refused BEFORE INSERT ON public.github_rule_defaults FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_refused();


--
-- Name: github_task_links a_sealed_workspace_refused; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_refused BEFORE INSERT ON public.github_task_links FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_refused();


--
-- Name: github_task_rule_changes a_sealed_workspace_refused; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_refused BEFORE INSERT ON public.github_task_rule_changes FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_refused();


--
-- Name: github_task_rules a_sealed_workspace_refused; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_refused BEFORE INSERT ON public.github_task_rules FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_refused();


--
-- Name: agent_runtime_bindings agent_runtime_auth_lifecycle; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER agent_runtime_auth_lifecycle AFTER UPDATE OF state ON public.agent_runtime_bindings FOR EACH ROW EXECUTE FUNCTION public.invalidate_runtime_auth_operations();


--
-- Name: agent_task_events agent_task_events_notify; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER agent_task_events_notify AFTER INSERT ON public.agent_task_events FOR EACH STATEMENT EXECUTE FUNCTION public.agent_task_events_notify();


--
-- Name: cowork_units ai_work_admission; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ai_work_admission BEFORE INSERT ON public.cowork_units FOR EACH ROW EXECUTE FUNCTION public.ai_work_admission();


--
-- Name: personal_runs ai_work_admission; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ai_work_admission BEFORE INSERT ON public.personal_runs FOR EACH ROW EXECUTE FUNCTION public.ai_work_admission();


--
-- Name: auth_accounts auth_account_password_changed; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER auth_account_password_changed BEFORE UPDATE OF password, password_version_expected ON public.auth_accounts FOR EACH ROW WHEN (((new.password_version_expected IS NOT NULL) OR (new.password IS DISTINCT FROM old.password))) EXECUTE FUNCTION public.auth_account_password_changed();


--
-- Name: auth_sessions auth_session_password_unchanged; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER auth_session_password_unchanged BEFORE INSERT ON public.auth_sessions FOR EACH ROW WHEN ((new.password_version_checked IS NOT NULL)) EXECUTE FUNCTION public.auth_session_password_unchanged();


--
-- Name: auth_sessions auth_sessions_revoke_live_admissions; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER auth_sessions_revoke_live_admissions AFTER DELETE ON public.auth_sessions FOR EACH ROW EXECUTE FUNCTION public.flux_revoke_live_admissions();


--
-- Name: agent_connections cowork_connection_deleted; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cowork_connection_deleted BEFORE DELETE ON public.agent_connections FOR EACH ROW EXECUTE FUNCTION public.cowork_stop_connection_units();


--
-- Name: agent_connections cowork_connection_revoked; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cowork_connection_revoked BEFORE UPDATE OF revoked_at ON public.agent_connections FOR EACH ROW EXECUTE FUNCTION public.cowork_stop_connection_units();


--
-- Name: dm_messages dm_messages_flat_thread; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dm_messages_flat_thread BEFORE INSERT OR UPDATE OF thread_root_id ON public.dm_messages FOR EACH ROW EXECUTE FUNCTION public.dm_messages_flat_thread();


--
-- Name: doc_live_archives doc_live_archive_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER doc_live_archive_immutable BEFORE UPDATE ON public.doc_live_archives FOR EACH ROW EXECUTE FUNCTION public.immutable_live_editing_record();


--
-- Name: doc_live_replicas doc_live_replica_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER doc_live_replica_immutable BEFORE UPDATE ON public.doc_live_replicas FOR EACH ROW EXECUTE FUNCTION public.live_replica_ownership_immutable();


--
-- Name: doc_live_snapshots doc_live_snapshot_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER doc_live_snapshot_immutable BEFORE UPDATE ON public.doc_live_snapshots FOR EACH ROW EXECUTE FUNCTION public.immutable_live_editing_record();


--
-- Name: doc_live_updates doc_live_update_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER doc_live_update_immutable BEFORE UPDATE ON public.doc_live_updates FOR EACH ROW EXECUTE FUNCTION public.immutable_live_editing_record();


--
-- Name: events events_assign_seq; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER events_assign_seq BEFORE INSERT ON public.events FOR EACH ROW EXECUTE FUNCTION public.flux_events_assign_seq();


--
-- Name: events events_notify; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER events_notify AFTER INSERT ON public.events FOR EACH ROW EXECUTE FUNCTION public.flux_events_notify();


--
-- Name: live_editing_intents live_editing_intent_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER live_editing_intent_immutable BEFORE DELETE OR UPDATE ON public.live_editing_intents FOR EACH ROW EXECUTE FUNCTION public.immutable_live_editing_record();


--
-- Name: live_sessions live_sessions_doc_in_space; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER live_sessions_doc_in_space BEFORE INSERT OR UPDATE OF doc_id, project_id, workspace_id ON public.live_sessions FOR EACH ROW EXECUTE FUNCTION public.live_session_doc_in_space();


--
-- Name: map_live_heads map_live_head_identity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER map_live_head_identity BEFORE UPDATE ON public.map_live_heads FOR EACH ROW EXECUTE FUNCTION public.guard_map_live_identity();


--
-- Name: map_live_journal map_live_journal_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER map_live_journal_immutable BEFORE UPDATE ON public.map_live_journal FOR EACH ROW EXECUTE FUNCTION public.immutable_live_editing_record();


--
-- Name: map_live_object_versions map_live_object_identity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER map_live_object_identity BEFORE UPDATE ON public.map_live_object_versions FOR EACH ROW EXECUTE FUNCTION public.guard_map_live_identity();


--
-- Name: map_live_undone map_live_undone_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER map_live_undone_immutable BEFORE UPDATE ON public.map_live_undone FOR EACH ROW EXECUTE FUNCTION public.immutable_live_editing_record();


--
-- Name: project_materials material_agent_doc_stays_doc; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER material_agent_doc_stays_doc BEFORE UPDATE OF kind ON public.project_materials FOR EACH ROW EXECUTE FUNCTION public.material_agent_doc_stays_doc();


--
-- Name: project_material_versions material_version_agent_doc_parent; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER material_version_agent_doc_parent BEFORE INSERT ON public.project_material_versions FOR EACH ROW EXECUTE FUNCTION public.material_version_agent_doc_parent();


--
-- Name: project_material_versions material_version_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER material_version_immutable BEFORE UPDATE ON public.project_material_versions FOR EACH ROW EXECUTE FUNCTION public.forbid_material_version_update();


--
-- Name: personal_runs personal_run_private_texts_end; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER personal_run_private_texts_end AFTER UPDATE OF status ON public.personal_runs FOR EACH ROW WHEN (((new.status <> ALL (ARRAY['queued'::text, 'reading'::text, 'dispatching'::text])) AND (old.status IS DISTINCT FROM new.status))) EXECUTE FUNCTION public.personal_run_private_texts_end();


--
-- Name: personal_runs personal_run_task_ended; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER personal_run_task_ended AFTER UPDATE OF status ON public.personal_runs FOR EACH ROW WHEN (((new.work_id IS NOT NULL) AND (old.status = ANY (ARRAY['queued'::text, 'reading'::text, 'dispatching'::text])) AND (new.status <> ALL (ARRAY['queued'::text, 'reading'::text, 'dispatching'::text])))) EXECUTE FUNCTION public.personal_run_task_ended();


--
-- Name: personal_runs personal_run_task_started; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER personal_run_task_started AFTER UPDATE OF status ON public.personal_runs FOR EACH ROW WHEN (((new.work_id IS NOT NULL) AND (new.kind = 'task'::text) AND (old.status = 'queued'::text) AND (new.status = 'reading'::text))) EXECUTE FUNCTION public.personal_run_task_started();


--
-- Name: projects project_ai_policy_create; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER project_ai_policy_create AFTER INSERT ON public.projects FOR EACH ROW EXECUTE FUNCTION public.project_ai_policy_create();


--
-- Name: project_ai_policies project_ai_policy_encrypted; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER project_ai_policy_encrypted BEFORE INSERT OR UPDATE ON public.project_ai_policies FOR EACH ROW EXECUTE FUNCTION public.project_ai_policy_encrypted();


--
-- Name: project_task_dependencies project_task_dependency_bound; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER project_task_dependency_bound BEFORE INSERT ON public.project_task_dependencies FOR EACH ROW EXECUTE FUNCTION public.flux_task_dependency_bound();


--
-- Name: project_task_plan_intents project_task_plan_intent_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER project_task_plan_intent_immutable BEFORE UPDATE ON public.project_task_plan_intents FOR EACH ROW EXECUTE FUNCTION public.flux_task_plan_intent_immutable();


--
-- Name: projects project_task_sequence_lifecycle; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER project_task_sequence_lifecycle AFTER INSERT OR DELETE ON public.projects FOR EACH ROW EXECUTE FUNCTION public.project_task_sequence_lifecycle();


--
-- Name: project_work_items project_work_number; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER project_work_number BEFORE INSERT OR UPDATE OF number, project_id ON public.project_work_items FOR EACH ROW EXECUTE FUNCTION public.project_work_number();


--
-- Name: search_documents search_change_log; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_change_log AFTER INSERT OR DELETE OR UPDATE ON public.search_documents FOR EACH ROW EXECUTE FUNCTION public.search_change_log();


--
-- Name: auth_users search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER UPDATE OF name ON public.auth_users FOR EACH ROW WHEN ((new.name IS DISTINCT FROM old.name)) EXECUTE FUNCTION public.search_index_user_name();


--
-- Name: dm_messages search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER INSERT OR DELETE OR UPDATE ON public.dm_messages FOR EACH ROW EXECUTE FUNCTION public.search_index_dm_message();


--
-- Name: project_decisions search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER INSERT OR DELETE OR UPDATE ON public.project_decisions FOR EACH ROW EXECUTE FUNCTION public.search_index_decision();


--
-- Name: project_material_versions search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER INSERT OR DELETE OR UPDATE ON public.project_material_versions FOR EACH ROW EXECUTE FUNCTION public.search_index_material_version();


--
-- Name: project_messages search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER INSERT OR DELETE OR UPDATE ON public.project_messages FOR EACH ROW EXECUTE FUNCTION public.search_index_message();


--
-- Name: project_work_items search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER INSERT OR DELETE OR UPDATE ON public.project_work_items FOR EACH ROW EXECUTE FUNCTION public.search_index_work();


--
-- Name: projects search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER INSERT OR DELETE OR UPDATE OF name, visibility ON public.projects FOR EACH ROW EXECUTE FUNCTION public.search_index_project();


--
-- Name: sketch_thoughts search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER INSERT OR DELETE OR UPDATE ON public.sketch_thoughts FOR EACH ROW EXECUTE FUNCTION public.search_index_thought();


--
-- Name: sketches search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER INSERT OR DELETE OR UPDATE ON public.sketches FOR EACH ROW EXECUTE FUNCTION public.search_index_sketch();


--
-- Name: workspace_members search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER INSERT OR DELETE OR UPDATE ON public.workspace_members FOR EACH ROW EXECUTE FUNCTION public.search_index_member();


--
-- Name: project_work_items task_creation_history_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER task_creation_history_guard BEFORE UPDATE ON public.project_work_items FOR EACH ROW EXECUTE FUNCTION public.flux_guard_task_creation_history();


--
-- Name: task_creation_undo_receipts task_creation_receipt_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER task_creation_receipt_guard BEFORE DELETE OR UPDATE ON public.task_creation_undo_receipts FOR EACH ROW EXECUTE FUNCTION public.flux_guard_task_creation_receipt();


--
-- Name: workspaces workspace_company_link_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER workspace_company_link_guard BEFORE INSERT OR UPDATE OF company_workspace_id ON public.workspaces FOR EACH ROW EXECUTE FUNCTION public.workspace_company_link_guard();


--
-- Name: workspaces workspace_encryption_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER workspace_encryption_immutable BEFORE UPDATE OF encrypted ON public.workspaces FOR EACH ROW EXECUTE FUNCTION public.workspace_encryption_immutable();


--
-- Name: workspace_holders workspace_holder_delete_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER workspace_holder_delete_guard BEFORE DELETE ON public.workspace_holders FOR EACH ROW EXECUTE FUNCTION public.workspace_holder_delete_guard();


--
-- Name: workspace_holders workspace_holder_deleted; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER workspace_holder_deleted AFTER DELETE ON public.workspace_holders FOR EACH ROW EXECUTE FUNCTION public.workspace_holder_deleted();


--
-- Name: workspace_members workspace_manager_lost; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER workspace_manager_lost AFTER DELETE OR UPDATE OF role ON public.workspace_members FOR EACH ROW EXECUTE FUNCTION public.workspace_manager_lost();


--
-- Name: notifications z_notification_content_free; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_notification_content_free BEFORE INSERT OR UPDATE ON public.notifications FOR EACH ROW EXECUTE FUNCTION public.flux_notification_content_free();


--
-- Name: dm_messages z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.dm_messages FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'body', 'request_fingerprint');


--
-- Name: dms z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.dms FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'title');


--
-- Name: doc_live_archives z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.doc_live_archives FOR EACH ROW EXECUTE FUNCTION public.flux_sealed_backstop('via:doc_id:project_materials:id', 'body', 'codec_state', 'hash');


--
-- Name: doc_live_heads z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.doc_live_heads FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'body', 'codec_state', 'hash');


--
-- Name: doc_live_snapshots z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.doc_live_snapshots FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'hash');


--
-- Name: doc_live_updates z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.doc_live_updates FOR EACH ROW EXECUTE FUNCTION public.flux_sealed_backstop('via:doc_id:project_materials:id', 'bytes', 'ledger', 'fingerprint');


--
-- Name: idempotency_keys z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.idempotency_keys FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'response_body', 'request_hash');


--
-- Name: live_editing_intents z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.live_editing_intents FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'receipt', 'fingerprint');


--
-- Name: map_live_journal z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.map_live_journal FOR EACH ROW EXECUTE FUNCTION public.flux_sealed_backstop('via:sketch_id:sketches:id', 'change', 'fingerprint');


--
-- Name: native_command_receipts z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.native_command_receipts FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'request_fingerprint');


--
-- Name: project_decisions z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.project_decisions FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'title', 'rationale');


--
-- Name: project_files z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.project_files FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'name', 'sha256');


--
-- Name: project_material_versions z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.project_material_versions FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'title', 'body', 'url', 'reason', 'request_fingerprint');


--
-- Name: project_materials z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.project_materials FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'request_fingerprint');


--
-- Name: project_messages z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.project_messages FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'body', 'request_fingerprint');


--
-- Name: project_task_activity z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.project_task_activity FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'detail');


--
-- Name: project_task_plan_intents z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.project_task_plan_intents FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'creation_fingerprint');


--
-- Name: project_task_updates z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.project_task_updates FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'reason');


--
-- Name: project_work_items z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.project_work_items FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'title', 'outcome', 'blocker', 'criteria', 'creation_baseline', 'request_fingerprint', 'came_of_it');


--
-- Name: projects z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.projects FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'name');


--
-- Name: sketch_links z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.sketch_links FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'label');


--
-- Name: sketch_thoughts z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.sketch_thoughts FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'text');


--
-- Name: sketches z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.sketches FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'title');


--
-- Name: task_creation_undo_receipts z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.task_creation_undo_receipts FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'request_fingerprint');


--
-- Name: job_common dlq_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job_common
    ADD CONSTRAINT dlq_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: job_common q_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job_common
    ADD CONSTRAINT q_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: queue queue_dead_letter_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue
    ADD CONSTRAINT queue_dead_letter_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue(name);


--
-- Name: schedule schedule_name_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.schedule
    ADD CONSTRAINT schedule_name_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE CASCADE;


--
-- Name: subscription subscription_name_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.subscription
    ADD CONSTRAINT subscription_name_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE CASCADE;


--
-- Name: agent_chat_messages agent_chat_messages_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat_messages
    ADD CONSTRAINT agent_chat_messages_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.assistant_settings(agent_id) ON DELETE CASCADE;


--
-- Name: agent_chat_messages agent_chat_messages_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat_messages
    ADD CONSTRAINT agent_chat_messages_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agent_chat_messages agent_chat_messages_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat_messages
    ADD CONSTRAINT agent_chat_messages_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.personal_runs(id) ON DELETE CASCADE;


--
-- Name: agent_chat_reads agent_chat_reads_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat_reads
    ADD CONSTRAINT agent_chat_reads_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.assistant_settings(agent_id) ON DELETE CASCADE;


--
-- Name: agent_command_receipts agent_command_receipts_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_command_receipts
    ADD CONSTRAINT agent_command_receipts_binding_id_fkey FOREIGN KEY (binding_id) REFERENCES public.agent_oauth_bindings(id);


--
-- Name: agent_command_receipts agent_command_receipts_connection_id_runtime_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_command_receipts
    ADD CONSTRAINT agent_command_receipts_connection_id_runtime_session_id_fkey FOREIGN KEY (connection_id, runtime_session_id) REFERENCES public.agent_runtime_sessions(connection_id, id);


--
-- Name: agent_command_receipts agent_command_receipts_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_command_receipts
    ADD CONSTRAINT agent_command_receipts_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: agent_connections agent_connections_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_connections
    ADD CONSTRAINT agent_connections_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agent_connections agent_connections_workspace_id_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_connections
    ADD CONSTRAINT agent_connections_workspace_id_agent_id_fkey FOREIGN KEY (workspace_id, agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: agent_memory_items agent_memory_items_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_memory_items
    ADD CONSTRAINT agent_memory_items_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.assistant_settings(agent_id) ON DELETE CASCADE;


--
-- Name: agent_memory_items agent_memory_items_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_memory_items
    ADD CONSTRAINT agent_memory_items_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agent_oauth_bindings agent_oauth_bindings_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_oauth_bindings
    ADD CONSTRAINT agent_oauth_bindings_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.oauth_client(client_id);


--
-- Name: agent_oauth_bindings agent_oauth_bindings_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_oauth_bindings
    ADD CONSTRAINT agent_oauth_bindings_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.agent_connections(id);


--
-- Name: agent_oauth_bindings agent_oauth_bindings_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_oauth_bindings
    ADD CONSTRAINT agent_oauth_bindings_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id);


--
-- Name: agent_playbook_acknowledgments agent_playbook_acknowledgments_runtime_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_playbook_acknowledgments
    ADD CONSTRAINT agent_playbook_acknowledgments_runtime_session_id_fkey FOREIGN KEY (runtime_session_id) REFERENCES public.agent_runtime_sessions(id) ON DELETE CASCADE;


--
-- Name: agent_proposals agent_proposals_dismissed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_proposals
    ADD CONSTRAINT agent_proposals_dismissed_by_fkey FOREIGN KEY (dismissed_by) REFERENCES public.auth_users(id);


--
-- Name: agent_proposals agent_proposals_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_proposals
    ADD CONSTRAINT agent_proposals_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id);


--
-- Name: agent_proposals agent_proposals_workspace_id_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_proposals
    ADD CONSTRAINT agent_proposals_workspace_id_agent_id_fkey FOREIGN KEY (workspace_id, agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: agent_proposals agent_proposals_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_proposals
    ADD CONSTRAINT agent_proposals_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: agent_proposals agent_proposals_workspace_id_project_id_source_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_proposals
    ADD CONSTRAINT agent_proposals_workspace_id_project_id_source_material_id_fkey FOREIGN KEY (workspace_id, project_id, source_material_id, source_material_version) REFERENCES public.project_material_versions(workspace_id, project_id, material_id, version);


--
-- Name: agent_questions agent_questions_answered_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_questions
    ADD CONSTRAINT agent_questions_answered_by_fkey FOREIGN KEY (answered_by) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: agent_questions agent_questions_asked_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_questions
    ADD CONSTRAINT agent_questions_asked_user_id_fkey FOREIGN KEY (asked_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agent_questions agent_questions_workspace_id_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_questions
    ADD CONSTRAINT agent_questions_workspace_id_agent_id_fkey FOREIGN KEY (workspace_id, agent_id) REFERENCES public.agents(workspace_id, id) ON DELETE CASCADE;


--
-- Name: agent_questions agent_questions_workspace_id_project_id_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_questions
    ADD CONSTRAINT agent_questions_workspace_id_project_id_conversation_id_fkey FOREIGN KEY (workspace_id, project_id, conversation_id) REFERENCES public.project_conversations(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: agent_questions agent_questions_workspace_id_project_id_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_questions
    ADD CONSTRAINT agent_questions_workspace_id_project_id_message_id_fkey FOREIGN KEY (workspace_id, project_id, message_id) REFERENCES public.project_messages(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: agent_runtime_auth_operations agent_runtime_auth_operations_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_auth_operations
    ADD CONSTRAINT agent_runtime_auth_operations_binding_id_fkey FOREIGN KEY (binding_id) REFERENCES public.agent_runtime_bindings(id) ON DELETE CASCADE;


--
-- Name: agent_runtime_auth_operations agent_runtime_auth_operations_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_auth_operations
    ADD CONSTRAINT agent_runtime_auth_operations_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agent_runtime_bindings agent_runtime_bindings_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_bindings
    ADD CONSTRAINT agent_runtime_bindings_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agent_runtime_bindings agent_runtime_bindings_slot_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_bindings
    ADD CONSTRAINT agent_runtime_bindings_slot_fkey FOREIGN KEY (slot) REFERENCES public.agent_runtime_slots(slot);


--
-- Name: agent_runtime_client_history agent_runtime_client_history_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_client_history
    ADD CONSTRAINT agent_runtime_client_history_binding_id_fkey FOREIGN KEY (binding_id) REFERENCES public.agent_runtime_bindings(id) ON DELETE CASCADE;


--
-- Name: agent_runtime_connections agent_runtime_connections_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_connections
    ADD CONSTRAINT agent_runtime_connections_binding_id_fkey FOREIGN KEY (binding_id) REFERENCES public.agent_runtime_bindings(id) ON DELETE CASCADE;


--
-- Name: agent_runtime_connections agent_runtime_connections_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_connections
    ADD CONSTRAINT agent_runtime_connections_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agent_runtime_console_nonces agent_runtime_console_nonces_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_console_nonces
    ADD CONSTRAINT agent_runtime_console_nonces_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agent_runtime_sessions agent_runtime_sessions_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_sessions
    ADD CONSTRAINT agent_runtime_sessions_binding_id_fkey FOREIGN KEY (binding_id) REFERENCES public.agent_oauth_bindings(id);


--
-- Name: agent_runtime_sessions agent_runtime_sessions_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_sessions
    ADD CONSTRAINT agent_runtime_sessions_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id);


--
-- Name: agent_runtime_sessions agent_runtime_sessions_workspace_id_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_sessions
    ADD CONSTRAINT agent_runtime_sessions_workspace_id_agent_id_fkey FOREIGN KEY (workspace_id, agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: agent_runtime_sessions agent_runtime_sessions_workspace_id_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_sessions
    ADD CONSTRAINT agent_runtime_sessions_workspace_id_connection_id_fkey FOREIGN KEY (workspace_id, connection_id) REFERENCES public.agent_connections(workspace_id, id);


--
-- Name: agent_stops agent_stops_stopped_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_stops
    ADD CONSTRAINT agent_stops_stopped_by_fkey FOREIGN KEY (stopped_by) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agent_stops agent_stops_workspace_id_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_stops
    ADD CONSTRAINT agent_stops_workspace_id_agent_id_fkey FOREIGN KEY (workspace_id, agent_id) REFERENCES public.agents(workspace_id, id) ON DELETE CASCADE;


--
-- Name: agent_stops agent_stops_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_stops
    ADD CONSTRAINT agent_stops_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: agent_stops agent_stops_workspace_id_project_id_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_stops
    ADD CONSTRAINT agent_stops_workspace_id_project_id_task_id_fkey FOREIGN KEY (workspace_id, project_id, task_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: agent_task_events agent_task_events_run_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_task_events
    ADD CONSTRAINT agent_task_events_run_fkey FOREIGN KEY (run_id) REFERENCES public.personal_runs(id) ON DELETE CASCADE;


--
-- Name: agent_task_events agent_task_events_work_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_task_events
    ADD CONSTRAINT agent_task_events_work_fkey FOREIGN KEY (work_id) REFERENCES public.project_work_items(id) ON DELETE CASCADE;


--
-- Name: agent_task_taking agent_task_taking_agent_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_task_taking
    ADD CONSTRAINT agent_task_taking_agent_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_task_taking agent_task_taking_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_task_taking
    ADD CONSTRAINT agent_task_taking_owner_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agents agents_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agents agents_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: assistant_background_notes assistant_background_notes_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_background_notes
    ADD CONSTRAINT assistant_background_notes_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: assistant_changes assistant_changes_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.agent_connections(id) ON DELETE CASCADE;


--
-- Name: assistant_changes assistant_changes_conversation_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_conversation_fk FOREIGN KEY (workspace_id, project_id, conversation_id) REFERENCES public.project_conversations(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: assistant_changes assistant_changes_decided_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_decided_by_fkey FOREIGN KEY (decided_by) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: assistant_changes assistant_changes_other_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_other_user_id_fkey FOREIGN KEY (other_user_id) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: assistant_changes assistant_changes_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: assistant_changes assistant_changes_told_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_told_user_id_fkey FOREIGN KEY (told_user_id) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: assistant_changes assistant_changes_workspace_id_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_workspace_id_agent_id_fkey FOREIGN KEY (workspace_id, agent_id) REFERENCES public.agents(workspace_id, id) ON DELETE CASCADE;


--
-- Name: assistant_changes assistant_changes_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: assistant_changes assistant_changes_workspace_id_project_id_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_workspace_id_project_id_run_id_fkey FOREIGN KEY (workspace_id, project_id, run_id) REFERENCES public.personal_runs(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: assistant_job_runs assistant_job_runs_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_job_runs
    ADD CONSTRAINT assistant_job_runs_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.assistant_jobs(id) ON DELETE CASCADE;


--
-- Name: assistant_job_runs assistant_job_runs_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_job_runs
    ADD CONSTRAINT assistant_job_runs_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: assistant_job_runs assistant_job_runs_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_job_runs
    ADD CONSTRAINT assistant_job_runs_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.personal_runs(id) ON DELETE SET NULL;


--
-- Name: assistant_jobs assistant_jobs_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_jobs
    ADD CONSTRAINT assistant_jobs_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.assistant_settings(agent_id) ON DELETE CASCADE;


--
-- Name: assistant_jobs assistant_jobs_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_jobs
    ADD CONSTRAINT assistant_jobs_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: assistant_jobs assistant_jobs_prepared_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_jobs
    ADD CONSTRAINT assistant_jobs_prepared_run_id_fkey FOREIGN KEY (prepared_run_id) REFERENCES public.personal_runs(id) ON DELETE SET NULL;


--
-- Name: assistant_settings assistant_settings_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_settings
    ADD CONSTRAINT assistant_settings_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: assistant_settings assistant_settings_workspace_id_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_settings
    ADD CONSTRAINT assistant_settings_workspace_id_agent_id_fkey FOREIGN KEY (workspace_id, agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: assistant_settings assistant_settings_workspace_id_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_settings
    ADD CONSTRAINT assistant_settings_workspace_id_connection_id_fkey FOREIGN KEY (workspace_id, connection_id) REFERENCES public.agent_connections(workspace_id, id) ON DELETE CASCADE;


--
-- Name: assistant_settings assistant_settings_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_settings
    ADD CONSTRAINT assistant_settings_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: auth_accounts auth_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_accounts
    ADD CONSTRAINT auth_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: auth_idp_standing auth_idp_standing_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_idp_standing
    ADD CONSTRAINT auth_idp_standing_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: auth_link_intents auth_link_intents_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_link_intents
    ADD CONSTRAINT auth_link_intents_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: auth_session_identities auth_session_identities_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_session_identities
    ADD CONSTRAINT auth_session_identities_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id) ON DELETE CASCADE;


--
-- Name: auth_sessions auth_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: background_compute_connections background_compute_connections_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.background_compute_connections
    ADD CONSTRAINT background_compute_connections_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: cowork_checkpoints cowork_checkpoints_workspace_id_project_id_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_checkpoints
    ADD CONSTRAINT cowork_checkpoints_workspace_id_project_id_unit_id_fkey FOREIGN KEY (workspace_id, project_id, unit_id) REFERENCES public.cowork_units(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: cowork_connection_slots cowork_connection_slots_workspace_id_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_connection_slots
    ADD CONSTRAINT cowork_connection_slots_workspace_id_connection_id_fkey FOREIGN KEY (workspace_id, connection_id) REFERENCES public.agent_connections(workspace_id, id) ON DELETE CASCADE;


--
-- Name: cowork_units cowork_units_checkpoint_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_units
    ADD CONSTRAINT cowork_units_checkpoint_fk FOREIGN KEY (workspace_id, project_id, id, checkpoint_id) REFERENCES public.cowork_checkpoints(workspace_id, project_id, unit_id, id);


--
-- Name: cowork_units cowork_units_workspace_id_project_id_lineage_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_units
    ADD CONSTRAINT cowork_units_workspace_id_project_id_lineage_work_id_fkey FOREIGN KEY (workspace_id, project_id, lineage_work_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: cowork_units cowork_units_workspace_id_project_id_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_units
    ADD CONSTRAINT cowork_units_workspace_id_project_id_work_id_fkey FOREIGN KEY (workspace_id, project_id, work_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: dm_message_observations dm_message_observations_dm_id_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_message_observations
    ADD CONSTRAINT dm_message_observations_dm_id_message_id_fkey FOREIGN KEY (dm_id, message_id) REFERENCES public.dm_messages(dm_id, id) ON DELETE CASCADE;


--
-- Name: dm_message_observations dm_message_observations_viewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_message_observations
    ADD CONSTRAINT dm_message_observations_viewer_id_fkey FOREIGN KEY (viewer_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: dm_message_observations dm_message_observations_workspace_id_dm_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_message_observations
    ADD CONSTRAINT dm_message_observations_workspace_id_dm_id_fkey FOREIGN KEY (workspace_id, dm_id) REFERENCES public.dms(workspace_id, id) ON DELETE CASCADE;


--
-- Name: dm_messages dm_messages_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_messages
    ADD CONSTRAINT dm_messages_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.auth_users(id);


--
-- Name: dm_messages dm_messages_thread_root_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_messages
    ADD CONSTRAINT dm_messages_thread_root_fk FOREIGN KEY (dm_id, thread_root_id) REFERENCES public.dm_messages(dm_id, id) ON DELETE CASCADE;


--
-- Name: dm_messages dm_messages_workspace_id_dm_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_messages
    ADD CONSTRAINT dm_messages_workspace_id_dm_id_fkey FOREIGN KEY (workspace_id, dm_id) REFERENCES public.dms(workspace_id, id) ON DELETE CASCADE;


--
-- Name: dm_participants dm_participants_workspace_id_dm_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_participants
    ADD CONSTRAINT dm_participants_workspace_id_dm_id_fkey FOREIGN KEY (workspace_id, dm_id) REFERENCES public.dms(workspace_id, id) ON DELETE CASCADE;


--
-- Name: dm_participants dm_participants_workspace_id_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_participants
    ADD CONSTRAINT dm_participants_workspace_id_user_id_fkey FOREIGN KEY (workspace_id, user_id) REFERENCES public.workspace_members(workspace_id, user_id) ON DELETE CASCADE;


--
-- Name: dms dms_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dms
    ADD CONSTRAINT dms_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.auth_users(id);


--
-- Name: dms dms_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dms
    ADD CONSTRAINT dms_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: doc_live_archives doc_live_archives_doc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_archives
    ADD CONSTRAINT doc_live_archives_doc_id_fkey FOREIGN KEY (doc_id) REFERENCES public.project_materials(id) ON DELETE CASCADE;


--
-- Name: doc_live_heads doc_live_heads_workspace_id_project_id_doc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_heads
    ADD CONSTRAINT doc_live_heads_workspace_id_project_id_doc_id_fkey FOREIGN KEY (workspace_id, project_id, doc_id) REFERENCES public.project_materials(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: doc_live_heads doc_live_heads_workspace_id_project_id_doc_id_saved_versio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_heads
    ADD CONSTRAINT doc_live_heads_workspace_id_project_id_doc_id_saved_versio_fkey FOREIGN KEY (workspace_id, project_id, doc_id, saved_version) REFERENCES public.project_material_versions(workspace_id, project_id, material_id, version);


--
-- Name: doc_live_presence doc_live_presence_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_presence
    ADD CONSTRAINT doc_live_presence_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.auth_users(id);


--
-- Name: doc_live_presence doc_live_presence_doc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_presence
    ADD CONSTRAINT doc_live_presence_doc_id_fkey FOREIGN KEY (doc_id) REFERENCES public.project_materials(id) ON DELETE CASCADE;


--
-- Name: doc_live_presence doc_live_presence_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_presence
    ADD CONSTRAINT doc_live_presence_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id) ON DELETE CASCADE;


--
-- Name: doc_live_replicas doc_live_replicas_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_replicas
    ADD CONSTRAINT doc_live_replicas_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.auth_users(id);


--
-- Name: doc_live_replicas doc_live_replicas_doc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_replicas
    ADD CONSTRAINT doc_live_replicas_doc_id_fkey FOREIGN KEY (doc_id) REFERENCES public.project_materials(id) ON DELETE CASCADE;


--
-- Name: doc_live_snapshots doc_live_snapshots_workspace_id_project_id_doc_id_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_snapshots
    ADD CONSTRAINT doc_live_snapshots_workspace_id_project_id_doc_id_version_fkey FOREIGN KEY (workspace_id, project_id, doc_id, version) REFERENCES public.project_material_versions(workspace_id, project_id, material_id, version) ON DELETE CASCADE;


--
-- Name: doc_live_updates doc_live_updates_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_updates
    ADD CONSTRAINT doc_live_updates_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.auth_users(id);


--
-- Name: doc_live_updates doc_live_updates_doc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_updates
    ADD CONSTRAINT doc_live_updates_doc_id_fkey FOREIGN KEY (doc_id) REFERENCES public.project_materials(id) ON DELETE CASCADE;


--
-- Name: encrypted_workspace_creations encrypted_workspace_creations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encrypted_workspace_creations
    ADD CONSTRAINT encrypted_workspace_creations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: event_audience event_audience_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_audience
    ADD CONSTRAINT event_audience_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: events events_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: github_bindings github_bindings_author_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_bindings
    ADD CONSTRAINT github_bindings_author_user_id_fkey FOREIGN KEY (author_user_id) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: github_bindings github_bindings_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_bindings
    ADD CONSTRAINT github_bindings_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: github_credentials github_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_credentials
    ADD CONSTRAINT github_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: github_deliveries github_deliveries_target_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_deliveries
    ADD CONSTRAINT github_deliveries_target_binding_id_fkey FOREIGN KEY (target_binding_id) REFERENCES public.github_bindings(id) ON DELETE SET NULL;


--
-- Name: github_oauth_flows github_oauth_flows_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_oauth_flows
    ADD CONSTRAINT github_oauth_flows_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id) ON DELETE CASCADE;


--
-- Name: github_oauth_flows github_oauth_flows_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_oauth_flows
    ADD CONSTRAINT github_oauth_flows_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: github_oauth_flows github_oauth_flows_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_oauth_flows
    ADD CONSTRAINT github_oauth_flows_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: github_processing github_processing_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_processing
    ADD CONSTRAINT github_processing_binding_id_fkey FOREIGN KEY (binding_id) REFERENCES public.github_bindings(id) ON DELETE CASCADE;


--
-- Name: github_processing github_processing_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_processing
    ADD CONSTRAINT github_processing_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.github_deliveries(id) ON DELETE CASCADE;


--
-- Name: github_rule_defaults github_rule_defaults_set_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_rule_defaults
    ADD CONSTRAINT github_rule_defaults_set_by_user_id_fkey FOREIGN KEY (set_by_user_id) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: github_rule_defaults github_rule_defaults_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_rule_defaults
    ADD CONSTRAINT github_rule_defaults_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: github_task_links github_task_links_workspace_id_project_id_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_links
    ADD CONSTRAINT github_task_links_workspace_id_project_id_binding_id_fkey FOREIGN KEY (workspace_id, project_id, binding_id) REFERENCES public.github_bindings(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: github_task_links github_task_links_workspace_id_project_id_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_links
    ADD CONSTRAINT github_task_links_workspace_id_project_id_task_id_fkey FOREIGN KEY (workspace_id, project_id, task_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: github_task_rule_changes github_task_rule_changes_author_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_rule_changes
    ADD CONSTRAINT github_task_rule_changes_author_user_id_fkey FOREIGN KEY (author_user_id) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: github_task_rule_changes github_task_rule_changes_workspace_id_project_id_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_rule_changes
    ADD CONSTRAINT github_task_rule_changes_workspace_id_project_id_task_id_fkey FOREIGN KEY (workspace_id, project_id, task_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: github_task_rules github_task_rules_author_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_rules
    ADD CONSTRAINT github_task_rules_author_user_id_fkey FOREIGN KEY (author_user_id) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: github_task_rules github_task_rules_workspace_id_project_id_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_rules
    ADD CONSTRAINT github_task_rules_workspace_id_project_id_task_id_fkey FOREIGN KEY (workspace_id, project_id, task_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: idempotency_keys idempotency_keys_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: live_access_fences live_access_fences_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_access_fences
    ADD CONSTRAINT live_access_fences_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: live_access_fences live_access_fences_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_access_fences
    ADD CONSTRAINT live_access_fences_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: live_admissions live_admissions_live_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_admissions
    ADD CONSTRAINT live_admissions_live_session_id_fkey FOREIGN KEY (live_session_id) REFERENCES public.live_sessions(id) ON DELETE CASCADE;


--
-- Name: live_admissions live_admissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_admissions
    ADD CONSTRAINT live_admissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: live_editing_intents live_editing_intents_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_editing_intents
    ADD CONSTRAINT live_editing_intents_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.auth_users(id);


--
-- Name: live_invitations live_invitations_inviter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_invitations
    ADD CONSTRAINT live_invitations_inviter_id_fkey FOREIGN KEY (inviter_id) REFERENCES public.auth_users(id);


--
-- Name: live_invitations live_invitations_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_invitations
    ADD CONSTRAINT live_invitations_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.auth_users(id);


--
-- Name: live_invitations live_invitations_workspace_id_project_id_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_invitations
    ADD CONSTRAINT live_invitations_workspace_id_project_id_session_id_fkey FOREIGN KEY (workspace_id, project_id, session_id) REFERENCES public.live_sessions(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: live_presentations live_presentations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_presentations
    ADD CONSTRAINT live_presentations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.auth_users(id);


--
-- Name: live_presentations live_presentations_workspace_id_project_id_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_presentations
    ADD CONSTRAINT live_presentations_workspace_id_project_id_session_id_fkey FOREIGN KEY (workspace_id, project_id, session_id) REFERENCES public.live_sessions(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: live_sessions live_sessions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.auth_users(id);


--
-- Name: live_sessions live_sessions_workspace_id_project_id_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_workspace_id_project_id_conversation_id_fkey FOREIGN KEY (workspace_id, project_id, conversation_id) REFERENCES public.project_conversations(workspace_id, project_id, id);


--
-- Name: live_sessions live_sessions_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: live_sessions live_sessions_workspace_id_project_id_sketch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_workspace_id_project_id_sketch_id_fkey FOREIGN KEY (workspace_id, project_id, sketch_id) REFERENCES public.sketches(workspace_id, project_id, id);


--
-- Name: live_sessions live_sessions_workspace_id_project_id_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_workspace_id_project_id_work_id_fkey FOREIGN KEY (workspace_id, project_id, work_id) REFERENCES public.project_work_items(workspace_id, project_id, id);


--
-- Name: live_webhook_events live_webhook_events_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_webhook_events
    ADD CONSTRAINT live_webhook_events_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.live_sessions(id) ON DELETE CASCADE;


--
-- Name: map_live_gestures map_live_gestures_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_gestures
    ADD CONSTRAINT map_live_gestures_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.auth_users(id);


--
-- Name: map_live_gestures map_live_gestures_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_gestures
    ADD CONSTRAINT map_live_gestures_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id) ON DELETE CASCADE;


--
-- Name: map_live_gestures map_live_gestures_sketch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_gestures
    ADD CONSTRAINT map_live_gestures_sketch_id_fkey FOREIGN KEY (sketch_id) REFERENCES public.sketches(id) ON DELETE CASCADE;


--
-- Name: map_live_gestures map_live_gestures_sketch_id_generation_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_gestures
    ADD CONSTRAINT map_live_gestures_sketch_id_generation_fkey FOREIGN KEY (sketch_id, generation) REFERENCES public.map_live_heads(sketch_id, generation) ON DELETE CASCADE;


--
-- Name: map_live_heads map_live_heads_sketch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_heads
    ADD CONSTRAINT map_live_heads_sketch_id_fkey FOREIGN KEY (sketch_id) REFERENCES public.sketches(id) ON DELETE CASCADE;


--
-- Name: map_live_heads map_live_heads_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_heads
    ADD CONSTRAINT map_live_heads_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- Name: map_live_heads map_live_heads_workspace_id_sketch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_heads
    ADD CONSTRAINT map_live_heads_workspace_id_sketch_id_fkey FOREIGN KEY (workspace_id, sketch_id) REFERENCES public.sketches(workspace_id, id) ON DELETE CASCADE;


--
-- Name: map_live_journal map_live_journal_sketch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_journal
    ADD CONSTRAINT map_live_journal_sketch_id_fkey FOREIGN KEY (sketch_id) REFERENCES public.sketches(id) ON DELETE CASCADE;


--
-- Name: map_live_object_versions map_live_object_versions_sketch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_object_versions
    ADD CONSTRAINT map_live_object_versions_sketch_id_fkey FOREIGN KEY (sketch_id) REFERENCES public.sketches(id) ON DELETE CASCADE;


--
-- Name: map_live_presence map_live_presence_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_presence
    ADD CONSTRAINT map_live_presence_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.auth_users(id);


--
-- Name: map_live_presence map_live_presence_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_presence
    ADD CONSTRAINT map_live_presence_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id) ON DELETE CASCADE;


--
-- Name: map_live_presence map_live_presence_sketch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_presence
    ADD CONSTRAINT map_live_presence_sketch_id_fkey FOREIGN KEY (sketch_id) REFERENCES public.sketches(id) ON DELETE CASCADE;


--
-- Name: map_live_presence map_live_presence_sketch_id_generation_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_presence
    ADD CONSTRAINT map_live_presence_sketch_id_generation_fkey FOREIGN KEY (sketch_id, generation) REFERENCES public.map_live_heads(sketch_id, generation) ON DELETE CASCADE;


--
-- Name: map_live_undone map_live_undone_sketch_id_generation_inverse_sequence_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_undone
    ADD CONSTRAINT map_live_undone_sketch_id_generation_inverse_sequence_fkey FOREIGN KEY (sketch_id, generation, inverse_sequence) REFERENCES public.map_live_journal(sketch_id, generation, sequence) ON DELETE CASCADE;


--
-- Name: map_live_undone map_live_undone_sketch_id_generation_original_sequence_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_undone
    ADD CONSTRAINT map_live_undone_sketch_id_generation_original_sequence_fkey FOREIGN KEY (sketch_id, generation, original_sequence) REFERENCES public.map_live_journal(sketch_id, generation, sequence) ON DELETE CASCADE;


--
-- Name: message_references message_references_dm_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_references
    ADD CONSTRAINT message_references_dm_message_id_fkey FOREIGN KEY (dm_message_id) REFERENCES public.dm_messages(id) ON DELETE CASCADE;


--
-- Name: message_references message_references_project_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_references
    ADD CONSTRAINT message_references_project_message_id_fkey FOREIGN KEY (project_message_id) REFERENCES public.project_messages(id) ON DELETE CASCADE;


--
-- Name: message_references message_references_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_references
    ADD CONSTRAINT message_references_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: native_command_receipts native_command_receipts_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.native_command_receipts
    ADD CONSTRAINT native_command_receipts_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: native_command_receipts native_command_receipts_workspace_id_project_id_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.native_command_receipts
    ADD CONSTRAINT native_command_receipts_workspace_id_project_id_work_id_fkey FOREIGN KEY (workspace_id, project_id, work_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: needs_you_states needs_you_states_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.needs_you_states
    ADD CONSTRAINT needs_you_states_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: notification_address_tokens notification_address_tokens_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_address_tokens
    ADD CONSTRAINT notification_address_tokens_address_id_fkey FOREIGN KEY (address_id) REFERENCES public.notification_addresses(id) ON DELETE CASCADE;


--
-- Name: notification_addresses notification_addresses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_addresses
    ADD CONSTRAINT notification_addresses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: notification_emails notification_emails_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_emails
    ADD CONSTRAINT notification_emails_address_id_fkey FOREIGN KEY (address_id) REFERENCES public.notification_addresses(id) ON DELETE SET NULL;


--
-- Name: notification_emails notification_emails_notification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_emails
    ADD CONSTRAINT notification_emails_notification_id_fkey FOREIGN KEY (notification_id) REFERENCES public.notifications(id) ON DELETE CASCADE;


--
-- Name: notification_emails notification_emails_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_emails
    ADD CONSTRAINT notification_emails_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: notification_generation_failures notification_generation_failures_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_generation_failures
    ADD CONSTRAINT notification_generation_failures_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: notification_mutes notification_mutes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_mutes
    ADD CONSTRAINT notification_mutes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: notification_preferences notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: notification_verification_sends notification_verification_sends_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_verification_sends
    ADD CONSTRAINT notification_verification_sends_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: oauth_access_token oauth_access_token_client_id_oauth_client_client_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_token
    ADD CONSTRAINT oauth_access_token_client_id_oauth_client_client_id_fk FOREIGN KEY (client_id) REFERENCES public.oauth_client(client_id) ON DELETE CASCADE;


--
-- Name: oauth_access_token oauth_access_token_refresh_id_oauth_refresh_token_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_token
    ADD CONSTRAINT oauth_access_token_refresh_id_oauth_refresh_token_id_fk FOREIGN KEY (refresh_id) REFERENCES public.oauth_refresh_token(id) ON DELETE CASCADE;


--
-- Name: oauth_access_token oauth_access_token_session_id_auth_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_token
    ADD CONSTRAINT oauth_access_token_session_id_auth_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id) ON DELETE SET NULL;


--
-- Name: oauth_access_token oauth_access_token_user_id_auth_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_token
    ADD CONSTRAINT oauth_access_token_user_id_auth_users_id_fk FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: oauth_client_resource oauth_client_resource_client_id_oauth_client_client_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_resource
    ADD CONSTRAINT oauth_client_resource_client_id_oauth_client_client_id_fk FOREIGN KEY (client_id) REFERENCES public.oauth_client(client_id) ON DELETE CASCADE;


--
-- Name: oauth_client_resource oauth_client_resource_resource_id_oauth_resource_identifier_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_resource
    ADD CONSTRAINT oauth_client_resource_resource_id_oauth_resource_identifier_fk FOREIGN KEY (resource_id) REFERENCES public.oauth_resource(identifier) ON DELETE CASCADE;


--
-- Name: oauth_client oauth_client_user_id_auth_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client
    ADD CONSTRAINT oauth_client_user_id_auth_users_id_fk FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: oauth_consent oauth_consent_client_id_oauth_client_client_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_consent
    ADD CONSTRAINT oauth_consent_client_id_oauth_client_client_id_fk FOREIGN KEY (client_id) REFERENCES public.oauth_client(client_id) ON DELETE CASCADE;


--
-- Name: oauth_consent oauth_consent_user_id_auth_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_consent
    ADD CONSTRAINT oauth_consent_user_id_auth_users_id_fk FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: oauth_grant_authentication oauth_grant_authentication_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_grant_authentication
    ADD CONSTRAINT oauth_grant_authentication_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: oauth_refresh_token oauth_refresh_token_client_id_oauth_client_client_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_refresh_token
    ADD CONSTRAINT oauth_refresh_token_client_id_oauth_client_client_id_fk FOREIGN KEY (client_id) REFERENCES public.oauth_client(client_id) ON DELETE CASCADE;


--
-- Name: oauth_refresh_token oauth_refresh_token_session_id_auth_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_refresh_token
    ADD CONSTRAINT oauth_refresh_token_session_id_auth_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id) ON DELETE SET NULL;


--
-- Name: oauth_refresh_token oauth_refresh_token_user_id_auth_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_refresh_token
    ADD CONSTRAINT oauth_refresh_token_user_id_auth_users_id_fk FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: outbox outbox_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbox
    ADD CONSTRAINT outbox_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id);


--
-- Name: password_attempts password_attempts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_attempts
    ADD CONSTRAINT password_attempts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: password_attempts password_attempts_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_attempts
    ADD CONSTRAINT password_attempts_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: personal_run_private_texts personal_run_private_texts_run_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_run_private_texts
    ADD CONSTRAINT personal_run_private_texts_run_fkey FOREIGN KEY (run_id) REFERENCES public.personal_runs(id) ON DELETE CASCADE;


--
-- Name: personal_run_web_reads personal_run_web_reads_run_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_run_web_reads
    ADD CONSTRAINT personal_run_web_reads_run_fkey FOREIGN KEY (run_id) REFERENCES public.personal_runs(id) ON DELETE CASCADE;


--
-- Name: personal_run_web_searches personal_run_web_searches_run_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_run_web_searches
    ADD CONSTRAINT personal_run_web_searches_run_fkey FOREIGN KEY (run_id) REFERENCES public.personal_runs(id) ON DELETE CASCADE;


--
-- Name: personal_runs personal_runs_asked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_asked_by_fkey FOREIGN KEY (asked_by_run_id) REFERENCES public.personal_runs(id) ON DELETE SET NULL;


--
-- Name: personal_runs personal_runs_continues_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_continues_run_id_fkey FOREIGN KEY (continues_run_id) REFERENCES public.personal_runs(id) ON DELETE SET NULL;


--
-- Name: personal_runs personal_runs_dm_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_dm_fkey FOREIGN KEY (workspace_id, dm_id) REFERENCES public.dms(workspace_id, id) ON DELETE CASCADE;


--
-- Name: personal_runs personal_runs_dm_thread_root_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_dm_thread_root_fkey FOREIGN KEY (dm_id, dm_thread_root_id) REFERENCES public.dm_messages(dm_id, id) ON DELETE CASCADE;


--
-- Name: personal_runs personal_runs_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: personal_runs personal_runs_retry_of_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_retry_of_run_id_fkey FOREIGN KEY (retry_of_run_id) REFERENCES public.personal_runs(id) ON DELETE SET NULL;


--
-- Name: personal_runs personal_runs_stop_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_stop_by_fkey FOREIGN KEY (stop_requested_by) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: personal_runs personal_runs_work_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_work_fkey FOREIGN KEY (work_id) REFERENCES public.project_work_items(id) ON DELETE CASCADE;


--
-- Name: personal_runs personal_runs_workspace_id_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_workspace_id_agent_id_fkey FOREIGN KEY (workspace_id, agent_id) REFERENCES public.agents(workspace_id, id) ON DELETE CASCADE;


--
-- Name: personal_runs personal_runs_workspace_id_project_id_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_workspace_id_project_id_conversation_id_fkey FOREIGN KEY (workspace_id, project_id, conversation_id) REFERENCES public.project_conversations(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_ai_policies project_ai_policies_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_ai_policies
    ADD CONSTRAINT project_ai_policies_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: project_ai_policies project_ai_policies_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_ai_policies
    ADD CONSTRAINT project_ai_policies_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_conversations project_conversation_agent_workspace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_conversations
    ADD CONSTRAINT project_conversation_agent_workspace FOREIGN KEY (workspace_id, created_by_agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: project_conversations project_conversations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_conversations
    ADD CONSTRAINT project_conversations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.auth_users(id);


--
-- Name: project_conversations project_conversations_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_conversations
    ADD CONSTRAINT project_conversations_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: project_decisions project_decisions_decided_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decisions
    ADD CONSTRAINT project_decisions_decided_by_fkey FOREIGN KEY (decided_by) REFERENCES public.auth_users(id);


--
-- Name: project_decisions project_decisions_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decisions
    ADD CONSTRAINT project_decisions_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: project_decisions project_decisions_workspace_id_project_id_superseded_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decisions
    ADD CONSTRAINT project_decisions_workspace_id_project_id_superseded_by_id_fkey FOREIGN KEY (workspace_id, project_id, superseded_by_id) REFERENCES public.project_decisions(workspace_id, project_id, id);


--
-- Name: project_decisions project_decisions_workspace_id_project_id_supersedes_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decisions
    ADD CONSTRAINT project_decisions_workspace_id_project_id_supersedes_id_fkey FOREIGN KEY (workspace_id, project_id, supersedes_id) REFERENCES public.project_decisions(workspace_id, project_id, id);


--
-- Name: project_files project_files_replay_of_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_files
    ADD CONSTRAINT project_files_replay_of_fkey FOREIGN KEY (replay_of) REFERENCES public.project_files(id) ON DELETE CASCADE;


--
-- Name: project_files project_files_uploader_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_files
    ADD CONSTRAINT project_files_uploader_id_fkey FOREIGN KEY (uploader_id) REFERENCES public.auth_users(id);


--
-- Name: project_files project_files_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_files
    ADD CONSTRAINT project_files_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: project_files project_files_workspace_id_project_id_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_files
    ADD CONSTRAINT project_files_workspace_id_project_id_message_id_fkey FOREIGN KEY (workspace_id, project_id, message_id) REFERENCES public.project_messages(workspace_id, project_id, id);


--
-- Name: project_files project_files_workspace_id_uploader_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_files
    ADD CONSTRAINT project_files_workspace_id_uploader_agent_id_fkey FOREIGN KEY (workspace_id, uploader_agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: project_grants project_grants_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_grants
    ADD CONSTRAINT project_grants_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: project_grants project_grants_workspace_id_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_grants
    ADD CONSTRAINT project_grants_workspace_id_user_id_fkey FOREIGN KEY (workspace_id, user_id) REFERENCES public.workspace_members(workspace_id, user_id) ON DELETE CASCADE;


--
-- Name: project_materials project_material_agent_workspace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_materials
    ADD CONSTRAINT project_material_agent_workspace FOREIGN KEY (workspace_id, created_by_agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: project_material_versions project_material_version_agent_workspace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_material_versions
    ADD CONSTRAINT project_material_version_agent_workspace FOREIGN KEY (workspace_id, author_agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: project_material_versions project_material_versions_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_material_versions
    ADD CONSTRAINT project_material_versions_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.auth_users(id);


--
-- Name: project_material_versions project_material_versions_workspace_id_project_id_material_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_material_versions
    ADD CONSTRAINT project_material_versions_workspace_id_project_id_material_fkey FOREIGN KEY (workspace_id, project_id, material_id) REFERENCES public.project_materials(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_materials project_materials_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_materials
    ADD CONSTRAINT project_materials_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.auth_users(id);


--
-- Name: project_materials project_materials_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_materials
    ADD CONSTRAINT project_materials_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: project_messages project_message_agent_workspace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_messages
    ADD CONSTRAINT project_message_agent_workspace FOREIGN KEY (workspace_id, author_agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: project_message_observations project_message_observations_viewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_message_observations
    ADD CONSTRAINT project_message_observations_viewer_id_fkey FOREIGN KEY (viewer_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: project_message_observations project_message_observations_workspace_id_project_id_messa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_message_observations
    ADD CONSTRAINT project_message_observations_workspace_id_project_id_messa_fkey FOREIGN KEY (workspace_id, project_id, message_id) REFERENCES public.project_messages(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_messages project_messages_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_messages
    ADD CONSTRAINT project_messages_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.auth_users(id);


--
-- Name: project_messages project_messages_workspace_id_project_id_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_messages
    ADD CONSTRAINT project_messages_workspace_id_project_id_conversation_id_fkey FOREIGN KEY (workspace_id, project_id, conversation_id) REFERENCES public.project_conversations(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_messages project_messages_workspace_id_project_id_source_material_i_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_messages
    ADD CONSTRAINT project_messages_workspace_id_project_id_source_material_i_fkey FOREIGN KEY (workspace_id, project_id, source_material_id, source_material_version) REFERENCES public.project_material_versions(workspace_id, project_id, material_id, version);


--
-- Name: project_object_links project_object_links_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_object_links
    ADD CONSTRAINT project_object_links_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: project_task_activity project_task_activity_workspace_id_project_id_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_activity
    ADD CONSTRAINT project_task_activity_workspace_id_project_id_work_id_fkey FOREIGN KEY (workspace_id, project_id, work_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_task_dependencies project_task_dependencies_workspace_id_project_id_prerequi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_dependencies
    ADD CONSTRAINT project_task_dependencies_workspace_id_project_id_prerequi_fkey FOREIGN KEY (workspace_id, project_id, prerequisite_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_task_dependencies project_task_dependencies_workspace_id_project_id_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_dependencies
    ADD CONSTRAINT project_task_dependencies_workspace_id_project_id_task_id_fkey FOREIGN KEY (workspace_id, project_id, task_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_task_discussions project_task_discussions_conversation_id_root_message_id_r_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_discussions
    ADD CONSTRAINT project_task_discussions_conversation_id_root_message_id_r_fkey FOREIGN KEY (conversation_id, root_message_id, root_sequence) REFERENCES public.project_messages(conversation_id, id, sequence) ON DELETE CASCADE;


--
-- Name: project_task_discussions project_task_discussions_workspace_id_project_id_conversat_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_discussions
    ADD CONSTRAINT project_task_discussions_workspace_id_project_id_conversat_fkey FOREIGN KEY (workspace_id, project_id, conversation_id) REFERENCES public.project_conversations(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_task_discussions project_task_discussions_workspace_id_project_id_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_discussions
    ADD CONSTRAINT project_task_discussions_workspace_id_project_id_work_id_fkey FOREIGN KEY (workspace_id, project_id, work_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_task_notices project_task_notices_workspace_id_project_id_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_notices
    ADD CONSTRAINT project_task_notices_workspace_id_project_id_work_id_fkey FOREIGN KEY (workspace_id, project_id, work_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_task_plan_intents project_task_plan_intents_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_plan_intents
    ADD CONSTRAINT project_task_plan_intents_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: project_task_plan_intents project_task_plan_intents_workspace_id_project_id_material_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_plan_intents
    ADD CONSTRAINT project_task_plan_intents_workspace_id_project_id_material_fkey FOREIGN KEY (workspace_id, project_id, material_id, material_version) REFERENCES public.project_material_versions(workspace_id, project_id, material_id, version);


--
-- Name: project_task_plan_intents project_task_plan_intents_workspace_id_project_id_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_plan_intents
    ADD CONSTRAINT project_task_plan_intents_workspace_id_project_id_task_id_fkey FOREIGN KEY (workspace_id, project_id, task_id) REFERENCES public.project_work_items(workspace_id, project_id, id);


--
-- Name: project_task_updates project_task_updates_waiting_for_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_updates
    ADD CONSTRAINT project_task_updates_waiting_for_user_id_fkey FOREIGN KEY (waiting_for_user_id) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: project_task_updates project_task_updates_workspace_id_project_id_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_updates
    ADD CONSTRAINT project_task_updates_workspace_id_project_id_work_id_fkey FOREIGN KEY (workspace_id, project_id, work_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_work_items project_work_items_owner_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_work_items
    ADD CONSTRAINT project_work_items_owner_agent_id_fkey FOREIGN KEY (owner_agent_id) REFERENCES public.agents(id);


--
-- Name: project_work_items project_work_items_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_work_items
    ADD CONSTRAINT project_work_items_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id);


--
-- Name: project_work_items project_work_items_waiting_for_decision_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_work_items
    ADD CONSTRAINT project_work_items_waiting_for_decision_id_fkey FOREIGN KEY (waiting_for_decision_id) REFERENCES public.project_decisions(id) ON DELETE SET NULL;


--
-- Name: project_work_items project_work_items_waiting_for_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_work_items
    ADD CONSTRAINT project_work_items_waiting_for_user_id_fkey FOREIGN KEY (waiting_for_user_id) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: project_work_items project_work_items_waiting_for_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_work_items
    ADD CONSTRAINT project_work_items_waiting_for_work_id_fkey FOREIGN KEY (waiting_for_work_id) REFERENCES public.project_work_items(id) ON DELETE SET NULL;


--
-- Name: project_work_items project_work_items_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_work_items
    ADD CONSTRAINT project_work_items_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: projects projects_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: push_subscriptions push_subscriptions_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id) ON DELETE CASCADE;


--
-- Name: push_subscriptions push_subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: return_points return_points_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_points
    ADD CONSTRAINT return_points_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.project_conversations(id) ON DELETE CASCADE;


--
-- Name: return_points return_points_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_points
    ADD CONSTRAINT return_points_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: return_points return_points_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_points
    ADD CONSTRAINT return_points_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: sample_results sample_results_sample_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sample_results
    ADD CONSTRAINT sample_results_sample_id_fkey FOREIGN KEY (sample_id) REFERENCES public.samples(id);


--
-- Name: sealed_job_waits sealed_job_waits_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sealed_job_waits
    ADD CONSTRAINT sealed_job_waits_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: search_changes search_changes_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_changes
    ADD CONSTRAINT search_changes_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: search_documents search_documents_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_documents
    ADD CONSTRAINT search_documents_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: sketch_links sketch_links_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_links
    ADD CONSTRAINT sketch_links_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.auth_users(id);


--
-- Name: sketch_links sketch_links_sketch_id_from_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_links
    ADD CONSTRAINT sketch_links_sketch_id_from_id_fkey FOREIGN KEY (sketch_id, from_id) REFERENCES public.sketch_thoughts(sketch_id, id) ON DELETE CASCADE;


--
-- Name: sketch_links sketch_links_sketch_id_to_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_links
    ADD CONSTRAINT sketch_links_sketch_id_to_id_fkey FOREIGN KEY (sketch_id, to_id) REFERENCES public.sketch_thoughts(sketch_id, id) ON DELETE CASCADE;


--
-- Name: sketch_links sketch_links_workspace_id_sketch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_links
    ADD CONSTRAINT sketch_links_workspace_id_sketch_id_fkey FOREIGN KEY (workspace_id, sketch_id) REFERENCES public.sketches(workspace_id, id) ON DELETE CASCADE;


--
-- Name: sketch_thoughts sketch_thoughts_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_thoughts
    ADD CONSTRAINT sketch_thoughts_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.auth_users(id);


--
-- Name: sketch_thoughts sketch_thoughts_source_author_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_thoughts
    ADD CONSTRAINT sketch_thoughts_source_author_agent_id_fkey FOREIGN KEY (source_author_agent_id) REFERENCES public.agents(id);


--
-- Name: sketch_thoughts sketch_thoughts_source_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_thoughts
    ADD CONSTRAINT sketch_thoughts_source_author_id_fkey FOREIGN KEY (source_author_id) REFERENCES public.auth_users(id);


--
-- Name: sketch_thoughts sketch_thoughts_source_project_message_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_thoughts
    ADD CONSTRAINT sketch_thoughts_source_project_message_fk FOREIGN KEY (source_project_message_id) REFERENCES public.project_messages(id);


--
-- Name: sketch_thoughts sketch_thoughts_workspace_id_created_by_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_thoughts
    ADD CONSTRAINT sketch_thoughts_workspace_id_created_by_agent_id_fkey FOREIGN KEY (workspace_id, created_by_agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: sketch_thoughts sketch_thoughts_workspace_id_sketch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_thoughts
    ADD CONSTRAINT sketch_thoughts_workspace_id_sketch_id_fkey FOREIGN KEY (workspace_id, sketch_id) REFERENCES public.sketches(workspace_id, id) ON DELETE CASCADE;


--
-- Name: sketches sketches_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketches
    ADD CONSTRAINT sketches_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.auth_users(id);


--
-- Name: sketches sketches_workspace_id_created_by_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketches
    ADD CONSTRAINT sketches_workspace_id_created_by_agent_id_fkey FOREIGN KEY (workspace_id, created_by_agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: sketches sketches_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketches
    ADD CONSTRAINT sketches_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: sketches sketches_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketches
    ADD CONSTRAINT sketches_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: project_work_items task_creation_reversion_notice_scope; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_work_items
    ADD CONSTRAINT task_creation_reversion_notice_scope FOREIGN KEY (workspace_id, project_id, id, creation_reversion_notice_id) REFERENCES public.project_task_notices(workspace_id, project_id, work_id, id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: task_creation_undo_receipts task_creation_undo_receipts_workspace_id_project_id_work__fkey1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_creation_undo_receipts
    ADD CONSTRAINT task_creation_undo_receipts_workspace_id_project_id_work__fkey1 FOREIGN KEY (workspace_id, project_id, work_id, notice_id) REFERENCES public.project_task_notices(workspace_id, project_id, work_id, id);


--
-- Name: task_creation_undo_receipts task_creation_undo_receipts_workspace_id_project_id_work_i_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_creation_undo_receipts
    ADD CONSTRAINT task_creation_undo_receipts_workspace_id_project_id_work_i_fkey FOREIGN KEY (workspace_id, project_id, work_id) REFERENCES public.project_work_items(workspace_id, project_id, id);


--
-- Name: workspace_dek_wraps workspace_dek_wraps_holder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_dek_wraps
    ADD CONSTRAINT workspace_dek_wraps_holder_id_fkey FOREIGN KEY (holder_id) REFERENCES public.workspace_holders(id) ON DELETE CASCADE;


--
-- Name: workspace_dek_wraps workspace_dek_wraps_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_dek_wraps
    ADD CONSTRAINT workspace_dek_wraps_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspace_keys(workspace_id) ON DELETE CASCADE;


--
-- Name: workspace_holders workspace_holders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_holders
    ADD CONSTRAINT workspace_holders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: workspace_holders workspace_holders_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_holders
    ADD CONSTRAINT workspace_holders_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspace_keys(workspace_id) ON DELETE CASCADE;


--
-- Name: workspace_invites workspace_invites_accepted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invites
    ADD CONSTRAINT workspace_invites_accepted_by_fkey FOREIGN KEY (accepted_by) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: workspace_invites workspace_invites_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invites
    ADD CONSTRAINT workspace_invites_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: workspace_invites workspace_invites_revoked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invites
    ADD CONSTRAINT workspace_invites_revoked_by_fkey FOREIGN KEY (revoked_by) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: workspace_invites workspace_invites_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invites
    ADD CONSTRAINT workspace_invites_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: workspace_key_versions workspace_key_versions_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_key_versions
    ADD CONSTRAINT workspace_key_versions_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspace_keys(workspace_id) ON DELETE CASCADE;


--
-- Name: workspace_keys workspace_keys_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_keys
    ADD CONSTRAINT workspace_keys_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: workspace_members workspace_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_members
    ADD CONSTRAINT workspace_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: workspace_members workspace_members_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_members
    ADD CONSTRAINT workspace_members_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: workspace_removals workspace_removals_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_removals
    ADD CONSTRAINT workspace_removals_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspace_keys(workspace_id) ON DELETE CASCADE;


--
-- Name: workspace_removed_holders workspace_removed_holders_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_removed_holders
    ADD CONSTRAINT workspace_removed_holders_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspace_keys(workspace_id) ON DELETE CASCADE;


--
-- Name: workspace_removed_people workspace_removed_people_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_removed_people
    ADD CONSTRAINT workspace_removed_people_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: workspace_removed_people workspace_removed_people_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_removed_people
    ADD CONSTRAINT workspace_removed_people_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: workspace_rotation_progress workspace_rotation_progress_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_rotation_progress
    ADD CONSTRAINT workspace_rotation_progress_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspace_keys(workspace_id) ON DELETE CASCADE;


--
-- Name: workspace_unlocks workspace_unlocks_unlocked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_unlocks
    ADD CONSTRAINT workspace_unlocks_unlocked_by_fkey FOREIGN KEY (unlocked_by) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: workspace_unlocks workspace_unlocks_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_unlocks
    ADD CONSTRAINT workspace_unlocks_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspace_keys(workspace_id) ON DELETE CASCADE;


--
-- Name: workspace_wrap_grants workspace_wrap_grants_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_wrap_grants
    ADD CONSTRAINT workspace_wrap_grants_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: workspace_wrap_grants workspace_wrap_grants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_wrap_grants
    ADD CONSTRAINT workspace_wrap_grants_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: workspace_wrap_grants workspace_wrap_grants_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_wrap_grants
    ADD CONSTRAINT workspace_wrap_grants_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspace_keys(workspace_id) ON DELETE CASCADE;


--
-- Name: workspaces workspaces_company_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_company_workspace_id_fkey FOREIGN KEY (company_workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: workspaces workspaces_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.auth_users(id);


--
-- PostgreSQL database dump complete
--



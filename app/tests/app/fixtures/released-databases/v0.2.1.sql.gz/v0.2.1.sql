--
-- PostgreSQL database dump
--


-- Dumped from database version 18.6 (Debian 18.6-1.pgdg13+2)
-- Dumped by pg_dump version 18.6 (Debian 18.6-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: paradedb; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA paradedb;


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: pg_search; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_search WITH SCHEMA paradedb;


--
-- Name: EXTENSION pg_search; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_search IS 'pg_search: One Postgres for your application data, full-text search, vector retrieval, and aggregations';


--
-- Name: pgboss; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pgboss;


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: job_state; Type: TYPE; Schema: pgboss; Owner: -
--

CREATE TYPE pgboss.job_state AS ENUM (
    'created',
    'retry',
    'active',
    'completed',
    'cancelled',
    'failed'
);


--
-- Name: create_queue(text, jsonb); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.create_queue(queue_name text, options jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $_$
    DECLARE
      tablename varchar := CASE WHEN options->>'partition' = 'true'
                            THEN 'j' || encode(sha224(queue_name::bytea), 'hex')
                            ELSE 'job_common'
                            END;
      queue_created_on timestamptz;
    BEGIN

      WITH q as (
        INSERT INTO pgboss.queue (
          name,
          policy,
          retry_limit,
          retry_delay,
          retry_backoff,
          retry_delay_max,
          expire_seconds,
          retention_seconds,
          deletion_seconds,
          warning_queued,
          dead_letter,
          partition,
          table_name,
          heartbeat_seconds,
          notify,
          created_on,
          updated_on
        )
        VALUES (
          queue_name,
          options->>'policy',
          COALESCE((options->>'retryLimit')::int, 2),
          COALESCE((options->>'retryDelay')::int, 0),
          COALESCE((options->>'retryBackoff')::bool, false),
          (options->>'retryDelayMax')::int,
          COALESCE((options->>'expireInSeconds')::int, 900),
          COALESCE((options->>'retentionSeconds')::int, 1209600),
          COALESCE((options->>'deleteAfterSeconds')::int, 604800),
          COALESCE((options->>'warningQueueSize')::int, 0),
          options->>'deadLetter',
          COALESCE((options->>'partition')::bool, false),
          tablename,
          (options->>'heartbeatSeconds')::int,
          COALESCE((options->>'notify')::bool, false),
          pgboss.job_now(),
          pgboss.job_now()
        )
        ON CONFLICT DO NOTHING
        RETURNING created_on
      )
      SELECT created_on into queue_created_on from q;

      IF queue_created_on IS NULL OR options->>'partition' IS DISTINCT FROM 'true' THEN
        RETURN;
      END IF;

      EXECUTE format('CREATE TABLE pgboss.%I (LIKE pgboss.job INCLUDING DEFAULTS)', tablename);

      EXECUTE pgboss.job_table_format($cmd$ALTER TABLE pgboss.job ADD PRIMARY KEY (name, id)$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$ALTER TABLE pgboss.job ADD CONSTRAINT q_fkey FOREIGN KEY (name) REFERENCES pgboss.queue (name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$ALTER TABLE pgboss.job ADD CONSTRAINT dlq_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue (name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED$cmd$, tablename);

      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i11 ON pgboss.job (name, priority DESC, created_on, start_after) WHERE state < 'active' AND NOT blocked$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i4 ON pgboss.job (name, singleton_on, COALESCE(singleton_key, '')) WHERE state <> 'cancelled' AND singleton_on IS NOT NULL$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i7 ON pgboss.job (name, group_id) WHERE state = 'active' AND group_id IS NOT NULL$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i9 ON pgboss.job (name, id) WHERE blocking AND state = 'completed'$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i12 ON pgboss.job (source_root_id) WHERE source_root_id IS NOT NULL$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i13 ON pgboss.job (name, singleton_key) WHERE state = 'created' AND upsert_by_key$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i14 ON pgboss.job (name, state, blocked, start_after) WHERE state IN ('created', 'retry', 'active', 'failed')$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i15 ON pgboss.job (name, created_on)$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i16 ON pgboss.job (name, completed_on) WHERE completed_on IS NOT NULL$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i17 ON pgboss.job (name, singleton_key, created_on) WHERE state < 'active' AND singleton_key IS NOT NULL$cmd$, tablename);

      IF options->>'policy' = 'short' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i1 ON pgboss.job (name, COALESCE(singleton_key, '')) WHERE state = 'created' AND policy = 'short'$cmd$, tablename);
      ELSIF options->>'policy' = 'singleton' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i2 ON pgboss.job (name, COALESCE(singleton_key, '')) WHERE state = 'active' AND policy = 'singleton'$cmd$, tablename);
      ELSIF options->>'policy' = 'stately' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i3 ON pgboss.job (name, state, COALESCE(singleton_key, '')) WHERE state <= 'active' AND policy = 'stately'$cmd$, tablename);
      ELSIF options->>'policy' = 'exclusive' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i6 ON pgboss.job (name, COALESCE(singleton_key, '')) WHERE state <= 'active' AND policy = 'exclusive'$cmd$, tablename);
      ELSIF options->>'policy' = 'key_strict_fifo' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i8 ON pgboss.job (name, singleton_key) WHERE state IN ('active', 'retry', 'failed') AND policy = 'key_strict_fifo'$cmd$, tablename);
        EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i10 ON pgboss.job (name, singleton_key, state DESC, created_on, id) INCLUDE (start_after) WHERE state < 'active' AND NOT blocked AND policy = 'key_strict_fifo'$cmd$, tablename);
        EXECUTE pgboss.job_table_format($cmd$ALTER TABLE pgboss.job ADD CONSTRAINT job_key_strict_fifo_singleton_key_check CHECK (NOT (policy = 'key_strict_fifo' AND singleton_key IS NULL))$cmd$, tablename);
      END IF;

      EXECUTE format('ALTER TABLE pgboss.%I ADD CONSTRAINT cjc CHECK (name=%L)', tablename, queue_name);
      EXECUTE format('ALTER TABLE pgboss.job ATTACH PARTITION pgboss.%I FOR VALUES IN (%L)', tablename, queue_name);
    END;
    $_$;


--
-- Name: delete_queue(text); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.delete_queue(queue_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      v_table varchar;
      v_partition bool;
    BEGIN
      
      SELECT table_name, partition
      FROM pgboss.queue
      WHERE name = queue_name
      INTO v_table, v_partition;

      IF v_partition THEN
        EXECUTE format('DROP TABLE IF EXISTS pgboss.%I', v_table);
      ELSE
        EXECUTE format('DELETE FROM pgboss.%I WHERE name = %L', v_table, queue_name);
      END IF;
    
      DELETE FROM pgboss.queue WHERE name = queue_name;
    END;
    $$;


--
-- Name: job_now(); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.job_now() RETURNS timestamp with time zone
    LANGUAGE sql STABLE
    AS $$
      SELECT pg_catalog.now();
    $$;


--
-- Name: job_table_format(text, text); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.job_table_format(command text, table_name text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $_$
      SELECT format(
        regexp_replace(
          regexp_replace(command, '\.job\y', '.%1$I', 'g'),
          '\yjob_i(\d+)', '%1$s_i\1', 'g'
        ),
        table_name
      );
    $_$;


--
-- Name: job_table_run(text, text, text); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.job_table_run(command text, tbl_name text DEFAULT NULL::text, queue_name text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      tbl RECORD;
    BEGIN
      IF queue_name IS NOT NULL THEN
        SELECT table_name INTO tbl_name FROM pgboss.queue WHERE name = queue_name;
      END IF;

      IF tbl_name IS NOT NULL THEN
        EXECUTE pgboss.job_table_format(command, tbl_name);
        RETURN;
      END IF;

      EXECUTE pgboss.job_table_format(command, 'job_common');

      FOR tbl IN SELECT table_name FROM pgboss.queue WHERE partition = true
      LOOP
        EXECUTE pgboss.job_table_format(command, tbl.table_name);
      END LOOP;
    END;
    $$;


--
-- Name: job_table_run_async(text, integer, text, text, text); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.job_table_run_async(command_name text, version integer, command text, tbl_name text DEFAULT NULL::text, queue_name text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF queue_name IS NOT NULL THEN
        SELECT table_name INTO tbl_name FROM pgboss.queue WHERE name = queue_name;
      END IF;

      IF tbl_name IS NOT NULL THEN
        INSERT INTO pgboss.bam (name, version, status, queue, table_name, command)
        VALUES (
          command_name,
          version,
          'pending',
          queue_name,
          tbl_name,
          pgboss.job_table_format(command, tbl_name)
        );
        RETURN;
      END IF;

      INSERT INTO pgboss.bam (name, version, status, queue, table_name, command)
      SELECT
        command_name,
        version,
        'pending',
        NULL,
        'job_common',
        pgboss.job_table_format(command, 'job_common')
      UNION ALL
      SELECT
        command_name,
        version,
        'pending',
        queue.name,
        queue.table_name,
        pgboss.job_table_format(command, queue.table_name)
      FROM pgboss.queue
      WHERE partition = true;
    END;
    $$;


--
-- Name: agent_chat_file_gone(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_chat_file_gone() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  INSERT INTO file_garbage (id) VALUES (OLD.id) ON CONFLICT DO NOTHING;
  RETURN NULL;
END $$;


--
-- Name: agent_chat_file_text_job(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_chat_file_text_job() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF workspace_sealed(NEW.workspace_id) OR NOT file_text_extractable(NEW.name) THEN RETURN NULL; END IF;
  INSERT INTO file_text_jobs (file_id) VALUES (NEW.id) ON CONFLICT DO NOTHING;
  PERFORM pg_notify('flux_file_text', '');
  RETURN NULL;
END $$;


--
-- Name: agent_revoked_chat_files(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_revoked_chat_files() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  DELETE FROM project_files WHERE agent_id = NEW.id;
  RETURN NULL;
END $$;


--
-- Name: agent_task_events_notify(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_task_events_notify() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  PERFORM pg_notify('flux_agent_tasks', '');
  RETURN NULL;
END $$;


--
-- Name: ai_work_admission(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ai_work_admission() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  pid uuid;
  policy record;
BEGIN
  IF TG_TABLE_NAME = 'assistant_reaction_events' THEN
    SELECT project_id INTO pid FROM assistant_reactions WHERE id = NEW.reaction_id;
  ELSE
    pid := NEW.project_id;
  END IF;
  IF pid IS NULL AND TG_TABLE_NAME = 'personal_runs' THEN
    RETURN NEW;
  END IF;
  SELECT state, epoch INTO policy FROM project_ai_policies WHERE project_id = pid FOR SHARE;
  IF NOT FOUND OR policy.state <> 'allowed' OR NEW.ai_epoch IS DISTINCT FROM policy.epoch THEN
    RAISE EXCEPTION 'AI is turned off in this space' USING ERRCODE = 'FX403', HINT = 'SPACE_AI_OFF';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: auth_account_password_changed(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.auth_account_password_changed() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  -- OLD is the row as it is now, after any update that held the lock first.
  IF NEW.password_version_expected IS NOT NULL AND OLD.password_version IS DISTINCT FROM NEW.password_version_expected THEN
    RAISE EXCEPTION 'flux:password_changed: the password changed after it was checked' USING ERRCODE = 'P0001';
  END IF;
  IF NEW.password IS DISTINCT FROM OLD.password THEN
    NEW.password_version := OLD.password_version + 1;
    IF NEW.password_version_expected IS NULL AND NEW.provider_id = 'credential' THEN
      -- A password written with no check of the old one (a reset) ends every session, here, with the write. Better Auth deletes the sessions
      -- just before it writes, and a session created between the two (it saw the old version, and holds the share lock this write waited
      -- for) would otherwise stay.
      DELETE FROM auth_sessions WHERE user_id = NEW.user_id;
    END IF;
  END IF;
  NEW.password_version_expected := NULL;
  RETURN NEW;
END $$;


--
-- Name: auth_session_password_unchanged(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.auth_session_password_unchanged() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  -- FOR SHARE: a change of the password that comes in meanwhile waits for this insert to commit, and then deletes the session with the others.
  PERFORM 1 FROM auth_accounts a
    WHERE a.user_id = NEW.user_id AND a.provider_id = 'credential' AND a.password_version = NEW.password_version_checked
    FOR SHARE OF a;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'flux:password_changed: the password changed after it was checked' USING ERRCODE = 'P0001';
  END IF;
  NEW.password_version_checked := NULL;
  RETURN NEW;
END $$;


--
-- Name: cowork_stop_connection_units(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cowork_stop_connection_units() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND (NEW.revoked_at IS NULL OR OLD.revoked_at IS NOT NULL) THEN
    RETURN NEW;
  END IF;
  -- The parent connection row is already exclusively locked by UPDATE/DELETE.
  PERFORM connection_id FROM cowork_connection_slots
    WHERE connection_id = OLD.id ORDER BY connection_id FOR UPDATE;
  PERFORM id FROM project_work_items
    WHERE id IN (SELECT work_id FROM cowork_units WHERE assignment_connection_id = OLD.id
      AND state NOT IN ('completed', 'stopped')) ORDER BY id FOR UPDATE;
  PERFORM id FROM cowork_units WHERE assignment_connection_id = OLD.id
    AND state NOT IN ('completed', 'stopped') ORDER BY id FOR UPDATE;
  UPDATE cowork_units SET state = 'stopped', generation = generation + 1, version = version + 1,
    lease_id = NULL, lease_session_id = NULL, lease_expires_at = NULL, updated_at = clock_timestamp()
    WHERE assignment_connection_id = OLD.id AND state NOT IN ('completed', 'stopped');
  IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
  RETURN NEW;
END $$;


--
-- Name: dm_messages_flat_thread(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dm_messages_flat_thread() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.thread_root_id IS NOT NULL AND EXISTS (SELECT 1 FROM dm_messages r WHERE r.id = NEW.thread_root_id AND r.thread_root_id IS NOT NULL) THEN
    RAISE EXCEPTION 'a reply cannot be the root of another thread' USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: file_text_extractable(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.file_text_extractable(p_name text) RETURNS boolean
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$ SELECT lower(p_name) ~ '\.(pdf|docx|md|markdown|txt|text|log|csv|tsv)$' $_$;


--
-- Name: flux_event_audience_shape(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_event_audience_shape() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$
BEGIN
  IF NEW.recipient ~ '^(human|agent):[A-Za-z0-9_-]{1,64}$' THEN RETURN NEW; END IF;
  IF NOT EXISTS (SELECT 1 FROM events e WHERE e.id = NEW.event_id AND e.workspace_id IS NOT NULL AND workspace_sealed(e.workspace_id)) THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'An encrypted workspace''s event audience names principals only' USING ERRCODE = 'FX409', HINT = 'EVENT_CONTENT_REFUSED';
END $_$;


--
-- Name: flux_event_data_free(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_event_data_free() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$
DECLARE
  v text;
BEGIN
  IF NEW.workspace_id IS NULL OR NOT workspace_sealed(NEW.workspace_id) THEN RETURN NEW; END IF;
  -- The actor and the kind are shapes, never text (#721 review P3-3).
  IF NEW.actor_id !~ '^(human|agent|fixture):[A-Za-z0-9_-]{1,64}$' OR NEW.kind !~ '^[a-z][a-z_]*(\.[a-z][a-z_]*)+\.v[0-9]+$' THEN
    RAISE EXCEPTION 'An encrypted workspace''s event must be content-free' USING ERRCODE = 'FX409', HINT = 'EVENT_CONTENT_REFUSED';
  END IF;
  FOR v IN SELECT k #>> '{}' FROM jsonb_path_query(NEW.data, 'strict $.** ? (@.type() == "object").keyvalue().key') AS k LOOP
    CONTINUE WHEN v = '$sealed';
    CONTINUE WHEN v ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$';
    CONTINUE WHEN EXISTS (SELECT 1 FROM event_data_keys t WHERE t.key = v);
    RAISE EXCEPTION 'An encrypted workspace''s event must be content-free' USING ERRCODE = 'FX409', HINT = 'EVENT_CONTENT_REFUSED';
  END LOOP;
  FOR v IN SELECT x #>> '{}' FROM jsonb_path_query(NEW.data, 'strict $.**') AS x WHERE jsonb_typeof(x) = 'string' LOOP
    CONTINUE WHEN v ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$';
    CONTINUE WHEN v ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]{1,9})?(Z|[+-][0-9]{2}:[0-9]{2})$';
    CONTINUE WHEN flux_is_sealed(v);
    CONTINUE WHEN EXISTS (SELECT 1 FROM event_data_tokens t WHERE t.token = v);
    CONTINUE WHEN EXISTS (SELECT 1 FROM auth_users u WHERE u.id::text = v);
    CONTINUE WHEN v LIKE 'human:%' AND EXISTS (SELECT 1 FROM auth_users u WHERE u.id::text = substr(v, 7));
    CONTINUE WHEN v LIKE 'agent:%' AND EXISTS (SELECT 1 FROM agents a WHERE a.id::text = substr(v, 7));
    RAISE EXCEPTION 'An encrypted workspace''s event must be content-free' USING ERRCODE = 'FX409', HINT = 'EVENT_CONTENT_REFUSED';
  END LOOP;
  RETURN NEW;
END $_$;


--
-- Name: flux_events_assign_seq(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_events_assign_seq() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('flux.events.seq'));
  NEW.seq := nextval(pg_get_serial_sequence('events', 'seq'));
  RETURN NEW;
END
$$;


--
-- Name: flux_events_notify(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_events_notify() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.workspace_id IS NOT NULL THEN
    PERFORM pg_notify('flux_events', NEW.seq::text);
  END IF;
  RETURN NULL;
END
$$;


--
-- Name: flux_guard_task_creation_history(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_guard_task_creation_history() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.creation_baseline_version IS NOT NULL AND
    (NEW.creation_baseline_version IS DISTINCT FROM OLD.creation_baseline_version OR NEW.creation_baseline IS DISTINCT FROM OLD.creation_baseline OR NEW.creation_origin IS DISTINCT FROM OLD.creation_origin) THEN
    RAISE EXCEPTION 'immutable task creation baseline' USING ERRCODE = 'check_violation';
  END IF;
  IF OLD.first_persisted_use_at IS NOT NULL AND NEW.first_persisted_use_at IS DISTINCT FROM OLD.first_persisted_use_at THEN
    RAISE EXCEPTION 'immutable first task use' USING ERRCODE = 'check_violation';
  END IF;
  -- Every column this migration knows; a later migration's own new column can still be backfilled.
  IF OLD.creation_reverted_at IS NOT NULL AND (ROW(NEW.id, NEW.workspace_id, NEW.project_id, NEW.title, NEW.outcome, NEW.status, NEW.blocker,
      NEW.owner_user_id, NEW.owner_agent_id, NEW.created_by_kind, NEW.created_by_id,
      NEW.client_command_id, NEW.request_fingerprint, NEW.criteria, NEW.version, NEW.created_at, NEW.updated_at,
      NEW.creation_origin, NEW.creation_baseline, NEW.creation_baseline_version, NEW.first_persisted_use_at,
      NEW.creation_reverted_at, NEW.creation_reverted_by_kind, NEW.creation_reverted_by_id, NEW.creation_reversion_notice_id)
    IS DISTINCT FROM ROW(OLD.id, OLD.workspace_id, OLD.project_id, OLD.title, OLD.outcome, OLD.status, OLD.blocker,
      OLD.owner_user_id, OLD.owner_agent_id, OLD.created_by_kind, OLD.created_by_id,
      OLD.client_command_id, OLD.request_fingerprint, OLD.criteria, OLD.version, OLD.created_at, OLD.updated_at,
      OLD.creation_origin, OLD.creation_baseline, OLD.creation_baseline_version, OLD.first_persisted_use_at,
      OLD.creation_reverted_at, OLD.creation_reverted_by_kind, OLD.creation_reverted_by_id, OLD.creation_reversion_notice_id)) THEN
    RAISE EXCEPTION 'reverted task is read only' USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: flux_guard_task_creation_receipt(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_guard_task_creation_receipt() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'immutable task creation Undo receipt' USING ERRCODE = 'check_violation';
END $$;


--
-- Name: flux_is_sealed(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_is_sealed(value jsonb) RETURNS boolean
    LANGUAGE sql IMMUTABLE STRICT
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$
  SELECT coalesce(CASE jsonb_typeof(value)
    WHEN 'string' THEN flux_is_sealed(value #>> '{}')
    WHEN 'object' THEN (SELECT count(*) FROM jsonb_object_keys(value)) = 1 AND jsonb_typeof(value -> '$sealed') = 'string'
      AND flux_is_sealed(value ->> '$sealed')
    ELSE false END, false) $_$;


--
-- Name: flux_is_sealed(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_is_sealed(value text) RETURNS boolean
    LANGUAGE sql IMMUTABLE STRICT
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$ SELECT value ~ '^fx1\.[1-9][0-9]{0,8}\.[A-Za-z0-9_-]{38,}$' $_$;


--
-- Name: flux_joined_words(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_joined_words(text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT PARALLEL SAFE
    RETURN regexp_replace($1, '([[:alnum:]])[-‐‑]+(?=[[:alnum:]])'::text, '\1'::text, 'g'::text);


--
-- Name: flux_max_version(integer[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_max_version(integer[]) RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $_$ SELECT max(v) FROM unnest($1) v $_$;


--
-- Name: flux_notification_content_free(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_notification_content_free() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  ws text;
  sep text;
  who text;
BEGIN
  IF NEW.workspace_id IS NULL OR NOT workspace_sealed(NEW.workspace_id) THEN RETURN NEW; END IF;
  -- A read-state or delivery update keeps the stored text, which was checked when written: a later rename of the
  -- account or the workspace must not make the row impossible to mark read (#712 review P2-1).
  IF TG_OP = 'UPDATE' AND NEW.title IS NOT DISTINCT FROM OLD.title AND NEW.body IS NOT DISTINCT FROM OLD.body
    AND NEW.url IS NOT DISTINCT FROM OLD.url AND NEW.workspace_id = OLD.workspace_id THEN RETURN NEW; END IF;
  -- The link carries ids only: one of the generator's forms with every id replaced (#712 review P3).
  IF NEW.url IS NOT NULL AND regexp_replace(NEW.url, '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}', 'ID', 'g')
    NOT IN ('/inbox', '/projects/ID/conversations/ID#message-ID', '/dm/ID#message-ID', '/projects/ID/tasks?open=work:ID',
      '/projects/ID?open=decision:ID', '/projects/ID/live/ID?invitation=ID', '/projects/ID/live/ID') THEN
    RAISE EXCEPTION 'An encrypted workspace''s notification must be content-free' USING ERRCODE = 'FX409', HINT = 'NOTIFICATION_CONTENT_REFUSED';
  END IF;
  SELECT name INTO ws FROM workspaces WHERE id = NEW.workspace_id;
  IF NEW.body = '' THEN
    IF NEW.title = ws || '''s encryption keys were changed outside Flux. It stays locked.' THEN RETURN NEW; END IF;
    IF NEW.title = ws || '''s key change cannot finish yet. Ask your server''s operator.' THEN RETURN NEW; END IF;
    FOREACH sep IN ARRAY ARRAY[' mentioned you in ', ' asked you in ', ' replied in ', ' sent you a message in ', ' assigned you a task in ',
      ' asked for your review in ', ' invited you to a call in ', ' now has an unlock password for ', ' started a call in '] LOOP
      IF length(NEW.title) > length(sep || ws) AND right(NEW.title, length(sep || ws)) = sep || ws THEN
        who := left(NEW.title, length(NEW.title) - length(sep || ws));
        IF who IN ('Someone', 'An agent') OR EXISTS (SELECT 1 FROM auth_users u WHERE u.name = who) THEN RETURN NEW; END IF;
      END IF;
    END LOOP;
  END IF;
  RAISE EXCEPTION 'An encrypted workspace''s notification must be content-free' USING ERRCODE = 'FX409', HINT = 'NOTIFICATION_CONTENT_REFUSED';
END $$;


--
-- Name: flux_person_photo_garbage(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_person_photo_garbage() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO public.file_garbage (id) VALUES (old.object_64), (old.object_128), (old.object_256) ON CONFLICT DO NOTHING;
  RETURN old;
END;
$$;


--
-- Name: flux_revoke_live_admissions(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_revoke_live_admissions() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  UPDATE live_admissions SET revoked_at = now()
  WHERE auth_session_id = OLD.id AND revoked_at IS NULL;
  IF FOUND THEN
    PERFORM pg_notify('flux_live_admissions', OLD.id);
  END IF;
  RETURN OLD;
END;
$$;


--
-- Name: flux_sealed_backstop(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_sealed_backstop() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$
DECLARE
  r jsonb := to_jsonb(NEW);
  path text[] := string_to_array(TG_ARGV[0], ':');
  ws uuid;
  v jsonb;
BEGIN
  IF path[1] = 'workspace_id' THEN
    ws := (r ->> 'workspace_id')::uuid;
  ELSIF r ->> path[2] IS NOT NULL THEN
    EXECUTE format('SELECT workspace_id FROM %I WHERE %I = $1', path[3], path[4]) INTO ws USING (r ->> path[2])::uuid;
  END IF;
  IF ws IS NULL OR NOT workspace_sealed(ws) THEN RETURN NEW; END IF;
  FOR i IN 1 .. TG_NARGS - 1 LOOP
    v := r -> TG_ARGV[i];
    CONTINUE WHEN v IS NULL OR v = 'null'::jsonb OR v = '""'::jsonb;
    IF flux_is_sealed(v) IS NOT TRUE THEN
      RAISE EXCEPTION 'An encrypted workspace refuses plaintext in %.%', TG_TABLE_NAME, TG_ARGV[i]
        USING ERRCODE = 'FX409', HINT = 'WORKSPACE_PLAINTEXT_REFUSED';
    END IF;
  END LOOP;
  RETURN NEW;
END $_$;


--
-- Name: flux_sealed_wait_ids_only(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_sealed_wait_ids_only() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$
BEGIN
  IF NEW.queue ~ '^[a-z][a-z0-9_.-]{0,63}$' AND jsonb_typeof(NEW.payload) = 'object' AND NOT EXISTS (SELECT 1 FROM jsonb_each(NEW.payload) p
      WHERE p.key <> 'eventId' OR jsonb_typeof(p.value) <> 'string'
        OR NOT (p.value #>> '{}') ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$') THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'A sealed job wait carries ids only' USING ERRCODE = 'FX409', HINT = 'EVENT_CONTENT_REFUSED';
END $_$;


--
-- Name: flux_space_icon_garbage(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_space_icon_garbage() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF old.picture IS NOT NULL THEN
    INSERT INTO public.file_garbage (id) VALUES (old.object_64), (old.object_128), (old.object_256) ON CONFLICT DO NOTHING;
  END IF;
  RETURN old;
END;
$$;


--
-- Name: flux_task_criteria_valid(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_task_criteria_valid(criteria jsonb) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $$
  SELECT CASE WHEN jsonb_typeof(criteria) <> 'array' THEN false ELSE
    jsonb_array_length(criteria) <= 20
    AND NOT EXISTS (
      SELECT 1 FROM jsonb_array_elements(criteria) AS item
      WHERE jsonb_typeof(item) <> 'string'
        OR length(item #>> '{}') NOT BETWEEN 1 AND 1000
        OR (item #>> '{}') <> btrim(item #>> '{}', E' \t\r\n'))
    AND (SELECT count(DISTINCT item) FROM jsonb_array_elements(criteria) AS item) = jsonb_array_length(criteria)
  END
$$;


--
-- Name: flux_task_dependency_bound(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_task_dependency_bound() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF (SELECT count(*) FROM project_task_dependencies WHERE task_id = NEW.task_id) >= 50 THEN
    RAISE EXCEPTION 'a task has at most 50 prerequisites' USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: flux_task_plan_intent_immutable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flux_task_plan_intent_immutable() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'task plan intents are immutable' USING ERRCODE = 'check_violation';
END;
$$;


--
-- Name: forbid_material_version_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.forbid_material_version_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'material versions are immutable' USING ERRCODE = 'check_violation';
END;
$$;


--
-- Name: guard_map_live_identity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_map_live_identity() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_TABLE_NAME='map_live_object_versions' THEN
    IF ROW(NEW.kind,NEW.object_id,NEW.sketch_id) IS DISTINCT FROM ROW(OLD.kind,OLD.object_id,OLD.sketch_id) OR NEW.version<=OLD.version THEN
      RAISE EXCEPTION 'immutable map object ownership or non-monotonic version' USING ERRCODE='23514';
    END IF;
  ELSIF TG_TABLE_NAME='map_live_heads' THEN
    IF ROW(NEW.sketch_id,NEW.workspace_id,NEW.generation) IS DISTINCT FROM ROW(OLD.sketch_id,OLD.workspace_id,OLD.generation) OR NEW.sequence<OLD.sequence THEN
      RAISE EXCEPTION 'immutable map room or non-monotonic sequence' USING ERRCODE='23514';
    END IF;
  END IF;
  RETURN NEW;
END $$;


--
-- Name: idempotency_scope_required(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.idempotency_scope_required() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF NEW.workspace_id IS NULL AND NOT EXISTS (SELECT 1 FROM idempotency_account_operations WHERE operation = NEW.operation) THEN
    RAISE EXCEPTION 'An Idempotency-Key response needs the workspace of its command' USING ERRCODE = 'FX409', HINT = 'IDEMPOTENCY_SCOPE_REQUIRED';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: immutable_live_editing_record(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.immutable_live_editing_record() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN RAISE EXCEPTION 'live editing history and receipts are immutable' USING ERRCODE = 'check_violation'; END $$;


--
-- Name: invalidate_runtime_auth_operations(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_runtime_auth_operations() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.state <> 'active' THEN
    UPDATE agent_runtime_auth_operations SET phase = 'uncertain', settled_at = NULL
      WHERE binding_id = NEW.id AND phase = 'active';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: live_replica_ownership_immutable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.live_replica_ownership_immutable() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF (NEW.doc_id,NEW.generation,NEW.replica_id,NEW.owner_kind,NEW.actor_id,NEW.instance_id)
    IS DISTINCT FROM (OLD.doc_id,OLD.generation,OLD.replica_id,OLD.owner_kind,OLD.actor_id,OLD.instance_id) THEN
    RAISE EXCEPTION 'live replica ownership is immutable' USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: live_session_doc_in_space(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.live_session_doc_in_space() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF NEW.doc_id IS NULL OR TG_OP = 'UPDATE' AND NEW.doc_id IS NOT DISTINCT FROM OLD.doc_id
     AND NEW.project_id IS NOT DISTINCT FROM OLD.project_id AND NEW.workspace_id IS NOT DISTINCT FROM OLD.workspace_id THEN
    RETURN NEW;
  END IF;
  PERFORM pm.id FROM project_materials pm
    WHERE pm.id = NEW.doc_id AND pm.kind = 'doc' AND pm.workspace_id = NEW.workspace_id AND pm.project_id = NEW.project_id
    FOR KEY SHARE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'a live session''s page must be a page of its own space'
      USING ERRCODE = 'foreign_key_violation', CONSTRAINT = 'live_sessions_doc_in_space';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: material_agent_doc_stays_doc(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.material_agent_doc_stays_doc() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.kind IS DISTINCT FROM 'doc' AND EXISTS (
    SELECT 1 FROM project_material_versions v WHERE v.material_id = NEW.id AND v.author_agent_id IS NOT NULL) THEN
    RAISE EXCEPTION 'a material with an agent-written version stays a doc'
      USING ERRCODE = 'check_violation', CONSTRAINT = 'project_material_version_agent_doc_parent';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: material_version_agent_doc_parent(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.material_version_agent_doc_parent() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  parent_kind text;
BEGIN
  IF NEW.author_agent_id IS NULL THEN RETURN NEW; END IF;
  SELECT pm.kind INTO parent_kind FROM project_materials pm WHERE pm.id = NEW.material_id FOR SHARE;
  IF parent_kind IS DISTINCT FROM 'doc' THEN
    RAISE EXCEPTION 'only a doc version can have an agent author'
      USING ERRCODE = 'check_violation', CONSTRAINT = 'project_material_version_agent_doc_parent';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: personal_run_cites_end(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.personal_run_cites_end() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  DELETE FROM personal_run_cites WHERE run_id = NEW.id;
  RETURN NULL;
END $$;


--
-- Name: personal_run_pictures_gone(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.personal_run_pictures_gone() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  INSERT INTO file_garbage (id) VALUES (OLD.id) ON CONFLICT DO NOTHING;
  RETURN NULL;
END $$;


--
-- Name: personal_run_private_texts_decided(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.personal_run_private_texts_decided() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF NEW.run_id IS NOT NULL
    AND EXISTS (SELECT 1 FROM personal_runs WHERE id = NEW.run_id AND status NOT IN ('queued', 'reading', 'dispatching'))
    AND NOT EXISTS (SELECT 1 FROM assistant_changes WHERE run_id = NEW.run_id AND operation = 'answer.picture.attach' AND state = 'waiting') THEN
    DELETE FROM personal_run_private_texts WHERE run_id = NEW.run_id;
  END IF;
  RETURN NULL;
END $$;


--
-- Name: personal_run_private_texts_end(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.personal_run_private_texts_end() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM assistant_changes WHERE run_id = NEW.id AND operation = 'answer.picture.attach' AND state = 'waiting') THEN
    DELETE FROM personal_run_private_texts WHERE run_id = NEW.id;
  END IF;
  RETURN NULL;
END $$;


--
-- Name: personal_run_task_ended(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.personal_run_task_ended() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  INSERT INTO agent_task_events (kind, work_id, run_id) VALUES ('finished', NEW.work_id, NEW.id);
  RETURN NULL;
END $$;


--
-- Name: personal_run_task_started(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.personal_run_task_started() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  INSERT INTO agent_task_events (kind, work_id, run_id) VALUES ('started', NEW.work_id, NEW.id);
  RETURN NULL;
END $$;


--
-- Name: project_ai_policy_create(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.project_ai_policy_create() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  INSERT INTO project_ai_policies (project_id, state) VALUES (NEW.id, CASE WHEN workspace_sealed(NEW.workspace_id) THEN 'blocked' ELSE 'allowed' END);
  RETURN NEW;
END $$;


--
-- Name: project_ai_policy_encrypted(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.project_ai_policy_encrypted() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF NEW.state = 'allowed' AND workspace_sealed((SELECT p.workspace_id FROM projects p WHERE p.id = NEW.project_id)) THEN
    RAISE EXCEPTION 'AI is always off in an encrypted workspace' USING ERRCODE = 'FX409', HINT = 'WORKSPACE_ENCRYPTED_AI_OFF';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: project_task_sequence(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.project_task_sequence(project uuid) RETURNS regclass
    LANGUAGE sql STABLE
    AS $$
  SELECT to_regclass('project_task_number_' || replace(project::text, '-', ''))
$$;


--
-- Name: project_task_sequence_lifecycle(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.project_task_sequence_lifecycle() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    EXECUTE format('CREATE SEQUENCE %I AS integer', 'project_task_number_' || replace(NEW.id::text, '-', ''));
  ELSE
    EXECUTE format('DROP SEQUENCE IF EXISTS %I', 'project_task_number_' || replace(OLD.id::text, '-', ''));
  END IF;
  RETURN NULL;
END $$;


--
-- Name: project_work_number(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.project_work_number() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  sequence regclass;
BEGIN
  IF TG_OP = 'UPDATE' THEN
    IF NEW.number IS DISTINCT FROM OLD.number THEN
      RAISE EXCEPTION 'a task number never changes' USING ERRCODE = 'restrict_violation';
    END IF;
    -- The number belongs to the project's sequence: a numbered task never moves to another project.
    IF NEW.project_id IS DISTINCT FROM OLD.project_id THEN
      RAISE EXCEPTION 'a numbered task never moves to another project' USING ERRCODE = 'restrict_violation';
    END IF;
    RETURN NEW;
  END IF;
  sequence := project_task_sequence(NEW.project_id);
  IF sequence IS NULL THEN
    RAISE EXCEPTION 'no task numbering for project %', NEW.project_id USING ERRCODE = 'foreign_key_violation';
  END IF;
  NEW.number := nextval(sequence);
  RETURN NEW;
END $$;


--
-- Name: sealed_workspace_no_ai(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sealed_workspace_no_ai() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$
DECLARE
  r jsonb := to_jsonb(NEW);
  uuid_text text := '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$';
  ws uuid;
BEGIN
  IF coalesce(r->>'workspace_id', '') ~* uuid_text THEN
    ws := (r->>'workspace_id')::uuid;
  ELSIF coalesce(r->>'project_id', '') ~* uuid_text THEN
    SELECT workspace_id INTO ws FROM projects WHERE id = (r->>'project_id')::uuid;
  ELSIF coalesce(r->>'agent_id', '') ~* uuid_text THEN
    SELECT workspace_id INTO ws FROM agents WHERE id = (r->>'agent_id')::uuid;
  ELSIF TG_TABLE_NAME LIKE 'agent%' AND coalesce(r->>'connection_id', '') ~* uuid_text THEN
    SELECT workspace_id INTO ws FROM agent_connections WHERE id = (r->>'connection_id')::uuid;
  END IF;
  IF ws IS NOT NULL AND workspace_sealed(ws) THEN
    RAISE EXCEPTION 'AI is always off in an encrypted workspace' USING ERRCODE = 'FX409', HINT = 'WORKSPACE_ENCRYPTED_AI_OFF';
  END IF;
  RETURN NEW;
END $_$;


--
-- Name: sealed_workspace_refused(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sealed_workspace_refused() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$
DECLARE
  r jsonb := to_jsonb(NEW);
  uuid_text text := '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$';
  ws uuid;
BEGIN
  IF coalesce(r ->> 'workspace_id', '') ~* uuid_text THEN
    ws := (r ->> 'workspace_id')::uuid;
  ELSIF coalesce(r ->> 'project_id', '') ~* uuid_text THEN
    SELECT workspace_id INTO ws FROM projects WHERE id = (r ->> 'project_id')::uuid;
  END IF;
  IF ws IS NOT NULL AND workspace_sealed(ws) THEN
    RAISE EXCEPTION 'This is not available in an encrypted workspace' USING ERRCODE = 'FX409', HINT = 'WORKSPACE_ENCRYPTED_UNSUPPORTED';
  END IF;
  RETURN NEW;
END $_$;


--
-- Name: search_change_log(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_change_log() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    IF OLD.sealed THEN INSERT INTO search_changes (workspace_id, doc_key) VALUES (OLD.workspace_id, OLD.doc_key); END IF;
    RETURN OLD;
  END IF;
  IF NEW.sealed THEN INSERT INTO search_changes (workspace_id, doc_key) VALUES (NEW.workspace_id, NEW.doc_key); END IF;
  RETURN NEW;
END $$;


--
-- Name: search_index_decision(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_decision() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN DELETE FROM search_documents WHERE doc_key = 'decision:' || OLD.id; RETURN OLD; END IF;
  PERFORM search_put('decision:' || NEW.id, 'decision', NEW.workspace_id, 'project:' || NEW.project_id, NEW.project_id, NEW.id::text, NULL, NULL,
    NEW.status, NEW.title, NEW.rationale, NEW.proposed_by_kind, NEW.proposed_by_id, NEW.updated_at);
  RETURN NEW;
END $$;


--
-- Name: search_index_dm_message(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_dm_message() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN DELETE FROM search_documents WHERE doc_key = 'dm_message:' || OLD.id; RETURN OLD; END IF;
  IF NEW.kind <> 'text' THEN RETURN NEW; END IF;
  IF NEW.removed_at IS NOT NULL THEN DELETE FROM search_documents WHERE doc_key = 'dm_message:' || NEW.id; RETURN NEW; END IF;
  PERFORM search_put('dm_message:' || NEW.id, 'dm_message', NEW.workspace_id, 'dm:' || NEW.dm_id, NULL, NEW.id::text,
    NEW.dm_id, NULL, NULL, '', NEW.body, 'human', NEW.author_id, NEW.created_at);
  RETURN NEW;
END $$;


--
-- Name: search_index_file(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_file() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF NEW.poster_of IS NOT NULL THEN RETURN NULL; END IF;
  PERFORM search_put('file:' || NEW.id || ':0', 'file', NEW.workspace_id, 'project:' || NEW.project_id, NEW.project_id, NEW.id::text, m.conversation_id, 0,
    NULL, NEW.name, '', CASE WHEN NEW.uploader_id IS NOT NULL THEN 'human' ELSE 'agent' END, coalesce(NEW.uploader_id, NEW.uploader_agent_id::text),
    NEW.published_at)
  FROM project_messages m WHERE m.id = NEW.message_id;
  IF workspace_sealed(NEW.workspace_id) OR NOT file_text_extractable(NEW.name) THEN RETURN NULL; END IF;
  INSERT INTO file_text_jobs (file_id) VALUES (NEW.id) ON CONFLICT DO NOTHING;
  PERFORM pg_notify('flux_file_text', '');
  RETURN NULL;
END $$;


--
-- Name: search_index_material_version(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_material_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  material_kind text;
BEGIN
  IF TG_OP = 'DELETE' THEN DELETE FROM search_documents WHERE doc_key = 'material:' || OLD.material_id || ':' || OLD.version; RETURN OLD; END IF;
  SELECT pm.kind INTO material_kind FROM project_materials pm WHERE pm.id = NEW.material_id;
  PERFORM search_put('material:' || NEW.material_id || ':' || NEW.version, coalesce(material_kind, 'material'), NEW.workspace_id, 'project:' || NEW.project_id,
    NEW.project_id, NEW.material_id::text, NULL, NEW.version, NULL, NEW.title, concat_ws(E'\n', NEW.body, NEW.url),
    CASE WHEN NEW.author_id IS NOT NULL THEN 'human' ELSE 'agent' END, coalesce(NEW.author_id, NEW.author_agent_id::text), NEW.created_at);
  RETURN NEW;
END $$;


--
-- Name: search_index_member(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_member() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN DELETE FROM search_documents WHERE doc_key = 'person:' || OLD.workspace_id || ':' || OLD.user_id; RETURN OLD; END IF;
  PERFORM search_put('person:' || NEW.workspace_id || ':' || NEW.user_id, 'person', NEW.workspace_id, 'members:' || NEW.workspace_id, NULL,
    NEW.user_id, NULL, NULL, NEW.role, (SELECT u.name FROM auth_users u WHERE u.id = NEW.user_id), '', NULL, NULL, NEW.created_at);
  RETURN NEW;
END $$;


--
-- Name: search_index_message(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_message() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN DELETE FROM search_documents WHERE doc_key = 'message:' || OLD.id; RETURN OLD; END IF;
  IF NEW.removed_at IS NOT NULL THEN DELETE FROM search_documents WHERE doc_key = 'message:' || NEW.id; RETURN NEW; END IF;
  PERFORM search_put('message:' || NEW.id, 'message', NEW.workspace_id, 'project:' || NEW.project_id, NEW.project_id, NEW.id::text,
    NEW.conversation_id, NULL, NULL, CASE WHEN btrim(NEW.body) = '' THEN 'Attached files' ELSE '' END, NEW.body,
    CASE WHEN NEW.author_id IS NOT NULL THEN 'human' ELSE 'agent' END,
    coalesce(NEW.author_id, NEW.author_agent_id::text), NEW.created_at);
  RETURN NEW;
END $$;


--
-- Name: search_index_project(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_project() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN DELETE FROM search_documents WHERE doc_key = 'project:' || OLD.id; RETURN OLD; END IF;
  PERFORM search_put('project:' || NEW.id, 'project', NEW.workspace_id, 'project:' || NEW.id, NEW.id, NEW.id::text, NULL, NULL,
    NEW.visibility, NEW.name, '', NULL, NULL, NEW.updated_at);
  RETURN NEW;
END $$;


--
-- Name: search_index_sketch(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_sketch() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    DELETE FROM search_documents WHERE doc_key = 'sketch:' || OLD.id;
    RETURN OLD;
  END IF;
  PERFORM search_put('sketch:' || NEW.id, 'sketch', NEW.workspace_id, 'sketch:' || NEW.id, NEW.project_id, NEW.id::text, NULL, NULL,
    NEW.scope, NEW.title, '', CASE WHEN NEW.created_by_user_id IS NOT NULL THEN 'human' WHEN NEW.created_by_agent_id IS NOT NULL THEN 'agent' END,
    coalesce(NEW.created_by_user_id, NEW.created_by_agent_id::text), NEW.updated_at);
  IF TG_OP = 'UPDATE' AND NEW.project_id IS DISTINCT FROM OLD.project_id THEN
    UPDATE search_documents SET project_id = NEW.project_id WHERE parent_id = NEW.id AND kind = 'thought';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: search_index_thought(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_thought() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN DELETE FROM search_documents WHERE doc_key = 'thought:' || OLD.id; RETURN OLD; END IF;
  -- Moving a thought on the map changes nothing that can be searched.
  IF TG_OP = 'UPDATE' AND NEW.text IS NOT DISTINCT FROM OLD.text THEN RETURN NEW; END IF;
  PERFORM search_put('thought:' || NEW.id, 'thought', NEW.workspace_id, 'sketch:' || NEW.sketch_id,
    (SELECT s.project_id FROM sketches s WHERE s.id = NEW.sketch_id), NEW.id::text, NEW.sketch_id, NULL, NULL, NEW.text, '',
    CASE WHEN NEW.created_by_user_id IS NOT NULL THEN 'human' WHEN NEW.created_by_agent_id IS NOT NULL THEN 'agent' END,
    coalesce(NEW.created_by_user_id, NEW.created_by_agent_id::text), NEW.updated_at);
  RETURN NEW;
END $$;


--
-- Name: search_index_user_name(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_user_name() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  UPDATE search_documents SET title = NEW.name WHERE kind = 'person' AND object_id = NEW.id;
  RETURN NEW;
END $$;


--
-- Name: search_index_work(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_index_work() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN DELETE FROM search_documents WHERE doc_key = 'work:' || OLD.id; RETURN OLD; END IF;
  PERFORM search_put('work:' || NEW.id, 'work', NEW.workspace_id, 'project:' || NEW.project_id, NEW.project_id, NEW.id::text, NULL, NULL,
    NEW.status,
    NEW.title, concat_ws(E'\n', '#' || NEW.number, nullif(NEW.outcome, ''), NEW.blocker), NEW.created_by_kind, NEW.created_by_id, NEW.updated_at);
  RETURN NEW;
END $$;


--
-- Name: search_key(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_key(p_audience text, p_term text) RETURNS bigint
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    AS $$ SELECT hashtextextended(p_audience || '|' || p_term, 0) $$;


--
-- Name: search_keys(text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_keys(p_audience text, p_title text, p_body text) RETURNS bigint[]
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    SET search_path TO 'public', 'pg_catalog'
    AS $$
  SELECT coalesce(array_agg(DISTINCT search_key(p_audience, k)), '{}')
  FROM (
    SELECT prefixes.k
    FROM (SELECT lexeme FROM unnest(to_tsvector('simple', coalesce(p_title, '') || ' ' || left(coalesce(p_body, ''), 100000)))) words,
    LATERAL (VALUES ('1:' || left(words.lexeme, 1)), (CASE WHEN length(words.lexeme) >= 2 THEN '2:' || left(words.lexeme, 2) END),
      (CASE WHEN length(words.lexeme) >= 3 THEN '3:' || left(words.lexeme, 3) END)) AS prefixes(k)
    UNION ALL
    SELECT 't:' || trigram FROM unnest(show_trgm(left(coalesce(p_title, ''), 1000))) AS trigram
  ) keys
  WHERE k IS NOT NULL
$$;


--
-- Name: search_put(text, text, uuid, text, uuid, text, uuid, integer, text, text, text, text, text, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_put(p_key text, p_kind text, p_workspace uuid, p_audience text, p_project uuid, p_object text, p_parent uuid, p_version integer, p_status text, p_title text, p_body text, p_author_kind text, p_author text, p_at timestamp with time zone) RETURNS void
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE placeholder boolean := p_kind <> 'person' AND workspace_sealed(p_workspace);
BEGIN
  INSERT INTO search_documents(doc_key, kind, workspace_id, audience_key, project_id, object_id, parent_id, version, status, title, body, author_kind, author_id, at, sealed)
  VALUES (p_key, p_kind, p_workspace, p_audience, p_project, p_object, p_parent, p_version, p_status,
    CASE WHEN placeholder THEN '' ELSE coalesce(p_title, '') END, CASE WHEN placeholder THEN '' ELSE coalesce(p_body, '') END,
    p_author_kind, p_author, p_at, placeholder)
  ON CONFLICT (doc_key) DO UPDATE SET
    workspace_id = EXCLUDED.workspace_id, audience_key = EXCLUDED.audience_key, project_id = EXCLUDED.project_id,
    parent_id = EXCLUDED.parent_id, version = EXCLUDED.version, status = EXCLUDED.status, title = EXCLUDED.title,
    body = EXCLUDED.body, author_kind = EXCLUDED.author_kind, author_id = EXCLUDED.author_id, at = EXCLUDED.at, sealed = EXCLUDED.sealed;
END $$;


--
-- Name: search_term(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_term(p_lexeme text) RETURNS text
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    AS $$ SELECT least(length(p_lexeme), 3)::text || ':' || left(p_lexeme, 3) $$;


--
-- Name: search_unindex_file(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_unindex_file() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  DELETE FROM search_documents WHERE kind = 'file' AND object_id = OLD.id::text;
  RETURN NULL;
END $$;


--
-- Name: search_vector_eligible(text, boolean, text, text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_vector_eligible(p_kind text, p_sealed boolean, p_title text, p_body text, p_project uuid) RETURNS boolean
    LANGUAGE sql STABLE
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
  SELECT NOT p_sealed AND p_kind <> 'person' AND (btrim(p_title) <> '' OR btrim(p_body) <> '')
    AND (p_project IS NULL OR EXISTS (SELECT 1 FROM project_ai_policies a WHERE a.project_id = p_project AND a.state = 'allowed'))
$$;


--
-- Name: search_vector_space_ai(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_vector_space_ai() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM search_vector_state) THEN RETURN NULL; END IF;
  IF NEW.state = 'allowed' THEN
    INSERT INTO search_vector_queue (document_id)
      SELECT d.id FROM search_documents d
      WHERE d.project_id = NEW.project_id AND search_vector_eligible(d.kind, d.sealed, d.title, d.body, d.project_id)
      ON CONFLICT DO NOTHING;
    PERFORM pg_notify('flux_search_vectors', '');
  ELSE
    DELETE FROM search_vectors WHERE document_id IN (SELECT d.id FROM search_documents d WHERE d.project_id = NEW.project_id);
    DELETE FROM search_vector_queue WHERE document_id IN (SELECT d.id FROM search_documents d WHERE d.project_id = NEW.project_id);
  END IF;
  RETURN NULL;
END $$;


--
-- Name: search_vector_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_vector_sync() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM search_vector_state) THEN RETURN NULL; END IF;
  IF TG_OP = 'UPDATE' THEN
    DELETE FROM search_vectors WHERE document_id = NEW.id;
    DELETE FROM search_vector_queue WHERE document_id = NEW.id;
  END IF;
  IF search_vector_eligible(NEW.kind, NEW.sealed, NEW.title, NEW.body, NEW.project_id) THEN
    INSERT INTO search_vector_queue (document_id) VALUES (NEW.id) ON CONFLICT DO NOTHING;
    PERFORM pg_notify('flux_search_vectors', '');
  END IF;
  RETURN NULL;
END $$;


--
-- Name: workspace_company_link_guard(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.workspace_company_link_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.company_workspace_id IS NOT NULL AND EXISTS (SELECT 1 FROM workspaces parent WHERE parent.id = NEW.company_workspace_id AND parent.encrypted) THEN
    RAISE EXCEPTION 'An encrypted space belongs to the company, never to another encrypted space' USING ERRCODE = 'FX409', HINT = 'ENCRYPTED_SPACE_COMPANY_ONLY';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: workspace_encryption_immutable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.workspace_encryption_immutable() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.encrypted IS DISTINCT FROM OLD.encrypted THEN
    RAISE EXCEPTION 'A workspace''s encryption is chosen at creation and cannot change' USING ERRCODE = 'FX409', HINT = 'WORKSPACE_ENCRYPTION_IMMUTABLE';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: workspace_holder_delete_guard(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.workspace_holder_delete_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.kind = 'password' AND EXISTS (SELECT 1 FROM workspaces WHERE id = OLD.workspace_id)
    AND NOT EXISTS (SELECT 1 FROM workspace_holders WHERE workspace_id = OLD.workspace_id AND kind = 'password' AND id <> OLD.id) THEN
    RAISE EXCEPTION 'The workspace needs at least one unlock password' USING ERRCODE = 'FX409', HINT = 'LAST_UNLOCK_PASSWORD';
  END IF;
  RETURN OLD;
END $$;


--
-- Name: workspace_holder_deleted(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.workspace_holder_deleted() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM workspace_keys WHERE workspace_id = OLD.workspace_id) THEN
    INSERT INTO workspace_removed_holders (workspace_id, holder_id, user_id, public_key)
      VALUES (OLD.workspace_id, OLD.id, OLD.user_id, OLD.public_key) ON CONFLICT DO NOTHING;
    UPDATE workspace_keys SET rotation = 'pending', rotation_reason = jsonb_build_object('kind', 'holder_deleted', 'userId', OLD.user_id)
      WHERE workspace_id = OLD.workspace_id AND rotation IN ('none', 'reencrypting');
  END IF;
  RETURN NULL;
END $$;


--
-- Name: workspace_manager_lost(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.workspace_manager_lost() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF OLD.role IN ('owner', 'admin') AND (TG_OP = 'DELETE' OR NEW.role NOT IN ('owner', 'admin'))
    AND EXISTS (SELECT 1 FROM workspaces WHERE id = OLD.workspace_id AND encrypted)
    AND EXISTS (SELECT 1 FROM workspace_keys WHERE workspace_id = OLD.workspace_id) THEN
    DELETE FROM workspace_holders WHERE workspace_id = OLD.workspace_id
      AND (kind = 'recovery' OR (kind = 'password' AND user_id = OLD.user_id));
    UPDATE workspace_keys SET rotation = 'pending',
      rotation_reason = jsonb_build_object('kind', CASE WHEN TG_OP = 'DELETE' THEN 'removed' ELSE 'demoted' END, 'userId', OLD.user_id)
      WHERE workspace_id = OLD.workspace_id;
  END IF;
  RETURN NULL;
END $$;


--
-- Name: workspace_sealed(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.workspace_sealed(uuid) RETURNS boolean
    LANGUAGE sql STABLE
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$ SELECT coalesce((SELECT encrypted FROM workspaces WHERE id = $1), false) $_$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bam; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.bam (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    version integer NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    queue text,
    table_name text NOT NULL,
    command text NOT NULL,
    error text,
    created_on timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    started_on timestamp with time zone,
    completed_on timestamp with time zone
);


--
-- Name: instance; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.instance (
    id uuid NOT NULL,
    name text,
    host text NOT NULL,
    pid integer NOT NULL,
    version text NOT NULL,
    node_version text NOT NULL,
    application_name text,
    heartbeat_seconds integer NOT NULL,
    supervise boolean NOT NULL,
    schedule boolean NOT NULL,
    migrate boolean NOT NULL,
    persist_queue_stats boolean NOT NULL,
    persist_warnings boolean NOT NULL,
    pool_max integer,
    pool_total integer,
    pool_idle integer,
    pool_waiting integer,
    workers jsonb DEFAULT '[]'::jsonb NOT NULL,
    metrics jsonb,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    crash_restarts integer DEFAULT 0 NOT NULL,
    crash_restarts_since timestamp with time zone,
    started_on timestamp with time zone DEFAULT now() NOT NULL,
    heartbeat_on timestamp with time zone DEFAULT now() NOT NULL,
    stopped_on timestamp with time zone
);


--
-- Name: job; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.job (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    data jsonb,
    state pgboss.job_state DEFAULT 'created'::pgboss.job_state NOT NULL,
    retry_limit integer DEFAULT 2 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    retry_delay integer DEFAULT 0 NOT NULL,
    retry_backoff boolean DEFAULT false NOT NULL,
    retry_delay_max integer,
    expire_seconds integer DEFAULT 900 NOT NULL,
    deletion_seconds integer DEFAULT 604800 NOT NULL,
    singleton_key text,
    singleton_on timestamp without time zone,
    group_id text,
    group_tier text,
    start_after timestamp with time zone DEFAULT now() NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    started_on timestamp with time zone,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone DEFAULT (now() + '336:00:00'::interval) NOT NULL,
    output jsonb,
    dead_letter text,
    policy text,
    heartbeat_on timestamp with time zone,
    heartbeat_seconds integer,
    blocked boolean DEFAULT false NOT NULL,
    blocking boolean DEFAULT false NOT NULL,
    pending_dependencies integer DEFAULT 0 NOT NULL,
    source_name text,
    source_id uuid,
    source_created_on timestamp with time zone,
    source_retry_count integer,
    source_output jsonb,
    source_root_id uuid,
    trace_context jsonb,
    upsert_by_key boolean
)
PARTITION BY LIST (name);


--
-- Name: job_common; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.job_common (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT job_id_not_null NOT NULL,
    name text CONSTRAINT job_name_not_null NOT NULL,
    priority integer DEFAULT 0 CONSTRAINT job_priority_not_null NOT NULL,
    data jsonb,
    state pgboss.job_state DEFAULT 'created'::pgboss.job_state CONSTRAINT job_state_not_null NOT NULL,
    retry_limit integer DEFAULT 2 CONSTRAINT job_retry_limit_not_null NOT NULL,
    retry_count integer DEFAULT 0 CONSTRAINT job_retry_count_not_null NOT NULL,
    retry_delay integer DEFAULT 0 CONSTRAINT job_retry_delay_not_null NOT NULL,
    retry_backoff boolean DEFAULT false CONSTRAINT job_retry_backoff_not_null NOT NULL,
    retry_delay_max integer,
    expire_seconds integer DEFAULT 900 CONSTRAINT job_expire_seconds_not_null NOT NULL,
    deletion_seconds integer DEFAULT 604800 CONSTRAINT job_deletion_seconds_not_null NOT NULL,
    singleton_key text,
    singleton_on timestamp without time zone,
    group_id text,
    group_tier text,
    start_after timestamp with time zone DEFAULT now() CONSTRAINT job_start_after_not_null NOT NULL,
    created_on timestamp with time zone DEFAULT now() CONSTRAINT job_created_on_not_null NOT NULL,
    started_on timestamp with time zone,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone DEFAULT (now() + '336:00:00'::interval) CONSTRAINT job_keep_until_not_null NOT NULL,
    output jsonb,
    dead_letter text,
    policy text,
    heartbeat_on timestamp with time zone,
    heartbeat_seconds integer,
    blocked boolean DEFAULT false CONSTRAINT job_blocked_not_null NOT NULL,
    blocking boolean DEFAULT false CONSTRAINT job_blocking_not_null NOT NULL,
    pending_dependencies integer DEFAULT 0 CONSTRAINT job_pending_dependencies_not_null NOT NULL,
    source_name text,
    source_id uuid,
    source_created_on timestamp with time zone,
    source_retry_count integer,
    source_output jsonb,
    source_root_id uuid,
    trace_context jsonb,
    upsert_by_key boolean,
    CONSTRAINT job_key_strict_fifo_singleton_key_check CHECK ((NOT ((policy = 'key_strict_fifo'::text) AND (singleton_key IS NULL))))
);


--
-- Name: job_dependency; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.job_dependency (
    child_name text NOT NULL,
    child_id uuid NOT NULL,
    parent_name text NOT NULL,
    parent_id uuid NOT NULL
);


--
-- Name: queue; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.queue (
    name text NOT NULL,
    policy text NOT NULL,
    retry_limit integer NOT NULL,
    retry_delay integer NOT NULL,
    retry_backoff boolean NOT NULL,
    retry_delay_max integer,
    expire_seconds integer NOT NULL,
    retention_seconds integer NOT NULL,
    deletion_seconds integer NOT NULL,
    dead_letter text,
    partition boolean NOT NULL,
    table_name text NOT NULL,
    deferred_count integer DEFAULT 0 NOT NULL,
    blocked_count integer DEFAULT 0 NOT NULL,
    queued_count integer DEFAULT 0 NOT NULL,
    ready_count integer DEFAULT 0 NOT NULL,
    warning_queued integer DEFAULT 0 NOT NULL,
    active_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    total_count integer DEFAULT 0 NOT NULL,
    retained_count integer,
    retained_on timestamp with time zone,
    created_delta integer DEFAULT 0 NOT NULL,
    completed_delta integer DEFAULT 0 NOT NULL,
    failed_delta integer DEFAULT 0 NOT NULL,
    delta_on timestamp with time zone,
    delta_seconds integer,
    wait_bins integer[],
    run_bins integer[],
    ready_oldest_seconds integer,
    ready_history integer[] DEFAULT '{}'::integer[] NOT NULL,
    heartbeat_seconds integer,
    notify boolean DEFAULT false NOT NULL,
    singletons_active text[],
    monitor_claim_on timestamp with time zone,
    monitor_on timestamp with time zone,
    maintain_on timestamp with time zone,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    updated_on timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT queue_check CHECK ((dead_letter IS DISTINCT FROM name))
);


--
-- Name: queue_stats; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.queue_stats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    deferred_count integer DEFAULT 0 NOT NULL,
    queued_count integer DEFAULT 0 NOT NULL,
    ready_count integer DEFAULT 0 NOT NULL,
    active_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    total_count integer DEFAULT 0 NOT NULL,
    created_delta integer,
    completed_delta integer,
    failed_delta integer,
    delta_seconds integer,
    delta_on timestamp with time zone,
    wait_bins integer[],
    run_bins integer[],
    ready_oldest_seconds integer,
    captured_on timestamp with time zone DEFAULT now() NOT NULL
)
PARTITION BY RANGE (captured_on);


--
-- Name: queue_stats_20261120; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.queue_stats_20261120 (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT queue_stats_id_not_null NOT NULL,
    name text CONSTRAINT queue_stats_name_not_null NOT NULL,
    deferred_count integer DEFAULT 0 CONSTRAINT queue_stats_deferred_count_not_null NOT NULL,
    queued_count integer DEFAULT 0 CONSTRAINT queue_stats_queued_count_not_null NOT NULL,
    ready_count integer DEFAULT 0 CONSTRAINT queue_stats_ready_count_not_null NOT NULL,
    active_count integer DEFAULT 0 CONSTRAINT queue_stats_active_count_not_null NOT NULL,
    failed_count integer DEFAULT 0 CONSTRAINT queue_stats_failed_count_not_null NOT NULL,
    total_count integer DEFAULT 0 CONSTRAINT queue_stats_total_count_not_null NOT NULL,
    created_delta integer,
    completed_delta integer,
    failed_delta integer,
    delta_seconds integer,
    delta_on timestamp with time zone,
    wait_bins integer[],
    run_bins integer[],
    ready_oldest_seconds integer,
    captured_on timestamp with time zone DEFAULT now() CONSTRAINT queue_stats_captured_on_not_null NOT NULL
);


--
-- Name: queue_stats_20261121; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.queue_stats_20261121 (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT queue_stats_id_not_null NOT NULL,
    name text CONSTRAINT queue_stats_name_not_null NOT NULL,
    deferred_count integer DEFAULT 0 CONSTRAINT queue_stats_deferred_count_not_null NOT NULL,
    queued_count integer DEFAULT 0 CONSTRAINT queue_stats_queued_count_not_null NOT NULL,
    ready_count integer DEFAULT 0 CONSTRAINT queue_stats_ready_count_not_null NOT NULL,
    active_count integer DEFAULT 0 CONSTRAINT queue_stats_active_count_not_null NOT NULL,
    failed_count integer DEFAULT 0 CONSTRAINT queue_stats_failed_count_not_null NOT NULL,
    total_count integer DEFAULT 0 CONSTRAINT queue_stats_total_count_not_null NOT NULL,
    created_delta integer,
    completed_delta integer,
    failed_delta integer,
    delta_seconds integer,
    delta_on timestamp with time zone,
    wait_bins integer[],
    run_bins integer[],
    ready_oldest_seconds integer,
    captured_on timestamp with time zone DEFAULT now() CONSTRAINT queue_stats_captured_on_not_null NOT NULL
);


--
-- Name: schedule; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.schedule (
    name text NOT NULL,
    key text DEFAULT ''::text NOT NULL,
    kind text DEFAULT 'cron'::text NOT NULL,
    cron text NOT NULL,
    timezone text DEFAULT 'UTC'::text,
    data jsonb,
    options jsonb,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    updated_on timestamp with time zone DEFAULT now() NOT NULL,
    last_job_id uuid,
    CONSTRAINT schedule_kind_check CHECK ((kind = ANY (ARRAY['cron'::text, 'rrule'::text])))
);


--
-- Name: subscription; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.subscription (
    event text NOT NULL,
    name text NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    updated_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: version; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.version (
    version integer NOT NULL,
    cron_on timestamp with time zone,
    bam_on timestamp with time zone,
    flow_on timestamp with time zone,
    reindex_on timestamp with time zone,
    monitor_backoff_on timestamp with time zone
);


--
-- Name: warning; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.warning (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    type text NOT NULL,
    message text NOT NULL,
    data jsonb,
    created_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_chat_file_text; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_chat_file_text (
    file_id uuid NOT NULL,
    part integer NOT NULL,
    workspace_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    page integer,
    body text NOT NULL,
    CONSTRAINT agent_chat_file_text_part_check CHECK ((part >= 1))
);


--
-- Name: agent_chat_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_chat_messages (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    owner_user_id text NOT NULL,
    run_id uuid,
    key text NOT NULL,
    body text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    schedule jsonb,
    CONSTRAINT agent_chat_messages_body_check CHECK (((char_length(btrim(body)) >= 1) AND (char_length(btrim(body)) <= 100000))),
    CONSTRAINT agent_chat_messages_key_check CHECK (((char_length(key) >= 1) AND (char_length(key) <= 200)))
);


--
-- Name: agent_chat_reads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_chat_reads (
    agent_id uuid NOT NULL,
    read_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_command_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_command_receipts (
    connection_id uuid NOT NULL,
    client_command_id uuid NOT NULL,
    runtime_session_id uuid NOT NULL,
    binding_id uuid NOT NULL,
    binding_generation integer NOT NULL,
    fingerprint text NOT NULL,
    operation text NOT NULL,
    project_id uuid NOT NULL,
    value jsonb NOT NULL,
    postconditions jsonb NOT NULL,
    completed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_command_receipts_binding_generation_check CHECK ((binding_generation > 0)),
    CONSTRAINT agent_command_receipts_fingerprint_check CHECK ((length(fingerprint) = 64)),
    CONSTRAINT agent_command_receipts_postconditions_check CHECK ((jsonb_typeof(postconditions) = 'array'::text))
);


--
-- Name: agent_connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_connections (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    owner_user_id text NOT NULL,
    agent_id uuid NOT NULL,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name text DEFAULT 'External connection'::text NOT NULL,
    client_designation text DEFAULT 'other'::text NOT NULL,
    compute_source text DEFAULT 'user_operated_external_client'::text NOT NULL,
    may_do text DEFAULT 'act'::text NOT NULL,
    CONSTRAINT agent_connections_client_designation_check CHECK ((client_designation = ANY (ARRAY['claude_code'::text, 'codex'::text, 'other'::text]))),
    CONSTRAINT agent_connections_compute_source_check CHECK ((compute_source = ANY (ARRAY['user_operated_claude_code'::text, 'user_operated_external_client'::text, 'owner_assistant'::text]))),
    CONSTRAINT agent_connections_may_do_check CHECK ((may_do = ANY (ARRAY['act'::text, 'ask'::text]))),
    CONSTRAINT agent_connections_name_check CHECK (((length(btrim(name)) >= 1) AND (length(btrim(name)) <= 120)))
);


--
-- Name: agent_memory_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_memory_items (
    id uuid NOT NULL,
    agent_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    owner_user_id text NOT NULL,
    body text NOT NULL,
    source text DEFAULT 'Added by you'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_memory_items_body_check CHECK (((char_length(body) >= 1) AND (char_length(body) <= 500))),
    CONSTRAINT agent_memory_items_source_check CHECK (((char_length(source) >= 1) AND (char_length(source) <= 160)))
);


--
-- Name: agent_oauth_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_oauth_bindings (
    id uuid NOT NULL,
    owner_user_id text NOT NULL,
    connection_id uuid NOT NULL,
    client_id text NOT NULL,
    generation integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    auth_method text,
    auth_idp_sid text,
    auth_confirmed_at timestamp with time zone,
    CONSTRAINT agent_oauth_bindings_auth_idp_sid_check CHECK (((auth_idp_sid IS NULL) OR ((length(auth_idp_sid) >= 1) AND (length(auth_idp_sid) <= 512)))),
    CONSTRAINT agent_oauth_bindings_auth_method_check CHECK (((auth_method IS NULL) OR ((length(auth_method) >= 1) AND (length(auth_method) <= 200)))),
    CONSTRAINT agent_oauth_bindings_generation_check CHECK ((generation > 0))
);


--
-- Name: agent_playbook_acknowledgments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_playbook_acknowledgments (
    runtime_session_id uuid NOT NULL,
    bundle_id text NOT NULL,
    version text NOT NULL,
    digest text NOT NULL,
    acknowledged_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_playbook_acknowledgments_bundle_id_check CHECK ((bundle_id ~ '^[a-z][a-z0-9.-]{0,63}$'::text)),
    CONSTRAINT agent_playbook_acknowledgments_digest_check CHECK ((digest ~ '^sha256:[0-9a-f]{64}$'::text)),
    CONSTRAINT agent_playbook_acknowledgments_version_check CHECK ((version ~ '^[0-9]{1,4}\.[0-9]{1,4}\.[0-9]{1,4}$'::text))
);


--
-- Name: agent_proposals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_proposals (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    owner_user_id text NOT NULL,
    compute_source text NOT NULL,
    source_material_id uuid NOT NULL,
    source_material_version integer NOT NULL,
    client_command_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    fact text NOT NULL,
    interpretation text NOT NULL,
    suggested_action text NOT NULL,
    status text DEFAULT 'proposed'::text NOT NULL,
    dismissed_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_proposals_compute_source_check CHECK ((compute_source = ANY (ARRAY['user_operated_claude_code'::text, 'user_operated_external_client'::text, 'owner_assistant'::text]))),
    CONSTRAINT agent_proposals_fact_check CHECK (((length(btrim(fact)) >= 1) AND (length(btrim(fact)) <= 10000))),
    CONSTRAINT agent_proposals_interpretation_check CHECK (((length(btrim(interpretation)) >= 1) AND (length(btrim(interpretation)) <= 10000))),
    CONSTRAINT agent_proposals_source_material_version_check CHECK ((source_material_version > 0)),
    CONSTRAINT agent_proposals_status_check CHECK ((status = ANY (ARRAY['proposed'::text, 'dismissed'::text]))),
    CONSTRAINT agent_proposals_suggested_action_check CHECK (((length(btrim(suggested_action)) >= 1) AND (length(btrim(suggested_action)) <= 10000)))
);


--
-- Name: agent_questions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_questions (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    conversation_id uuid NOT NULL,
    message_id uuid NOT NULL,
    task_id uuid,
    agent_id uuid NOT NULL,
    asked_user_id text NOT NULL,
    question text NOT NULL,
    options jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    answered_option integer,
    answer_text text,
    answered_by text,
    answer_message_id uuid,
    answered_at timestamp with time zone,
    CONSTRAINT agent_questions_answer_text_check CHECK (((char_length(answer_text) >= 1) AND (char_length(answer_text) <= 2000))),
    CONSTRAINT agent_questions_answered_option_check CHECK (((answered_option >= 0) AND (answered_option <= 3))),
    CONSTRAINT agent_questions_check CHECK (((answered_at IS NULL) = (answer_text IS NULL))),
    CONSTRAINT agent_questions_check1 CHECK (((answered_option IS NULL) OR (answered_at IS NOT NULL))),
    CONSTRAINT agent_questions_options_check CHECK (((jsonb_typeof(options) = 'array'::text) AND ((jsonb_array_length(options) >= 2) AND (jsonb_array_length(options) <= 4)))),
    CONSTRAINT agent_questions_question_check CHECK (((char_length(question) >= 1) AND (char_length(question) <= 2000)))
);


--
-- Name: agent_runtime_auth_admission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_auth_admission (
    singleton boolean DEFAULT true NOT NULL,
    blocked boolean DEFAULT false NOT NULL,
    purge_id uuid,
    changed_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT agent_runtime_auth_admission_check CHECK ((blocked = (purge_id IS NOT NULL))),
    CONSTRAINT agent_runtime_auth_admission_singleton_check CHECK (singleton)
);


--
-- Name: agent_runtime_auth_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_auth_operations (
    binding_id uuid NOT NULL,
    client text NOT NULL,
    owner_user_id text NOT NULL,
    operation_id uuid NOT NULL,
    revision integer NOT NULL,
    boot_id uuid NOT NULL,
    actor_digest text NOT NULL,
    kind text NOT NULL,
    phase text NOT NULL,
    claimed_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    lease_ends_at timestamp with time zone NOT NULL,
    hard_ends_at timestamp with time zone NOT NULL,
    settled_at timestamp with time zone,
    CONSTRAINT agent_runtime_auth_operations_actor_digest_check CHECK ((actor_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT agent_runtime_auth_operations_check CHECK (((claimed_at < lease_ends_at) AND (lease_ends_at <= hard_ends_at))),
    CONSTRAINT agent_runtime_auth_operations_check1 CHECK (((phase = 'settled'::text) = (settled_at IS NOT NULL))),
    CONSTRAINT agent_runtime_auth_operations_client_check CHECK ((client = ANY (ARRAY['claude_code'::text, 'codex'::text]))),
    CONSTRAINT agent_runtime_auth_operations_kind_check CHECK ((kind = ANY (ARRAY['check'::text, 'logout'::text, 'console'::text]))),
    CONSTRAINT agent_runtime_auth_operations_operation_id_check CHECK (((operation_id)::text ~ '^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'::text)),
    CONSTRAINT agent_runtime_auth_operations_phase_check CHECK ((phase = ANY (ARRAY['active'::text, 'settled'::text, 'uncertain'::text]))),
    CONSTRAINT agent_runtime_auth_operations_revision_check CHECK ((revision > 0))
);


--
-- Name: agent_runtime_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_bindings (
    id uuid NOT NULL,
    owner_user_id text NOT NULL,
    slot text NOT NULL,
    state text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone,
    release_reason text,
    release_requested_at timestamp with time zone,
    released_at timestamp with time zone,
    release_logout_failed boolean,
    CONSTRAINT agent_runtime_bindings_id_check CHECK (((id)::text ~ '^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'::text)),
    CONSTRAINT agent_runtime_bindings_release_check CHECK ((((state = ANY (ARRAY['releasing'::text, 'released'::text])) = (release_reason IS NOT NULL)) AND ((release_reason IS NULL) = (release_requested_at IS NULL)) AND ((state = 'released'::text) = (released_at IS NOT NULL)) AND ((state = 'released'::text) OR (release_logout_failed IS NULL)))),
    CONSTRAINT agent_runtime_bindings_release_reason_check CHECK ((release_reason = ANY (ARRAY['owner'::text, 'operator'::text, 'idle'::text, 'purge'::text, 'bind_failed'::text, 'auth_recovery'::text]))),
    CONSTRAINT agent_runtime_bindings_state_check CHECK ((state = ANY (ARRAY['binding'::text, 'active'::text, 'sign_in_again'::text, 'releasing'::text, 'released'::text])))
);


--
-- Name: agent_runtime_client_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_client_history (
    binding_id uuid NOT NULL,
    client text NOT NULL,
    first_login_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    login_possible boolean DEFAULT true NOT NULL,
    changed_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT agent_runtime_client_history_client_check CHECK ((client = ANY (ARRAY['claude_code'::text, 'codex'::text])))
);


--
-- Name: agent_runtime_connection_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_connection_models (
    connection_id uuid NOT NULL,
    model_id text NOT NULL,
    "position" smallint NOT NULL,
    name text NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    sees_pictures boolean DEFAULT true NOT NULL,
    retired boolean DEFAULT false NOT NULL,
    CONSTRAINT agent_runtime_connection_models_model_id_check CHECK ((model_id ~ '^[a-z0-9][a-z0-9.-]{0,63}$'::text)),
    CONSTRAINT agent_runtime_connection_models_name_check CHECK (((length(name) >= 1) AND (length(name) <= 80))),
    CONSTRAINT agent_runtime_connection_models_note_check CHECK ((length(note) <= 200)),
    CONSTRAINT agent_runtime_connection_models_position_check CHECK (("position" >= 0))
);


--
-- Name: agent_runtime_connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_connections (
    id uuid NOT NULL,
    owner_user_id text NOT NULL,
    binding_id uuid NOT NULL,
    transport text DEFAULT 'runtime'::text NOT NULL,
    client text NOT NULL,
    state text NOT NULL,
    sign_in_method text,
    auth_method text,
    plan_label text,
    account_label text,
    signed_in_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    account_fingerprint text,
    previous_account_label text,
    account_changed_at timestamp with time zone,
    signed_out_at timestamp with time zone,
    sign_out_failed boolean,
    usage_left_percent smallint,
    usage_window text,
    usage_resets_at timestamp with time zone,
    usage_limit_reached boolean DEFAULT false NOT NULL,
    usage_read_at timestamp with time zone,
    models_status text,
    models_checked_at timestamp with time zone,
    CONSTRAINT agent_runtime_connections_account_label_check CHECK ((account_label ~ '^[A-Za-z0-9*]\*\*\*@[A-Za-z0-9.*-]{1,70}$'::text)),
    CONSTRAINT agent_runtime_connections_auth_method_check CHECK ((auth_method ~ '^[a-z][a-z0-9_.-]{0,31}$'::text)),
    CONSTRAINT agent_runtime_connections_client_check CHECK ((client = ANY (ARRAY['claude_code'::text, 'codex'::text]))),
    CONSTRAINT agent_runtime_connections_codex_method_check CHECK (((client <> 'codex'::text) OR (sign_in_method IS NULL) OR (sign_in_method = ANY (ARRAY['device_code'::text, 'api_key'::text, 'access_token'::text])))),
    CONSTRAINT agent_runtime_connections_fingerprint_check CHECK ((account_fingerprint ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT agent_runtime_connections_method_check CHECK (((client <> 'claude_code'::text) OR (sign_in_method IS NULL) OR (sign_in_method = ANY (ARRAY['claude_account'::text, 'console'::text, 'sso'::text])))),
    CONSTRAINT agent_runtime_connections_models_status_check CHECK ((models_status = ANY (ARRAY['listed'::text, 'unavailable'::text]))),
    CONSTRAINT agent_runtime_connections_notice_check CHECK (((account_changed_at IS NOT NULL) OR (previous_account_label IS NULL))),
    CONSTRAINT agent_runtime_connections_plan_label_check CHECK (((length(plan_label) <= 40) AND (plan_label ~ '^[A-Za-z0-9][A-Za-z0-9 ._+-]*$'::text))),
    CONSTRAINT agent_runtime_connections_previous_label_check CHECK ((previous_account_label ~ '^[A-Za-z0-9*]\*\*\*@[A-Za-z0-9.*-]{1,70}$'::text)),
    CONSTRAINT agent_runtime_connections_revoked_check CHECK (((revoked_at IS NULL) OR (state <> 'signed_in'::text))),
    CONSTRAINT agent_runtime_connections_sign_in_method_check CHECK ((sign_in_method = ANY (ARRAY['claude_account'::text, 'console'::text, 'sso'::text, 'device_code'::text, 'api_key'::text, 'access_token'::text]))),
    CONSTRAINT agent_runtime_connections_sign_out_check CHECK (((signed_out_at IS NULL) = (sign_out_failed IS NULL))),
    CONSTRAINT agent_runtime_connections_signed_in_check CHECK (((state = 'signed_in'::text) = (signed_in_at IS NOT NULL))),
    CONSTRAINT agent_runtime_connections_state_check CHECK ((state = ANY (ARRAY['signed_out'::text, 'signed_in'::text, 'sign_in_again'::text]))),
    CONSTRAINT agent_runtime_connections_transport_check CHECK ((transport = 'runtime'::text)),
    CONSTRAINT agent_runtime_connections_usage_left_percent_check CHECK (((usage_left_percent >= 0) AND (usage_left_percent <= 100))),
    CONSTRAINT agent_runtime_connections_usage_window_check CHECK ((usage_window = ANY (ARRAY['five_hour'::text, 'weekly'::text])))
);


--
-- Name: agent_runtime_console_nonces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_console_nonces (
    nonce_digest text NOT NULL,
    owner_user_id text NOT NULL,
    actor_digest text NOT NULL,
    operation_id uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT agent_runtime_console_nonces_actor_digest_check CHECK ((actor_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT agent_runtime_console_nonces_check CHECK ((consumed_at < expires_at)),
    CONSTRAINT agent_runtime_console_nonces_nonce_digest_check CHECK ((nonce_digest ~ '^[0-9a-f]{64}$'::text))
);


--
-- Name: agent_runtime_operator_statements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_operator_statements (
    statement text NOT NULL,
    agreed_on date NOT NULL,
    recorded_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_runtime_operator_statements_agreed_on_check CHECK ((agreed_on >= '2023-01-01'::date)),
    CONSTRAINT agent_runtime_operator_statements_statement_check CHECK ((statement = 'anthropic_commercial_terms'::text))
);


--
-- Name: agent_runtime_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_sessions (
    id uuid NOT NULL,
    binding_id uuid NOT NULL,
    binding_generation integer NOT NULL,
    client_session_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    connection_id uuid NOT NULL,
    owner_user_id text NOT NULL,
    agent_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT agent_runtime_sessions_binding_generation_check CHECK ((binding_generation > 0))
);


--
-- Name: agent_runtime_slots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_slots (
    slot text NOT NULL,
    state text NOT NULL,
    boot_id uuid,
    out_of_pool_reason text,
    reported_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    capacity smallint,
    CONSTRAINT agent_runtime_slots_capacity_check CHECK (((capacity IS NULL) OR (capacity >= 1))),
    CONSTRAINT agent_runtime_slots_out_of_pool_check CHECK (((state = 'out_of_pool'::text) = (out_of_pool_reason IS NOT NULL))),
    CONSTRAINT agent_runtime_slots_out_of_pool_reason_check CHECK ((out_of_pool_reason = ANY (ARRAY['data_not_empty'::text, 'missing'::text]))),
    CONSTRAINT agent_runtime_slots_slot_check CHECK ((slot ~ '^runtime-[1-9][0-9]{0,2}$'::text)),
    CONSTRAINT agent_runtime_slots_state_check CHECK ((state = ANY (ARRAY['unknown'::text, 'ready'::text, 'out_of_pool'::text])))
);


--
-- Name: agent_stops; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_stops (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    task_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    stopped_by text NOT NULL,
    units_stopped integer NOT NULL,
    stopped_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_stops_units_stopped_check CHECK ((units_stopped >= 0))
);


--
-- Name: agent_task_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_task_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    kind text NOT NULL,
    work_id uuid NOT NULL,
    run_id uuid,
    owner_user_id text,
    owner_agent_id uuid,
    by_kind text,
    by_id text,
    attempts smallint DEFAULT 0 NOT NULL,
    next_try_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    handled_at timestamp with time zone,
    CONSTRAINT agent_task_events_kind_check CHECK ((kind = ANY (ARRAY['assigned'::text, 'started'::text, 'finished'::text, 'released'::text]))),
    CONSTRAINT agent_task_events_owner_check CHECK ((num_nonnulls(owner_user_id, owner_agent_id) <= 1)),
    CONSTRAINT agent_task_events_shape_check CHECK (((kind = ANY (ARRAY['started'::text, 'finished'::text])) = (run_id IS NOT NULL)))
);


--
-- Name: agent_task_taking; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_task_taking (
    owner_user_id text NOT NULL,
    agent_id uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_thread_guard_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agent_thread_guard_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agents (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    name text NOT NULL,
    owner_user_id text NOT NULL,
    created_by text NOT NULL,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agents_name_check CHECK (((length(btrim(name)) >= 1) AND (length(btrim(name)) <= 200)))
);


--
-- Name: ai_price_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_price_lists (
    list text NOT NULL,
    fetched_on date NOT NULL,
    source text NOT NULL,
    prices jsonb NOT NULL,
    stored_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ai_price_lists_list_check CHECK ((list = ANY (ARRAY['litellm'::text, 'openrouter'::text]))),
    CONSTRAINT ai_price_lists_prices_check CHECK ((jsonb_typeof(prices) = 'object'::text)),
    CONSTRAINT ai_price_lists_source_check CHECK (((char_length(source) >= 1) AND (char_length(source) <= 2048)))
);


--
-- Name: api_key_checks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_key_checks (
    id uuid NOT NULL,
    connection_id uuid NOT NULL,
    model text NOT NULL,
    checked_at timestamp with time zone DEFAULT now() NOT NULL,
    charged_micros bigint NOT NULL,
    calls_tools boolean NOT NULL,
    CONSTRAINT api_key_checks_charged_micros_check CHECK ((charged_micros >= 0)),
    CONSTRAINT api_key_checks_model_check CHECK ((model ~ '^[A-Za-z0-9][A-Za-z0-9._:/@+-]{0,199}$'::text))
);


--
-- Name: assistant_background_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assistant_background_notes (
    owner_user_id text NOT NULL,
    account_key text NOT NULL,
    note_version text NOT NULL,
    accepted_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT assistant_background_notes_account_key_check CHECK (((char_length(account_key) >= 1) AND (char_length(account_key) <= 100))),
    CONSTRAINT assistant_background_notes_note_version_check CHECK (((char_length(note_version) >= 1) AND (char_length(note_version) <= 64)))
);


--
-- Name: assistant_changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assistant_changes (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    run_id uuid,
    owner_user_id text NOT NULL,
    agent_id uuid NOT NULL,
    client_command_id uuid NOT NULL,
    fingerprint text NOT NULL,
    tool text NOT NULL,
    operation text NOT NULL,
    object_type text NOT NULL,
    object_id uuid,
    object_title text DEFAULT ''::text NOT NULL,
    state text NOT NULL,
    wait_reason text,
    authority text,
    prepared_command jsonb,
    before_version integer,
    after_version integer,
    receipt jsonb,
    refusal text,
    other_user_id text,
    decided_by text,
    decided_at timestamp with time zone,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    connection_id uuid,
    conversation_id uuid,
    told_user_id text,
    scope_id uuid,
    CONSTRAINT assistant_changes_after_version_check CHECK ((after_version > 0)),
    CONSTRAINT assistant_changes_after_wait_check CHECK (((state <> 'applied_after_wait'::text) OR (authority = 'owner_approval'::text))),
    CONSTRAINT assistant_changes_applied_authority_check CHECK (((state <> 'applied'::text) OR (authority = 'owner_request'::text))),
    CONSTRAINT assistant_changes_applied_check CHECK (((state <> ALL (ARRAY['applied'::text, 'applied_after_wait'::text, 'undone'::text])) OR ((authority IS NOT NULL) AND (receipt IS NOT NULL)))),
    CONSTRAINT assistant_changes_authority_check CHECK ((authority = ANY (ARRAY['owner_request'::text, 'owner_approval'::text]))),
    CONSTRAINT assistant_changes_before_version_check CHECK ((before_version > 0)),
    CONSTRAINT assistant_changes_decided_check CHECK (((decided_at IS NULL) = (decided_by IS NULL))),
    CONSTRAINT assistant_changes_fingerprint_check CHECK ((fingerprint ~ '^[a-f0-9]{64}$'::text)),
    CONSTRAINT assistant_changes_object_title_check CHECK ((char_length(object_title) <= 300)),
    CONSTRAINT assistant_changes_object_type_check CHECK ((object_type = ANY (ARRAY['work'::text, 'doc'::text, 'map'::text, 'thought'::text, 'link'::text, 'message'::text, 'decision'::text, 'picture'::text, 'file'::text]))),
    CONSTRAINT assistant_changes_operation_check CHECK (((char_length(operation) >= 1) AND (char_length(operation) <= 60))),
    CONSTRAINT assistant_changes_prepared_check CHECK (((state <> 'waiting'::text) OR (prepared_command IS NOT NULL))),
    CONSTRAINT assistant_changes_prepared_command_check CHECK (((prepared_command IS NULL) OR ((jsonb_typeof(prepared_command) = 'object'::text) AND (octet_length((prepared_command)::text) <= 65536)))),
    CONSTRAINT assistant_changes_receipt_check CHECK (((receipt IS NULL) OR ((jsonb_typeof(receipt) = 'object'::text) AND (octet_length((receipt)::text) <= 65536)))),
    CONSTRAINT assistant_changes_refusal_check CHECK (((refusal IS NULL) OR (char_length(refusal) <= 500))),
    CONSTRAINT assistant_changes_source_check CHECK ((num_nonnulls(run_id, connection_id) = 1)),
    CONSTRAINT assistant_changes_state_check CHECK ((state = ANY (ARRAY['applied'::text, 'waiting'::text, 'applied_after_wait'::text, 'skipped'::text, 'undone'::text, 'refused'::text]))),
    CONSTRAINT assistant_changes_tool_check CHECK ((tool ~ '^flux_[a-z_]{1,60}$'::text)),
    CONSTRAINT assistant_changes_version_check CHECK ((version > 0)),
    CONSTRAINT assistant_changes_wait_reason_check CHECK ((wait_reason = ANY (ARRAY['ask'::text, 'removal'::text, 'others'::text, 'tells'::text]))),
    CONSTRAINT assistant_changes_waiting_check CHECK (((state = 'waiting'::text) = (wait_reason IS NOT NULL)))
);


--
-- Name: assistant_job_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assistant_job_runs (
    id uuid NOT NULL,
    job_id uuid NOT NULL,
    owner_user_id text NOT NULL,
    fired_at timestamp with time zone NOT NULL,
    fired_by text NOT NULL,
    run_id uuid,
    state text NOT NULL,
    result_line text DEFAULT ''::text NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    CONSTRAINT assistant_job_runs_finished_check CHECK (((state = 'running'::text) = (finished_at IS NULL))),
    CONSTRAINT assistant_job_runs_fired_by_check CHECK ((fired_by = ANY (ARRAY['schedule'::text, 'now'::text]))),
    CONSTRAINT assistant_job_runs_result_line_check CHECK ((char_length(result_line) <= 300)),
    CONSTRAINT assistant_job_runs_state_check CHECK ((state = ANY (ARRAY['running'::text, 'done'::text, 'skipped'::text, 'failed'::text])))
);


--
-- Name: assistant_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assistant_jobs (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    owner_user_id text NOT NULL,
    title text NOT NULL,
    text text NOT NULL,
    schedule_kind text NOT NULL,
    schedule jsonb NOT NULL,
    time_zone text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    prepared boolean DEFAULT false NOT NULL,
    prepared_run_id uuid,
    next_run_at timestamp with time zone,
    last_run_at timestamp with time zone,
    deleted_at timestamp with time zone,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    agent_id uuid NOT NULL,
    CONSTRAINT assistant_jobs_due_check CHECK (((next_run_at IS NULL) OR enabled)),
    CONSTRAINT assistant_jobs_schedule_check CHECK (((jsonb_typeof(schedule) = 'object'::text) AND (octet_length((schedule)::text) <= 1000))),
    CONSTRAINT assistant_jobs_schedule_kind_check CHECK ((schedule_kind = ANY (ARRAY['daily'::text, 'weekdays'::text, 'weekly'::text, 'hourly'::text, 'cron'::text, 'once'::text]))),
    CONSTRAINT assistant_jobs_text_check CHECK (((char_length(text) >= 1) AND (char_length(text) <= 4000))),
    CONSTRAINT assistant_jobs_time_zone_check CHECK (((char_length(time_zone) >= 1) AND (char_length(time_zone) <= 64))),
    CONSTRAINT assistant_jobs_title_check CHECK (((char_length(title) >= 1) AND (char_length(title) <= 60))),
    CONSTRAINT assistant_jobs_version_check CHECK ((version > 0))
);


--
-- Name: assistant_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assistant_settings (
    workspace_id uuid NOT NULL,
    owner_user_id text NOT NULL,
    agent_id uuid NOT NULL,
    connection_id uuid NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    instructions text DEFAULT ''::text NOT NULL,
    colour text DEFAULT 'ink'::text NOT NULL,
    engine text NOT NULL,
    api_key_id uuid,
    provider text NOT NULL,
    model text,
    CONSTRAINT assistant_settings_colour_check CHECK ((colour = ANY (ARRAY['ink'::text, 'clay'::text, 'ochre'::text, 'sage'::text, 'teal'::text, 'indigo'::text, 'plum'::text, 'rose'::text]))),
    CONSTRAINT assistant_settings_engine_check CHECK ((engine = ANY (ARRAY['server'::text, 'runtime'::text]))),
    CONSTRAINT assistant_settings_instructions_check CHECK ((char_length(instructions) <= 4000)),
    CONSTRAINT assistant_settings_key_check CHECK (((engine = 'server'::text) = (api_key_id IS NOT NULL))),
    CONSTRAINT assistant_settings_model_check CHECK (((model IS NULL) OR (model ~ '^[A-Za-z0-9][A-Za-z0-9._:/@+-]{0,199}$'::text))),
    CONSTRAINT assistant_settings_provider_check CHECK ((provider = ANY (ARRAY['anthropic'::text, 'openai'::text, 'openrouter'::text, 'gemini'::text, 'openai_compatible'::text]))),
    CONSTRAINT assistant_settings_version_check CHECK ((version > 0))
);


--
-- Name: auth_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_accounts (
    id text NOT NULL,
    user_id text NOT NULL,
    account_id text NOT NULL,
    provider_id text NOT NULL,
    access_token text,
    refresh_token text,
    id_token text,
    access_token_expires_at timestamp with time zone,
    refresh_token_expires_at timestamp with time zone,
    scope text,
    password text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    confirmed_at timestamp with time zone,
    password_version integer DEFAULT 0 NOT NULL,
    password_version_expected integer
);


--
-- Name: auth_email_claims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_email_claims (
    id text NOT NULL,
    token_hash text NOT NULL,
    provider_id text NOT NULL,
    subject text NOT NULL,
    email text NOT NULL,
    held_by text NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    claimed_at timestamp with time zone,
    released_email text,
    CONSTRAINT auth_email_claims_provider_id_check CHECK (((length(provider_id) >= 1) AND (length(provider_id) <= 200))),
    CONSTRAINT auth_email_claims_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'claimed'::text]))),
    CONSTRAINT auth_email_claims_subject_check CHECK (((length(subject) >= 1) AND (length(subject) <= 512)))
);


--
-- Name: auth_identity_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_identity_audit (
    id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    action text NOT NULL,
    user_id text NOT NULL,
    provider_id text NOT NULL,
    old_subject text,
    new_subject text,
    actor text NOT NULL,
    reason text NOT NULL,
    mode text NOT NULL,
    old_issuer text,
    new_issuer text,
    CONSTRAINT auth_identity_audit_action_check CHECK ((action = ANY (ARRAY['rekey'::text, 'unlink'::text]))),
    CONSTRAINT auth_identity_audit_actor_check CHECK (((length(actor) >= 1) AND (length(actor) <= 200))),
    CONSTRAINT auth_identity_audit_mode_check CHECK ((mode = ANY (ARRAY['prepare'::text, 'sso'::text]))),
    CONSTRAINT auth_identity_audit_new_issuer_check CHECK (((new_issuer IS NULL) OR ((length(new_issuer) >= 1) AND (length(new_issuer) <= 2000)))),
    CONSTRAINT auth_identity_audit_old_issuer_check CHECK (((old_issuer IS NULL) OR ((length(old_issuer) >= 1) AND (length(old_issuer) <= 2000)))),
    CONSTRAINT auth_identity_audit_provider_id_check CHECK (((length(provider_id) >= 1) AND (length(provider_id) <= 200))),
    CONSTRAINT auth_identity_audit_reason_check CHECK (((length(reason) >= 1) AND (length(reason) <= 500)))
);


--
-- Name: auth_idp_standing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_idp_standing (
    user_id text NOT NULL,
    provider_id text NOT NULL,
    state text DEFAULT 'ok'::text NOT NULL,
    reason text,
    refresh_token_enc text,
    confirmed_at timestamp with time zone,
    state_changed_at timestamp with time zone DEFAULT now() NOT NULL,
    last_check_at timestamp with time zone,
    last_outcome text,
    next_check_at timestamp with time zone DEFAULT now() NOT NULL,
    lease_id text,
    lease_until timestamp with time zone,
    refresh_token_sid text,
    CONSTRAINT auth_idp_standing_last_outcome_check CHECK (((last_outcome IS NULL) OR (last_outcome = ANY (ARRAY['success'::text, 'sign_in_required'::text, 'unknown'::text])))),
    CONSTRAINT auth_idp_standing_provider_id_check CHECK (((length(provider_id) >= 1) AND (length(provider_id) <= 200))),
    CONSTRAINT auth_idp_standing_reason_check CHECK (((reason IS NULL) OR (length(reason) <= 100))),
    CONSTRAINT auth_idp_standing_refresh_token_enc_check CHECK (((refresh_token_enc IS NULL) OR (length(refresh_token_enc) <= 16384))),
    CONSTRAINT auth_idp_standing_refresh_token_sid_check CHECK (((refresh_token_sid IS NULL) OR ((length(refresh_token_sid) >= 1) AND (length(refresh_token_sid) <= 512)))),
    CONSTRAINT auth_idp_standing_state_check CHECK ((state = ANY (ARRAY['ok'::text, 'sign_in_required'::text])))
);


--
-- Name: auth_link_intents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_link_intents (
    id text NOT NULL,
    token_hash text NOT NULL,
    user_id text NOT NULL,
    session_id text NOT NULL,
    provider_id text NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    CONSTRAINT auth_link_intents_provider_id_check CHECK (((length(provider_id) >= 1) AND (length(provider_id) <= 200))),
    CONSTRAINT auth_link_intents_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'used'::text])))
);


--
-- Name: auth_logout_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_logout_tokens (
    provider_id text NOT NULL,
    jti text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT auth_logout_tokens_jti_check CHECK (((length(jti) >= 1) AND (length(jti) <= 512))),
    CONSTRAINT auth_logout_tokens_provider_id_check CHECK (((length(provider_id) >= 1) AND (length(provider_id) <= 200)))
);


--
-- Name: auth_rate_limits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_rate_limits (
    id text NOT NULL,
    key text NOT NULL,
    count integer NOT NULL,
    last_request bigint NOT NULL
);


--
-- Name: auth_session_identities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_session_identities (
    session_id text NOT NULL,
    method text NOT NULL,
    idp_sid text,
    confirmed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT auth_session_identities_idp_sid_check CHECK (((idp_sid IS NULL) OR ((length(idp_sid) >= 1) AND (length(idp_sid) <= 512)))),
    CONSTRAINT auth_session_identities_method_check CHECK (((length(method) >= 1) AND (length(method) <= 200)))
);


--
-- Name: auth_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_sessions (
    id text NOT NULL,
    user_id text NOT NULL,
    token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    ip_address text,
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    password_version_checked integer
);


--
-- Name: auth_sign_in_throttle; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_sign_in_throttle (
    account_hash text NOT NULL,
    failures integer NOT NULL,
    last_failure_at timestamp with time zone NOT NULL,
    locked_until timestamp with time zone
);


--
-- Name: auth_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_users (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    email_verified boolean DEFAULT false NOT NULL,
    image text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    device_generation integer DEFAULT 0 NOT NULL,
    time_zone text DEFAULT 'UTC'::text NOT NULL,
    last_active_at timestamp with time zone,
    show_last_active boolean DEFAULT true NOT NULL,
    first_steps_hidden_at timestamp with time zone
);


--
-- Name: auth_verifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_verifications (
    id text NOT NULL,
    identifier text NOT NULL,
    value text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: background_compute_connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.background_compute_connections (
    id uuid NOT NULL,
    owner_user_id text NOT NULL,
    provider text NOT NULL,
    model text NOT NULL,
    encrypted_key text,
    key_last_four text NOT NULL,
    key_fingerprint text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    base_url text,
    input_price_micros_per_mtok integer,
    output_price_micros_per_mtok integer,
    price_source text,
    price_checked_on date,
    name text NOT NULL,
    daily_budget_cents integer NOT NULL,
    time_zone text DEFAULT 'UTC'::text NOT NULL,
    listed_models jsonb,
    models_listed_at timestamp with time zone,
    models_checked_at timestamp with time zone,
    models_list_status text,
    model_prices jsonb DEFAULT '{}'::jsonb NOT NULL,
    retired_models text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT background_compute_connectio_output_price_micros_per_mtok_check CHECK (((output_price_micros_per_mtok >= 0) AND (output_price_micros_per_mtok <= 1000000000))),
    CONSTRAINT background_compute_connection_input_price_micros_per_mtok_check CHECK (((input_price_micros_per_mtok >= 0) AND (input_price_micros_per_mtok <= 1000000000))),
    CONSTRAINT background_compute_connections_base_url_check CHECK ((((provider = 'openai_compatible'::text) = (base_url IS NOT NULL)) AND ((base_url IS NULL) OR ((length(base_url) <= 2048) AND (base_url ~ '^https?://[^[:space:]@?#]+$'::text))))),
    CONSTRAINT background_compute_connections_check1 CHECK (((encrypted_key IS NOT NULL) = (revoked_at IS NULL))),
    CONSTRAINT background_compute_connections_daily_budget_cents_check CHECK (((daily_budget_cents >= 10) AND (daily_budget_cents <= 100000))),
    CONSTRAINT background_compute_connections_key_fingerprint_check CHECK ((length(key_fingerprint) = 16)),
    CONSTRAINT background_compute_connections_key_last_four_check CHECK ((length(key_last_four) = 4)),
    CONSTRAINT background_compute_connections_model_check CHECK ((model ~ '^[A-Za-z0-9][A-Za-z0-9._:/@+-]{0,199}$'::text)),
    CONSTRAINT background_compute_connections_models_list_status_check CHECK (((models_list_status IS NULL) OR (models_list_status = ANY (ARRAY['listed'::text, 'key_refused'::text, 'unavailable'::text, 'refused'::text])))),
    CONSTRAINT background_compute_connections_name_check CHECK ((((length(btrim(name)) >= 1) AND (length(btrim(name)) <= 80)) AND (name = btrim(name)))),
    CONSTRAINT background_compute_connections_price_check CHECK ((((input_price_micros_per_mtok IS NULL) = (price_source IS NULL)) AND ((output_price_micros_per_mtok IS NULL) = (price_source IS NULL)) AND ((price_checked_on IS NULL) = ((price_source IS NULL) OR (price_source = 'owner'::text))))),
    CONSTRAINT background_compute_connections_price_source_check CHECK ((price_source = ANY (ARRAY['list'::text, 'owner'::text]))),
    CONSTRAINT background_compute_connections_provider_check CHECK ((provider = ANY (ARRAY['anthropic'::text, 'openai'::text, 'openrouter'::text, 'gemini'::text, 'openai_compatible'::text]))),
    CONSTRAINT background_compute_connections_time_zone_check CHECK (((length(time_zone) >= 1) AND (length(time_zone) <= 64)))
);


--
-- Name: cowork_checkpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cowork_checkpoints (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    unit_id uuid NOT NULL,
    connection_id uuid NOT NULL,
    runtime_session_id text NOT NULL,
    generation integer NOT NULL,
    progress jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT cowork_checkpoints_generation_check CHECK ((generation > 0)),
    CONSTRAINT cowork_checkpoints_progress_check CHECK (((jsonb_typeof(progress) = 'object'::text) AND (octet_length((progress)::text) <= 16384))),
    CONSTRAINT cowork_checkpoints_runtime_session_id_check CHECK (((length(runtime_session_id) >= 1) AND (length(runtime_session_id) <= 255)))
);


--
-- Name: cowork_connection_slots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cowork_connection_slots (
    connection_id uuid NOT NULL,
    workspace_id uuid NOT NULL
);


--
-- Name: cowork_units; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cowork_units (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    work_id uuid NOT NULL,
    lineage_work_id uuid NOT NULL,
    run_id uuid NOT NULL,
    unit_key text NOT NULL,
    role text NOT NULL,
    assignment_connection_id uuid NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    generation integer DEFAULT 0 NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    lease_id uuid,
    lease_session_id text,
    lease_expires_at timestamp with time zone,
    checkpoint_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    outcome_ref jsonb,
    transferred_from_connection_id uuid,
    ai_epoch bigint NOT NULL,
    CONSTRAINT cowork_units_check CHECK ((((state = 'claimed'::text) AND (generation > 0) AND (lease_id IS NOT NULL) AND (lease_session_id IS NOT NULL) AND ((length(lease_session_id) >= 1) AND (length(lease_session_id) <= 255)) AND (lease_expires_at IS NOT NULL)) OR ((state <> 'claimed'::text) AND (lease_id IS NULL) AND (lease_session_id IS NULL) AND (lease_expires_at IS NULL)))),
    CONSTRAINT cowork_units_generation_check CHECK ((generation >= 0)),
    CONSTRAINT cowork_units_outcome_check CHECK (((outcome_ref IS NULL) OR ((state = 'completed'::text) AND (jsonb_typeof(outcome_ref) = 'object'::text) AND ((outcome_ref ->> 'type'::text) = ANY (ARRAY['message'::text, 'material'::text, 'doc'::text, 'work'::text, 'thought'::text])) AND (octet_length((outcome_ref)::text) <= 1024)))),
    CONSTRAINT cowork_units_role_check CHECK ((role = ANY (ARRAY['execute'::text, 'review'::text, 'plan'::text]))),
    CONSTRAINT cowork_units_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'claimed'::text, 'paused'::text, 'completed'::text, 'stopped'::text]))),
    CONSTRAINT cowork_units_unit_key_check CHECK (((length(unit_key) >= 1) AND (length(unit_key) <= 200))),
    CONSTRAINT cowork_units_version_check CHECK ((version > 0))
);


--
-- Name: dm_message_observations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dm_message_observations (
    workspace_id uuid NOT NULL,
    dm_id uuid NOT NULL,
    message_id uuid NOT NULL,
    viewer_id text NOT NULL,
    observed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dm_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dm_messages (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    dm_id uuid NOT NULL,
    author_id text NOT NULL,
    client_message_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    sequence integer NOT NULL,
    body text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    thread_root_id uuid,
    via text,
    kind text DEFAULT 'text'::text NOT NULL,
    edited_at timestamp with time zone,
    removed_at timestamp with time zone,
    via_colour text,
    attachment_count smallint DEFAULT 0 NOT NULL,
    CONSTRAINT dm_message_attachment_count CHECK (((attachment_count >= 0) AND (attachment_count <= 10))),
    CONSTRAINT dm_messages_ai_used_check CHECK (((kind = 'text'::text) OR ((via IS NULL) AND (thread_root_id IS NULL)))),
    CONSTRAINT dm_messages_body_check CHECK ((public.flux_is_sealed(body) OR ((length(btrim(body)) <= 100000) AND ((length(btrim(body)) >= 1) OR (attachment_count > 0))))),
    CONSTRAINT dm_messages_kind_check CHECK ((kind = ANY (ARRAY['text'::text, 'ai_used'::text]))),
    CONSTRAINT dm_messages_sequence_check CHECK ((sequence > 0)),
    CONSTRAINT dm_messages_thread_root_not_self CHECK (((thread_root_id IS NULL) OR (thread_root_id <> id))),
    CONSTRAINT dm_messages_via_check CHECK (((via IS NULL) OR ((char_length(via) >= 1) AND (char_length(via) <= 80)))),
    CONSTRAINT dm_messages_via_colour_check CHECK (((via_colour IS NULL) OR ((via IS NOT NULL) AND (via_colour = ANY (ARRAY['ink'::text, 'clay'::text, 'ochre'::text, 'sage'::text, 'teal'::text, 'indigo'::text, 'plum'::text, 'rose'::text])))))
);


--
-- Name: dm_participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dm_participants (
    workspace_id uuid NOT NULL,
    dm_id uuid NOT NULL,
    user_id text NOT NULL,
    joined_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dm_reads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dm_reads (
    workspace_id uuid NOT NULL,
    dm_id uuid NOT NULL,
    user_id text NOT NULL,
    read_through integer NOT NULL,
    read_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dm_reads_read_through_check CHECK ((read_through >= 0))
);


--
-- Name: dms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dms (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    kind text NOT NULL,
    pair_key text,
    title text,
    created_by text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    next_sequence integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_message_at timestamp with time zone,
    CONSTRAINT dms_check CHECK (((kind = 'pair'::text) = (pair_key IS NOT NULL))),
    CONSTRAINT dms_check1 CHECK (((kind = 'group'::text) OR (title IS NULL))),
    CONSTRAINT dms_kind_check CHECK ((kind = ANY (ARRAY['pair'::text, 'group'::text]))),
    CONSTRAINT dms_next_sequence_check CHECK ((next_sequence > 0)),
    CONSTRAINT dms_title_check CHECK ((public.flux_is_sealed(title) OR ((title IS NULL) OR ((length(btrim(title)) >= 1) AND (length(btrim(title)) <= 80))))),
    CONSTRAINT dms_version_check CHECK ((version >= 1))
);


--
-- Name: doc_live_archives; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_live_archives (
    doc_id uuid NOT NULL,
    generation uuid NOT NULL,
    sequence bigint NOT NULL,
    body text NOT NULL,
    hash text NOT NULL,
    saved_version integer NOT NULL,
    saved_sequence bigint NOT NULL,
    codec_state jsonb,
    retired_at timestamp with time zone DEFAULT now() NOT NULL,
    snapshot_sequence bigint,
    CONSTRAINT doc_live_archive_body CHECK ((public.flux_is_sealed(body) OR (char_length(body) <= 100000))),
    CONSTRAINT doc_live_archive_codec_bytes CHECK (((codec_state IS NULL) OR (octet_length((codec_state)::text) <= 8388608))),
    CONSTRAINT doc_live_archive_hash CHECK ((public.flux_is_sealed(hash) OR (hash ~ '^[a-f0-9]{64}$'::text))),
    CONSTRAINT doc_live_archive_sequence CHECK ((((sequence >= 0) AND (sequence <= '9007199254740991'::bigint)) AND ((saved_sequence >= 0) AND (saved_sequence <= sequence)))),
    CONSTRAINT doc_live_archive_snapshot CHECK (((snapshot_sequence IS NULL) OR ((snapshot_sequence >= 0) AND (snapshot_sequence <= sequence))))
);


--
-- Name: doc_live_heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_live_heads (
    doc_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    generation uuid NOT NULL,
    sequence bigint DEFAULT 0 NOT NULL,
    body text NOT NULL,
    hash text NOT NULL,
    saved_version integer NOT NULL,
    saved_sequence bigint DEFAULT 0 NOT NULL,
    codec_state jsonb,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    snapshot_sequence bigint DEFAULT 0 NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT doc_live_head_body CHECK ((public.flux_is_sealed(body) OR (char_length(body) <= 100000))),
    CONSTRAINT doc_live_head_codec_bytes CHECK (((codec_state IS NULL) OR (octet_length((codec_state)::text) <= 8388608))),
    CONSTRAINT doc_live_head_hash CHECK ((public.flux_is_sealed(hash) OR (hash ~ '^[a-f0-9]{64}$'::text))),
    CONSTRAINT doc_live_head_sequence CHECK ((((sequence >= 0) AND (sequence <= '9007199254740991'::bigint)) AND ((saved_sequence >= 0) AND (saved_sequence <= sequence)))),
    CONSTRAINT doc_live_head_snapshot CHECK ((((snapshot_sequence >= 0) AND (snapshot_sequence <= sequence)) AND ((revision >= 0) AND (revision <= '9007199254740991'::bigint))))
);


--
-- Name: doc_live_presence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_live_presence (
    connection_id uuid NOT NULL,
    doc_id uuid NOT NULL,
    generation uuid NOT NULL,
    actor_id text NOT NULL,
    session_id text NOT NULL,
    cursor jsonb NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    slot smallint DEFAULT 0 NOT NULL,
    CONSTRAINT doc_live_presence_cursor CHECK (((jsonb_typeof(cursor) = 'object'::text) AND (octet_length((cursor)::text) <= 4096))),
    CONSTRAINT doc_live_presence_slot_check CHECK (((slot >= 0) AND (slot < 128)))
);


--
-- Name: doc_live_replicas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_live_replicas (
    doc_id uuid NOT NULL,
    generation uuid NOT NULL,
    replica_id bigint NOT NULL,
    owner_kind text DEFAULT 'human'::text NOT NULL,
    actor_id text,
    instance_id uuid NOT NULL,
    connection_id uuid,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT doc_live_replica_id CHECK (((replica_id >= 0) AND (replica_id <= '9007199254740991'::bigint))),
    CONSTRAINT doc_live_replica_owner CHECK ((((owner_kind = 'human'::text) AND (actor_id IS NOT NULL)) OR ((owner_kind = 'server'::text) AND (actor_id IS NULL))))
);


--
-- Name: doc_live_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_live_snapshots (
    doc_id uuid NOT NULL,
    version integer NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    generation uuid NOT NULL,
    from_sequence bigint NOT NULL,
    to_sequence bigint NOT NULL,
    hash text NOT NULL,
    contributors jsonb NOT NULL,
    CONSTRAINT doc_live_snapshot_contributors CHECK (((jsonb_typeof(contributors) = 'array'::text) AND (octet_length((contributors)::text) <= 8388608))),
    CONSTRAINT doc_live_snapshot_hash CHECK ((public.flux_is_sealed(hash) OR (hash ~ '^[a-f0-9]{64}$'::text))),
    CONSTRAINT doc_live_snapshot_interval CHECK ((((from_sequence >= 0) AND (from_sequence <= to_sequence)) AND (to_sequence <= '9007199254740991'::bigint)))
);


--
-- Name: doc_live_updates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_live_updates (
    doc_id uuid NOT NULL,
    generation uuid NOT NULL,
    sequence bigint NOT NULL,
    actor_id text NOT NULL,
    command_id uuid NOT NULL,
    fingerprint text NOT NULL,
    bytes text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    ledger jsonb,
    CONSTRAINT doc_live_update_bytes CHECK ((public.flux_is_sealed(bytes) OR (octet_length(bytes) <= 11184812))),
    CONSTRAINT doc_live_update_fingerprint CHECK ((public.flux_is_sealed(fingerprint) OR (fingerprint ~ '^[a-f0-9]{64}$'::text))),
    CONSTRAINT doc_live_update_ledger CHECK (((ledger IS NULL) OR ((jsonb_typeof(ledger) = 'object'::text) AND (octet_length((ledger)::text) <= 8388608)))),
    CONSTRAINT doc_live_update_sequence CHECK (((sequence >= 1) AND (sequence <= '9007199254740991'::bigint)))
);


--
-- Name: encrypted_workspace_creations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.encrypted_workspace_creations (
    id uuid NOT NULL,
    user_id text NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: event_audience; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_audience (
    recipient text NOT NULL,
    seq bigint NOT NULL,
    event_id uuid NOT NULL
);


--
-- Name: event_data_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_data_keys (
    key text NOT NULL
);


--
-- Name: event_data_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_data_tokens (
    token text NOT NULL
);


--
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.events (
    id uuid NOT NULL,
    kind text NOT NULL,
    object_id uuid NOT NULL,
    actor_id text NOT NULL,
    data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    workspace_id uuid,
    seq bigint NOT NULL
);


--
-- Name: events_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.events_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: events_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.events_seq_seq OWNED BY public.events.seq;


--
-- Name: file_garbage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_garbage (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: file_text_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_text_jobs (
    file_id uuid NOT NULL,
    queued_at timestamp with time zone DEFAULT now() NOT NULL,
    claimed_at timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL
);


--
-- Name: flux_schema_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flux_schema_version (
    version integer NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: github_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_bindings (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    host text DEFAULT 'github.com'::text NOT NULL,
    installation_id text NOT NULL,
    repository_id text NOT NULL,
    owner text NOT NULL,
    name text NOT NULL,
    private boolean NOT NULL,
    url text NOT NULL,
    author_user_id text,
    author_github_user_id text NOT NULL,
    app_id text NOT NULL,
    authorization_generation uuid NOT NULL,
    state text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT github_bindings_host_check CHECK ((host = 'github.com'::text)),
    CONSTRAINT github_bindings_installation_id_check CHECK ((installation_id ~ '^[1-9][0-9]*$'::text)),
    CONSTRAINT github_bindings_repository_id_check CHECK ((repository_id ~ '^[1-9][0-9]*$'::text)),
    CONSTRAINT github_bindings_state_check CHECK ((state = ANY (ARRAY['active'::text, 'disconnected'::text, 'revoked'::text])))
);


--
-- Name: github_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_credentials (
    user_id text NOT NULL,
    host text DEFAULT 'github.com'::text NOT NULL,
    generation uuid NOT NULL,
    github_user_id text NOT NULL,
    app_id text NOT NULL,
    encrypted_tokens text,
    expires_at timestamp with time zone,
    refresh_expires_at timestamp with time zone,
    state text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT github_credentials_app_id_check CHECK ((app_id ~ '^[1-9][0-9]*$'::text)),
    CONSTRAINT github_credentials_github_user_id_check CHECK ((github_user_id ~ '^[1-9][0-9]*$'::text)),
    CONSTRAINT github_credentials_host_check CHECK ((host = 'github.com'::text)),
    CONSTRAINT github_credentials_state_check CHECK ((state = ANY (ARRAY['active'::text, 'refreshing'::text, 'uncertain'::text, 'revoked'::text])))
);


--
-- Name: github_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_deliveries (
    id text NOT NULL,
    app_id text NOT NULL,
    digest text NOT NULL,
    event text NOT NULL,
    payload jsonb NOT NULL,
    installation_id text,
    repository_id text,
    provider_object_id text,
    target_binding_id uuid,
    origin text NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT github_deliveries_origin_check CHECK ((origin = ANY (ARRAY['webhook'::text, 'reconcile'::text])))
);


--
-- Name: github_oauth_flows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_oauth_flows (
    state_hash text NOT NULL,
    id uuid NOT NULL,
    user_id text NOT NULL,
    session_id text NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    purpose text NOT NULL,
    encrypted_verifier text,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone,
    CONSTRAINT github_oauth_flows_purpose_check CHECK ((purpose = ANY (ARRAY['authorize'::text, 'install'::text])))
);


--
-- Name: github_processing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_processing (
    delivery_id text NOT NULL,
    binding_id uuid NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    error_code text,
    CONSTRAINT github_processing_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'completed'::text])))
);


--
-- Name: github_rule_defaults; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_rule_defaults (
    project_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    mode text,
    set_by_user_id text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT github_rule_defaults_mode_check CHECK ((mode = ANY (ARRAY['complete'::text, 'ready'::text])))
);


--
-- Name: github_task_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_task_links (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    task_id uuid NOT NULL,
    binding_id uuid NOT NULL,
    pull_id text NOT NULL,
    role text NOT NULL,
    facts jsonb NOT NULL,
    verified_at timestamp with time zone DEFAULT now() NOT NULL,
    state text DEFAULT 'current'::text NOT NULL,
    CONSTRAINT github_task_links_pull_id_check CHECK ((pull_id ~ '^[1-9][0-9]*$'::text)),
    CONSTRAINT github_task_links_role_check CHECK ((role = ANY (ARRAY['required_output'::text, 'related'::text]))),
    CONSTRAINT github_task_links_state_check CHECK ((state = ANY (ARRAY['current'::text, 'stale'::text, 'unavailable'::text])))
);


--
-- Name: github_task_rule_changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_task_rule_changes (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    task_id uuid NOT NULL,
    code text NOT NULL,
    from_status text NOT NULL,
    to_status text NOT NULL,
    blocker text,
    ready_to_close boolean NOT NULL,
    author_user_id text,
    link_id uuid,
    pull_number integer,
    head_sha text,
    check_name text,
    delivery_id text,
    binding_id uuid NOT NULL,
    origin text NOT NULL,
    task_version integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT github_task_rule_changes_check CHECK (((origin = 'binding'::text) = (delivery_id IS NULL))),
    CONSTRAINT github_task_rule_changes_check_name_check CHECK ((char_length(check_name) <= 200)),
    CONSTRAINT github_task_rule_changes_code_check CHECK ((code = ANY (ARRAY['pull_open'::text, 'pull_reopened'::text, 'check_failed'::text, 'checks_passed'::text, 'pull_closed'::text, 'merged_done'::text, 'merged_ready'::text, 'suspended_manual'::text, 'suspended_access'::text, 'suspended_repository'::text]))),
    CONSTRAINT github_task_rule_changes_from_status_check CHECK ((from_status = ANY (ARRAY['open'::text, 'in_progress'::text, 'blocked'::text, 'done'::text]))),
    CONSTRAINT github_task_rule_changes_head_sha_check CHECK ((head_sha ~ '^[a-f0-9]{40}([a-f0-9]{24})?$'::text)),
    CONSTRAINT github_task_rule_changes_origin_check CHECK ((origin = ANY (ARRAY['webhook'::text, 'reconcile'::text, 'binding'::text]))),
    CONSTRAINT github_task_rule_changes_pull_number_check CHECK ((pull_number >= 1)),
    CONSTRAINT github_task_rule_changes_task_version_check CHECK ((task_version >= 1)),
    CONSTRAINT github_task_rule_changes_to_status_check CHECK ((to_status = ANY (ARRAY['open'::text, 'in_progress'::text, 'blocked'::text, 'done'::text])))
);


--
-- Name: github_task_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_task_rules (
    task_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    mode text NOT NULL,
    state text NOT NULL,
    suspended_reason text,
    author_user_id text,
    author_github_user_id text NOT NULL,
    author_generation uuid NOT NULL,
    app_id text NOT NULL,
    expected_version integer NOT NULL,
    expected_status text NOT NULL,
    expected_blocker text,
    blocked_by text,
    ready_to_close boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    CONSTRAINT github_task_rules_app_id_check CHECK ((app_id ~ '^[1-9][0-9]*$'::text)),
    CONSTRAINT github_task_rules_author_github_user_id_check CHECK ((author_github_user_id ~ '^[1-9][0-9]*$'::text)),
    CONSTRAINT github_task_rules_blocked_by_check CHECK ((blocked_by = ANY (ARRAY['check'::text, 'closed'::text]))),
    CONSTRAINT github_task_rules_check CHECK (((state = 'suspended'::text) = (suspended_reason IS NOT NULL))),
    CONSTRAINT github_task_rules_expected_status_check CHECK ((expected_status = ANY (ARRAY['open'::text, 'in_progress'::text, 'blocked'::text, 'done'::text]))),
    CONSTRAINT github_task_rules_expected_version_check CHECK ((expected_version >= 1)),
    CONSTRAINT github_task_rules_mode_check CHECK ((mode = ANY (ARRAY['complete'::text, 'ready'::text]))),
    CONSTRAINT github_task_rules_revision_check CHECK ((revision >= 1)),
    CONSTRAINT github_task_rules_state_check CHECK ((state = ANY (ARRAY['active'::text, 'suspended'::text, 'off'::text]))),
    CONSTRAINT github_task_rules_suspended_reason_check CHECK ((suspended_reason = ANY (ARRAY['manual_change'::text, 'author_access'::text, 'repository_unavailable'::text])))
);


--
-- Name: idempotency_account_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idempotency_account_operations (
    operation text NOT NULL
);


--
-- Name: idempotency_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idempotency_keys (
    id uuid NOT NULL,
    principal text NOT NULL,
    workspace_id uuid,
    operation text NOT NULL,
    key text NOT NULL,
    request_hash text NOT NULL,
    response_status integer NOT NULL,
    response_body jsonb,
    response_etag text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT idempotency_keys_key_check CHECK (((length(key) >= 1) AND (length(key) <= 255)))
);


--
-- Name: jwks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jwks (
    id text NOT NULL,
    public_key text NOT NULL,
    private_key text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone,
    alg text,
    crv text
);


--
-- Name: live_access_fences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.live_access_fences (
    scope_key text NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT live_access_fences_check CHECK ((((project_id IS NULL) AND (scope_key = ('w:'::text || (workspace_id)::text))) OR ((project_id IS NOT NULL) AND (scope_key = ('p:'::text || (project_id)::text)))))
);


--
-- Name: live_admissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.live_admissions (
    id text NOT NULL,
    live_session_id uuid NOT NULL,
    user_id text NOT NULL,
    auth_session_id text NOT NULL,
    issued_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT live_admissions_id_check CHECK ((id ~ '^[A-Za-z0-9_-]{22}$'::text))
);


--
-- Name: live_editing_intents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.live_editing_intents (
    actor_id text NOT NULL,
    command_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    kind text NOT NULL,
    resource_id uuid NOT NULL,
    generation uuid NOT NULL,
    operation text NOT NULL,
    fingerprint text NOT NULL,
    byte_length integer NOT NULL,
    receipt jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT live_editing_intent_bytes CHECK (((byte_length >= 0) AND (byte_length <= 8388608))),
    CONSTRAINT live_editing_intent_fingerprint CHECK ((public.flux_is_sealed(fingerprint) OR (fingerprint ~ '^[a-f0-9]{64}$'::text))),
    CONSTRAINT live_editing_intent_kind CHECK ((kind = ANY (ARRAY['wiki'::text, 'map'::text]))),
    CONSTRAINT live_editing_intent_receipt CHECK (((jsonb_typeof(receipt) = 'object'::text) AND (octet_length((receipt)::text) <= 8388608)))
);


--
-- Name: live_invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.live_invitations (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    session_id uuid NOT NULL,
    inviter_id text NOT NULL,
    recipient_id text NOT NULL,
    response text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    responded_at timestamp with time zone,
    CONSTRAINT live_invitations_check CHECK ((inviter_id <> recipient_id)),
    CONSTRAINT live_invitations_check1 CHECK (((response = 'pending'::text) = (responded_at IS NULL))),
    CONSTRAINT live_invitations_response_check CHECK ((response = ANY (ARRAY['pending'::text, 'later'::text, 'text'::text])))
);


--
-- Name: live_presentations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.live_presentations (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    session_id uuid NOT NULL,
    generation integer NOT NULL,
    created_by text NOT NULL,
    client_event_id uuid NOT NULL,
    ref_type text NOT NULL,
    ref_id uuid NOT NULL,
    ref_version integer NOT NULL,
    selected_thought_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT live_presentations_check CHECK (((ref_type = 'sketch'::text) OR (cardinality(selected_thought_ids) = 0))),
    CONSTRAINT live_presentations_generation_check CHECK ((generation > 0)),
    CONSTRAINT live_presentations_ref_type_check CHECK ((ref_type = ANY (ARRAY['message'::text, 'material'::text, 'work'::text, 'sketch'::text]))),
    CONSTRAINT live_presentations_ref_version_check CHECK ((ref_version > 0)),
    CONSTRAINT live_presentations_selected_thought_ids_check CHECK ((cardinality(selected_thought_ids) <= 100))
);


--
-- Name: live_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.live_sessions (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    conversation_id uuid,
    work_id uuid,
    sketch_id uuid,
    doc_id uuid,
    created_by text NOT NULL,
    client_session_id uuid NOT NULL,
    state text DEFAULT 'available'::text NOT NULL,
    generation integer DEFAULT 1 NOT NULL,
    room_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    empty_since timestamp with time zone,
    last_grant_at timestamp with time zone,
    connected_once boolean DEFAULT false NOT NULL,
    ended_at timestamp with time zone,
    joined_by text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT live_sessions_check CHECK ((num_nonnulls(conversation_id, work_id, sketch_id, doc_id) <= 1)),
    CONSTRAINT live_sessions_generation_check CHECK ((generation > 0)),
    CONSTRAINT live_sessions_joined_by_check CHECK (((cardinality(joined_by) <= 64) AND (array_position(joined_by, NULL::text) IS NULL))),
    CONSTRAINT live_sessions_room_id_check CHECK (((length(room_id) >= 16) AND (length(room_id) <= 128))),
    CONSTRAINT live_sessions_state_check CHECK ((state = ANY (ARRAY['available'::text, 'rotating'::text, 'ending'::text, 'ended'::text])))
);


--
-- Name: live_webhook_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.live_webhook_events (
    event_id text NOT NULL,
    session_id uuid NOT NULL,
    generation integer NOT NULL,
    room_id text NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT live_webhook_events_generation_check CHECK ((generation > 0))
);


--
-- Name: map_live_gestures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.map_live_gestures (
    lease_id uuid NOT NULL,
    sketch_id uuid NOT NULL,
    generation uuid NOT NULL,
    gesture_id uuid NOT NULL,
    actor_id text NOT NULL,
    session_id text NOT NULL,
    connection_id uuid,
    sequence bigint DEFAULT 0 NOT NULL,
    thoughts jsonb NOT NULL,
    positions jsonb DEFAULT '[]'::jsonb NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT map_live_gestures_positions_check CHECK (((jsonb_typeof(positions) = 'array'::text) AND (jsonb_array_length(positions) <= 200) AND (octet_length((positions)::text) <= 65536))),
    CONSTRAINT map_live_gestures_sequence_check CHECK (((sequence >= 0) AND (sequence <= '9007199254740991'::bigint))),
    CONSTRAINT map_live_gestures_thoughts_check CHECK (((jsonb_typeof(thoughts) = 'array'::text) AND ((jsonb_array_length(thoughts) >= 1) AND (jsonb_array_length(thoughts) <= 200)) AND (octet_length((thoughts)::text) <= 65536)))
);


--
-- Name: map_live_heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.map_live_heads (
    sketch_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    generation uuid NOT NULL,
    sequence bigint DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT map_live_heads_sequence_check CHECK (((sequence >= 0) AND (sequence <= '9007199254740991'::bigint)))
);


--
-- Name: map_live_journal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.map_live_journal (
    sketch_id uuid NOT NULL,
    generation uuid NOT NULL,
    sequence bigint NOT NULL,
    actor_kind text NOT NULL,
    actor_id text NOT NULL,
    command_id uuid NOT NULL,
    fingerprint text NOT NULL,
    change jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT map_live_journal_actor_kind_check CHECK ((actor_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT map_live_journal_change_check CHECK (((jsonb_typeof(change) = 'object'::text) AND (octet_length((change)::text) <= 8388608))),
    CONSTRAINT map_live_journal_fingerprint_check CHECK ((public.flux_is_sealed(fingerprint) OR (fingerprint ~ '^[a-f0-9]{64}$'::text))),
    CONSTRAINT map_live_journal_sequence_check CHECK (((sequence >= 1) AND (sequence <= '9007199254740991'::bigint)))
);


--
-- Name: map_live_object_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.map_live_object_versions (
    kind text NOT NULL,
    object_id uuid NOT NULL,
    sketch_id uuid NOT NULL,
    version bigint NOT NULL,
    CONSTRAINT map_live_object_versions_kind_check CHECK ((kind = ANY (ARRAY['thought'::text, 'link'::text]))),
    CONSTRAINT map_live_object_versions_version_check CHECK (((version >= 1) AND (version <= '9007199254740991'::bigint)))
);


--
-- Name: map_live_presence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.map_live_presence (
    connection_id uuid NOT NULL,
    sketch_id uuid NOT NULL,
    generation uuid NOT NULL,
    actor_id text NOT NULL,
    session_id text NOT NULL,
    selected jsonb NOT NULL,
    cursor jsonb,
    expires_at timestamp with time zone NOT NULL,
    slot smallint DEFAULT 0 NOT NULL,
    CONSTRAINT map_live_presence_cursor_check CHECK (((cursor IS NULL) OR ((jsonb_typeof(cursor) = 'object'::text) AND (octet_length((cursor)::text) <= 256)))),
    CONSTRAINT map_live_presence_selected_check CHECK (((jsonb_typeof(selected) = 'array'::text) AND (jsonb_array_length(selected) <= 16))),
    CONSTRAINT map_live_presence_slot_check CHECK (((slot >= 0) AND (slot < 128)))
);


--
-- Name: map_live_undone; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.map_live_undone (
    sketch_id uuid NOT NULL,
    generation uuid NOT NULL,
    original_sequence bigint NOT NULL,
    inverse_sequence bigint NOT NULL
);


--
-- Name: message_references; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_references (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    project_message_id uuid,
    dm_message_id uuid,
    "position" smallint NOT NULL,
    kind text NOT NULL,
    target_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT message_references_kind CHECK ((kind = ANY (ARRAY['thought'::text, 'message'::text]))),
    CONSTRAINT message_references_one_owner CHECK ((num_nonnulls(project_message_id, dm_message_id) = 1)),
    CONSTRAINT message_references_position CHECK ((("position" >= 0) AND ("position" <= 3)))
);


--
-- Name: native_command_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.native_command_receipts (
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    actor_kind text NOT NULL,
    actor_id text NOT NULL,
    operation text NOT NULL,
    client_command_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    work_id uuid NOT NULL,
    work_version integer NOT NULL,
    message_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT native_command_receipts_actor_kind_check CHECK ((actor_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT native_command_receipts_operation_check CHECK ((operation = 'work.update'::text)),
    CONSTRAINT native_command_receipts_work_version_check CHECK (((work_version IS NULL) OR (work_version >= 1)))
);


--
-- Name: needs_you_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.needs_you_states (
    user_id text NOT NULL,
    item_key text NOT NULL,
    state text NOT NULL,
    until timestamp with time zone,
    until_work_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    restore jsonb,
    CONSTRAINT needs_you_states_check CHECK (((state = 'snoozed'::text) OR ((until IS NULL) AND (until_work_id IS NULL)))),
    CONSTRAINT needs_you_states_check1 CHECK (((state <> 'snoozed'::text) OR ((until IS NOT NULL) <> (until_work_id IS NOT NULL)))),
    CONSTRAINT needs_you_states_item_key_check CHECK (((char_length(item_key) >= 1) AND (char_length(item_key) <= 100))),
    CONSTRAINT needs_you_states_state_check CHECK ((state = ANY (ARRAY['done'::text, 'declined'::text, 'snoozed'::text])))
);


--
-- Name: notification_address_sends; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_address_sends (
    address_hash text NOT NULL,
    window_start timestamp with time zone NOT NULL,
    sent integer NOT NULL,
    last_sent_at timestamp with time zone NOT NULL
);


--
-- Name: notification_address_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_address_tokens (
    token_hash text NOT NULL,
    address_id uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notification_addresses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_addresses (
    id uuid NOT NULL,
    user_id text NOT NULL,
    email text NOT NULL,
    verified_at timestamp with time zone,
    last_sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    CONSTRAINT notification_addresses_email_check CHECK (((length(email) >= 3) AND (length(email) <= 254)))
);


--
-- Name: notification_cursor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_cursor (
    id text NOT NULL,
    seq bigint NOT NULL,
    CONSTRAINT notification_cursor_seq_check CHECK ((seq >= 0))
);


--
-- Name: notification_emails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_emails (
    id uuid NOT NULL,
    notification_id uuid NOT NULL,
    user_id text NOT NULL,
    address_kind text NOT NULL,
    address text,
    status text DEFAULT 'queued'::text NOT NULL,
    skip_reason text,
    attempts integer DEFAULT 0 NOT NULL,
    unsubscribe_hash text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    sent_at timestamp with time zone,
    last_error text,
    last_error_at timestamp with time zone,
    address_id uuid,
    CONSTRAINT notification_emails_address_kind_check CHECK ((address_kind = ANY (ARRAY['account'::text, 'extra'::text]))),
    CONSTRAINT notification_emails_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'sending'::text, 'sent'::text, 'skipped'::text])))
);


--
-- Name: notification_follows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_follows (
    user_id text NOT NULL,
    conversation_id uuid NOT NULL,
    following boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notification_generation_failures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_generation_failures (
    event_id uuid NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    dead_at timestamp with time zone
);


--
-- Name: notification_mutes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_mutes (
    user_id text NOT NULL,
    source_type text NOT NULL,
    source_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT notification_mutes_source_type_check CHECK ((source_type = ANY (ARRAY['project'::text, 'dm'::text])))
);


--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_preferences (
    user_id text NOT NULL,
    quiet_enabled boolean DEFAULT false NOT NULL,
    quiet_start smallint DEFAULT 1320 NOT NULL,
    quiet_end smallint DEFAULT 420 NOT NULL,
    time_zone text DEFAULT 'UTC'::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    level text DEFAULT 'needsYou'::text NOT NULL,
    email_me boolean DEFAULT true NOT NULL,
    account_enabled boolean DEFAULT true NOT NULL,
    sound_messages boolean DEFAULT false NOT NULL,
    sound_calls boolean DEFAULT true NOT NULL,
    hide_previews boolean DEFAULT false NOT NULL,
    CONSTRAINT notification_preferences_level_check CHECK ((level = ANY (ARRAY['needsYou'::text, 'everything'::text, 'nothing'::text]))),
    CONSTRAINT notification_preferences_quiet_end_check CHECK (((quiet_end >= 0) AND (quiet_end <= 1439))),
    CONSTRAINT notification_preferences_quiet_start_check CHECK (((quiet_start >= 0) AND (quiet_start <= 1439))),
    CONSTRAINT notification_preferences_time_zone_check CHECK (((length(time_zone) >= 1) AND (length(time_zone) <= 64)))
);


--
-- Name: notification_verification_sends; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_verification_sends (
    user_id text NOT NULL,
    window_start timestamp with time zone NOT NULL,
    sent integer NOT NULL,
    last_sent_at timestamp with time zone NOT NULL,
    CONSTRAINT notification_verification_sends_sent_check CHECK ((sent >= 0))
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    user_id text NOT NULL,
    workspace_id uuid NOT NULL,
    source_type text NOT NULL,
    source_id uuid NOT NULL,
    title text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    url text,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    reason text,
    event_id uuid,
    in_inbox boolean DEFAULT true NOT NULL,
    ai_origin boolean NOT NULL,
    answer boolean DEFAULT false NOT NULL,
    from_actor text,
    CONSTRAINT notifications_answer_reason CHECK (((NOT answer) OR (reason = ANY (ARRAY['mention'::text, 'question'::text])))),
    CONSTRAINT notifications_reason_check CHECK ((reason = ANY (ARRAY['mention'::text, 'question'::text, 'reply'::text, 'dm'::text, 'assigned'::text, 'review'::text, 'invitation'::text, 'security'::text, 'approval'::text, 'call'::text]))),
    CONSTRAINT notifications_source_type_check CHECK ((source_type = ANY (ARRAY['workspace'::text, 'project'::text, 'dm'::text]))),
    CONSTRAINT notifications_workspace_source_check CHECK (((source_type <> 'workspace'::text) OR (source_id = workspace_id)))
);


--
-- Name: oauth_access_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_access_token (
    id text NOT NULL,
    token text NOT NULL,
    client_id text NOT NULL,
    session_id text,
    user_id text,
    reference_id text,
    authorization_code_id text,
    resources text[],
    requested_user_info_claims text[],
    refresh_id text,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL,
    revoked timestamp with time zone,
    confirmation jsonb,
    scopes text[] NOT NULL
);


--
-- Name: oauth_client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_client (
    id text NOT NULL,
    client_id text NOT NULL,
    client_secret text,
    client_discovery_id text,
    disabled boolean DEFAULT false,
    skip_consent boolean,
    enable_end_session boolean,
    subject_type text,
    scopes text[],
    client_credentials_scopes text[] DEFAULT '{}'::text[],
    user_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name text,
    uri text,
    icon text,
    contacts text[],
    tos text,
    policy text,
    software_id text,
    software_version text,
    software_statement text,
    redirect_uris text[] NOT NULL,
    post_logout_redirect_uris text[],
    backchannel_logout_uri text,
    backchannel_logout_session_required boolean,
    token_endpoint_auth_method text,
    application_type text,
    jwks text,
    jwks_uri text,
    grant_types text[],
    response_types text[],
    require_pkce boolean,
    dpop_bound_access_tokens boolean DEFAULT false,
    reference_id text,
    metadata jsonb
);


--
-- Name: oauth_client_assertion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_client_assertion (
    id text NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: oauth_client_resource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_client_resource (
    id text NOT NULL,
    client_id text NOT NULL,
    resource_id text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone
);


--
-- Name: oauth_consent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_consent (
    id text NOT NULL,
    client_id text NOT NULL,
    user_id text,
    reference_id text,
    resources text[],
    requested_user_info_claims text[],
    scopes text[] NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: oauth_grant_authentication; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_grant_authentication (
    authorization_code_id text NOT NULL,
    user_id text NOT NULL,
    reference_id text NOT NULL,
    auth_method text NOT NULL,
    auth_idp_sid text,
    auth_confirmed_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT oauth_grant_authentication_auth_idp_sid_check CHECK (((auth_idp_sid IS NULL) OR ((length(auth_idp_sid) >= 1) AND (length(auth_idp_sid) <= 512)))),
    CONSTRAINT oauth_grant_authentication_auth_method_check CHECK (((length(auth_method) >= 1) AND (length(auth_method) <= 200)))
);


--
-- Name: oauth_refresh_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_refresh_token (
    id text NOT NULL,
    token text NOT NULL,
    client_id text NOT NULL,
    session_id text,
    user_id text NOT NULL,
    reference_id text,
    authorization_code_id text,
    resources text[],
    requested_user_info_claims text[],
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL,
    revoked timestamp with time zone,
    rotated_at timestamp with time zone,
    rotation_replay_response text,
    rotation_replay_expires_at timestamp with time zone,
    auth_time timestamp with time zone,
    confirmation jsonb,
    scopes text[] NOT NULL
);


--
-- Name: oauth_resource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_resource (
    id text NOT NULL,
    identifier text NOT NULL,
    name text NOT NULL,
    access_token_ttl integer,
    refresh_token_ttl integer,
    signing_algorithm text,
    signing_key_id text,
    allowed_scopes text[],
    custom_claims jsonb,
    dpop_bound_access_tokens_required boolean DEFAULT false,
    disabled boolean DEFAULT false,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    policy_version integer DEFAULT 1,
    metadata jsonb
);


--
-- Name: outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outbox (
    id uuid NOT NULL,
    event_id uuid NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: password_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_attempts (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    user_id text NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: password_reset_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_links (
    id uuid NOT NULL,
    user_id text NOT NULL,
    verification_identifier text NOT NULL,
    via text NOT NULL,
    made_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    stopped_at timestamp with time zone,
    CONSTRAINT password_reset_links_maker_check CHECK (((via = 'settings'::text) OR (made_by IS NULL))),
    CONSTRAINT password_reset_links_via_check CHECK ((via = ANY (ARRAY['settings'::text, 'command'::text, 'email'::text])))
);


--
-- Name: person_photos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_photos (
    id uuid NOT NULL,
    user_id text NOT NULL,
    object_64 uuid NOT NULL,
    object_128 uuid NOT NULL,
    object_256 uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: personal_run_cites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.personal_run_cites (
    run_id uuid NOT NULL,
    kind text NOT NULL,
    object_id uuid NOT NULL,
    CONSTRAINT personal_run_cites_kind_check CHECK ((kind = ANY (ARRAY['doc'::text, 'task'::text, 'decision'::text, 'message'::text])))
);


--
-- Name: personal_run_pictures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.personal_run_pictures (
    id uuid NOT NULL,
    run_id uuid NOT NULL,
    owner_user_id text NOT NULL,
    name text NOT NULL,
    size integer NOT NULL,
    sha256 text NOT NULL,
    "position" smallint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT personal_run_pictures_name_check CHECK (((char_length(name) >= 1) AND (char_length(name) <= 200))),
    CONSTRAINT personal_run_pictures_position_check CHECK ((("position" >= 0) AND ("position" <= 9))),
    CONSTRAINT personal_run_pictures_sha256_check CHECK ((sha256 ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT personal_run_pictures_size_check CHECK (((size >= 1) AND (size <= 5242880)))
);


--
-- Name: personal_run_private_texts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.personal_run_private_texts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid NOT NULL,
    body text NOT NULL,
    addresses text[] DEFAULT '{}'::text[] NOT NULL,
    read_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: personal_run_web_reads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.personal_run_web_reads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid NOT NULL,
    url text NOT NULL,
    final_url text NOT NULL,
    title text,
    read_at timestamp with time zone DEFAULT now() NOT NULL,
    outcome text DEFAULT 'read'::text NOT NULL,
    writable boolean DEFAULT false NOT NULL,
    CONSTRAINT personal_run_web_reads_outcome_check CHECK ((outcome = ANY (ARRAY['asked'::text, 'read'::text, 'redirected'::text, 'blocked'::text, 'unreachable'::text, 'timeout'::text, 'status'::text, 'type'::text, 'redirects'::text, 'invalid'::text, 'empty'::text]))),
    CONSTRAINT personal_run_web_reads_title_check CHECK (((title IS NULL) OR (char_length(title) <= 300))),
    CONSTRAINT personal_run_web_reads_url_check CHECK (((char_length(url) <= 2048) AND (char_length(final_url) <= 2048)))
);


--
-- Name: personal_run_web_searches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.personal_run_web_searches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid NOT NULL,
    queries text[] DEFAULT '{}'::text[] NOT NULL,
    results text[] DEFAULT '{}'::text[] NOT NULL,
    cited text[] DEFAULT '{}'::text[] NOT NULL,
    searched_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT personal_run_web_searches_size_check CHECK (((cardinality(queries) <= 10) AND (cardinality(results) <= 100) AND (cardinality(cited) <= 100)))
);


--
-- Name: personal_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.personal_runs (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid,
    conversation_id uuid,
    owner_user_id text NOT NULL,
    agent_id uuid NOT NULL,
    connection_id uuid,
    client_run_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    kind text NOT NULL,
    prompt text NOT NULL,
    target_sketch_id uuid,
    target_thought_id uuid,
    continues_run_id uuid,
    retry_of_run_id uuid,
    status text DEFAULT 'queued'::text NOT NULL,
    stopped_at_stage text,
    stop_requested_at timestamp with time zone,
    cost_state text DEFAULT 'reserved'::text NOT NULL,
    reserved_micros integer NOT NULL,
    charged_micros integer DEFAULT 0 NOT NULL,
    input_tokens integer,
    output_tokens integer,
    model text NOT NULL,
    answer_body text,
    answer_truncated boolean DEFAULT false NOT NULL,
    answer_sources jsonb DEFAULT '[]'::jsonb NOT NULL,
    committed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    dispatched_at timestamp with time zone,
    completed_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    provider text NOT NULL,
    engine text DEFAULT 'server'::text NOT NULL,
    end_reason text,
    plan_limit_resets_at timestamp with time zone,
    stop_acknowledged_at timestamp with time zone,
    answer_redacted boolean DEFAULT false NOT NULL,
    run_token_nonce_hash text,
    run_token_jti uuid,
    run_token_expires_at timestamp with time zone,
    run_token_closed_at timestamp with time zone,
    run_tools text[] DEFAULT '{}'::text[] NOT NULL,
    mcp_result_bytes integer DEFAULT 0 NOT NULL,
    mcp_limit text,
    authority text DEFAULT 'owner_request'::text NOT NULL,
    background_label text,
    ai_epoch bigint,
    resume_at timestamp with time zone,
    reserved_at timestamp with time zone DEFAULT now() NOT NULL,
    largest_request_micros integer,
    work_id uuid,
    stop_requested_by text,
    asked_by_run_id uuid,
    exchange_turn smallint DEFAULT 0 NOT NULL,
    dm_id uuid,
    shown_at timestamp with time zone,
    dismissed_at timestamp with time zone,
    dm_thread_root_id uuid,
    gateway_token_hash text,
    gateway_token_expires_at timestamp with time zone,
    attachment_count smallint DEFAULT 0 NOT NULL,
    CONSTRAINT personal_run_attachment_count CHECK (((attachment_count >= 0) AND (attachment_count <= 10))),
    CONSTRAINT personal_runs_anchor_check CHECK (((kind = ANY (ARRAY['ask'::text, 'summarize'::text, 'map_thought'::text])) OR (conversation_id IS NOT NULL) OR ((kind = 'scheduled'::text) AND (project_id IS NULL) AND (dm_id IS NULL)))),
    CONSTRAINT personal_runs_answer_body_check CHECK (((answer_body IS NULL) OR (length(answer_body) <= 100000))),
    CONSTRAINT personal_runs_authority_check CHECK ((authority = ANY (ARRAY['owner_request'::text, 'owner_schedule'::text]))),
    CONSTRAINT personal_runs_authority_label_check CHECK (((authority = 'owner_request'::text) = (background_label IS NULL))),
    CONSTRAINT personal_runs_background_label_check CHECK (((background_label IS NULL) OR ((char_length(background_label) >= 1) AND (char_length(background_label) <= 80)))),
    CONSTRAINT personal_runs_charged_micros_check CHECK ((charged_micros >= 0)),
    CONSTRAINT personal_runs_check CHECK (((target_sketch_id IS NULL) = (target_thought_id IS NULL))),
    CONSTRAINT personal_runs_check1 CHECK (((answer_body IS NULL) = (committed_at IS NULL))),
    CONSTRAINT personal_runs_cost_state_check CHECK ((cost_state = ANY (ARRAY['reserved'::text, 'released'::text, 'observed'::text, 'unknown'::text]))),
    CONSTRAINT personal_runs_dm_thread_check CHECK (((dm_thread_root_id IS NULL) OR (dm_id IS NOT NULL))),
    CONSTRAINT personal_runs_end_reason_check CHECK ((end_reason = ANY (ARRAY['sign_in_again'::text, 'plan_limit'::text, 'wall_clock'::text, 'no_event'::text, 'crashed'::text, 'answer_too_large'::text, 'mcp_results_too_large'::text, 'local_tool'::text, 'slot_busy'::text, 'unknown'::text, 'max_turns'::text, 'refused'::text, 'model_unavailable'::text, 'ai_off'::text, 'budget'::text, 'credits'::text, 'no_room'::text]))),
    CONSTRAINT personal_runs_engine_check CHECK ((engine = ANY (ARRAY['server'::text, 'runtime'::text]))),
    CONSTRAINT personal_runs_exchange_turn_check CHECK ((exchange_turn >= 0)),
    CONSTRAINT personal_runs_gateway_token_check CHECK (((gateway_token_hash IS NULL) = (gateway_token_expires_at IS NULL))),
    CONSTRAINT personal_runs_gateway_token_hash_check CHECK ((gateway_token_hash ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT personal_runs_input_tokens_check CHECK ((input_tokens >= 0)),
    CONSTRAINT personal_runs_kind_check CHECK ((kind = ANY (ARRAY['ask'::text, 'summarize'::text, 'map_thought'::text, 'scheduled'::text, 'task'::text, 'task_answer'::text]))),
    CONSTRAINT personal_runs_largest_request_micros_check CHECK ((largest_request_micros >= 0)),
    CONSTRAINT personal_runs_mcp_limit_check CHECK ((mcp_limit = ANY (ARRAY['call'::text, 'run'::text]))),
    CONSTRAINT personal_runs_mcp_result_bytes_check CHECK ((mcp_result_bytes >= 0)),
    CONSTRAINT personal_runs_output_tokens_check CHECK ((output_tokens >= 0)),
    CONSTRAINT personal_runs_place_check CHECK ((((conversation_id IS NULL) OR (project_id IS NOT NULL)) AND ((dm_id IS NULL) OR (project_id IS NULL)) AND ((project_id IS NOT NULL) = (ai_epoch IS NOT NULL)))),
    CONSTRAINT personal_runs_plan_limit_check CHECK (((plan_limit_resets_at IS NULL) OR (end_reason = 'plan_limit'::text))),
    CONSTRAINT personal_runs_prompt_check CHECK (((length(btrim(prompt)) <= 4000) AND ((length(btrim(prompt)) >= 1) OR (attachment_count > 0)))),
    CONSTRAINT personal_runs_provider_check CHECK ((provider = ANY (ARRAY['anthropic'::text, 'openai'::text, 'openrouter'::text, 'gemini'::text, 'openai_compatible'::text]))),
    CONSTRAINT personal_runs_put_away_check CHECK (((shown_at IS NULL) OR (dismissed_at IS NULL))),
    CONSTRAINT personal_runs_reserved_micros_check CHECK ((reserved_micros >= 0)),
    CONSTRAINT personal_runs_resume_check CHECK (((resume_at IS NULL) OR (status = ANY (ARRAY['queued'::text, 'stopped'::text, 'paused'::text, 'revoked'::text, 'denied'::text, 'unavailable'::text])))),
    CONSTRAINT personal_runs_run_token_check CHECK (((run_token_jti IS NULL) = (run_token_expires_at IS NULL))),
    CONSTRAINT personal_runs_run_token_nonce_hash_check CHECK ((run_token_nonce_hash ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT personal_runs_run_tools_check CHECK ((cardinality(run_tools) <= 64)),
    CONSTRAINT personal_runs_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'reading'::text, 'dispatching'::text, 'completed'::text, 'truncated'::text, 'stopped'::text, 'denied'::text, 'paused'::text, 'revoked'::text, 'cap_reached'::text, 'unavailable'::text, 'input_too_large'::text, 'provider_failed'::text]))),
    CONSTRAINT personal_runs_stopped_at_stage_check CHECK ((stopped_at_stage = ANY (ARRAY['before_read'::text, 'before_dispatch'::text, 'before_commit'::text]))),
    CONSTRAINT personal_runs_task_check CHECK (((kind = ANY (ARRAY['task'::text, 'task_answer'::text])) = (work_id IS NOT NULL)))
);


--
-- Name: project_ai_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_ai_policies (
    project_id uuid NOT NULL,
    state text NOT NULL,
    epoch bigint DEFAULT 1 NOT NULL,
    changed_by text,
    changed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_ai_policies_epoch_check CHECK ((epoch >= 1)),
    CONSTRAINT project_ai_policies_state_check CHECK ((state = ANY (ARRAY['allowed'::text, 'blocked'::text])))
);


--
-- Name: project_conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_conversations (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    created_by text,
    next_sequence integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by_agent_id uuid,
    CONSTRAINT project_conversation_exact_actor CHECK ((num_nonnulls(created_by, created_by_agent_id) = 1)),
    CONSTRAINT project_conversations_next_sequence_check CHECK ((next_sequence > 0))
);


--
-- Name: project_decision_discussions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_decision_discussions (
    decision_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    conversation_id uuid NOT NULL,
    root_message_id uuid NOT NULL,
    root_sequence integer DEFAULT 1 NOT NULL,
    CONSTRAINT project_decision_discussions_root_sequence_check CHECK ((root_sequence = 1))
);


--
-- Name: project_decision_resumptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_decision_resumptions (
    decision_id uuid NOT NULL,
    work_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    version integer NOT NULL,
    blocker text
);


--
-- Name: project_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_decisions (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    title text NOT NULL,
    rationale text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'proposed'::text NOT NULL,
    proposed_by_kind text NOT NULL,
    proposed_by_id text NOT NULL,
    decided_by text,
    decided_at timestamp with time zone,
    supersedes_id uuid,
    superseded_by_id uuid,
    superseded_at timestamp with time zone,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_decisions_check CHECK (((status = 'proposed'::text) = (decided_by IS NULL))),
    CONSTRAINT project_decisions_check1 CHECK (((decided_by IS NULL) = (decided_at IS NULL))),
    CONSTRAINT project_decisions_check2 CHECK (((status = 'superseded'::text) = (superseded_by_id IS NOT NULL))),
    CONSTRAINT project_decisions_check3 CHECK (((superseded_by_id IS NULL) = (superseded_at IS NULL))),
    CONSTRAINT project_decisions_check4 CHECK (((supersedes_id IS NULL) OR (supersedes_id <> id))),
    CONSTRAINT project_decisions_proposed_by_kind_check CHECK ((proposed_by_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT project_decisions_rationale_check CHECK ((public.flux_is_sealed(rationale) OR (length(rationale) <= 20000))),
    CONSTRAINT project_decisions_status_check CHECK ((status = ANY (ARRAY['proposed'::text, 'accepted'::text, 'superseded'::text]))),
    CONSTRAINT project_decisions_title_check CHECK ((public.flux_is_sealed(title) OR ((length(btrim(title)) >= 1) AND (length(btrim(title)) <= 200)))),
    CONSTRAINT project_decisions_version_check CHECK ((version > 0))
);


--
-- Name: project_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_files (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid,
    uploader_id text,
    uploader_agent_id uuid,
    upload_id uuid NOT NULL,
    replay_of uuid,
    name text NOT NULL,
    state text NOT NULL,
    reserved_bytes integer NOT NULL,
    size integer,
    sha256 text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    ready_at timestamp with time zone,
    expires_at timestamp with time zone,
    message_id uuid,
    "position" smallint,
    published_at timestamp with time zone,
    thought_id uuid,
    key_version integer,
    page_count integer,
    row_count integer,
    duration_ms integer,
    video_container text,
    poster_of uuid,
    dm_id uuid,
    dm_message_id uuid,
    agent_id uuid,
    run_id uuid,
    CONSTRAINT project_file_dm_message_scope CHECK (((dm_message_id IS NULL) OR (dm_id IS NOT NULL))),
    CONSTRAINT project_file_exact_uploader CHECK ((num_nonnulls(uploader_id, uploader_agent_id) = 1)),
    CONSTRAINT project_file_one_scope CHECK ((num_nonnulls(project_id, dm_id, agent_id) = 1)),
    CONSTRAINT project_file_publication CHECK ((((((message_id IS NULL) AND (dm_message_id IS NULL) AND (run_id IS NULL)) = ("position" IS NULL)) OR ((poster_of IS NOT NULL) AND ((message_id IS NOT NULL) OR (dm_message_id IS NOT NULL) OR (run_id IS NOT NULL)) AND ("position" IS NULL))) AND (num_nonnulls(message_id, dm_message_id, run_id, thought_id) <= 1) AND ((num_nonnulls(message_id, dm_message_id, run_id, thought_id) = 1) = (published_at IS NOT NULL)))),
    CONSTRAINT project_file_published_ready CHECK (((published_at IS NULL) OR ((state = 'ready'::text) AND (expires_at IS NULL)))),
    CONSTRAINT project_file_ready_identity CHECK (((state = 'ready'::text) = ((size IS NOT NULL) AND (sha256 IS NOT NULL) AND (ready_at IS NOT NULL)))),
    CONSTRAINT project_file_replay_receiving CHECK (((replay_of IS NULL) OR ((state = 'receiving'::text) AND (published_at IS NULL)))),
    CONSTRAINT project_file_run_scope CHECK (((run_id IS NULL) OR (agent_id IS NOT NULL))),
    CONSTRAINT project_file_unpublished_expires CHECK (((published_at IS NOT NULL) OR (expires_at IS NOT NULL))),
    CONSTRAINT project_files_check CHECK ((((reserved_bytes >= 0) AND (reserved_bytes <=
CASE
    WHEN (video_container IS NULL) THEN 5242880
    ELSE 1073741824
END)) AND ((reserved_bytes > 0) OR (replay_of IS NOT NULL)))),
    CONSTRAINT project_files_duration_ms_check CHECK (((duration_ms IS NULL) OR (duration_ms >= 0))),
    CONSTRAINT project_files_key_version_check CHECK (((key_version IS NULL) OR (key_version >= 1))),
    CONSTRAINT project_files_name_check CHECK ((public.flux_is_sealed(name) OR ((char_length(name) >= 1) AND (char_length(name) <= 200)))),
    CONSTRAINT project_files_page_count_check CHECK (((page_count IS NULL) OR (page_count >= 0))),
    CONSTRAINT project_files_position_check CHECK ((("position" >= 0) AND ("position" <= 9))),
    CONSTRAINT project_files_row_count_check CHECK (((row_count IS NULL) OR (row_count >= 0))),
    CONSTRAINT project_files_sha256_check CHECK ((public.flux_is_sealed(sha256) OR (sha256 ~ '^[0-9a-f]{64}$'::text))),
    CONSTRAINT project_files_size_check CHECK (((size >= 1) AND (size <=
CASE
    WHEN (video_container IS NULL) THEN 5242880
    ELSE 1073741824
END))),
    CONSTRAINT project_files_state_check CHECK ((state = ANY (ARRAY['receiving'::text, 'ready'::text]))),
    CONSTRAINT project_files_video_container_check CHECK ((video_container = ANY (ARRAY['mp4'::text, 'webm'::text, 'mov'::text])))
);


--
-- Name: project_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_grants (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    user_id text NOT NULL,
    role text NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    admin_held boolean DEFAULT false NOT NULL,
    CONSTRAINT project_grants_manager_person CHECK (((role <> 'manager'::text) OR (user_id IS NOT NULL))),
    CONSTRAINT project_grants_role_check CHECK ((role = ANY (ARRAY['manager'::text, 'contributor'::text])))
);


--
-- Name: project_material_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_material_versions (
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    material_id uuid NOT NULL,
    version integer NOT NULL,
    title text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    url text,
    author_id text,
    client_mutation_id uuid,
    request_fingerprint text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    reason text DEFAULT ''::text NOT NULL,
    author_agent_id uuid,
    CONSTRAINT project_material_version_exact_actor CHECK ((num_nonnulls(author_id, author_agent_id) = 1)),
    CONSTRAINT project_material_versions_body_check CHECK ((public.flux_is_sealed(body) OR (length(body) <= 100000))),
    CONSTRAINT project_material_versions_check1 CHECK (((client_mutation_id IS NULL) = (request_fingerprint IS NULL))),
    CONSTRAINT project_material_versions_reason_check CHECK ((public.flux_is_sealed(reason) OR (length(reason) <= 500))),
    CONSTRAINT project_material_versions_title_check CHECK ((public.flux_is_sealed(title) OR ((length(btrim(title)) >= 1) AND (length(btrim(title)) <= 200)))),
    CONSTRAINT project_material_versions_version_check CHECK ((version > 0))
);


--
-- Name: project_materials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_materials (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    created_by text,
    client_mutation_id uuid,
    request_fingerprint text,
    current_version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    kind text DEFAULT 'material'::text NOT NULL,
    created_by_agent_id uuid,
    CONSTRAINT project_material_agent_doc CHECK (((created_by_agent_id IS NULL) OR (kind = 'doc'::text))),
    CONSTRAINT project_material_exact_actor CHECK ((num_nonnulls(created_by, created_by_agent_id) = 1)),
    CONSTRAINT project_materials_client_mutation_check CHECK (((kind = 'doc'::text) OR ((client_mutation_id IS NOT NULL) AND (request_fingerprint IS NOT NULL)))),
    CONSTRAINT project_materials_current_version_check CHECK ((current_version > 0)),
    CONSTRAINT project_materials_kind_check CHECK ((kind = ANY (ARRAY['material'::text, 'doc'::text])))
);


--
-- Name: project_message_observations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_message_observations (
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    message_id uuid NOT NULL,
    viewer_id text NOT NULL,
    observed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: project_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_messages (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    conversation_id uuid NOT NULL,
    author_id text,
    client_message_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    sequence integer NOT NULL,
    body text NOT NULL,
    source_material_id uuid,
    source_material_version integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    author_agent_id uuid,
    contribution_kind text DEFAULT 'text'::text NOT NULL,
    attachment_count smallint DEFAULT 0 NOT NULL,
    removed_at timestamp with time zone,
    via text,
    edited_at timestamp with time zone,
    source_deleted boolean DEFAULT false NOT NULL,
    by_flux boolean DEFAULT false NOT NULL,
    via_colour text,
    CONSTRAINT project_message_attachment_count CHECK (((attachment_count >= 0) AND (attachment_count <= 10))),
    CONSTRAINT project_message_body_or_attachments CHECK ((public.flux_is_sealed(body) OR ((length(btrim(body)) <= 100000) AND ((length(btrim(body)) >= 1) OR (attachment_count > 0))))),
    CONSTRAINT project_message_by_flux_agent CHECK (((NOT by_flux) OR (author_agent_id IS NOT NULL))),
    CONSTRAINT project_message_contribution_kind CHECK ((contribution_kind = ANY (ARRAY['text'::text, 'blocker'::text, 'handoff'::text, 'came_of_it'::text]))),
    CONSTRAINT project_message_exact_actor CHECK ((num_nonnulls(author_id, author_agent_id) = 1)),
    CONSTRAINT project_message_source_deleted CHECK (((NOT source_deleted) OR ((source_material_id IS NULL) AND (source_material_version IS NULL)))),
    CONSTRAINT project_messages_check CHECK (((source_material_id IS NULL) = (source_material_version IS NULL))),
    CONSTRAINT project_messages_sequence_check CHECK ((sequence > 0)),
    CONSTRAINT project_messages_via_check CHECK (((via IS NULL) OR ((author_id IS NOT NULL) AND ((char_length(via) >= 1) AND (char_length(via) <= 80))))),
    CONSTRAINT project_messages_via_colour_check CHECK (((via_colour IS NULL) OR ((via IS NOT NULL) AND (via_colour = ANY (ARRAY['ink'::text, 'clay'::text, 'ochre'::text, 'sage'::text, 'teal'::text, 'indigo'::text, 'plum'::text, 'rose'::text])))))
);


--
-- Name: project_object_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_object_links (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    role text NOT NULL,
    from_type text NOT NULL,
    from_id uuid NOT NULL,
    to_type text NOT NULL,
    to_id uuid NOT NULL,
    to_version integer,
    created_by_kind text NOT NULL,
    created_by_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_object_links_check CHECK (((to_type = 'material'::text) = (to_version IS NOT NULL))),
    CONSTRAINT project_object_links_check1 CHECK ((NOT ((from_type = to_type) AND (from_id = to_id)))),
    CONSTRAINT project_object_links_created_by_kind_check CHECK ((created_by_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT project_object_links_from_type_check CHECK ((from_type = ANY (ARRAY['work'::text, 'decision'::text, 'doc'::text]))),
    CONSTRAINT project_object_links_role_check CHECK ((role = ANY (ARRAY['source'::text, 'affects'::text, 'related'::text, 'mentions'::text, 'part_of'::text]))),
    CONSTRAINT project_object_links_to_type_check CHECK ((to_type = ANY (ARRAY['message'::text, 'thought'::text, 'material'::text, 'work'::text, 'decision'::text, 'doc'::text, 'sketch'::text]))),
    CONSTRAINT project_object_links_to_version_check CHECK (((to_version IS NULL) OR (to_version > 0)))
);


--
-- Name: project_task_activity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_task_activity (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    work_id uuid NOT NULL,
    kind text NOT NULL,
    actor_kind text NOT NULL,
    actor_id text NOT NULL,
    detail jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_task_activity_actor_kind_check CHECK ((actor_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT project_task_activity_kind_check CHECK ((kind = ANY (ARRAY['status'::text, 'owner'::text, 'due'::text, 'title'::text])))
);


--
-- Name: project_task_dependencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_task_dependencies (
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    task_id uuid NOT NULL,
    prerequisite_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_task_dependency_not_self CHECK ((task_id <> prerequisite_id))
);


--
-- Name: project_task_discussions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_task_discussions (
    work_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    conversation_id uuid NOT NULL,
    root_message_id uuid NOT NULL,
    root_sequence integer DEFAULT 1 NOT NULL,
    CONSTRAINT project_task_discussions_root_sequence_check CHECK ((root_sequence = 1))
);


--
-- Name: project_task_notices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_task_notices (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    work_id uuid NOT NULL,
    kind text NOT NULL,
    created_by_kind text NOT NULL,
    created_by_id text NOT NULL,
    sources jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT project_task_notices_created_by_kind_check CHECK ((created_by_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT project_task_notices_kind_check CHECK ((kind = ANY (ARRAY['task.created'::text, 'task.creation_reverted'::text]))),
    CONSTRAINT project_task_notices_sources_check CHECK ((jsonb_typeof(sources) = 'array'::text))
);


--
-- Name: project_task_number_4afe924292a04ab0a010c1e3c2eb6c47; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_task_number_4afe924292a04ab0a010c1e3c2eb6c47
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_task_number_664527cf118c48f4b7fff829c0460d26; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_task_number_664527cf118c48f4b7fff829c0460d26
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_task_number_93feece2e36348a88a6851f71e062b79; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_task_number_93feece2e36348a88a6851f71e062b79
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_task_number_a86025f9f9ba46c48fd0d4949e07a97c; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_task_number_a86025f9f9ba46c48fd0d4949e07a97c
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_task_plan_intents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_task_plan_intents (
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    material_id uuid NOT NULL,
    material_version integer NOT NULL,
    intent_key text NOT NULL,
    task_id uuid NOT NULL,
    creation_fingerprint text NOT NULL,
    task_version integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_task_plan_intent_key CHECK ((((length(intent_key) >= 1) AND (length(intent_key) <= 120)) AND (intent_key = btrim(intent_key, ' 	
'::text)))),
    CONSTRAINT project_task_plan_intents_creation_fingerprint_check CHECK ((public.flux_is_sealed(creation_fingerprint) OR (creation_fingerprint ~ '^[0-9a-f]{64}$'::text))),
    CONSTRAINT project_task_plan_intents_material_version_check CHECK ((material_version > 0)),
    CONSTRAINT project_task_plan_intents_task_version_check CHECK ((task_version > 0))
);


--
-- Name: project_task_updates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_task_updates (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    work_id uuid NOT NULL,
    kind text NOT NULL,
    created_by_kind text NOT NULL,
    created_by_id text NOT NULL,
    waiting_for_user_id text,
    reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_task_updates_created_by_kind_check CHECK ((created_by_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT project_task_updates_kind_check CHECK ((kind = ANY (ARRAY['task.blocked'::text, 'task.unblocked'::text, 'task.resumed'::text])))
);


--
-- Name: project_work_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_work_items (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    title text NOT NULL,
    outcome text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    blocker text,
    owner_user_id text,
    owner_agent_id uuid,
    created_by_kind text NOT NULL,
    created_by_id text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    client_command_id uuid,
    request_fingerprint text,
    criteria jsonb DEFAULT '[]'::jsonb NOT NULL,
    creation_origin text,
    creation_baseline jsonb,
    creation_baseline_version integer,
    first_persisted_use_at timestamp with time zone,
    creation_reverted_at timestamp with time zone,
    creation_reverted_by_kind text,
    creation_reverted_by_id text,
    creation_reversion_notice_id uuid,
    number integer NOT NULL,
    waiting_for_user_id text,
    due_on date,
    waiting_for_decision_id uuid,
    waiting_for_work_id uuid,
    dropped boolean DEFAULT false NOT NULL,
    came_of_it text,
    CONSTRAINT project_work_command_pair CHECK (((client_command_id IS NULL) = (request_fingerprint IS NULL))),
    CONSTRAINT project_work_criteria_bounded CHECK ((public.flux_is_sealed(criteria) OR public.flux_task_criteria_valid(criteria))),
    CONSTRAINT project_work_items_came_of_it_length CHECK (((came_of_it IS NULL) OR (length(came_of_it) <= 20000))),
    CONSTRAINT project_work_items_check CHECK (((blocker IS NULL) OR ((status = 'blocked'::text) AND (public.flux_is_sealed(blocker) OR (length(blocker) <= 2000))))),
    CONSTRAINT project_work_items_check1 CHECK (((owner_user_id IS NULL) OR (owner_agent_id IS NULL))),
    CONSTRAINT project_work_items_created_by_kind_check CHECK ((created_by_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT project_work_items_creation_baseline_version_check CHECK ((creation_baseline_version > 0)),
    CONSTRAINT project_work_items_creation_origin_check CHECK ((creation_origin = ANY (ARRAY['native_agent'::text, 'ai_proposal'::text, 'human'::text]))),
    CONSTRAINT project_work_items_creation_reverted_by_kind_check CHECK ((creation_reverted_by_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT project_work_items_due_on_range CHECK (((due_on IS NULL) OR ((due_on >= '1970-01-01'::date) AND (due_on <= '9999-12-31'::date)))),
    CONSTRAINT project_work_items_not_waiting_for_itself CHECK ((waiting_for_work_id IS DISTINCT FROM id)),
    CONSTRAINT project_work_items_note_only_done CHECK ((((NOT dropped) AND (came_of_it IS NULL)) OR (status = 'done'::text))),
    CONSTRAINT project_work_items_one_wait CHECK ((num_nonnulls(waiting_for_user_id, waiting_for_decision_id, waiting_for_work_id) <= 1)),
    CONSTRAINT project_work_items_outcome_check CHECK ((public.flux_is_sealed(outcome) OR (length(outcome) <= 4000))),
    CONSTRAINT project_work_items_status_check CHECK ((status = ANY (ARRAY['open'::text, 'in_progress'::text, 'blocked'::text, 'done'::text]))),
    CONSTRAINT project_work_items_title_check CHECK ((public.flux_is_sealed(title) OR ((length(btrim(title)) >= 1) AND (length(btrim(title)) <= 200)))),
    CONSTRAINT project_work_items_version_check CHECK ((version > 0)),
    CONSTRAINT project_work_items_wait_only_blocked CHECK ((((waiting_for_decision_id IS NULL) AND (waiting_for_work_id IS NULL)) OR (status = 'blocked'::text))),
    CONSTRAINT task_creation_baseline_origin CHECK ((((creation_baseline_version IS NULL) = (creation_origin IS NULL)) AND ((creation_baseline IS NULL) = (creation_origin IS NULL)))),
    CONSTRAINT task_creation_reversion_shape CHECK ((((creation_reverted_at IS NULL) AND (creation_reverted_by_kind IS NULL) AND (creation_reverted_by_id IS NULL) AND (creation_reversion_notice_id IS NULL)) OR ((creation_reverted_at IS NOT NULL) AND (creation_reverted_by_kind IS NOT NULL) AND (creation_reverted_by_id IS NOT NULL) AND (creation_reversion_notice_id IS NOT NULL) AND (creation_baseline_version IS NOT NULL) AND (creation_origin = ANY (ARRAY['native_agent'::text, 'ai_proposal'::text, 'human'::text])) AND (first_persisted_use_at IS NULL))))
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    name text NOT NULL,
    visibility text DEFAULT 'workspace'::text NOT NULL,
    created_by text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT projects_name_check CHECK ((public.flux_is_sealed(name) OR ((length(btrim(name)) >= 1) AND (length(btrim(name)) <= 200)))),
    CONSTRAINT projects_version_check CHECK ((version >= 1)),
    CONSTRAINT projects_visibility_check CHECK ((visibility = ANY (ARRAY['workspace'::text, 'restricted'::text])))
);


--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_subscriptions (
    id uuid NOT NULL,
    user_id text NOT NULL,
    session_id text NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    expiration_time timestamp with time zone,
    device_label text,
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_success_at timestamp with time zone,
    last_failure_at timestamp with time zone,
    last_failure_status integer
);


--
-- Name: return_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.return_points (
    user_id text NOT NULL,
    place_key text NOT NULL,
    place_type text NOT NULL,
    project_id uuid,
    conversation_id uuid,
    seq bigint NOT NULL,
    saved_at timestamp with time zone DEFAULT now() NOT NULL,
    previous_seq bigint,
    previous_saved_at timestamp with time zone,
    CONSTRAINT return_points_check CHECK (((previous_seq IS NULL) = (previous_saved_at IS NULL))),
    CONSTRAINT return_points_check1 CHECK (((place_type = 'home'::text) = (project_id IS NULL))),
    CONSTRAINT return_points_check2 CHECK (((place_type = 'conversation'::text) = (conversation_id IS NOT NULL))),
    CONSTRAINT return_points_check3 CHECK ((place_key =
CASE place_type
    WHEN 'home'::text THEN 'home'::text
    WHEN 'project'::text THEN ('project:'::text || (project_id)::text)
    ELSE ('conversation:'::text || (conversation_id)::text)
END)),
    CONSTRAINT return_points_place_type_check CHECK ((place_type = ANY (ARRAY['home'::text, 'project'::text, 'conversation'::text]))),
    CONSTRAINT return_points_previous_seq_check CHECK (((previous_seq IS NULL) OR (previous_seq >= 0))),
    CONSTRAINT return_points_seq_check CHECK ((seq >= 0))
);


--
-- Name: sample_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sample_results (
    sample_id uuid NOT NULL,
    processed_at timestamp with time zone DEFAULT now() NOT NULL,
    worker_id text NOT NULL
);


--
-- Name: samples; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.samples (
    id uuid NOT NULL,
    title text NOT NULL,
    created_by text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sealed_job_waits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sealed_job_waits (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    queue text NOT NULL,
    payload jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    attempts integer DEFAULT 0 NOT NULL
);


--
-- Name: search_changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.search_changes (
    seq bigint NOT NULL,
    workspace_id uuid NOT NULL,
    doc_key text NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL,
    xid xid8 DEFAULT pg_current_xact_id() NOT NULL
);


--
-- Name: search_changes_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.search_changes_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: search_changes_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.search_changes_seq_seq OWNED BY public.search_changes.seq;


--
-- Name: search_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.search_documents (
    id bigint NOT NULL,
    doc_key text NOT NULL,
    kind text NOT NULL,
    workspace_id uuid NOT NULL,
    audience_key text NOT NULL,
    project_id uuid,
    object_id text NOT NULL,
    parent_id uuid,
    version integer,
    status text,
    title text DEFAULT ''::text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    author_kind text,
    author_id text,
    at timestamp with time zone NOT NULL,
    tsv tsvector GENERATED ALWAYS AS ((setweight(to_tsvector('simple'::regconfig, title), 'A'::"char") || setweight(to_tsvector('simple'::regconfig, "left"(body, 100000)), 'B'::"char"))) STORED,
    keys bigint[] GENERATED ALWAYS AS (public.search_keys(audience_key, title, body)) STORED,
    sealed boolean DEFAULT false NOT NULL,
    page integer,
    CONSTRAINT search_documents_author_kind_check CHECK ((author_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT search_documents_kind_check CHECK ((kind = ANY (ARRAY['project'::text, 'message'::text, 'dm_message'::text, 'material'::text, 'doc'::text, 'work'::text, 'decision'::text, 'result'::text, 'sketch'::text, 'thought'::text, 'draft'::text, 'person'::text, 'file'::text]))),
    CONSTRAINT search_documents_page_check CHECK (((page IS NULL) OR (page >= 1))),
    CONSTRAINT search_documents_sealed_placeholder CHECK (((NOT sealed) OR ((title = ''::text) AND (body = ''::text))))
);


--
-- Name: search_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.search_documents ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.search_documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: search_vector_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.search_vector_queue (
    document_id bigint NOT NULL,
    queued_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: search_vector_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.search_vector_state (
    only_row boolean DEFAULT true NOT NULL,
    model text NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT search_vector_state_only_row CHECK (only_row)
);


--
-- Name: search_vectors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.search_vectors (
    document_id bigint NOT NULL,
    embedding public.halfvec(1024) NOT NULL
);
ALTER TABLE ONLY public.search_vectors ALTER COLUMN embedding SET STORAGE PLAIN;


--
-- Name: sketch_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sketch_links (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    sketch_id uuid NOT NULL,
    from_id uuid NOT NULL,
    to_id uuid NOT NULL,
    label text,
    created_by_user_id text,
    created_by_agent_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT sketch_links_check CHECK ((from_id <> to_id)),
    CONSTRAINT sketch_links_check1 CHECK (((created_by_user_id IS NULL) <> (created_by_agent_id IS NULL))),
    CONSTRAINT sketch_links_label_check CHECK ((public.flux_is_sealed(label) OR ((label IS NULL) OR ((length(btrim(label)) >= 1) AND (length(btrim(label)) <= 80)))))
);


--
-- Name: sketch_thoughts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sketch_thoughts (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    sketch_id uuid NOT NULL,
    text text NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    width integer DEFAULT 184 NOT NULL,
    height integer DEFAULT 72 NOT NULL,
    shape text DEFAULT 'card'::text NOT NULL,
    created_by_user_id text,
    created_by_agent_id uuid,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    source_author_id text,
    source_author_name text,
    source_sent_at timestamp with time zone,
    source_author_agent_id uuid,
    source_project_message_id uuid,
    edited_by text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT sketch_thoughts_check1 CHECK (((created_by_user_id IS NULL) <> (created_by_agent_id IS NULL))),
    CONSTRAINT sketch_thoughts_height_check CHECK (((height >= 40) AND (height <= 800))),
    CONSTRAINT sketch_thoughts_shape_check CHECK ((shape = ANY (ARRAY['card'::text, 'pill'::text, 'circle'::text]))),
    CONSTRAINT sketch_thoughts_source_author_kind_check CHECK ((num_nonnulls(source_author_id, source_author_agent_id) = ANY (ARRAY[0, 1]))),
    CONSTRAINT sketch_thoughts_source_presence_check CHECK ((((source_sent_at IS NULL) = (source_author_name IS NULL)) AND ((source_sent_at IS NULL) = (num_nonnulls(source_author_id, source_author_agent_id) = 0)))),
    CONSTRAINT sketch_thoughts_source_project_message_check CHECK (((source_project_message_id IS NULL) OR ((source_sent_at IS NOT NULL) AND (num_nonnulls(source_author_id, source_author_agent_id) = 1)))),
    CONSTRAINT sketch_thoughts_text_check CHECK ((public.flux_is_sealed(text) OR ((length(btrim(text)) >= 1) AND (length(btrim(text)) <= 1000)))),
    CONSTRAINT sketch_thoughts_version_check CHECK ((version >= 1)),
    CONSTRAINT sketch_thoughts_width_check CHECK (((width >= 80) AND (width <= 800))),
    CONSTRAINT sketch_thoughts_x_check CHECK (((x >= '-100000'::integer) AND (x <= 100000))),
    CONSTRAINT sketch_thoughts_y_check CHECK (((y >= '-100000'::integer) AND (y <= 100000)))
);


--
-- Name: sketches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sketches (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    scope text NOT NULL,
    project_id uuid,
    title text NOT NULL,
    created_by_user_id text,
    created_by_agent_id uuid,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    edited_by text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT sketches_check CHECK (((scope = 'project'::text) = (project_id IS NOT NULL))),
    CONSTRAINT sketches_check1 CHECK (((scope <> 'private'::text) OR (created_by_user_id IS NOT NULL))),
    CONSTRAINT sketches_check2 CHECK (((created_by_user_id IS NULL) <> (created_by_agent_id IS NULL))),
    CONSTRAINT sketches_dm_person_check CHECK (((scope <> 'dm'::text) OR (created_by_user_id IS NOT NULL))),
    CONSTRAINT sketches_scope_check CHECK ((scope = ANY (ARRAY['project'::text, 'private'::text]))),
    CONSTRAINT sketches_title_check CHECK ((public.flux_is_sealed(title) OR ((length(btrim(title)) >= 1) AND (length(btrim(title)) <= 200)))),
    CONSTRAINT sketches_version_check CHECK ((version >= 1))
);


--
-- Name: space_icons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.space_icons (
    project_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    emoji text,
    picture uuid,
    object_64 uuid,
    object_128 uuid,
    object_256 uuid,
    changed_by text NOT NULL,
    changed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT space_icons_one_kind CHECK ((((emoji IS NOT NULL) AND ((char_length(emoji) >= 1) AND (char_length(emoji) <= 32)) AND (picture IS NULL) AND (object_64 IS NULL) AND (object_128 IS NULL) AND (object_256 IS NULL)) OR ((emoji IS NULL) AND (picture IS NOT NULL) AND (object_64 IS NOT NULL) AND (object_128 IS NOT NULL) AND (object_256 IS NOT NULL))))
);


--
-- Name: space_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.space_order (
    user_id text NOT NULL,
    project_id uuid NOT NULL,
    "position" integer NOT NULL,
    CONSTRAINT space_order_position_check CHECK (("position" >= 0))
);


--
-- Name: task_creation_undo_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_creation_undo_receipts (
    workspace_id uuid NOT NULL,
    project_id uuid NOT NULL,
    actor_kind text NOT NULL,
    actor_id text NOT NULL,
    client_command_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    work_id uuid NOT NULL,
    notice_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT task_creation_undo_receipts_actor_kind_check CHECK ((actor_kind = ANY (ARRAY['human'::text, 'agent'::text]))),
    CONSTRAINT task_creation_undo_receipts_request_fingerprint_check CHECK ((public.flux_is_sealed(request_fingerprint) OR (request_fingerprint ~ '^[a-f0-9]{64}$'::text)))
);


--
-- Name: workspace_dek_wraps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_dek_wraps (
    holder_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    key_version integer NOT NULL,
    ephemeral_public text NOT NULL,
    sealed_dek text NOT NULL,
    confirm text,
    CONSTRAINT workspace_dek_wraps_key_version_check CHECK ((key_version >= 1))
);


--
-- Name: workspace_holders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_holders (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    kind text NOT NULL,
    user_id text,
    kdf jsonb NOT NULL,
    public_key text NOT NULL,
    wrapped_private text NOT NULL,
    holder_mac text NOT NULL,
    holder_mac_version integer NOT NULL,
    secret_check text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    confirmed_versions integer[] DEFAULT '{}'::integer[] NOT NULL,
    pin text,
    CONSTRAINT workspace_holders_check CHECK (((kind = 'recovery'::text) = (user_id IS NULL))),
    CONSTRAINT workspace_holders_holder_mac_version_check CHECK ((holder_mac_version >= 1)),
    CONSTRAINT workspace_holders_kdf_check CHECK ((jsonb_typeof(kdf) = 'object'::text)),
    CONSTRAINT workspace_holders_kind_check CHECK ((kind = ANY (ARRAY['password'::text, 'recovery'::text])))
);


--
-- Name: workspace_invites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_invites (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    role text NOT NULL,
    email text,
    token_hash text NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    revoked_by text,
    accepted_at timestamp with time zone,
    accepted_by text,
    space_id uuid,
    CONSTRAINT workspace_invites_check CHECK ((expires_at > created_at)),
    CONSTRAINT workspace_invites_check1 CHECK (((revoked_at IS NULL) OR (accepted_at IS NULL))),
    CONSTRAINT workspace_invites_email_check CHECK (((email IS NULL) OR ((email = lower(email)) AND ((length(email) >= 3) AND (length(email) <= 320))))),
    CONSTRAINT workspace_invites_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'member'::text, 'guest'::text]))),
    CONSTRAINT workspace_invites_token_hash_check CHECK ((token_hash ~ '^[0-9a-f]{64}$'::text))
);


--
-- Name: workspace_key_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_key_versions (
    workspace_id uuid NOT NULL,
    key_version integer NOT NULL,
    commitment text,
    check_value text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    pin text,
    CONSTRAINT workspace_key_versions_check CHECK (((key_version = 1) = (commitment IS NULL))),
    CONSTRAINT workspace_key_versions_key_version_check CHECK ((key_version >= 1))
);


--
-- Name: workspace_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_keys (
    workspace_id uuid NOT NULL,
    current_version integer DEFAULT 1 NOT NULL,
    live_versions integer[] DEFAULT '{1}'::integer[] NOT NULL,
    rotation text DEFAULT 'none'::text NOT NULL,
    rotation_reason jsonb,
    tampered_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    removal_head text,
    key_change_reason jsonb,
    CONSTRAINT workspace_keys_check CHECK (((cardinality(live_versions) >= 1) AND (current_version = public.flux_max_version(live_versions)))),
    CONSTRAINT workspace_keys_current_version_check CHECK ((current_version >= 1)),
    CONSTRAINT workspace_keys_key_change_reason_check CHECK (((key_change_reason IS NULL) OR (jsonb_typeof(key_change_reason) = 'object'::text))),
    CONSTRAINT workspace_keys_rotation_check CHECK ((rotation = ANY (ARRAY['none'::text, 'pending'::text, 'reencrypting'::text]))),
    CONSTRAINT workspace_keys_rotation_reason_check CHECK (((rotation_reason IS NULL) OR (jsonb_typeof(rotation_reason) = 'object'::text)))
);


--
-- Name: workspace_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_members (
    workspace_id uuid NOT NULL,
    user_id text NOT NULL,
    role text NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT workspace_members_role_check CHECK ((role = ANY (ARRAY['owner'::text, 'admin'::text, 'member'::text, 'guest'::text])))
);


--
-- Name: workspace_removals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_removals (
    workspace_id uuid NOT NULL,
    seq integer NOT NULL,
    holder_id uuid NOT NULL,
    user_id text,
    public_key text NOT NULL,
    removed_version integer NOT NULL,
    pin text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT workspace_removals_removed_version_check CHECK ((removed_version >= 1)),
    CONSTRAINT workspace_removals_seq_check CHECK ((seq >= 1))
);


--
-- Name: workspace_removed_holders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_removed_holders (
    workspace_id uuid NOT NULL,
    holder_id uuid NOT NULL,
    user_id text,
    public_key text NOT NULL,
    removed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workspace_removed_people; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_removed_people (
    workspace_id uuid NOT NULL,
    user_id text NOT NULL,
    removed_by text NOT NULL,
    removed_at timestamp with time zone DEFAULT now() NOT NULL,
    role text NOT NULL,
    kept jsonb NOT NULL,
    CONSTRAINT workspace_removed_people_kept_check CHECK (((jsonb_typeof((kept -> 'spaces'::text)) = 'array'::text) AND (jsonb_typeof((kept -> 'dms'::text)) = 'array'::text))),
    CONSTRAINT workspace_removed_people_role_check CHECK ((role = ANY (ARRAY['owner'::text, 'admin'::text, 'member'::text, 'guest'::text])))
);


--
-- Name: workspace_rotation_progress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_rotation_progress (
    workspace_id uuid NOT NULL,
    target_version integer NOT NULL,
    step text NOT NULL,
    cursor jsonb,
    rows_done bigint DEFAULT 0 NOT NULL,
    rows_estimate bigint DEFAULT 0 NOT NULL,
    passes integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    stalled_on text,
    stalled_at timestamp with time zone,
    pass_changes bigint DEFAULT 0 NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workspace_unlocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_unlocks (
    workspace_id uuid NOT NULL,
    key_version integer NOT NULL,
    boot_id uuid NOT NULL,
    sealed_dek text NOT NULL,
    unlocked_by text,
    unlocked_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT workspace_unlocks_key_version_check CHECK ((key_version >= 1))
);


--
-- Name: workspace_wrap_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_wrap_grants (
    workspace_id uuid NOT NULL,
    user_id text NOT NULL,
    granted_by text NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: workspaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspaces (
    id uuid NOT NULL,
    name text NOT NULL,
    created_by text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    encrypted boolean DEFAULT false NOT NULL,
    creation_id uuid,
    company boolean DEFAULT false NOT NULL,
    company_workspace_id uuid,
    CONSTRAINT workspaces_company_workspace_check CHECK (((company_workspace_id IS NULL) OR (encrypted AND (company_workspace_id <> id)))),
    CONSTRAINT workspaces_name_check CHECK (((length(btrim(name)) >= 1) AND (length(btrim(name)) <= 200))),
    CONSTRAINT workspaces_version_check CHECK ((version >= 1))
);


--
-- Name: job_common; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job ATTACH PARTITION pgboss.job_common DEFAULT;


--
-- Name: queue_stats_20261120; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats ATTACH PARTITION pgboss.queue_stats_20261120 FOR VALUES FROM ('2026-11-20 00:00:00+00') TO ('2026-11-21 00:00:00+00');


--
-- Name: queue_stats_20261121; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats ATTACH PARTITION pgboss.queue_stats_20261121 FOR VALUES FROM ('2026-11-21 00:00:00+00') TO ('2026-11-22 00:00:00+00');


--
-- Name: search_changes seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_changes ALTER COLUMN seq SET DEFAULT nextval('public.search_changes_seq_seq'::regclass);


--
-- Data for Name: _typmod_cache; Type: TABLE DATA; Schema: paradedb; Owner: -
--

INSERT INTO paradedb._typmod_cache VALUES (1, '{ascii_folding=true,stemmer=polish,alias=title_pl}');
INSERT INTO paradedb._typmod_cache VALUES (2, '{ascii_folding=true,stemmer=english,alias=title_en}');
INSERT INTO paradedb._typmod_cache VALUES (3, '{ascii_folding=true,stemmer=polish,alias=body_pl}');
INSERT INTO paradedb._typmod_cache VALUES (4, '{ascii_folding=true,stemmer=english,alias=body_en}');
INSERT INTO paradedb._typmod_cache VALUES (5, '{ascii_folding=true,stemmer=english,alias=title_joined}');
INSERT INTO paradedb._typmod_cache VALUES (6, '{ascii_folding=true,stemmer=english,alias=body_joined}');


--
-- Data for Name: bam; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: instance; Type: TABLE DATA; Schema: pgboss; Owner: -
--

INSERT INTO pgboss.instance VALUES ('47d057e9-23bc-4411-a56a-434efb115833', NULL, '811e2eee3745', 1, '12.38.1', 'v24.22.2', 'pgboss:47d057e9', 30, true, true, true, false, false, 10, 2, 1, 1, '[]', '{"cpu": null, "rss": 328269824, "cgroup": 2, "cpuLimit": 24, "heapUsed": 38957584, "heapLimit": 4496293888, "loopDelay": null, "memoryUsed": null, "memoryLimit": 66457145344, "cpuThrottled": null, "loopDelayMax": null, "loopUtilization": null}', '{"adapter": "pg", "backend": "postgres", "migrate": true, "reindex": true, "schedule": true, "supervise": true, "createSchema": true, "useListenNotify": false, "bamIntervalSeconds": 60, "flowIntervalSeconds": 5, "warningRetentionDays": 365, "monitorIntervalSeconds": 60, "queueStatRetentionDays": 7, "reindexIntervalSeconds": 86400, "instanceHeartbeatSeconds": 30, "superviseIntervalSeconds": 60, "cronWorkerIntervalSeconds": 5, "queueCacheIntervalSeconds": 60, "cronMonitorIntervalSeconds": 30, "maintenanceIntervalSeconds": 86400, "clockMonitorIntervalSeconds": 600}', 0, NULL, '2026-11-20 11:26:35.469881+00', '2026-11-20 11:26:35.469881+00', '2026-11-20 11:26:36.001038+00');
INSERT INTO pgboss.instance VALUES ('accb5ee1-8e0e-4d84-bf9e-2e6f3852898e', NULL, '4829e7aac5cb', 1, '12.38.1', 'v24.22.2', 'pgboss:accb5ee1', 300, true, true, false, false, false, 10, 2, 1, 1, '[]', '{"cpu": null, "rss": 108244992, "cgroup": 2, "cpuLimit": 24, "heapUsed": 33568008, "heapLimit": 271581184, "loopDelay": null, "memoryUsed": 56451072, "memoryLimit": 536870912, "cpuThrottled": null, "loopDelayMax": null, "loopUtilization": null}', '{"adapter": "pg", "backend": "postgres", "migrate": false, "reindex": true, "schedule": true, "supervise": true, "createSchema": true, "useListenNotify": true, "bamIntervalSeconds": 60, "flowIntervalSeconds": 120, "warningRetentionDays": 365, "monitorIntervalSeconds": 60, "queueStatRetentionDays": 7, "reindexIntervalSeconds": 86400, "instanceHeartbeatSeconds": 300, "superviseIntervalSeconds": 60, "cronWorkerIntervalSeconds": 15, "queueCacheIntervalSeconds": 300, "cronMonitorIntervalSeconds": 30, "maintenanceIntervalSeconds": 86400, "clockMonitorIntervalSeconds": 600}', 0, NULL, '2026-11-20 11:26:39.349796+00', '2026-11-20 11:26:39.349796+00', NULL);
INSERT INTO pgboss.instance VALUES ('1dff13b1-3ad8-4dcd-a945-1702b637b6c4', NULL, '0ef65d75cdc8', 1, '12.38.1', 'v24.22.2', 'pgboss:1dff13b1', 300, false, false, false, false, false, 10, 1, 1, 0, '[]', '{"cpu": null, "rss": 292511744, "cgroup": 2, "cpuLimit": 24, "heapUsed": 100705272, "heapLimit": 905969664, "loopDelay": null, "memoryUsed": 259850240, "memoryLimit": 1610612736, "cpuThrottled": null, "loopDelayMax": null, "loopUtilization": null}', '{"adapter": "pg", "backend": "postgres", "migrate": false, "reindex": true, "schedule": false, "supervise": false, "createSchema": true, "useListenNotify": false, "bamIntervalSeconds": 60, "flowIntervalSeconds": 5, "warningRetentionDays": 365, "monitorIntervalSeconds": 60, "queueStatRetentionDays": 7, "reindexIntervalSeconds": 86400, "instanceHeartbeatSeconds": 300, "superviseIntervalSeconds": 60, "cronWorkerIntervalSeconds": 5, "queueCacheIntervalSeconds": 60, "cronMonitorIntervalSeconds": 30, "maintenanceIntervalSeconds": 86400, "clockMonitorIntervalSeconds": 600}', 0, NULL, '2026-11-20 11:26:41.490601+00', '2026-11-20 11:26:41.490601+00', NULL);


--
-- Data for Name: job_common; Type: TABLE DATA; Schema: pgboss; Owner: -
--

INSERT INTO pgboss.job_common VALUES ('c87064e2-1b21-4bba-af39-f7a98b84f350', 'ai-price-list.refresh.v1', 0, '{}', 'completed', 3, 0, 900, false, NULL, 900, 604800, 'start', NULL, NULL, NULL, '2026-11-20 11:26:39.544875+00', '2026-11-20 11:26:39.544875+00', '2026-11-20 11:26:39.561029+00', '2026-11-20 11:26:41.105667+00', '2026-12-04 11:26:39.544875+00', NULL, NULL, 'singleton', '2026-11-20 11:26:39.561029+00', NULL, false, false, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO pgboss.job_common VALUES ('f1df8678-ca35-4818-ad69-c2b152bc8a4e', 'personal-run.dispatch.v1', 0, '{"runId": "4bf28a7e-832f-4fda-ac69-c8d63724a780"}', 'completed', 0, 0, 0, false, NULL, 4200, 604800, NULL, NULL, NULL, NULL, '2026-11-20 11:26:46.739513+00', '2026-11-20 11:26:46.739513+00', '2026-11-20 11:26:46.780985+00', '2026-11-20 11:26:46.809784+00', '2026-12-04 11:26:46.739513+00', NULL, NULL, 'standard', '2026-11-20 11:26:46.780985+00', NULL, false, false, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);


--
-- Data for Name: job_dependency; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: queue; Type: TABLE DATA; Schema: pgboss; Owner: -
--

INSERT INTO pgboss.queue VALUES ('__pgboss__send-it', 'standard', 2, 0, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, false, NULL, NULL, NULL, NULL, '2026-11-20 11:26:35.436573+00', '2026-11-20 11:26:35.436573+00');
INSERT INTO pgboss.queue VALUES ('sample.process', 'standard', 2, 0, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-20 11:26:35.651215+00', '2026-11-20 11:26:35.661587+00');
INSERT INTO pgboss.queue VALUES ('draft.summarize.v1', 'standard', 2, 0, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-20 11:26:35.670919+00', '2026-11-20 11:26:35.681388+00');
INSERT INTO pgboss.queue VALUES ('idempotency.cleanup.v1', 'standard', 2, 0, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-20 11:26:35.691216+00', '2026-11-20 11:26:35.700938+00');
INSERT INTO pgboss.queue VALUES ('push.send', 'standard', 5, 10, true, 600, 60, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-20 11:26:35.717394+00', '2026-11-20 11:26:35.727625+00');
INSERT INTO pgboss.queue VALUES ('notification.email.v1', 'standard', 5, 30, true, 900, 120, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-20 11:26:35.737451+00', '2026-11-20 11:26:35.749518+00');
INSERT INTO pgboss.queue VALUES ('personal-run.dispatch.v1', 'standard', 0, 0, false, NULL, 4200, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-20 11:26:35.761084+00', '2026-11-20 11:26:35.77199+00');
INSERT INTO pgboss.queue VALUES ('assistant.background.tick.v1', 'singleton', 0, 0, false, NULL, 300, 1209600, 86400, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', 30, true, NULL, NULL, NULL, NULL, '2026-11-20 11:26:35.782375+00', '2026-11-20 11:26:35.802313+00');
INSERT INTO pgboss.queue VALUES ('space-ai.sweep.v1', 'standard', 5, 5, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-20 11:26:35.814903+00', '2026-11-20 11:26:35.835389+00');
INSERT INTO pgboss.queue VALUES ('workspace-encryption.resume.v1', 'standard', 5, 5, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-20 11:26:35.847113+00', '2026-11-20 11:26:35.86633+00');
INSERT INTO pgboss.queue VALUES ('search-changes.cleanup.v1', 'standard', 2, 0, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-20 11:26:35.885329+00', '2026-11-20 11:26:35.904566+00');
INSERT INTO pgboss.queue VALUES ('api-key.model-list.v1', 'short', 0, 0, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-20 11:26:35.92168+00', '2026-11-20 11:26:35.94074+00');
INSERT INTO pgboss.queue VALUES ('ai-price-list.refresh.v1', 'singleton', 3, 900, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '{}', NULL, true, NULL, NULL, NULL, NULL, '2026-11-20 11:26:35.961975+00', '2026-11-20 11:26:35.979349+00');


--
-- Data for Name: queue_stats_20261120; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: queue_stats_20261121; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: schedule; Type: TABLE DATA; Schema: pgboss; Owner: -
--

INSERT INTO pgboss.schedule VALUES ('assistant.background.tick.v1', '', 'cron', '* * * * *', 'UTC', NULL, '{}', '2026-11-20 11:26:39.440076+00', '2026-11-20 11:26:39.440076+00', NULL);
INSERT INTO pgboss.schedule VALUES ('idempotency.cleanup.v1', '', 'cron', '17 * * * *', 'UTC', NULL, '{}', '2026-11-20 11:26:39.46941+00', '2026-11-20 11:26:39.46941+00', NULL);
INSERT INTO pgboss.schedule VALUES ('search-changes.cleanup.v1', '', 'cron', '37 * * * *', 'UTC', NULL, '{}', '2026-11-20 11:26:39.507728+00', '2026-11-20 11:26:39.507728+00', NULL);
INSERT INTO pgboss.schedule VALUES ('ai-price-list.refresh.v1', '', 'cron', '17 4 * * *', 'UTC', NULL, '{}', '2026-11-20 11:26:39.527422+00', '2026-11-20 11:26:39.527422+00', NULL);


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: version; Type: TABLE DATA; Schema: pgboss; Owner: -
--

INSERT INTO pgboss.version VALUES (46, '2026-11-20 11:26:35.472765+00', '2026-11-20 11:26:35.472842+00', '2026-11-20 11:26:35.443348+00', NULL, NULL);


--
-- Data for Name: warning; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: agent_chat_file_text; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_chat_messages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_chat_reads; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_command_receipts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_connections; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.agent_connections VALUES ('6a8281f1-8349-409d-a97c-dc6498e9b37a', '79bbedd2-67db-4944-a1b6-55c9a4553889', '11c2823a-c8ac-4431-955a-a5ca0948254b', '1185d65b-0e5e-42cb-b620-bf84e8855d13', NULL, '2026-11-20 11:26:46.53095+00', '2026-11-20 11:26:46.53095+00', 'Assistant', 'other', 'owner_assistant', 'act');
INSERT INTO public.agent_connections VALUES ('308b53da-cb7a-4029-94a0-e40cd7141398', '79bbedd2-67db-4944-a1b6-55c9a4553889', '11c2823a-c8ac-4431-955a-a5ca0948254b', '154e1a8e-024d-40ed-9f26-9403774a7331', NULL, '2026-11-20 11:26:46.580006+00', '2026-11-20 11:26:46.580006+00', 'Planner bd0292a3', 'other', 'owner_assistant', 'act');


--
-- Data for Name: agent_memory_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.agent_memory_items VALUES ('654d2b1b-1026-4361-889d-5bb43b1f9ba8', '154e1a8e-024d-40ed-9f26-9403774a7331', '79bbedd2-67db-4944-a1b6-55c9a4553889', '11c2823a-c8ac-4431-955a-a5ca0948254b', 'The garden is on the north side (bd0292a3)', 'Added by you', '2026-11-20 11:26:46.616964+00', '2026-11-20 11:26:46.616964+00');
INSERT INTO public.agent_memory_items VALUES ('a46e6a33-5ee4-4ecd-886a-f8a82f2f12dd', '154e1a8e-024d-40ed-9f26-9403774a7331', '79bbedd2-67db-4944-a1b6-55c9a4553889', '11c2823a-c8ac-4431-955a-a5ca0948254b', 'Water on Mondays (bd0292a3)', 'Added by you', '2026-11-20 11:26:46.657088+00', '2026-11-20 11:26:46.657088+00');


--
-- Data for Name: agent_oauth_bindings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_playbook_acknowledgments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_proposals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_questions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_runtime_auth_admission; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.agent_runtime_auth_admission VALUES (true, false, NULL, '2026-11-20 11:26:33.296688+00');


--
-- Data for Name: agent_runtime_auth_operations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_runtime_bindings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.agent_runtime_bindings VALUES ('8cf7aa5e-b024-4508-8564-36f0160ec9ab', '11c2823a-c8ac-4431-955a-a5ca0948254b', 'runtime-1', 'active', '2026-11-20 11:26:46.862252+00', '2026-11-20 11:26:47.084928+00', NULL, NULL, NULL, NULL);


--
-- Data for Name: agent_runtime_client_history; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_runtime_connection_models; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_runtime_connections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_runtime_console_nonces; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_runtime_operator_statements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_runtime_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_runtime_slots; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.agent_runtime_slots VALUES ('runtime-1', 'ready', '8bfdf895-6181-45ca-8118-5cd3ad79c437', NULL, '2026-11-20 11:26:49.615692+00', '2026-11-20 11:26:39.626705+00', 2);


--
-- Data for Name: agent_stops; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_task_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_task_taking; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.agents VALUES ('1185d65b-0e5e-42cb-b620-bf84e8855d13', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'Assistant', '11c2823a-c8ac-4431-955a-a5ca0948254b', '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, '2026-11-20 11:26:46.53095+00', '2026-11-20 11:26:46.53095+00');
INSERT INTO public.agents VALUES ('154e1a8e-024d-40ed-9f26-9403774a7331', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'Planner bd0292a3', '11c2823a-c8ac-4431-955a-a5ca0948254b', '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, '2026-11-20 11:26:46.580006+00', '2026-11-20 11:26:46.580006+00');


--
-- Data for Name: ai_price_lists; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ai_price_lists VALUES ('litellm', '2026-11-20', 'https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json', '{"gemini": {"genie-4": {"inputMicrosPerMTok": 1500000, "outputMicrosPerMTok": 9000000}, "lyria-3.5": {"inputMicrosPerMTok": 0, "outputMicrosPerMTok": 0}, "gemini-4-neon": {"inputMicrosPerMTok": 3000000, "outputMicrosPerMTok": 15000000}, "gemini-2.5-pro": {"tiers": [{"fromTokens": 200001, "inputMicrosPerMTok": 2500000, "outputMicrosPerMTok": 15000000}], "inputMicrosPerMTok": 1250000, "outputMicrosPerMTok": 10000000}, "gemini-4-argon": {"inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 10000000}, "gemma-3-27b-it": {"tiers": [{"fromTokens": 128001, "inputMicrosPerMTok": 0, "outputMicrosPerMTok": 0}], "inputMicrosPerMTok": 0, "outputMicrosPerMTok": 0}, "gemma-4-31b-it": {"inputMicrosPerMTok": 0, "outputMicrosPerMTok": 0}, "gemini-4-carbon": {"inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 10000000}, "gemini-exp-1114": {"tiers": [{"fromTokens": 128001, "inputMicrosPerMTok": 0, "outputMicrosPerMTok": 0}], "inputMicrosPerMTok": 0, "outputMicrosPerMTok": 0}, "gemini-exp-1206": {"tiers": [{"fromTokens": 128001, "inputMicrosPerMTok": 0, "outputMicrosPerMTok": 0}], "inputMicrosPerMTok": 0, "outputMicrosPerMTok": 0}, "gemini-2.5-flash": {"inputMicrosPerMTok": 300000, "outputMicrosPerMTok": 2500000}, "gemini-3.5-flash": {"inputMicrosPerMTok": 1500000, "outputMicrosPerMTok": 9000000}, "gemini-3.6-flash": {"inputMicrosPerMTok": 750000, "outputMicrosPerMTok": 3750000}, "gemini-3.7-flash": {"inputMicrosPerMTok": 750000, "outputMicrosPerMTok": 3750000}, "gemini-3.8-flash": {"inputMicrosPerMTok": 750000, "outputMicrosPerMTok": 3750000}, "gemini-4-hydrogen": {"inputMicrosPerMTok": 1500000, "outputMicrosPerMTok": 7500000}, "gemini-pro-latest": {"tiers": [{"fromTokens": 200001, "inputMicrosPerMTok": 4000000, "outputMicrosPerMTok": 18000000}], "inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 12000000}, "gemma-4-26b-a4b-it": {"inputMicrosPerMTok": 0, "outputMicrosPerMTok": 0}, "lyria-realtime-exp": {"inputMicrosPerMTok": 0, "outputMicrosPerMTok": 0}, "gemini-flash-latest": {"inputMicrosPerMTok": 750000, "outputMicrosPerMTok": 3750000}, "lyria-3-pro-preview": {"inputMicrosPerMTok": 0, "outputMicrosPerMTok": 0}, "gemini-gemma-2-9b-it": {"inputMicrosPerMTok": 350000, "outputMicrosPerMTok": 1050000}, "lyria-3-clip-preview": {"inputMicrosPerMTok": 0, "outputMicrosPerMTok": 0}, "gemini-2.5-flash-lite": {"inputMicrosPerMTok": 100000, "outputMicrosPerMTok": 400000}, "gemini-3.1-flash-lite": {"inputMicrosPerMTok": 250000, "outputMicrosPerMTok": 1500000}, "gemini-3.5-flash-lite": {"inputMicrosPerMTok": 300000, "outputMicrosPerMTok": 2500000}, "gemini-gemma-2-27b-it": {"inputMicrosPerMTok": 350000, "outputMicrosPerMTok": 1050000}, "gemini-omni-1.1-flash": {"inputMicrosPerMTok": 1500000, "outputMicrosPerMTok": 9000000}, "gemini-omni-1.2-flash": {"inputMicrosPerMTok": 1500000, "outputMicrosPerMTok": 9000000}, "lyria-3.5-pro-preview": {"inputMicrosPerMTok": 0, "outputMicrosPerMTok": 0}, "gemini-3-flash-preview": {"inputMicrosPerMTok": 500000, "outputMicrosPerMTok": 3000000}, "gemini-3.1-pro-preview": {"tiers": [{"fromTokens": 200001, "inputMicrosPerMTok": 4000000, "outputMicrosPerMTok": 18000000}], "inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 12000000}, "lyria-3.5-clip-preview": {"inputMicrosPerMTok": 0, "outputMicrosPerMTok": 0}, "gemini-flash-lite-latest": {"inputMicrosPerMTok": 300000, "outputMicrosPerMTok": 2500000}, "gemini-omni-flash-preview": {"inputMicrosPerMTok": 1500000, "outputMicrosPerMTok": 9000000}, "gemini-2.5-pro-preview-tts": {"inputMicrosPerMTok": 1000000, "outputMicrosPerMTok": 20000000}, "gemini-robotics-er-2-preview": {"inputMicrosPerMTok": 1000000, "outputMicrosPerMTok": 5000000}, "learnlm-1.5-pro-experimental": {"tiers": [{"fromTokens": 128001, "inputMicrosPerMTok": 0, "outputMicrosPerMTok": 0}], "inputMicrosPerMTok": 0, "outputMicrosPerMTok": 0}, "deep-research-preview-04-2026": {"inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 12000000}, "gemini-3.1-flash-lite-preview": {"inputMicrosPerMTok": 250000, "outputMicrosPerMTok": 1500000}, "deep-research-max-preview-04-2026": {"inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 12000000}, "deep-research-pro-preview-12-2025": {"inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 12000000}, "gemini-3.1-pro-preview-customtools": {"tiers": [{"fromTokens": 200001, "inputMicrosPerMTok": 4000000, "outputMicrosPerMTok": 18000000}], "inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 12000000}, "gemini-robotics-er-2-streaming-preview": {"inputMicrosPerMTok": 1000000, "outputMicrosPerMTok": 5000000}, "gemini-2.5-computer-use-preview-10-2025": {"tiers": [{"fromTokens": 200001, "inputMicrosPerMTok": 2500000, "outputMicrosPerMTok": 15000000}], "inputMicrosPerMTok": 1250000, "outputMicrosPerMTok": 10000000}}, "openai": {"o1": {"inputMicrosPerMTok": 15000000, "outputMicrosPerMTok": 60000000}, "o3": {"inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 8000000}, "gpt-4": {"inputMicrosPerMTok": 30000000, "outputMicrosPerMTok": 60000000}, "gpt-5": {"inputMicrosPerMTok": 1250000, "outputMicrosPerMTok": 10000000}, "gpt-4o": {"inputMicrosPerMTok": 2500000, "outputMicrosPerMTok": 10000000}, "o1-pro": {"inputMicrosPerMTok": 150000000, "outputMicrosPerMTok": 600000000}, "o3-pro": {"inputMicrosPerMTok": 20000000, "outputMicrosPerMTok": 80000000}, "gpt-4.1": {"inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 8000000}, "gpt-5.1": {"inputMicrosPerMTok": 1250000, "outputMicrosPerMTok": 10000000}, "gpt-5.2": {"inputMicrosPerMTok": 1750000, "outputMicrosPerMTok": 14000000}, "gpt-5.4": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 5000000, "outputMicrosPerMTok": 22500000}], "inputMicrosPerMTok": 2500000, "outputMicrosPerMTok": 15000000}, "gpt-5.5": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 10000000, "outputMicrosPerMTok": 45000000}], "inputMicrosPerMTok": 5000000, "outputMicrosPerMTok": 30000000}, "gpt-5.6": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 8000000, "outputMicrosPerMTok": 30000000}], "inputMicrosPerMTok": 4000000, "outputMicrosPerMTok": 20000000}, "o3-mini": {"inputMicrosPerMTok": 1100000, "outputMicrosPerMTok": 4400000}, "o4-mini": {"inputMicrosPerMTok": 1100000, "outputMicrosPerMTok": 4400000}, "gpt-5-pro": {"inputMicrosPerMTok": 15000000, "outputMicrosPerMTok": 120000000}, "gpt-6-sol": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 4000000, "outputMicrosPerMTok": 15000000}], "inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 10000000}, "gpt-audio": {"inputMicrosPerMTok": 2500000, "outputMicrosPerMTok": 10000000}, "gpt-4-0613": {"inputMicrosPerMTok": 30000000, "outputMicrosPerMTok": 60000000}, "gpt-5-chat": {"inputMicrosPerMTok": 1250000, "outputMicrosPerMTok": 10000000}, "gpt-5-mini": {"inputMicrosPerMTok": 250000, "outputMicrosPerMTok": 2000000}, "gpt-5-nano": {"inputMicrosPerMTok": 50000, "outputMicrosPerMTok": 400000}, "gpt-6-luna": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 200000, "outputMicrosPerMTok": 750000}], "inputMicrosPerMTok": 100000, "outputMicrosPerMTok": 500000}, "chat-latest": {"inputMicrosPerMTok": 5000000, "outputMicrosPerMTok": 30000000}, "gpt-4-turbo": {"inputMicrosPerMTok": 10000000, "outputMicrosPerMTok": 30000000}, "gpt-4o-mini": {"inputMicrosPerMTok": 150000, "outputMicrosPerMTok": 600000}, "gpt-5-codex": {"inputMicrosPerMTok": 1250000, "outputMicrosPerMTok": 10000000}, "gpt-5.2-pro": {"inputMicrosPerMTok": 21000000, "outputMicrosPerMTok": 168000000}, "gpt-5.4-pro": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 60000000, "outputMicrosPerMTok": 270000000}], "inputMicrosPerMTok": 30000000, "outputMicrosPerMTok": 180000000}, "gpt-5.5-pro": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 60000000, "outputMicrosPerMTok": 270000000}], "inputMicrosPerMTok": 30000000, "outputMicrosPerMTok": 180000000}, "gpt-5.6-sol": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 8000000, "outputMicrosPerMTok": 30000000}], "inputMicrosPerMTok": 4000000, "outputMicrosPerMTok": 20000000}, "gpt-6-astra": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 20000000, "outputMicrosPerMTok": 75000000}], "inputMicrosPerMTok": 10000000, "outputMicrosPerMTok": 50000000}, "gpt-6-cyber": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 40000000, "outputMicrosPerMTok": 150000000}], "inputMicrosPerMTok": 20000000, "outputMicrosPerMTok": 100000000}, "gpt-6.1-sol": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 4000000, "outputMicrosPerMTok": 15000000}], "inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 10000000}, "gpt-6.2-sol": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 4000000, "outputMicrosPerMTok": 15000000}], "inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 10000000}, "gpt-4.1-mini": {"inputMicrosPerMTok": 400000, "outputMicrosPerMTok": 1600000}, "gpt-4.1-nano": {"inputMicrosPerMTok": 100000, "outputMicrosPerMTok": 400000}, "gpt-5.4-mini": {"inputMicrosPerMTok": 750000, "outputMicrosPerMTok": 4500000}, "gpt-5.4-nano": {"inputMicrosPerMTok": 200000, "outputMicrosPerMTok": 1250000}, "gpt-5.6-luna": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 400000, "outputMicrosPerMTok": 1800000}], "inputMicrosPerMTok": 200000, "outputMicrosPerMTok": 1200000}, "ft:gpt-4-0613": {"inputMicrosPerMTok": 30000000, "outputMicrosPerMTok": 60000000}, "gpt-3.5-turbo": {"inputMicrosPerMTok": 500000, "outputMicrosPerMTok": 1500000}, "gpt-5.1-codex": {"inputMicrosPerMTok": 1250000, "outputMicrosPerMTok": 10000000}, "gpt-5.2-codex": {"inputMicrosPerMTok": 1750000, "outputMicrosPerMTok": 14000000}, "gpt-5.3-codex": {"inputMicrosPerMTok": 1750000, "outputMicrosPerMTok": 14000000}, "gpt-5.5-cyber": {"inputMicrosPerMTok": 12500000, "outputMicrosPerMTok": 75000000}, "gpt-5.6-cyber": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 25000000, "outputMicrosPerMTok": 112500000}], "inputMicrosPerMTok": 12500000, "outputMicrosPerMTok": 75000000}, "gpt-5.6-terra": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 4000000, "outputMicrosPerMTok": 18000000}], "inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 12000000}, "gpt-6.1-terra": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 7500000}], "inputMicrosPerMTok": 1000000, "outputMicrosPerMTok": 5000000}, "gpt-6.2-astra": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 16000000, "outputMicrosPerMTok": 60000000}], "inputMicrosPerMTok": 8000000, "outputMicrosPerMTok": 40000000}, "gpt-audio-1.5": {"inputMicrosPerMTok": 2500000, "outputMicrosPerMTok": 10000000}, "o1-2024-12-17": {"inputMicrosPerMTok": 15000000, "outputMicrosPerMTok": 60000000}, "o3-2025-04-16": {"inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 8000000}, "gpt-6-rosalind": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 20000000, "outputMicrosPerMTok": 75000000}], "inputMicrosPerMTok": 10000000, "outputMicrosPerMTok": 50000000}, "gpt-audio-mini": {"inputMicrosPerMTok": 600000, "outputMicrosPerMTok": 2400000}, "gpt-6-astra-law": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 20000000, "outputMicrosPerMTok": 75000000}], "inputMicrosPerMTok": 10000000, "outputMicrosPerMTok": 50000000}, "ft:gpt-3.5-turbo": {"inputMicrosPerMTok": 3000000, "outputMicrosPerMTok": 6000000}, "gpt-5-2025-08-07": {"inputMicrosPerMTok": 1250000, "outputMicrosPerMTok": 10000000}, "gpt-5-search-api": {"inputMicrosPerMTok": 1250000, "outputMicrosPerMTok": 10000000}, "o3-deep-research": {"inputMicrosPerMTok": 10000000, "outputMicrosPerMTok": 40000000}, "gpt-3.5-turbo-16k": {"inputMicrosPerMTok": 3000000, "outputMicrosPerMTok": 4000000}, "gpt-4o-2024-05-13": {"inputMicrosPerMTok": 5000000, "outputMicrosPerMTok": 15000000}, "gpt-4o-2024-08-06": {"inputMicrosPerMTok": 2500000, "outputMicrosPerMTok": 10000000}, "gpt-4o-2024-11-20": {"inputMicrosPerMTok": 2500000, "outputMicrosPerMTok": 10000000}, "gpt-5-chat-latest": {"inputMicrosPerMTok": 1250000, "outputMicrosPerMTok": 10000000}, "gpt-5.1-codex-max": {"inputMicrosPerMTok": 1250000, "outputMicrosPerMTok": 10000000}, "gpt-6.2-astra-law": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 16000000, "outputMicrosPerMTok": 60000000}], "inputMicrosPerMTok": 8000000, "outputMicrosPerMTok": 40000000}, "o1-pro-2025-03-19": {"inputMicrosPerMTok": 150000000, "outputMicrosPerMTok": 600000000}, "o3-pro-2025-06-10": {"inputMicrosPerMTok": 20000000, "outputMicrosPerMTok": 80000000}, "gpt-3.5-turbo-0125": {"inputMicrosPerMTok": 500000, "outputMicrosPerMTok": 1500000}, "gpt-3.5-turbo-1106": {"inputMicrosPerMTok": 1000000, "outputMicrosPerMTok": 2000000}, "gpt-4-1106-preview": {"inputMicrosPerMTok": 10000000, "outputMicrosPerMTok": 30000000}, "gpt-4.1-2025-04-14": {"inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 8000000}, "gpt-5.1-2025-11-13": {"inputMicrosPerMTok": 1250000, "outputMicrosPerMTok": 10000000}, "gpt-5.1-codex-mini": {"inputMicrosPerMTok": 250000, "outputMicrosPerMTok": 2000000}, "gpt-5.2-2025-12-11": {"inputMicrosPerMTok": 1750000, "outputMicrosPerMTok": 14000000}, "gpt-5.4-2026-03-05": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 5000000, "outputMicrosPerMTok": 22500000}], "inputMicrosPerMTok": 2500000, "outputMicrosPerMTok": 15000000}, "gpt-5.5-2026-04-23": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 10000000, "outputMicrosPerMTok": 45000000}], "inputMicrosPerMTok": 5000000, "outputMicrosPerMTok": 30000000}, "o3-mini-2025-01-31": {"inputMicrosPerMTok": 1100000, "outputMicrosPerMTok": 4400000}, "o4-mini-2025-04-16": {"inputMicrosPerMTok": 1100000, "outputMicrosPerMTok": 4400000}, "daybreak-red-latest": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 25000000, "outputMicrosPerMTok": 112500000}], "inputMicrosPerMTok": 12500000, "outputMicrosPerMTok": 75000000}, "gpt-5.1-chat-latest": {"inputMicrosPerMTok": 1250000, "outputMicrosPerMTok": 10000000}, "gpt-5.2-chat-latest": {"inputMicrosPerMTok": 1750000, "outputMicrosPerMTok": 14000000}, "gpt-5.3-chat-latest": {"inputMicrosPerMTok": 1750000, "outputMicrosPerMTok": 14000000}, "computer-use-preview": {"inputMicrosPerMTok": 3000000, "outputMicrosPerMTok": 12000000}, "daybreak-blue-latest": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 8000000, "outputMicrosPerMTok": 30000000}], "inputMicrosPerMTok": 4000000, "outputMicrosPerMTok": 20000000}, "ft:gpt-4o-2024-08-06": {"inputMicrosPerMTok": 3750000, "outputMicrosPerMTok": 15000000}, "ft:gpt-4o-2024-11-20": {"inputMicrosPerMTok": 3750000, "outputMicrosPerMTok": 15000000}, "gpt-5-pro-2025-10-06": {"inputMicrosPerMTok": 15000000, "outputMicrosPerMTok": 120000000}, "gpt-audio-2025-08-28": {"inputMicrosPerMTok": 2500000, "outputMicrosPerMTok": 10000000}, "ft:gpt-3.5-turbo-0125": {"inputMicrosPerMTok": 3000000, "outputMicrosPerMTok": 6000000}, "ft:gpt-3.5-turbo-0613": {"inputMicrosPerMTok": 3000000, "outputMicrosPerMTok": 6000000}, "ft:gpt-3.5-turbo-1106": {"inputMicrosPerMTok": 3000000, "outputMicrosPerMTok": 6000000}, "ft:gpt-4.1-2025-04-14": {"inputMicrosPerMTok": 3000000, "outputMicrosPerMTok": 12000000}, "ft:o4-mini-2025-04-16": {"inputMicrosPerMTok": 4000000, "outputMicrosPerMTok": 16000000}, "gpt-4o-search-preview": {"inputMicrosPerMTok": 2500000, "outputMicrosPerMTok": 10000000}, "gpt-5-mini-2025-08-07": {"inputMicrosPerMTok": 250000, "outputMicrosPerMTok": 2000000}, "gpt-5-nano-2025-08-07": {"inputMicrosPerMTok": 50000, "outputMicrosPerMTok": 400000}, "gpt-5.5-cyber-preview": {"inputMicrosPerMTok": 12500000, "outputMicrosPerMTok": 75000000}, "gpt-rosalind-research": {"inputMicrosPerMTok": 5000000, "outputMicrosPerMTok": 25000000}, "o4-mini-deep-research": {"inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 8000000}, "gpt-4-turbo-2024-04-09": {"inputMicrosPerMTok": 10000000, "outputMicrosPerMTok": 30000000}, "gpt-4o-mini-2024-07-18": {"inputMicrosPerMTok": 150000, "outputMicrosPerMTok": 600000}, "gpt-5.2-pro-2025-12-11": {"inputMicrosPerMTok": 21000000, "outputMicrosPerMTok": 168000000}, "gpt-5.4-pro-2026-03-05": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 60000000, "outputMicrosPerMTok": 270000000}], "inputMicrosPerMTok": 30000000, "outputMicrosPerMTok": 180000000}, "gpt-5.5-pro-2026-04-23": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 60000000, "outputMicrosPerMTok": 270000000}], "inputMicrosPerMTok": 30000000, "outputMicrosPerMTok": 180000000}, "gpt-rosalind-discovery": {"inputMicrosPerMTok": 5000000, "outputMicrosPerMTok": 25000000}, "gpt-4.1-mini-2025-04-14": {"inputMicrosPerMTok": 400000, "outputMicrosPerMTok": 1600000}, "gpt-4.1-nano-2025-04-14": {"inputMicrosPerMTok": 100000, "outputMicrosPerMTok": 400000}, "gpt-5.4-mini-2026-03-17": {"inputMicrosPerMTok": 750000, "outputMicrosPerMTok": 4500000}, "gpt-5.4-nano-2026-03-17": {"inputMicrosPerMTok": 200000, "outputMicrosPerMTok": 1250000}, "gpt-daybreak-red-latest": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 25000000, "outputMicrosPerMTok": 112500000}], "inputMicrosPerMTok": 12500000, "outputMicrosPerMTok": 75000000}, "gpt-daybreak-blue-latest": {"tiers": [{"fromTokens": 272001, "inputMicrosPerMTok": 8000000, "outputMicrosPerMTok": 30000000}], "inputMicrosPerMTok": 4000000, "outputMicrosPerMTok": 20000000}, "ft:gpt-4o-mini-2024-07-18": {"inputMicrosPerMTok": 300000, "outputMicrosPerMTok": 1200000}, "gpt-audio-mini-2025-10-06": {"inputMicrosPerMTok": 600000, "outputMicrosPerMTok": 2400000}, "gpt-audio-mini-2025-12-15": {"inputMicrosPerMTok": 600000, "outputMicrosPerMTok": 2400000}, "ft:gpt-4.1-mini-2025-04-14": {"inputMicrosPerMTok": 800000, "outputMicrosPerMTok": 3200000}, "ft:gpt-4.1-nano-2025-04-14": {"inputMicrosPerMTok": 200000, "outputMicrosPerMTok": 800000}, "gpt-4o-mini-search-preview": {"inputMicrosPerMTok": 150000, "outputMicrosPerMTok": 600000}, "gpt-5-search-api-2025-10-14": {"inputMicrosPerMTok": 1250000, "outputMicrosPerMTok": 10000000}, "o3-deep-research-2025-06-26": {"inputMicrosPerMTok": 10000000, "outputMicrosPerMTok": 40000000}, "computer-use-preview-2025-03-11": {"inputMicrosPerMTok": 3000000, "outputMicrosPerMTok": 12000000}, "gpt-4o-audio-preview-2024-12-17": {"inputMicrosPerMTok": 2500000, "outputMicrosPerMTok": 10000000}, "gpt-4o-audio-preview-2025-06-03": {"inputMicrosPerMTok": 2500000, "outputMicrosPerMTok": 10000000}, "gpt-4o-search-preview-2025-03-11": {"inputMicrosPerMTok": 2500000, "outputMicrosPerMTok": 10000000}, "o4-mini-deep-research-2025-06-26": {"inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 8000000}, "gpt-4o-mini-audio-preview-2024-12-17": {"inputMicrosPerMTok": 150000, "outputMicrosPerMTok": 600000}, "gpt-4o-mini-search-preview-2025-03-11": {"inputMicrosPerMTok": 150000, "outputMicrosPerMTok": 600000}}, "anthropic": {"claude-opus-5": {"inputMicrosPerMTok": 5000000, "outputMicrosPerMTok": 25000000}, "claude-fable-5": {"inputMicrosPerMTok": 10000000, "outputMicrosPerMTok": 50000000}, "claude-mythos-5": {"inputMicrosPerMTok": 10000000, "outputMicrosPerMTok": 50000000}, "claude-opus-4-5": {"inputMicrosPerMTok": 5000000, "outputMicrosPerMTok": 25000000}, "claude-opus-4-6": {"inputMicrosPerMTok": 5000000, "outputMicrosPerMTok": 25000000}, "claude-opus-4-7": {"inputMicrosPerMTok": 5000000, "outputMicrosPerMTok": 25000000}, "claude-opus-4-8": {"inputMicrosPerMTok": 5000000, "outputMicrosPerMTok": 25000000}, "claude-opus-5-5": {"inputMicrosPerMTok": 4000000, "outputMicrosPerMTok": 20000000}, "claude-sonnet-5": {"inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 10000000}, "claude-fable-5-1": {"inputMicrosPerMTok": 10000000, "outputMicrosPerMTok": 50000000}, "claude-fable-5-2": {"inputMicrosPerMTok": 8000000, "outputMicrosPerMTok": 40000000}, "claude-haiku-4-5": {"inputMicrosPerMTok": 1000000, "outputMicrosPerMTok": 5000000}, "claude-haiku-5-5": {"tiers": [{"fromTokens": 100001, "inputMicrosPerMTok": 500000, "outputMicrosPerMTok": 2500000}], "inputMicrosPerMTok": 100000, "outputMicrosPerMTok": 500000}, "claude-mythos-5-1": {"inputMicrosPerMTok": 10000000, "outputMicrosPerMTok": 50000000}, "claude-mythos-5-2": {"inputMicrosPerMTok": 8000000, "outputMicrosPerMTok": 40000000}, "claude-sonnet-4-5": {"inputMicrosPerMTok": 3000000, "outputMicrosPerMTok": 15000000}, "claude-sonnet-4-6": {"inputMicrosPerMTok": 3000000, "outputMicrosPerMTok": 15000000}, "claude-sonnet-5-5": {"inputMicrosPerMTok": 2000000, "outputMicrosPerMTok": 10000000}, "claude-mythos-preview": {"inputMicrosPerMTok": 10000000, "outputMicrosPerMTok": 50000000}, "claude-opus-4-5-20251101": {"inputMicrosPerMTok": 5000000, "outputMicrosPerMTok": 25000000}, "claude-opus-4-6-20260205": {"inputMicrosPerMTok": 5000000, "outputMicrosPerMTok": 25000000}, "claude-opus-4-7-20260416": {"inputMicrosPerMTok": 5000000, "outputMicrosPerMTok": 25000000}, "claude-haiku-4-5-20251001": {"inputMicrosPerMTok": 1000000, "outputMicrosPerMTok": 5000000}, "claude-sonnet-4-5-20250929": {"inputMicrosPerMTok": 3000000, "outputMicrosPerMTok": 15000000}}}', '2026-11-20 11:26:41.08161+00');


--
-- Data for Name: api_key_checks; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.api_key_checks VALUES ('a2ceb937-95fb-441b-98ef-18f76406fbc8', '3b1bb027-216e-4eaa-9fa3-78720ba27253', 'upgrade-check-model', '2026-11-20 11:26:46.504132+00', 0, true);


--
-- Data for Name: assistant_background_notes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: assistant_changes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: assistant_job_runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: assistant_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.assistant_jobs VALUES ('3d2ba447-9b15-494b-bc5c-2ee1fc980569', '79bbedd2-67db-4944-a1b6-55c9a4553889', '11c2823a-c8ac-4431-955a-a5ca0948254b', 'Weekly summary bd0292a3', 'Summarise what changed in Garden', 'weekly', '{"at": "09:00", "kind": "weekly", "weekday": 1}', 'Europe/Warsaw', true, false, NULL, '2026-11-23 08:00:00+00', NULL, NULL, 1, '2026-11-20 11:26:46.682739+00', '2026-11-20 11:26:46.682739+00', '154e1a8e-024d-40ed-9f26-9403774a7331');
INSERT INTO public.assistant_jobs VALUES ('9d4ae43f-cc0b-4fc3-a4a5-a40b1c6148b7', '79bbedd2-67db-4944-a1b6-55c9a4553889', '11c2823a-c8ac-4431-955a-a5ca0948254b', 'Daily check bd0292a3', 'Look at the garden tasks', 'daily', '{"at": "07:30", "kind": "daily"}', 'Europe/Warsaw', false, false, NULL, NULL, NULL, NULL, 1, '2026-11-20 11:26:46.715841+00', '2026-11-20 11:26:46.715841+00', '154e1a8e-024d-40ed-9f26-9403774a7331');


--
-- Data for Name: assistant_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.assistant_settings VALUES ('79bbedd2-67db-4944-a1b6-55c9a4553889', '11c2823a-c8ac-4431-955a-a5ca0948254b', '1185d65b-0e5e-42cb-b620-bf84e8855d13', '6a8281f1-8349-409d-a97c-dc6498e9b37a', 1, '2026-11-20 11:26:46.53095+00', '2026-11-20 11:26:46.53095+00', '', 'ink', 'server', '3b1bb027-216e-4eaa-9fa3-78720ba27253', 'openai_compatible', 'upgrade-check-model');
INSERT INTO public.assistant_settings VALUES ('79bbedd2-67db-4944-a1b6-55c9a4553889', '11c2823a-c8ac-4431-955a-a5ca0948254b', '154e1a8e-024d-40ed-9f26-9403774a7331', '308b53da-cb7a-4029-94a0-e40cd7141398', 1, '2026-11-20 11:26:46.580006+00', '2026-11-20 11:26:46.580006+00', 'Plan the garden work, bd0292a3.', 'teal', 'server', '3b1bb027-216e-4eaa-9fa3-78720ba27253', 'openai_compatible', 'upgrade-check-model');


--
-- Data for Name: auth_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.auth_accounts VALUES ('38d1b7c5-0013-418a-b2be-88898d256898', '11c2823a-c8ac-4431-955a-a5ca0948254b', '11c2823a-c8ac-4431-955a-a5ca0948254b', 'credential', NULL, NULL, NULL, NULL, NULL, NULL, 'aef72e41f25770ed160202bf285235d2:463b0428eadd73afd968246c0114b8669b2e4f0b3f3f3a098f7bb733fcbd06b2ebecc26cba2ad0317c81150977810fd68957e9451e6b694057387a96737f7ddc', '2026-11-20 11:26:43.216+00', '2026-11-20 11:26:43.216+00', NULL, 0, NULL);
INSERT INTO public.auth_accounts VALUES ('c3fd346c-06a0-4187-b2c8-69fe43439767', '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 'credential', NULL, NULL, NULL, NULL, NULL, NULL, 'bb8ac62f25eb77cfc54bc1094abbc01a:2fc210d21b7a7067a65e1eb6079c0c7faf5fb70e6a9ede38f22104ed0d4a3d72341d91291084e9022e141c155017de4c6c158a324254668b0035cb2df2e4fce8', '2026-11-20 11:26:44.21+00', '2026-11-20 11:26:44.21+00', NULL, 0, NULL);
INSERT INTO public.auth_accounts VALUES ('c4f7dc6c-6f80-43cb-ba05-7191e130f28d', '812c1f3d-162a-47bb-8ba4-fd5381ea5923', '812c1f3d-162a-47bb-8ba4-fd5381ea5923', 'credential', NULL, NULL, NULL, NULL, NULL, NULL, 'f4a045d9d77a3b1673022c3d3528d729:75b7247221e3aa53d1cfb27cace094d1b724ce36aac22b84cfaa771f7f9691594d5462127e6fc1689774a339bcdd92fc825bd5237c02ea0f326a57856c1b8656', '2026-11-20 11:26:44.706+00', '2026-11-20 11:26:44.706+00', NULL, 0, NULL);


--
-- Data for Name: auth_email_claims; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: auth_identity_audit; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: auth_idp_standing; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: auth_link_intents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: auth_logout_tokens; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: auth_rate_limits; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.auth_rate_limits VALUES ('39eeccb6-25b0-4c44-b81c-e83a96e845c2', '172.16.48.1|/sign-up/email', 3, 1795174004401);
INSERT INTO public.auth_rate_limits VALUES ('1a10900f-ff0f-4af3-8742-4314c0ec5f51', '127.0.0.1|/jwks', 1, 1795174007692);
INSERT INTO public.auth_rate_limits VALUES ('2d7ffbe2-3acc-4723-8628-cc951ba10bac', '172.16.48.1|/sign-in/email', 1, 1795174008812);


--
-- Data for Name: auth_session_identities; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.auth_session_identities VALUES ('04a7a49a-acf8-4461-98e0-23944a7b707d', 'password', NULL, '2026-11-20 11:26:43.30159+00');
INSERT INTO public.auth_session_identities VALUES ('387c086f-76fc-42a9-aaa8-279c78022882', 'password', NULL, '2026-11-20 11:26:44.296503+00');
INSERT INTO public.auth_session_identities VALUES ('72a8e17d-6fcb-44fe-9855-0634fc8f1a13', 'password', NULL, '2026-11-20 11:26:44.773455+00');
INSERT INTO public.auth_session_identities VALUES ('6bd2d093-26c6-476d-8749-26ba9aeb8cc4', 'password', NULL, '2026-11-20 11:26:48.923708+00');


--
-- Data for Name: auth_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.auth_sessions VALUES ('04a7a49a-acf8-4461-98e0-23944a7b707d', '11c2823a-c8ac-4431-955a-a5ca0948254b', 'ZBINzEFMP7yQWH5azliTt6XsILoeXLef', '2026-11-27 11:26:43.237+00', '172.16.48.1', 'Python-urllib/3.13', '2026-11-20 11:26:43.237+00', '2026-11-20 11:26:43.237+00', NULL);
INSERT INTO public.auth_sessions VALUES ('387c086f-76fc-42a9-aaa8-279c78022882', '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '9lTLJoloiCGOwLY3yFXGzvqR33VFsNGQ', '2026-11-27 11:26:44.229+00', '172.16.48.1', 'Python-urllib/3.13', '2026-11-20 11:26:44.229+00', '2026-11-20 11:26:44.229+00', NULL);
INSERT INTO public.auth_sessions VALUES ('72a8e17d-6fcb-44fe-9855-0634fc8f1a13', '812c1f3d-162a-47bb-8ba4-fd5381ea5923', 'YBsa9Q1BIAxWKvASPggrityejd1eLEyc', '2026-11-27 11:26:44.725+00', '172.16.48.1', 'Python-urllib/3.13', '2026-11-20 11:26:44.725+00', '2026-11-20 11:26:44.725+00', NULL);
INSERT INTO public.auth_sessions VALUES ('6bd2d093-26c6-476d-8749-26ba9aeb8cc4', '11c2823a-c8ac-4431-955a-a5ca0948254b', 'FE3mz3hun7ThuoNKNPRXwCPI9dLFeTBm', '2026-11-27 11:26:48.911+00', '172.16.48.1', 'Python-urllib/3.13', '2026-11-20 11:26:48.911+00', '2026-11-20 11:26:48.911+00', NULL);


--
-- Data for Name: auth_sign_in_throttle; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: auth_users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.auth_users VALUES ('11c2823a-c8ac-4431-955a-a5ca0948254b', 'Release smoke user', 'release-c78a08f1271812fb@example.test', false, NULL, '2026-11-20 11:26:43.204+00', '2026-11-20 11:26:43.204+00', 0, 'UTC', '2026-11-20 11:26:43.333727+00', true, NULL);
INSERT INTO public.auth_users VALUES ('52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 'Ben Member', 'ben-bd0292a3-a3f085f65d4b@example.test', false, NULL, '2026-11-20 11:26:44.193+00', '2026-11-20 11:26:44.193+00', 0, 'UTC', '2026-11-20 11:26:44.322755+00', true, NULL);
INSERT INTO public.auth_users VALUES ('812c1f3d-162a-47bb-8ba4-fd5381ea5923', 'Gina Guest', 'gina-bd0292a3-244d53ea2ec3@example.test', false, NULL, '2026-11-20 11:26:44.688+00', '2026-11-20 11:26:44.688+00', 0, 'UTC', '2026-11-20 11:26:44.817549+00', true, NULL);


--
-- Data for Name: auth_verifications; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: background_compute_connections; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.background_compute_connections VALUES ('3b1bb027-216e-4eaa-9fa3-78720ba27253', '11c2823a-c8ac-4431-955a-a5ca0948254b', 'openai_compatible', 'upgrade-check-model', 'v1.zewkGIpuvw8tkBGL.mkbO5NdxFJlkE0gejFafYA.q6HIdg39fUjfM7UA9pQNRT6WwbB9tMkPBTiWukyDaQIpj8EJche1b68', '122a', '19012c4a98b3c043', '2026-11-20 11:26:46.504132+00', NULL, 'http://provider-mock:8091/v1', 0, 0, 'owner', NULL, 'Mock key bd0292a3', 500, 'UTC', NULL, NULL, NULL, NULL, '{}', '{}');


--
-- Data for Name: cowork_checkpoints; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: cowork_connection_slots; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: cowork_units; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: dm_message_observations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: dm_messages; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.dm_messages VALUES ('7036dbed-2470-4b34-b0ad-cc738b697f7e', '79bbedd2-67db-4944-a1b6-55c9a4553889', '93ead2ce-d190-40cc-945e-63a407d73985', '11c2823a-c8ac-4431-955a-a5ca0948254b', 'd5523536-ce4c-4eba-ac29-7c347f68972c', '968dec164eedde3ba29002eb46dd52dbc2ce638ab9f6450d8d43e269b38a1e1c', 1, 'DM-hello-bd0292a3', '2026-11-20 11:26:45.263517+00', NULL, NULL, 'text', NULL, NULL, NULL, 0);
INSERT INTO public.dm_messages VALUES ('e4def4c5-ee85-48dd-bda6-c0a1594bf4ea', '79bbedd2-67db-4944-a1b6-55c9a4553889', '93ead2ce-d190-40cc-945e-63a407d73985', '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '2a240ba3-1b94-4c69-896d-d1239aa53a3e', '92e5d2af8cd4164dce104ef3921b993730f2b2f0471cdba8a6118da399ce840a', 2, 'DM-reply-bd0292a3', '2026-11-20 11:26:45.29047+00', '7036dbed-2470-4b34-b0ad-cc738b697f7e', NULL, 'text', NULL, NULL, NULL, 0);
INSERT INTO public.dm_messages VALUES ('f6fac6ac-ce3f-4d72-b008-9c314bf1fddf', '79bbedd2-67db-4944-a1b6-55c9a4553889', '9ba59e5c-63fc-4e8a-ae12-9703781cd053', '11c2823a-c8ac-4431-955a-a5ca0948254b', '3ebbb714-46bb-4de1-96da-7c1657535017', '3daf5c1565ff7972481651f312f1d1766172ab30b418e7b7c9deb59b57445873', 1, 'GROUP-hello-bd0292a3', '2026-11-20 11:26:45.384071+00', NULL, NULL, 'text', NULL, NULL, NULL, 0);
INSERT INTO public.dm_messages VALUES ('49a516f8-749e-4d83-b320-72182ec9ba24', '79bbedd2-67db-4944-a1b6-55c9a4553889', '9ba59e5c-63fc-4e8a-ae12-9703781cd053', '11c2823a-c8ac-4431-955a-a5ca0948254b', '4647d670-163c-4469-a21b-adb6e32bb77b', 'ccdafd08a465e718b47e4283c414acbdd0dc63a6933583a9577f44f12660c53e', 2, 'ꟀꟁꟀꟁ UNICODE-bd0292a3', '2026-11-20 11:26:45.441177+00', NULL, NULL, 'text', NULL, NULL, NULL, 0);


--
-- Data for Name: dm_participants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.dm_participants VALUES ('79bbedd2-67db-4944-a1b6-55c9a4553889', '93ead2ce-d190-40cc-945e-63a407d73985', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:45.229034+00');
INSERT INTO public.dm_participants VALUES ('79bbedd2-67db-4944-a1b6-55c9a4553889', '93ead2ce-d190-40cc-945e-63a407d73985', '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '2026-11-20 11:26:45.229034+00');
INSERT INTO public.dm_participants VALUES ('79bbedd2-67db-4944-a1b6-55c9a4553889', '9ba59e5c-63fc-4e8a-ae12-9703781cd053', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:45.344137+00');
INSERT INTO public.dm_participants VALUES ('79bbedd2-67db-4944-a1b6-55c9a4553889', '9ba59e5c-63fc-4e8a-ae12-9703781cd053', '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '2026-11-20 11:26:45.344137+00');
INSERT INTO public.dm_participants VALUES ('79bbedd2-67db-4944-a1b6-55c9a4553889', '9ba59e5c-63fc-4e8a-ae12-9703781cd053', '812c1f3d-162a-47bb-8ba4-fd5381ea5923', '2026-11-20 11:26:45.344137+00');


--
-- Data for Name: dm_reads; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: dms; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.dms VALUES ('93ead2ce-d190-40cc-945e-63a407d73985', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'pair', '11c2823a-c8ac-4431-955a-a5ca0948254b:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', NULL, '11c2823a-c8ac-4431-955a-a5ca0948254b', 1, 3, '2026-11-20 11:26:45.229034+00', '2026-11-20 11:26:45.29047+00');
INSERT INTO public.dms VALUES ('9ba59e5c-63fc-4e8a-ae12-9703781cd053', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'group', NULL, 'Garden crew bd0292a3', '11c2823a-c8ac-4431-955a-a5ca0948254b', 1, 3, '2026-11-20 11:26:45.344137+00', '2026-11-20 11:26:45.441177+00');


--
-- Data for Name: doc_live_archives; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: doc_live_heads; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: doc_live_presence; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: doc_live_replicas; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: doc_live_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: doc_live_updates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: encrypted_workspace_creations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.encrypted_workspace_creations VALUES ('bf7d9d43-bf9a-4e7c-aa91-c486411e24da', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:46.146067+00');


--
-- Data for Name: event_audience; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 1, 'b85f2ea7-40c4-4ca1-a4e2-9b453adaddf0');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 2, '8b2fc1a4-a210-457e-87d7-6977c811e2c3');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 3, '7e414929-c17d-435c-94a1-425f2eb0fce3');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 4, '62e4f6dd-1779-4e42-9b09-a95d61f30a8c');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 5, '2cc2f548-d4cc-43e4-82fd-5262c9fbca93');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 6, 'd354e59a-13d8-4a24-9881-a4bc5332a73e');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 7, '2fcc0dec-b66a-464b-95f2-72b8ea34cf16');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 8, '50f185a5-2910-4fa5-a608-dd464ee2e2f5');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 9, '86dfa684-90f8-4b2e-8e21-66b0800392a3');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 10, 'e854df7d-a18c-46db-8151-085133379515');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 11, 'c48e43aa-9d13-4a4e-ad6d-64da77b39af3');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 12, 'd69ffe1f-8055-415e-b0f8-840d09876877');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 12, 'd69ffe1f-8055-415e-b0f8-840d09876877');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 13, 'a5d616ea-96d0-408d-9420-2ba3cc4dc3b1');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 13, 'a5d616ea-96d0-408d-9420-2ba3cc4dc3b1');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 14, 'c96c1dfb-6141-4dd2-8f2c-8d79cc3fd179');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 14, 'c96c1dfb-6141-4dd2-8f2c-8d79cc3fd179');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 14, 'c96c1dfb-6141-4dd2-8f2c-8d79cc3fd179');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 15, '96c9f4fe-01a1-44a1-ad97-b9ec5850ef64');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 15, '96c9f4fe-01a1-44a1-ad97-b9ec5850ef64');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 15, '96c9f4fe-01a1-44a1-ad97-b9ec5850ef64');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 16, 'f40fc067-57e1-4ffb-9568-839d3910b903');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 16, 'f40fc067-57e1-4ffb-9568-839d3910b903');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 16, 'f40fc067-57e1-4ffb-9568-839d3910b903');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 17, 'fc74e002-6499-46cf-865e-adc83a581e47');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 17, 'fc74e002-6499-46cf-865e-adc83a581e47');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 17, 'fc74e002-6499-46cf-865e-adc83a581e47');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 18, '63641bcd-396b-403c-8c13-24eabbd471ff');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 18, '63641bcd-396b-403c-8c13-24eabbd471ff');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 18, '63641bcd-396b-403c-8c13-24eabbd471ff');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 19, 'adf6ce37-1c4b-4236-a151-957acab449fc');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 19, 'adf6ce37-1c4b-4236-a151-957acab449fc');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 19, 'adf6ce37-1c4b-4236-a151-957acab449fc');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 20, '4aca25ce-2365-45e2-ab8d-3ea7cc23a9ad');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 20, '4aca25ce-2365-45e2-ab8d-3ea7cc23a9ad');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 20, '4aca25ce-2365-45e2-ab8d-3ea7cc23a9ad');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 21, '46081d0f-30ba-4fbb-a623-a87aba3a6f82');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 21, '46081d0f-30ba-4fbb-a623-a87aba3a6f82');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 22, 'ea0a6117-1f2d-446e-b330-25b0ed50918b');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 22, 'ea0a6117-1f2d-446e-b330-25b0ed50918b');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 23, '56d575c4-e05e-427e-986c-bb5833bb6aeb');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 24, '2e60fecc-1a94-485a-88e0-f6482a741ca6');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 24, '2e60fecc-1a94-485a-88e0-f6482a741ca6');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 25, '493f525e-c284-4ac4-abad-ef162571d25b');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 26, 'bb2ec908-09d5-4272-acc6-fafa1fbfb7ce');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 26, 'bb2ec908-09d5-4272-acc6-fafa1fbfb7ce');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 26, 'bb2ec908-09d5-4272-acc6-fafa1fbfb7ce');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 27, '08116329-1848-41d6-aa42-7f302f6a9a04');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 27, '08116329-1848-41d6-aa42-7f302f6a9a04');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 27, '08116329-1848-41d6-aa42-7f302f6a9a04');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 28, 'cc62a8aa-682b-497b-b33e-6963994eb31a');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 29, '6f6e1712-083b-4751-8ac1-92a9edc9fd52');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 30, 'da616ca6-053c-4b2d-b476-dd466b6fb5d5');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 30, 'da616ca6-053c-4b2d-b476-dd466b6fb5d5');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 30, 'da616ca6-053c-4b2d-b476-dd466b6fb5d5');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 31, 'a5df009c-e676-4f29-996d-ad74640aa652');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 32, '3e8c1eec-a7bd-46d3-b669-410e14c04398');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 33, '9aded7b1-edf7-4786-ae04-6c40308f1e37');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 33, '9aded7b1-edf7-4786-ae04-6c40308f1e37');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 33, '9aded7b1-edf7-4786-ae04-6c40308f1e37');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 34, '67913755-6e7d-424b-a4b2-f61dcdaa9a25');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 34, '67913755-6e7d-424b-a4b2-f61dcdaa9a25');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 34, '67913755-6e7d-424b-a4b2-f61dcdaa9a25');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 35, '54c240e1-00c7-4039-99bf-82f206735217');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 35, '54c240e1-00c7-4039-99bf-82f206735217');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 35, '54c240e1-00c7-4039-99bf-82f206735217');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 36, '25548804-7344-4c47-bf73-e177d9e8d2ae');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 36, '25548804-7344-4c47-bf73-e177d9e8d2ae');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 36, '25548804-7344-4c47-bf73-e177d9e8d2ae');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 37, '93b9f164-3185-491a-b610-e2b32119072e');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 37, '93b9f164-3185-491a-b610-e2b32119072e');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 37, '93b9f164-3185-491a-b610-e2b32119072e');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 38, 'db67c27c-1f18-4294-9f30-7f76c8364203');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 38, 'db67c27c-1f18-4294-9f30-7f76c8364203');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 38, 'db67c27c-1f18-4294-9f30-7f76c8364203');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 39, '4a86aec9-f9f6-4551-bda9-7f8f0f317251');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 39, '4a86aec9-f9f6-4551-bda9-7f8f0f317251');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 39, '4a86aec9-f9f6-4551-bda9-7f8f0f317251');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 40, 'c17e98fd-2cd5-43fb-88a7-5898561da504');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 40, 'c17e98fd-2cd5-43fb-88a7-5898561da504');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 40, 'c17e98fd-2cd5-43fb-88a7-5898561da504');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 41, 'fc2789db-3aa8-4510-a684-380766b7347b');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 44, '3c14f1ca-475a-4396-8e3e-344e1335d69e');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 42, '05b8a9b0-a546-4057-8ee7-a3d6331c4870');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 42, '05b8a9b0-a546-4057-8ee7-a3d6331c4870');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 42, '05b8a9b0-a546-4057-8ee7-a3d6331c4870');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 43, 'c7fe79b0-2736-4fca-a3db-5d76ca42c03c');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 43, 'c7fe79b0-2736-4fca-a3db-5d76ca42c03c');
INSERT INTO public.event_audience VALUES ('human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 43, 'c7fe79b0-2736-4fca-a3db-5d76ca42c03c');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 45, '4b183814-8893-4de9-963f-23eee6ecac0f');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 46, 'f8390c32-178c-4c6c-9668-6a8e7eaf677d');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 47, 'd351fefd-338f-45e1-9f28-592a09cd0ada');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 48, 'b1635160-73d3-479d-a010-75f81f0f91ae');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 49, 'ad6e8904-27bb-436a-b12e-8c6262d4e322');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 50, '26234443-76e8-4384-8bb3-317bfe944f7c');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 51, 'cd159269-3742-497d-b102-17d42fb05df4');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 51, 'cd159269-3742-497d-b102-17d42fb05df4');
INSERT INTO public.event_audience VALUES ('agent:1185d65b-0e5e-42cb-b620-bf84e8855d13', 51, 'cd159269-3742-497d-b102-17d42fb05df4');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 52, '5352857e-3d7c-4828-b727-baefbb826396');
INSERT INTO public.event_audience VALUES ('human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 52, '5352857e-3d7c-4828-b727-baefbb826396');
INSERT INTO public.event_audience VALUES ('agent:154e1a8e-024d-40ed-9f26-9403774a7331', 52, '5352857e-3d7c-4828-b727-baefbb826396');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 53, '6c55acda-609f-4a52-a941-7f287a221934');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 54, 'adf4388d-285b-4eae-b592-d32038bfdfc2');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 55, '1092b513-0904-402a-a6ad-8ed1df879f88');
INSERT INTO public.event_audience VALUES ('human:11c2823a-c8ac-4431-955a-a5ca0948254b', 56, '0ce1caba-0a13-4408-b6fe-0ad4e00359be');


--
-- Data for Name: event_data_keys; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.event_data_keys VALUES ('access');
INSERT INTO public.event_data_keys VALUES ('actor');
INSERT INTO public.event_data_keys VALUES ('actorId');
INSERT INTO public.event_data_keys VALUES ('additionalProperties');
INSERT INTO public.event_data_keys VALUES ('agentId');
INSERT INTO public.event_data_keys VALUES ('agentIds');
INSERT INTO public.event_data_keys VALUES ('ai');
INSERT INTO public.event_data_keys VALUES ('assignedTo');
INSERT INTO public.event_data_keys VALUES ('at');
INSERT INTO public.event_data_keys VALUES ('audience');
INSERT INTO public.event_data_keys VALUES ('author');
INSERT INTO public.event_data_keys VALUES ('automation');
INSERT INTO public.event_data_keys VALUES ('body');
INSERT INTO public.event_data_keys VALUES ('boundary');
INSERT INTO public.event_data_keys VALUES ('by');
INSERT INTO public.event_data_keys VALUES ('canCreateProject');
INSERT INTO public.event_data_keys VALUES ('caps');
INSERT INTO public.event_data_keys VALUES ('changed');
INSERT INTO public.event_data_keys VALUES ('changes');
INSERT INTO public.event_data_keys VALUES ('clientCommandId');
INSERT INTO public.event_data_keys VALUES ('clientMessageId');
INSERT INTO public.event_data_keys VALUES ('code');
INSERT INTO public.event_data_keys VALUES ('columns');
INSERT INTO public.event_data_keys VALUES ('command');
INSERT INTO public.event_data_keys VALUES ('commandId');
INSERT INTO public.event_data_keys VALUES ('contentIdentity');
INSERT INTO public.event_data_keys VALUES ('conversationId');
INSERT INTO public.event_data_keys VALUES ('createdAt');
INSERT INTO public.event_data_keys VALUES ('createdBy');
INSERT INTO public.event_data_keys VALUES ('data');
INSERT INTO public.event_data_keys VALUES ('decisionId');
INSERT INTO public.event_data_keys VALUES ('dm');
INSERT INTO public.event_data_keys VALUES ('dmId');
INSERT INTO public.event_data_keys VALUES ('docId');
INSERT INTO public.event_data_keys VALUES ('email');
INSERT INTO public.event_data_keys VALUES ('end');
INSERT INTO public.event_data_keys VALUES ('error');
INSERT INTO public.event_data_keys VALUES ('eventId');
INSERT INTO public.event_data_keys VALUES ('events');
INSERT INTO public.event_data_keys VALUES ('evidenceRef');
INSERT INTO public.event_data_keys VALUES ('expected');
INSERT INTO public.event_data_keys VALUES ('expiresAt');
INSERT INTO public.event_data_keys VALUES ('fence');
INSERT INTO public.event_data_keys VALUES ('file');
INSERT INTO public.event_data_keys VALUES ('fileId');
INSERT INTO public.event_data_keys VALUES ('fingerprint');
INSERT INTO public.event_data_keys VALUES ('firstMessageBody');
INSERT INTO public.event_data_keys VALUES ('from');
INSERT INTO public.event_data_keys VALUES ('fromTitle');
INSERT INTO public.event_data_keys VALUES ('goal');
INSERT INTO public.event_data_keys VALUES ('goalId');
INSERT INTO public.event_data_keys VALUES ('grantId');
INSERT INTO public.event_data_keys VALUES ('hasMoreBefore');
INSERT INTO public.event_data_keys VALUES ('height');
INSERT INTO public.event_data_keys VALUES ('holders');
INSERT INTO public.event_data_keys VALUES ('id');
INSERT INTO public.event_data_keys VALUES ('ids');
INSERT INTO public.event_data_keys VALUES ('inbox');
INSERT INTO public.event_data_keys VALUES ('index');
INSERT INTO public.event_data_keys VALUES ('input');
INSERT INTO public.event_data_keys VALUES ('intent');
INSERT INTO public.event_data_keys VALUES ('intents');
INSERT INTO public.event_data_keys VALUES ('interpretation');
INSERT INTO public.event_data_keys VALUES ('invitationId');
INSERT INTO public.event_data_keys VALUES ('inviteId');
INSERT INTO public.event_data_keys VALUES ('items');
INSERT INTO public.event_data_keys VALUES ('keys');
INSERT INTO public.event_data_keys VALUES ('kind');
INSERT INTO public.event_data_keys VALUES ('level');
INSERT INTO public.event_data_keys VALUES ('lifecycle');
INSERT INTO public.event_data_keys VALUES ('limit');
INSERT INTO public.event_data_keys VALUES ('link');
INSERT INTO public.event_data_keys VALUES ('linkId');
INSERT INTO public.event_data_keys VALUES ('linkIds');
INSERT INTO public.event_data_keys VALUES ('lock');
INSERT INTO public.event_data_keys VALUES ('materialId');
INSERT INTO public.event_data_keys VALUES ('maxLength');
INSERT INTO public.event_data_keys VALUES ('message');
INSERT INTO public.event_data_keys VALUES ('messageId');
INSERT INTO public.event_data_keys VALUES ('messageIds');
INSERT INTO public.event_data_keys VALUES ('messagePage');
INSERT INTO public.event_data_keys VALUES ('messages');
INSERT INTO public.event_data_keys VALUES ('myName');
INSERT INTO public.event_data_keys VALUES ('name');
INSERT INTO public.event_data_keys VALUES ('nextBeforeSequence');
INSERT INTO public.event_data_keys VALUES ('noticeId');
INSERT INTO public.event_data_keys VALUES ('objectId');
INSERT INTO public.event_data_keys VALUES ('observed');
INSERT INTO public.event_data_keys VALUES ('ok');
INSERT INTO public.event_data_keys VALUES ('op');
INSERT INTO public.event_data_keys VALUES ('operation');
INSERT INTO public.event_data_keys VALUES ('outcome');
INSERT INTO public.event_data_keys VALUES ('owner');
INSERT INTO public.event_data_keys VALUES ('ownerUserId');
INSERT INTO public.event_data_keys VALUES ('pairKey');
INSERT INTO public.event_data_keys VALUES ('participantIds');
INSERT INTO public.event_data_keys VALUES ('password');
INSERT INTO public.event_data_keys VALUES ('postconditions');
INSERT INTO public.event_data_keys VALUES ('principal');
INSERT INTO public.event_data_keys VALUES ('project');
INSERT INTO public.event_data_keys VALUES ('projectId');
INSERT INTO public.event_data_keys VALUES ('prompt');
INSERT INTO public.event_data_keys VALUES ('provider');
INSERT INTO public.event_data_keys VALUES ('query');
INSERT INTO public.event_data_keys VALUES ('questionId');
INSERT INTO public.event_data_keys VALUES ('queue');
INSERT INTO public.event_data_keys VALUES ('reason');
INSERT INTO public.event_data_keys VALUES ('recipientId');
INSERT INTO public.event_data_keys VALUES ('recipients');
INSERT INTO public.event_data_keys VALUES ('record');
INSERT INTO public.event_data_keys VALUES ('recoveryCode');
INSERT INTO public.event_data_keys VALUES ('replayed');
INSERT INTO public.event_data_keys VALUES ('requestId');
INSERT INTO public.event_data_keys VALUES ('requestedQuestion');
INSERT INTO public.event_data_keys VALUES ('required');
INSERT INTO public.event_data_keys VALUES ('results');
INSERT INTO public.event_data_keys VALUES ('resume');
INSERT INTO public.event_data_keys VALUES ('retained');
INSERT INTO public.event_data_keys VALUES ('retryDelay');
INSERT INTO public.event_data_keys VALUES ('retryLimit');
INSERT INTO public.event_data_keys VALUES ('retryable');
INSERT INTO public.event_data_keys VALUES ('reviewerConnectionId');
INSERT INTO public.event_data_keys VALUES ('reviewerOwnerId');
INSERT INTO public.event_data_keys VALUES ('revision');
INSERT INTO public.event_data_keys VALUES ('role');
INSERT INTO public.event_data_keys VALUES ('rootId');
INSERT INTO public.event_data_keys VALUES ('rootMessageId');
INSERT INTO public.event_data_keys VALUES ('row');
INSERT INTO public.event_data_keys VALUES ('runId');
INSERT INTO public.event_data_keys VALUES ('runToken');
INSERT INTO public.event_data_keys VALUES ('runtime');
INSERT INTO public.event_data_keys VALUES ('sampleId');
INSERT INTO public.event_data_keys VALUES ('scope');
INSERT INTO public.event_data_keys VALUES ('session');
INSERT INTO public.event_data_keys VALUES ('sessionId');
INSERT INTO public.event_data_keys VALUES ('sketch');
INSERT INTO public.event_data_keys VALUES ('sketchId');
INSERT INTO public.event_data_keys VALUES ('source');
INSERT INTO public.event_data_keys VALUES ('sources');
INSERT INTO public.event_data_keys VALUES ('stage');
INSERT INTO public.event_data_keys VALUES ('state');
INSERT INTO public.event_data_keys VALUES ('status');
INSERT INTO public.event_data_keys VALUES ('step');
INSERT INTO public.event_data_keys VALUES ('stop');
INSERT INTO public.event_data_keys VALUES ('stopId');
INSERT INTO public.event_data_keys VALUES ('stopped');
INSERT INTO public.event_data_keys VALUES ('sweep');
INSERT INTO public.event_data_keys VALUES ('task');
INSERT INTO public.event_data_keys VALUES ('taskId');
INSERT INTO public.event_data_keys VALUES ('taskIds');
INSERT INTO public.event_data_keys VALUES ('taskNoticeId');
INSERT INTO public.event_data_keys VALUES ('tell');
INSERT INTO public.event_data_keys VALUES ('text');
INSERT INTO public.event_data_keys VALUES ('thought');
INSERT INTO public.event_data_keys VALUES ('thoughtId');
INSERT INTO public.event_data_keys VALUES ('thoughtIds');
INSERT INTO public.event_data_keys VALUES ('thoughts');
INSERT INTO public.event_data_keys VALUES ('title');
INSERT INTO public.event_data_keys VALUES ('to');
INSERT INTO public.event_data_keys VALUES ('toTitle');
INSERT INTO public.event_data_keys VALUES ('tool');
INSERT INTO public.event_data_keys VALUES ('tools');
INSERT INTO public.event_data_keys VALUES ('total');
INSERT INTO public.event_data_keys VALUES ('type');
INSERT INTO public.event_data_keys VALUES ('userId');
INSERT INTO public.event_data_keys VALUES ('value');
INSERT INTO public.event_data_keys VALUES ('verdict');
INSERT INTO public.event_data_keys VALUES ('version');
INSERT INTO public.event_data_keys VALUES ('view');
INSERT INTO public.event_data_keys VALUES ('visibility');
INSERT INTO public.event_data_keys VALUES ('waitingFor');
INSERT INTO public.event_data_keys VALUES ('width');
INSERT INTO public.event_data_keys VALUES ('window');
INSERT INTO public.event_data_keys VALUES ('work');
INSERT INTO public.event_data_keys VALUES ('workId');
INSERT INTO public.event_data_keys VALUES ('workerId');
INSERT INTO public.event_data_keys VALUES ('workspace');
INSERT INTO public.event_data_keys VALUES ('workspaceId');
INSERT INTO public.event_data_keys VALUES ('resumedFor');


--
-- Data for Name: event_data_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.event_data_tokens VALUES ('accepted');
INSERT INTO public.event_data_tokens VALUES ('admin');
INSERT INTO public.event_data_tokens VALUES ('affects');
INSERT INTO public.event_data_tokens VALUES ('agent');
INSERT INTO public.event_data_tokens VALUES ('assigned');
INSERT INTO public.event_data_tokens VALUES ('blocked');
INSERT INTO public.event_data_tokens VALUES ('contributor');
INSERT INTO public.event_data_tokens VALUES ('conversation');
INSERT INTO public.event_data_tokens VALUES ('creation_reverted');
INSERT INTO public.event_data_tokens VALUES ('decision');
INSERT INTO public.event_data_tokens VALUES ('denied');
INSERT INTO public.event_data_tokens VALUES ('dm');
INSERT INTO public.event_data_tokens VALUES ('doc');
INSERT INTO public.event_data_tokens VALUES ('done');
INSERT INTO public.event_data_tokens VALUES ('group');
INSERT INTO public.event_data_tokens VALUES ('guest');
INSERT INTO public.event_data_tokens VALUES ('human');
INSERT INTO public.event_data_tokens VALUES ('in_progress');
INSERT INTO public.event_data_tokens VALUES ('invitation');
INSERT INTO public.event_data_tokens VALUES ('left');
INSERT INTO public.event_data_tokens VALUES ('link_added');
INSERT INTO public.event_data_tokens VALUES ('link_removed');
INSERT INTO public.event_data_tokens VALUES ('link_updated');
INSERT INTO public.event_data_tokens VALUES ('map');
INSERT INTO public.event_data_tokens VALUES ('material');
INSERT INTO public.event_data_tokens VALUES ('member');
INSERT INTO public.event_data_tokens VALUES ('mention');
INSERT INTO public.event_data_tokens VALUES ('mentions');
INSERT INTO public.event_data_tokens VALUES ('message');
INSERT INTO public.event_data_tokens VALUES ('open');
INSERT INTO public.event_data_tokens VALUES ('owner');
INSERT INTO public.event_data_tokens VALUES ('pair');
INSERT INTO public.event_data_tokens VALUES ('password');
INSERT INTO public.event_data_tokens VALUES ('person');
INSERT INTO public.event_data_tokens VALUES ('private');
INSERT INTO public.event_data_tokens VALUES ('project');
INSERT INTO public.event_data_tokens VALUES ('proposed');
INSERT INTO public.event_data_tokens VALUES ('question');
INSERT INTO public.event_data_tokens VALUES ('recovery');
INSERT INTO public.event_data_tokens VALUES ('rejoined');
INSERT INTO public.event_data_tokens VALUES ('related');
INSERT INTO public.event_data_tokens VALUES ('renamed');
INSERT INTO public.event_data_tokens VALUES ('reply');
INSERT INTO public.event_data_tokens VALUES ('restart');
INSERT INTO public.event_data_tokens VALUES ('restricted');
INSERT INTO public.event_data_tokens VALUES ('review');
INSERT INTO public.event_data_tokens VALUES ('self');
INSERT INTO public.event_data_tokens VALUES ('sketch');
INSERT INTO public.event_data_tokens VALUES ('source');
INSERT INTO public.event_data_tokens VALUES ('superseded');
INSERT INTO public.event_data_tokens VALUES ('thought');
INSERT INTO public.event_data_tokens VALUES ('thought_added');
INSERT INTO public.event_data_tokens VALUES ('thought_removed');
INSERT INTO public.event_data_tokens VALUES ('thought_updated');
INSERT INTO public.event_data_tokens VALUES ('thoughts_moved');
INSERT INTO public.event_data_tokens VALUES ('wiki');
INSERT INTO public.event_data_tokens VALUES ('work');
INSERT INTO public.event_data_tokens VALUES ('workspace');
INSERT INTO public.event_data_tokens VALUES ('manager');


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.events VALUES ('b85f2ea7-40c4-4ca1-a4e2-9b453adaddf0', 'workspace.created.v1', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{}', '2026-11-20 11:26:43.257462+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 1);
INSERT INTO public.events VALUES ('8b2fc1a4-a210-457e-87d7-6977c811e2c3', 'project.created.v1', '4afe9242-92a0-4ab0-a010-c1e3c2eb6c47', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"visibility": "workspace"}', '2026-11-20 11:26:43.257462+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 2);
INSERT INTO public.events VALUES ('7e414929-c17d-435c-94a1-425f2eb0fce3', 'workspace.renamed.v1', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{}', '2026-11-20 11:26:43.350442+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 3);
INSERT INTO public.events VALUES ('62e4f6dd-1779-4e42-9b09-a95d61f30a8c', 'project.created.v1', '664527cf-118c-48f4-b7ff-f829c0460d26', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"visibility": "restricted"}', '2026-11-20 11:26:43.384064+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 4);
INSERT INTO public.events VALUES ('2cc2f548-d4cc-43e4-82fd-5262c9fbca93', 'project.conversation_created.v1', '664527cf-118c-48f4-b7ff-f829c0460d26', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"messageId": "08074005-d0db-495c-8fcd-0a00e62b3338", "conversationId": "bf52fbba-c496-4746-84a1-1505adc31204"}', '2026-11-20 11:26:43.546566+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 5);
INSERT INTO public.events VALUES ('d354e59a-13d8-4a24-9881-a4bc5332a73e', 'project.message_sent.v1', '664527cf-118c-48f4-b7ff-f829c0460d26', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"messageId": "d9e1e557-69c9-4008-b2ab-9cbcf02b08b8", "conversationId": "bf52fbba-c496-4746-84a1-1505adc31204"}', '2026-11-20 11:26:43.59087+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 6);
INSERT INTO public.events VALUES ('2fcc0dec-b66a-464b-95f2-72b8ea34cf16', 'project.doc_created.v1', '664527cf-118c-48f4-b7ff-f829c0460d26', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"docId": "fda509f0-0c26-464c-a79b-4340bab00e5d", "version": 1}', '2026-11-20 11:26:43.653379+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 7);
INSERT INTO public.events VALUES ('50f185a5-2910-4fa5-a608-dd464ee2e2f5', 'project.doc_updated.v1', '664527cf-118c-48f4-b7ff-f829c0460d26', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"docId": "fda509f0-0c26-464c-a79b-4340bab00e5d", "version": 2}', '2026-11-20 11:26:43.69545+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 8);
INSERT INTO public.events VALUES ('86dfa684-90f8-4b2e-8e21-66b0800392a3', 'project.work_created.v1', '664527cf-118c-48f4-b7ff-f829c0460d26', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"workId": "04cac509-90e7-43d4-b05f-c2c743810c63"}', '2026-11-20 11:26:43.760257+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 9);
INSERT INTO public.events VALUES ('e854df7d-a18c-46db-8151-085133379515', 'sketch.created.v1', '96bda1f6-fcc4-4b1b-b9d1-afbeab0bf25e', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"scope": "private", "thoughtIds": []}', '2026-11-20 11:26:43.802064+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 10);
INSERT INTO public.events VALUES ('c48e43aa-9d13-4a4e-ad6d-64da77b39af3', 'workspace.invite_created.v1', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"role": "member", "inviteId": "e65337ea-2786-4cdc-b50a-ae386cf3b7d5"}', '2026-11-20 11:26:43.853929+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 11);
INSERT INTO public.events VALUES ('d69ffe1f-8055-415e-b0f8-840d09876877', 'workspace.member_added.v1', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '{"role": "member", "userId": "52bfbd7b-3c03-4c21-9fe9-1f68b174afa4", "inviteId": "e65337ea-2786-4cdc-b50a-ae386cf3b7d5"}', '2026-11-20 11:26:44.251297+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 12);
INSERT INTO public.events VALUES ('a5d616ea-96d0-408d-9420-2ba3cc4dc3b1', 'workspace.invite_created.v1', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"role": "guest", "inviteId": "51a2c572-9579-4a62-89c8-3e5a394d533f"}', '2026-11-20 11:26:44.370611+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 13);
INSERT INTO public.events VALUES ('c96c1dfb-6141-4dd2-8f2c-8d79cc3fd179', 'workspace.member_added.v1', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', '{"role": "guest", "userId": "812c1f3d-162a-47bb-8ba4-fd5381ea5923", "inviteId": "51a2c572-9579-4a62-89c8-3e5a394d533f"}', '2026-11-20 11:26:44.747442+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 14);
INSERT INTO public.events VALUES ('96c9f4fe-01a1-44a1-ad97-b9ec5850ef64', 'project.created.v1', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"visibility": "restricted"}', '2026-11-20 11:26:44.851195+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 15);
INSERT INTO public.events VALUES ('f40fc067-57e1-4ffb-9568-839d3910b903', 'project.grant_set.v1', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"role": "contributor", "grantId": "6caf5ee4-fd00-4b06-978e-9b043eed8641", "principal": {"id": "52bfbd7b-3c03-4c21-9fe9-1f68b174afa4", "kind": "human"}}', '2026-11-20 11:26:44.851195+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 16);
INSERT INTO public.events VALUES ('fc74e002-6499-46cf-865e-adc83a581e47', 'project.grant_set.v1', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"role": "contributor", "grantId": "f78a2d95-1c44-43a5-8968-afc7a4e24c4f", "principal": {"id": "812c1f3d-162a-47bb-8ba4-fd5381ea5923", "kind": "human"}}', '2026-11-20 11:26:44.851195+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 17);
INSERT INTO public.events VALUES ('63641bcd-396b-403c-8c13-24eabbd471ff', 'project.conversation_created.v1', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"messageId": "37aed0c9-7a96-450b-9d7d-aaba10788eaf", "conversationId": "e1aca7f5-107b-4e47-9a54-e6156ae0894a"}', '2026-11-20 11:26:45.109982+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 18);
INSERT INTO public.events VALUES ('adf6ce37-1c4b-4236-a151-957acab449fc', 'project.message_sent.v1', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '{"messageId": "d30b4aed-978d-4e57-8ba2-37bbd67385af", "conversationId": "e1aca7f5-107b-4e47-9a54-e6156ae0894a"}', '2026-11-20 11:26:45.154274+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 19);
INSERT INTO public.events VALUES ('4aca25ce-2365-45e2-ab8d-3ea7cc23a9ad', 'project.message_sent.v1', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'human:812c1f3d-162a-47bb-8ba4-fd5381ea5923', '{"messageId": "bd700eca-8b68-4935-b451-9fdf1693c34d", "conversationId": "e1aca7f5-107b-4e47-9a54-e6156ae0894a"}', '2026-11-20 11:26:45.191227+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 20);
INSERT INTO public.events VALUES ('46081d0f-30ba-4fbb-a623-a87aba3a6f82', 'dm.created.v1', '93ead2ce-d190-40cc-945e-63a407d73985', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"kind": "pair"}', '2026-11-20 11:26:45.229034+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 21);
INSERT INTO public.events VALUES ('ea0a6117-1f2d-446e-b330-25b0ed50918b', 'dm.message_sent.v1', '93ead2ce-d190-40cc-945e-63a407d73985', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"messageId": "7036dbed-2470-4b34-b0ad-cc738b697f7e"}', '2026-11-20 11:26:45.263517+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 22);
INSERT INTO public.events VALUES ('56d575c4-e05e-427e-986c-bb5833bb6aeb', 'dm.notice.v1', '93ead2ce-d190-40cc-945e-63a407d73985', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{}', '2026-11-20 11:26:45.285675+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 23);
INSERT INTO public.events VALUES ('2e60fecc-1a94-485a-88e0-f6482a741ca6', 'dm.message_sent.v1', '93ead2ce-d190-40cc-945e-63a407d73985', 'human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '{"rootId": "7036dbed-2470-4b34-b0ad-cc738b697f7e", "messageId": "e4def4c5-ee85-48dd-bda6-c0a1594bf4ea"}', '2026-11-20 11:26:45.29047+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 24);
INSERT INTO public.events VALUES ('493f525e-c284-4ac4-abad-ef162571d25b', 'dm.notice.v1', '93ead2ce-d190-40cc-945e-63a407d73985', 'human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '{}', '2026-11-20 11:26:45.340674+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 25);
INSERT INTO public.events VALUES ('bb2ec908-09d5-4272-acc6-fafa1fbfb7ce', 'dm.created.v1', '9ba59e5c-63fc-4e8a-ae12-9703781cd053', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"kind": "group"}', '2026-11-20 11:26:45.344137+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 26);
INSERT INTO public.events VALUES ('08116329-1848-41d6-aa42-7f302f6a9a04', 'dm.message_sent.v1', '9ba59e5c-63fc-4e8a-ae12-9703781cd053', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"messageId": "f6fac6ac-ce3f-4d72-b008-9c314bf1fddf"}', '2026-11-20 11:26:45.384071+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 27);
INSERT INTO public.events VALUES ('cc62a8aa-682b-497b-b33e-6963994eb31a', 'dm.notice.v1', '9ba59e5c-63fc-4e8a-ae12-9703781cd053', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{}', '2026-11-20 11:26:45.435377+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 28);
INSERT INTO public.events VALUES ('6f6e1712-083b-4751-8ac1-92a9edc9fd52', 'dm.notice.v1', '9ba59e5c-63fc-4e8a-ae12-9703781cd053', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{}', '2026-11-20 11:26:45.435377+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 29);
INSERT INTO public.events VALUES ('da616ca6-053c-4b2d-b476-dd466b6fb5d5', 'dm.message_sent.v1', '9ba59e5c-63fc-4e8a-ae12-9703781cd053', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"messageId": "49a516f8-749e-4d83-b320-72182ec9ba24"}', '2026-11-20 11:26:45.441177+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 30);
INSERT INTO public.events VALUES ('a5df009c-e676-4f29-996d-ad74640aa652', 'dm.notice.v1', '9ba59e5c-63fc-4e8a-ae12-9703781cd053', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{}', '2026-11-20 11:26:45.482663+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 31);
INSERT INTO public.events VALUES ('3e8c1eec-a7bd-46d3-b669-410e14c04398', 'dm.notice.v1', '9ba59e5c-63fc-4e8a-ae12-9703781cd053', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{}', '2026-11-20 11:26:45.482663+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 32);
INSERT INTO public.events VALUES ('9aded7b1-edf7-4786-ae04-6c40308f1e37', 'project.doc_created.v1', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"docId": "c932328a-2781-45af-8ca9-fb6b94d7ad48", "version": 1}', '2026-11-20 11:26:45.488944+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 33);
INSERT INTO public.events VALUES ('67913755-6e7d-424b-a4b2-f61dcdaa9a25', 'project.doc_updated.v1', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '{"docId": "c932328a-2781-45af-8ca9-fb6b94d7ad48", "version": 2}', '2026-11-20 11:26:45.541472+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 34);
INSERT INTO public.events VALUES ('54c240e1-00c7-4039-99bf-82f206735217', 'project.doc_updated.v1', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"docId": "c932328a-2781-45af-8ca9-fb6b94d7ad48", "version": 3}', '2026-11-20 11:26:45.577183+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 35);
INSERT INTO public.events VALUES ('25548804-7344-4c47-bf73-e177d9e8d2ae', 'sketch.created.v1', '5a6e389a-8c43-4630-b742-906b4ebb865d', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"scope": "project", "thoughtIds": []}', '2026-11-20 11:26:45.640707+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 36);
INSERT INTO public.events VALUES ('fc2789db-3aa8-4510-a684-380766b7347b', 'project.notice.v1', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{}', '2026-11-20 11:26:45.884593+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 41);
INSERT INTO public.events VALUES ('93b9f164-3185-491a-b610-e2b32119072e', 'sketch.changed.v1', '5a6e389a-8c43-4630-b742-906b4ebb865d', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"op": "thought_added", "linkIds": [], "thoughtIds": ["b29b0132-acf9-40f1-aa6d-5d1c924205ef"]}', '2026-11-20 11:26:45.677833+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 37);
INSERT INTO public.events VALUES ('db67c27c-1f18-4294-9f30-7f76c8364203', 'sketch.changed.v1', '5a6e389a-8c43-4630-b742-906b4ebb865d', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"op": "thought_added", "linkIds": ["2b34fef7-0405-4443-9d40-5bfe7ce23802"], "thoughtIds": ["e09da5bf-881e-41dc-94c1-d9df53140ba7"]}', '2026-11-20 11:26:45.723857+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 38);
INSERT INTO public.events VALUES ('4a86aec9-f9f6-4551-bda9-7f8f0f317251', 'sketch.changed.v1', '5a6e389a-8c43-4630-b742-906b4ebb865d', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"op": "thought_added", "linkIds": ["c36c3a67-1736-4dad-8f51-547aa796b52e"], "thoughtIds": ["e9bc48f6-5b03-4818-b786-a1af25b7308e"]}', '2026-11-20 11:26:45.777938+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 39);
INSERT INTO public.events VALUES ('c17e98fd-2cd5-43fb-88a7-5898561da504', 'project.work_created.v1', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"workId": "7073e9f2-ba3d-4ccf-ad7e-a24cf90446c2", "assignedTo": "52bfbd7b-3c03-4c21-9fe9-1f68b174afa4"}', '2026-11-20 11:26:45.833153+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 40);
INSERT INTO public.events VALUES ('05b8a9b0-a546-4057-8ee7-a3d6331c4870', 'project.work_created.v1', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"workId": "251cd34f-3781-4039-924f-cf37140a1536"}', '2026-11-20 11:26:45.887182+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 42);
INSERT INTO public.events VALUES ('c7fe79b0-2736-4fca-a3db-5d76ca42c03c', 'project.work_created.v1', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"workId": "b778cb8f-70d8-4cd0-a408-83cf5bf4ce4d", "waitingFor": "52bfbd7b-3c03-4c21-9fe9-1f68b174afa4"}', '2026-11-20 11:26:46.011585+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 43);
INSERT INTO public.events VALUES ('4b183814-8893-4de9-963f-23eee6ecac0f', 'project.notifications_changed.v1', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{}', '2026-11-20 11:26:46.098894+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 45);
INSERT INTO public.events VALUES ('f8390c32-178c-4c6c-9668-6a8e7eaf677d', 'workspace.created.v1', 'd2bba607-2757-4252-b991-8f3dad4dde96', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{}', '2026-11-20 11:26:46.336199+00', 'd2bba607-2757-4252-b991-8f3dad4dde96', 46);
INSERT INTO public.events VALUES ('d351fefd-338f-45e1-9f28-592a09cd0ada', 'workspace.unlocked.v1', 'd2bba607-2757-4252-b991-8f3dad4dde96', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"by": "11c2823a-c8ac-4431-955a-a5ca0948254b"}', '2026-11-20 11:26:46.336199+00', 'd2bba607-2757-4252-b991-8f3dad4dde96', 47);
INSERT INTO public.events VALUES ('b1635160-73d3-479d-a010-75f81f0f91ae', 'project.created.v1', '93feece2-e363-48a8-8a68-51f71e062b79', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"visibility": "workspace"}', '2026-11-20 11:26:46.37406+00', 'd2bba607-2757-4252-b991-8f3dad4dde96', 48);
INSERT INTO public.events VALUES ('ad6e8904-27bb-436a-b12e-8c6262d4e322', 'project.conversation_created.v1', '93feece2-e363-48a8-8a68-51f71e062b79', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"messageId": "6c554f4b-7b3e-4eda-bc74-a21ad9c7748f", "conversationId": "178a9281-45d0-473e-850c-0b91f48004aa"}', '2026-11-20 11:26:46.422157+00', 'd2bba607-2757-4252-b991-8f3dad4dde96', 49);
INSERT INTO public.events VALUES ('26234443-76e8-4384-8bb3-317bfe944f7c', 'workspace.locked.v1', 'd2bba607-2757-4252-b991-8f3dad4dde96', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"reason": "person"}', '2026-11-20 11:26:46.460221+00', 'd2bba607-2757-4252-b991-8f3dad4dde96', 50);
INSERT INTO public.events VALUES ('cd159269-3742-497d-b102-17d42fb05df4', 'agent.created.v1', '1185d65b-0e5e-42cb-b620-bf84e8855d13', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"owner": "self"}', '2026-11-20 11:26:46.53095+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 51);
INSERT INTO public.events VALUES ('5352857e-3d7c-4828-b727-baefbb826396', 'agent.created.v1', '154e1a8e-024d-40ed-9f26-9403774a7331', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"owner": "self"}', '2026-11-20 11:26:46.580006+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 52);
INSERT INTO public.events VALUES ('6c55acda-609f-4a52-a941-7f287a221934', 'assistant_run.changed.v1', '4bf28a7e-832f-4fda-ac69-c8d63724a780', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"status": "queued"}', '2026-11-20 11:26:46.739513+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 53);
INSERT INTO public.events VALUES ('3c14f1ca-475a-4396-8e3e-344e1335d69e', 'project.notice.v1', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{}', '2026-11-20 11:26:46.045302+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 44);
INSERT INTO public.events VALUES ('adf4388d-285b-4eae-b592-d32038bfdfc2', 'assistant_run.changed.v1', '4bf28a7e-832f-4fda-ac69-c8d63724a780', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"status": "reading"}', '2026-11-20 11:26:46.813284+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 54);
INSERT INTO public.events VALUES ('1092b513-0904-402a-a6ad-8ed1df879f88', 'assistant_run.changed.v1', '4bf28a7e-832f-4fda-ac69-c8d63724a780', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"status": "dispatching"}', '2026-11-20 11:26:46.92871+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 55);
INSERT INTO public.events VALUES ('0ce1caba-0a13-4408-b6fe-0ad4e00359be', 'assistant_run.changed.v1', '4bf28a7e-832f-4fda-ac69-c8d63724a780', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '{"status": "completed"}', '2026-11-20 11:26:48.01685+00', '79bbedd2-67db-4944-a1b6-55c9a4553889', 56);


--
-- Data for Name: file_garbage; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_text_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: flux_schema_version; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.flux_schema_version VALUES (1, '2026-11-20 11:26:33.15218+00');
INSERT INTO public.flux_schema_version VALUES (2, '2026-11-20 11:26:33.664635+00');
INSERT INTO public.flux_schema_version VALUES (3, '2026-11-20 11:26:33.681531+00');
INSERT INTO public.flux_schema_version VALUES (4, '2026-11-20 11:26:33.701211+00');
INSERT INTO public.flux_schema_version VALUES (5, '2026-11-20 11:26:33.731342+00');
INSERT INTO public.flux_schema_version VALUES (6, '2026-11-20 11:26:33.756716+00');
INSERT INTO public.flux_schema_version VALUES (7, '2026-11-20 11:26:33.780292+00');
INSERT INTO public.flux_schema_version VALUES (8, '2026-11-20 11:26:33.798339+00');
INSERT INTO public.flux_schema_version VALUES (9, '2026-11-20 11:26:33.815965+00');
INSERT INTO public.flux_schema_version VALUES (10, '2026-11-20 11:26:33.836306+00');
INSERT INTO public.flux_schema_version VALUES (11, '2026-11-20 11:26:33.85549+00');
INSERT INTO public.flux_schema_version VALUES (12, '2026-11-20 11:26:33.873415+00');
INSERT INTO public.flux_schema_version VALUES (13, '2026-11-20 11:26:33.88492+00');
INSERT INTO public.flux_schema_version VALUES (14, '2026-11-20 11:26:33.903288+00');
INSERT INTO public.flux_schema_version VALUES (15, '2026-11-20 11:26:33.922226+00');
INSERT INTO public.flux_schema_version VALUES (16, '2026-11-20 11:26:33.949072+00');
INSERT INTO public.flux_schema_version VALUES (17, '2026-11-20 11:26:33.979085+00');
INSERT INTO public.flux_schema_version VALUES (18, '2026-11-20 11:26:33.99559+00');
INSERT INTO public.flux_schema_version VALUES (19, '2026-11-20 11:26:34.007881+00');
INSERT INTO public.flux_schema_version VALUES (20, '2026-11-20 11:26:34.020058+00');
INSERT INTO public.flux_schema_version VALUES (21, '2026-11-20 11:26:34.034456+00');
INSERT INTO public.flux_schema_version VALUES (22, '2026-11-20 11:26:34.046334+00');
INSERT INTO public.flux_schema_version VALUES (23, '2026-11-20 11:26:34.064897+00');
INSERT INTO public.flux_schema_version VALUES (24, '2026-11-20 11:26:34.076857+00');
INSERT INTO public.flux_schema_version VALUES (25, '2026-11-20 11:26:34.091125+00');
INSERT INTO public.flux_schema_version VALUES (26, '2026-11-20 11:26:34.104712+00');
INSERT INTO public.flux_schema_version VALUES (27, '2026-11-20 11:26:34.125081+00');
INSERT INTO public.flux_schema_version VALUES (28, '2026-11-20 11:26:34.145272+00');
INSERT INTO public.flux_schema_version VALUES (29, '2026-11-20 11:26:34.163325+00');
INSERT INTO public.flux_schema_version VALUES (30, '2026-11-20 11:26:34.181864+00');
INSERT INTO public.flux_schema_version VALUES (31, '2026-11-20 11:26:34.199665+00');
INSERT INTO public.flux_schema_version VALUES (32, '2026-11-20 11:26:34.21993+00');
INSERT INTO public.flux_schema_version VALUES (35, '2026-11-20 11:26:34.238226+00');
INSERT INTO public.flux_schema_version VALUES (36, '2026-11-20 11:26:34.256963+00');
INSERT INTO public.flux_schema_version VALUES (37, '2026-11-20 11:26:34.27645+00');
INSERT INTO public.flux_schema_version VALUES (38, '2026-11-20 11:26:34.296367+00');
INSERT INTO public.flux_schema_version VALUES (39, '2026-11-20 11:26:34.314653+00');
INSERT INTO public.flux_schema_version VALUES (40, '2026-11-20 11:26:34.344995+00');
INSERT INTO public.flux_schema_version VALUES (41, '2026-11-20 11:26:34.366948+00');
INSERT INTO public.flux_schema_version VALUES (42, '2026-11-20 11:26:34.383563+00');
INSERT INTO public.flux_schema_version VALUES (43, '2026-11-20 11:26:34.394698+00');
INSERT INTO public.flux_schema_version VALUES (44, '2026-11-20 11:26:34.407072+00');
INSERT INTO public.flux_schema_version VALUES (46, '2026-11-20 11:26:34.466925+00');
INSERT INTO public.flux_schema_version VALUES (47, '2026-11-20 11:26:34.477919+00');
INSERT INTO public.flux_schema_version VALUES (48, '2026-11-20 11:26:34.495528+00');
INSERT INTO public.flux_schema_version VALUES (49, '2026-11-20 11:26:34.512944+00');
INSERT INTO public.flux_schema_version VALUES (50, '2026-11-20 11:26:34.530913+00');
INSERT INTO public.flux_schema_version VALUES (51, '2026-11-20 11:26:34.542842+00');
INSERT INTO public.flux_schema_version VALUES (52, '2026-11-20 11:26:34.564827+00');
INSERT INTO public.flux_schema_version VALUES (53, '2026-11-20 11:26:34.582327+00');
INSERT INTO public.flux_schema_version VALUES (54, '2026-11-20 11:26:34.600052+00');
INSERT INTO public.flux_schema_version VALUES (55, '2026-11-20 11:26:34.620077+00');
INSERT INTO public.flux_schema_version VALUES (56, '2026-11-20 11:26:34.638787+00');
INSERT INTO public.flux_schema_version VALUES (57, '2026-11-20 11:26:34.658757+00');
INSERT INTO public.flux_schema_version VALUES (58, '2026-11-20 11:26:34.692359+00');
INSERT INTO public.flux_schema_version VALUES (59, '2026-11-20 11:26:34.708216+00');
INSERT INTO public.flux_schema_version VALUES (60, '2026-11-20 11:26:34.726165+00');
INSERT INTO public.flux_schema_version VALUES (61, '2026-11-20 11:26:34.740933+00');
INSERT INTO public.flux_schema_version VALUES (62, '2026-11-20 11:26:34.768401+00');
INSERT INTO public.flux_schema_version VALUES (63, '2026-11-20 11:26:34.784196+00');
INSERT INTO public.flux_schema_version VALUES (64, '2026-11-20 11:26:34.800877+00');
INSERT INTO public.flux_schema_version VALUES (65, '2026-11-20 11:26:34.817922+00');
INSERT INTO public.flux_schema_version VALUES (66, '2026-11-20 11:26:34.90164+00');
INSERT INTO public.flux_schema_version VALUES (67, '2026-11-20 11:26:34.916795+00');
INSERT INTO public.flux_schema_version VALUES (68, '2026-11-20 11:26:34.928117+00');
INSERT INTO public.flux_schema_version VALUES (69, '2026-11-20 11:26:34.942514+00');
INSERT INTO public.flux_schema_version VALUES (70, '2026-11-20 11:26:34.95835+00');
INSERT INTO public.flux_schema_version VALUES (71, '2026-11-20 11:26:34.974979+00');
INSERT INTO public.flux_schema_version VALUES (72, '2026-11-20 11:26:34.988054+00');
INSERT INTO public.flux_schema_version VALUES (73, '2026-11-20 11:26:35.00961+00');
INSERT INTO public.flux_schema_version VALUES (74, '2026-11-20 11:26:35.02598+00');
INSERT INTO public.flux_schema_version VALUES (75, '2026-11-20 11:26:35.042051+00');
INSERT INTO public.flux_schema_version VALUES (76, '2026-11-20 11:26:35.058231+00');
INSERT INTO public.flux_schema_version VALUES (77, '2026-11-20 11:26:35.074919+00');
INSERT INTO public.flux_schema_version VALUES (78, '2026-11-20 11:26:35.091394+00');
INSERT INTO public.flux_schema_version VALUES (79, '2026-11-20 11:26:35.108052+00');
INSERT INTO public.flux_schema_version VALUES (80, '2026-11-20 11:26:35.125645+00');
INSERT INTO public.flux_schema_version VALUES (81, '2026-11-20 11:26:35.136812+00');
INSERT INTO public.flux_schema_version VALUES (82, '2026-11-20 11:26:35.153365+00');
INSERT INTO public.flux_schema_version VALUES (83, '2026-11-20 11:26:35.171613+00');
INSERT INTO public.flux_schema_version VALUES (84, '2026-11-20 11:26:35.186895+00');
INSERT INTO public.flux_schema_version VALUES (85, '2026-11-20 11:26:35.202959+00');
INSERT INTO public.flux_schema_version VALUES (86, '2026-11-20 11:26:35.224292+00');
INSERT INTO public.flux_schema_version VALUES (87, '2026-11-20 11:26:35.244389+00');
INSERT INTO public.flux_schema_version VALUES (88, '2026-11-20 11:26:35.260203+00');
INSERT INTO public.flux_schema_version VALUES (89, '2026-11-20 11:26:35.273367+00');
INSERT INTO public.flux_schema_version VALUES (90, '2026-11-20 11:26:35.283882+00');
INSERT INTO public.flux_schema_version VALUES (91, '2026-11-20 11:26:35.297871+00');
INSERT INTO public.flux_schema_version VALUES (92, '2026-11-20 11:26:35.310174+00');
INSERT INTO public.flux_schema_version VALUES (93, '2026-11-20 11:26:35.321238+00');
INSERT INTO public.flux_schema_version VALUES (94, '2026-11-20 11:26:35.337382+00');
INSERT INTO public.flux_schema_version VALUES (95, '2026-11-20 11:26:35.349752+00');


--
-- Data for Name: github_bindings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: github_credentials; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: github_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: github_oauth_flows; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: github_processing; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: github_rule_defaults; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: github_task_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: github_task_rule_changes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: github_task_rules; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: idempotency_account_operations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/agent-questions/:questionId/answer');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/assistant-runs/:runId/retry');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/assistant-runs/:runId/stop');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/conversations/:conversationId/assistant-runs');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/workspaces');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/my-agents');
INSERT INTO public.idempotency_account_operations VALUES ('PATCH /api/v1/my-agents/:agentId');
INSERT INTO public.idempotency_account_operations VALUES ('DELETE /api/v1/my-agents/:agentId');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/my-agents/:agentId/memory');
INSERT INTO public.idempotency_account_operations VALUES ('PATCH /api/v1/my-agents/:agentId/memory/:itemId');
INSERT INTO public.idempotency_account_operations VALUES ('DELETE /api/v1/my-agents/:agentId/memory/:itemId');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/projects/:projectId/assistant-runs');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/dms/:dmId/assistant-runs');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/my-agents/:agentId/assistant-runs');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/assistant-runs/:runId/show');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/assistant-runs/:runId/dismiss');
INSERT INTO public.idempotency_account_operations VALUES ('POST /api/v1/dms/:dmId/threads/:rootId/assistant-runs');


--
-- Data for Name: idempotency_keys; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.idempotency_keys VALUES ('a07a8ace-d205-416c-9ae6-defcf3083496', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'POST /api/v1/projects/:projectId/docs', '97fcae65-e276-4ca1-bc56-9ac92b6bcc82', '188d38885878a20aa092837f68887ca8c37580a3dc62c4660eb15142699b04e1', 201, '{"id": "fda509f0-0c26-464c-a79b-4340bab00e5d", "body": "RELEASE-doc-bd0292a3-v1", "html": "<p>RELEASE-doc-bd0292a3-v1</p>\n", "docId": "fda509f0-0c26-464c-a79b-4340bab00e5d", "links": [], "title": "RELEASE-doc-bd0292a3", "author": {"id": "11c2823a-c8ac-4431-955a-a5ca0948254b", "kind": "human", "name": "Release smoke user"}, "reason": "Started the page", "version": 1, "audience": {"kind": "project", "projectId": "664527cf-118c-48f4-b7ff-f829c0460d26"}, "mentions": [], "createdAt": "2026-11-20T11:26:43.653Z", "createdBy": {"id": "11c2823a-c8ac-4431-955a-a5ca0948254b", "kind": "human", "name": "Release smoke user"}, "projectId": "664527cf-118c-48f4-b7ff-f829c0460d26", "startedAt": "2026-11-20T11:26:43.653Z", "workspaceId": "79bbedd2-67db-4944-a1b6-55c9a4553889"}', '"1"', '2026-11-20 11:26:43.653379+00', '2026-11-21 11:26:43.653379+00');
INSERT INTO public.idempotency_keys VALUES ('1285029b-09ff-40e8-ae46-783d57986ec9', 'human:11c2823a-c8ac-4431-955a-a5ca0948254b', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'POST /api/v1/projects/:projectId/docs', '5d4bb9a6-083c-45f2-be1c-6fe803ceca53', '0f5285c5c1780209f10b5c8fca8d6b8ee90328ff3cb73f9b6150497bd9259614', 201, '{"id": "c932328a-2781-45af-8ca9-fb6b94d7ad48", "body": "GARDEN-wiki-bd0292a3-v1", "html": "<p>GARDEN-wiki-bd0292a3-v1</p>\n", "docId": "c932328a-2781-45af-8ca9-fb6b94d7ad48", "links": [], "title": "GARDEN-wiki-bd0292a3", "author": {"id": "11c2823a-c8ac-4431-955a-a5ca0948254b", "kind": "human", "name": "Release smoke user"}, "reason": "Started the page", "version": 1, "audience": {"kind": "project", "projectId": "a86025f9-f9ba-46c4-8fd0-d4949e07a97c"}, "mentions": [], "createdAt": "2026-11-20T11:26:45.488Z", "createdBy": {"id": "11c2823a-c8ac-4431-955a-a5ca0948254b", "kind": "human", "name": "Release smoke user"}, "projectId": "a86025f9-f9ba-46c4-8fd0-d4949e07a97c", "startedAt": "2026-11-20T11:26:45.488Z", "workspaceId": "79bbedd2-67db-4944-a1b6-55c9a4553889"}', '"1"', '2026-11-20 11:26:45.488944+00', '2026-11-21 11:26:45.488944+00');


--
-- Data for Name: jwks; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.jwks VALUES ('5b5e338f-6483-4ba0-8b21-e9a6a6ebf3d0', '{"kty":"OKP","crv":"Ed25519","x":"rQq1O-p8jMvxZkWO7aZSPSRvKDCZdiB03zDvm5dJVQo"}', '"e5a8bdbcc3046c094b1bab5043bd806d73a8ee70712ac0fff62b83e654a3007ae6808f8100b3c55506835b3c3a3428ad8430d8cc3d1c3d4808f5a97ffa23c0657ea956c264f3125a7706df58b01f6bd786a480aeefe72e79a8f529a5d51aac841c42dd2e024c0faa01ee7b615fc3942ff1f46098766f3e4af31f7843dbb64f0d740d5321d21c50a25bac36714760f15597230b0b1f06acfe9ca18072d905b1013080f6a89e2342d74b"', '2026-11-20 11:26:47.011+00', NULL, 'EdDSA', 'Ed25519');


--
-- Data for Name: live_access_fences; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: live_admissions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: live_editing_intents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: live_invitations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: live_presentations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: live_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: live_webhook_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: map_live_gestures; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: map_live_heads; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: map_live_journal; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: map_live_object_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: map_live_presence; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: map_live_undone; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: message_references; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: native_command_receipts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: needs_you_states; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notification_address_sends; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notification_address_tokens; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notification_addresses; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notification_cursor; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.notification_cursor VALUES ('generator', 56);


--
-- Data for Name: notification_emails; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notification_follows; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notification_generation_failures; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notification_mutes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.notification_mutes VALUES ('11c2823a-c8ac-4431-955a-a5ca0948254b', 'project', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', '2026-11-20 11:26:46.098894+00');


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.notification_preferences VALUES ('11c2823a-c8ac-4431-955a-a5ca0948254b', true, 1320, 420, 'Europe/Warsaw', '2026-11-20 11:26:46.062+00', 'everything', true, true, false, true, false);


--
-- Data for Name: notification_verification_sends; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.notifications VALUES ('8a903aff-a9d7-44bf-be2a-66440e84d1fa', '11c2823a-c8ac-4431-955a-a5ca0948254b', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'workspace', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'Ben Member joined Release restore probe', 'They are in Everyone now. Add them to other spaces in each space’s settings.', '/settings/company', NULL, '2026-11-20 11:26:44.251297+00', NULL, NULL, true, false, false, NULL);
INSERT INTO public.notifications VALUES ('b8440fd0-ab09-44c5-b019-cd71f915da8a', '11c2823a-c8ac-4431-955a-a5ca0948254b', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'workspace', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'Gina Guest joined Release restore probe', 'They are a guest: they see only the spaces you add them to, in each space’s settings.', '/settings/company', NULL, '2026-11-20 11:26:44.747442+00', NULL, NULL, true, false, false, NULL);
INSERT INTO public.notifications VALUES ('29b77316-7248-4695-9e60-fda16abe78ca', '11c2823a-c8ac-4431-955a-a5ca0948254b', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'Ben Member replied in “GARDEN-root-bd0292a3”', 'GARDEN-ben-bd0292a3', '/projects/a86025f9-f9ba-46c4-8fd0-d4949e07a97c/conversations/e1aca7f5-107b-4e47-9a54-e6156ae0894a#message-d30b4aed-978d-4e57-8ba2-37bbd67385af', NULL, '2026-11-20 11:26:45.188888+00', 'reply', 'adf6ce37-1c4b-4236-a151-957acab449fc', true, false, false, 'human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4');
INSERT INTO public.notifications VALUES ('e044c8dd-a01a-4473-9e63-d5adfc6c32e6', '11c2823a-c8ac-4431-955a-a5ca0948254b', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'Gina Guest replied in “GARDEN-root-bd0292a3”', 'GARDEN-gina-bd0292a3', '/projects/a86025f9-f9ba-46c4-8fd0-d4949e07a97c/conversations/e1aca7f5-107b-4e47-9a54-e6156ae0894a#message-bd700eca-8b68-4935-b451-9fdf1693c34d', NULL, '2026-11-20 11:26:45.228004+00', 'reply', '4aca25ce-2365-45e2-ab8d-3ea7cc23a9ad', true, false, false, 'human:812c1f3d-162a-47bb-8ba4-fd5381ea5923');
INSERT INTO public.notifications VALUES ('890b6a68-5a3d-4e20-acb7-418b2db33e0a', '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'Gina Guest replied in “GARDEN-root-bd0292a3”', 'GARDEN-gina-bd0292a3', '/projects/a86025f9-f9ba-46c4-8fd0-d4949e07a97c/conversations/e1aca7f5-107b-4e47-9a54-e6156ae0894a#message-bd700eca-8b68-4935-b451-9fdf1693c34d', NULL, '2026-11-20 11:26:45.228004+00', 'reply', '4aca25ce-2365-45e2-ab8d-3ea7cc23a9ad', true, false, false, 'human:812c1f3d-162a-47bb-8ba4-fd5381ea5923');
INSERT INTO public.notifications VALUES ('56d575c4-e05e-427e-986c-bb5833bb6aeb', '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'dm', '93ead2ce-d190-40cc-945e-63a407d73985', 'Release smoke user sent you a message', 'DM-hello-bd0292a3', '/dm/93ead2ce-d190-40cc-945e-63a407d73985#message-7036dbed-2470-4b34-b0ad-cc738b697f7e', NULL, '2026-11-20 11:26:45.285675+00', 'dm', 'ea0a6117-1f2d-446e-b330-25b0ed50918b', true, false, false, 'human:11c2823a-c8ac-4431-955a-a5ca0948254b');
INSERT INTO public.notifications VALUES ('493f525e-c284-4ac4-abad-ef162571d25b', '11c2823a-c8ac-4431-955a-a5ca0948254b', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'dm', '93ead2ce-d190-40cc-945e-63a407d73985', 'Ben Member sent you a message', 'DM-reply-bd0292a3', '/dm/93ead2ce-d190-40cc-945e-63a407d73985#message-e4def4c5-ee85-48dd-bda6-c0a1594bf4ea', NULL, '2026-11-20 11:26:45.340674+00', 'dm', '2e60fecc-1a94-485a-88e0-f6482a741ca6', true, false, false, 'human:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4');
INSERT INTO public.notifications VALUES ('cc62a8aa-682b-497b-b33e-6963994eb31a', '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'dm', '9ba59e5c-63fc-4e8a-ae12-9703781cd053', 'Release smoke user in “Garden crew bd0292a3”', 'GROUP-hello-bd0292a3', '/dm/9ba59e5c-63fc-4e8a-ae12-9703781cd053#message-f6fac6ac-ce3f-4d72-b008-9c314bf1fddf', NULL, '2026-11-20 11:26:45.435377+00', 'dm', '08116329-1848-41d6-aa42-7f302f6a9a04', true, false, false, 'human:11c2823a-c8ac-4431-955a-a5ca0948254b');
INSERT INTO public.notifications VALUES ('6f6e1712-083b-4751-8ac1-92a9edc9fd52', '812c1f3d-162a-47bb-8ba4-fd5381ea5923', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'dm', '9ba59e5c-63fc-4e8a-ae12-9703781cd053', 'Release smoke user in “Garden crew bd0292a3”', 'GROUP-hello-bd0292a3', '/dm/9ba59e5c-63fc-4e8a-ae12-9703781cd053#message-f6fac6ac-ce3f-4d72-b008-9c314bf1fddf', NULL, '2026-11-20 11:26:45.435377+00', 'dm', '08116329-1848-41d6-aa42-7f302f6a9a04', true, false, false, 'human:11c2823a-c8ac-4431-955a-a5ca0948254b');
INSERT INTO public.notifications VALUES ('a5df009c-e676-4f29-996d-ad74640aa652', '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'dm', '9ba59e5c-63fc-4e8a-ae12-9703781cd053', 'Release smoke user in “Garden crew bd0292a3”', 'ꟀꟁꟀꟁ UNICODE-bd0292a3', '/dm/9ba59e5c-63fc-4e8a-ae12-9703781cd053#message-49a516f8-749e-4d83-b320-72182ec9ba24', NULL, '2026-11-20 11:26:45.482663+00', 'dm', 'da616ca6-053c-4b2d-b476-dd466b6fb5d5', true, false, false, 'human:11c2823a-c8ac-4431-955a-a5ca0948254b');
INSERT INTO public.notifications VALUES ('3e8c1eec-a7bd-46d3-b669-410e14c04398', '812c1f3d-162a-47bb-8ba4-fd5381ea5923', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'dm', '9ba59e5c-63fc-4e8a-ae12-9703781cd053', 'Release smoke user in “Garden crew bd0292a3”', 'ꟀꟁꟀꟁ UNICODE-bd0292a3', '/dm/9ba59e5c-63fc-4e8a-ae12-9703781cd053#message-49a516f8-749e-4d83-b320-72182ec9ba24', NULL, '2026-11-20 11:26:45.482663+00', 'dm', 'da616ca6-053c-4b2d-b476-dd466b6fb5d5', true, false, false, 'human:11c2823a-c8ac-4431-955a-a5ca0948254b');
INSERT INTO public.notifications VALUES ('fc2789db-3aa8-4510-a684-380766b7347b', '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'Release smoke user assigned you “GARDEN-calibrate-bd0292a3”', 'Work in Garden space', '/projects/a86025f9-f9ba-46c4-8fd0-d4949e07a97c/tasks?open=work:7073e9f2-ba3d-4ccf-ad7e-a24cf90446c2', NULL, '2026-11-20 11:26:45.884593+00', 'assigned', 'c17e98fd-2cd5-43fb-88a7-5898561da504', true, false, false, 'human:11c2823a-c8ac-4431-955a-a5ca0948254b');
INSERT INTO public.notifications VALUES ('3c14f1ca-475a-4396-8e3e-344e1335d69e', '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'Release smoke user is waiting for you: #3 GARDEN-approve-bd0292a3', 'needs a decision of the owner', '/projects/a86025f9-f9ba-46c4-8fd0-d4949e07a97c/tasks?open=work:b778cb8f-70d8-4cd0-a408-83cf5bf4ce4d', NULL, '2026-11-20 11:26:46.045302+00', 'assigned', 'c7fe79b0-2736-4fca-a3db-5d76ca42c03c', true, false, false, 'human:11c2823a-c8ac-4431-955a-a5ca0948254b');


--
-- Data for Name: oauth_access_token; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: oauth_client; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: oauth_client_assertion; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: oauth_client_resource; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: oauth_consent; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: oauth_grant_authentication; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: oauth_refresh_token; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: oauth_resource; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.oauth_resource VALUES ('335b9e1c-ac5d-4527-a4d1-99804ac7d584', 'http://127.0.0.1:25851/mcp', 'http://127.0.0.1:25851/mcp', NULL, NULL, NULL, NULL, NULL, NULL, false, false, '2026-11-20 11:26:41.522+00', '2026-11-20 11:26:41.522+00', 1, NULL);


--
-- Data for Name: outbox; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: password_attempts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: password_reset_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: person_photos; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: personal_run_cites; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: personal_run_pictures; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: personal_run_private_texts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: personal_run_web_reads; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: personal_run_web_searches; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: personal_runs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.personal_runs VALUES ('4bf28a7e-832f-4fda-ac69-c8d63724a780', '79bbedd2-67db-4944-a1b6-55c9a4553889', NULL, NULL, '11c2823a-c8ac-4431-955a-a5ca0948254b', '154e1a8e-024d-40ed-9f26-9403774a7331', '3b1bb027-216e-4eaa-9fa3-78720ba27253', '2fbcef9d-17a0-4f0c-b673-7f07582f2c8e', 'b784231c2c965c54b547428977390eef3339154ea665d312859fa8a6991e972f', 'ask', 'What is the garden plan? (bd0292a3)', NULL, NULL, NULL, NULL, 'completed', NULL, NULL, 'released', 0, 0, 12, 8, 'upgrade-check-model', 'UPGRADE-CHECK-ANSWER: the provider mock answered.', false, '[]', '2026-11-20 11:26:48.025+00', '2026-11-20 11:26:46.739513+00', '2026-11-20 11:26:46.936+00', '2026-11-20 11:26:48.025+00', '2026-11-20 11:26:48.025+00', 'openai_compatible', 'server', NULL, NULL, NULL, false, NULL, '44a41e92-3694-4311-b1a9-49777aa92bea', '2026-11-20 12:31:46.988+00', '2026-11-20 11:26:47.993534+00', '{flux_changes_since,flux_get_conversation,flux_get_decision,flux_get_doc,flux_get_map,flux_get_task_discussion,flux_get_work,flux_list_contexts,flux_list_conversations,flux_list_decisions,flux_list_docs,flux_list_maps,flux_list_materials,flux_list_work,flux_project_orientation,flux_read_around,flux_read_file,flux_read_material,flux_read_web,flux_search,flux_summarize,flux_attach_image,flux_attach_file}', 0, NULL, 'owner_request', NULL, NULL, NULL, '2026-11-20 11:26:47.902+00', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0);


--
-- Data for Name: project_ai_policies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_ai_policies VALUES ('4afe9242-92a0-4ab0-a010-c1e3c2eb6c47', 'allowed', 1, NULL, '2026-11-20 11:26:43.257462+00');
INSERT INTO public.project_ai_policies VALUES ('664527cf-118c-48f4-b7ff-f829c0460d26', 'allowed', 1, NULL, '2026-11-20 11:26:43.384064+00');
INSERT INTO public.project_ai_policies VALUES ('a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'allowed', 1, NULL, '2026-11-20 11:26:44.851195+00');
INSERT INTO public.project_ai_policies VALUES ('93feece2-e363-48a8-8a68-51f71e062b79', 'blocked', 1, NULL, '2026-11-20 11:26:46.37406+00');


--
-- Data for Name: project_conversations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_conversations VALUES ('bf52fbba-c496-4746-84a1-1505adc31204', '79bbedd2-67db-4944-a1b6-55c9a4553889', '664527cf-118c-48f4-b7ff-f829c0460d26', '11c2823a-c8ac-4431-955a-a5ca0948254b', 3, '2026-11-20 11:26:43.546566+00', NULL);
INSERT INTO public.project_conversations VALUES ('e1aca7f5-107b-4e47-9a54-e6156ae0894a', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', '11c2823a-c8ac-4431-955a-a5ca0948254b', 4, '2026-11-20 11:26:45.109982+00', NULL);
INSERT INTO public.project_conversations VALUES ('178a9281-45d0-473e-850c-0b91f48004aa', 'd2bba607-2757-4252-b991-8f3dad4dde96', '93feece2-e363-48a8-8a68-51f71e062b79', '11c2823a-c8ac-4431-955a-a5ca0948254b', 2, '2026-11-20 11:26:46.422157+00', NULL);


--
-- Data for Name: project_decision_discussions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_decision_resumptions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_decisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_files; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_files VALUES ('18fc6f09-36dc-4f8a-b38f-e98d8bcbb0da', '79bbedd2-67db-4944-a1b6-55c9a4553889', '664527cf-118c-48f4-b7ff-f829c0460d26', '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, 'ec183cb5-e2f5-49d9-9a8d-330131f73809', NULL, 'release-probe.bin', 'ready', 5242880, 10, '5ee4e165e7030255912f6de8535b4234fecd9c37bcbac2c5dc818c72869d4e35', '2026-11-20 11:26:43.422929+00', '2026-11-20 11:26:43.52+00', NULL, '08074005-d0db-495c-8fcd-0a00e62b3338', 0, '2026-11-20 11:26:43.546+00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.project_files VALUES ('28023ce4-44a1-48e8-b63c-9454e47ddcb5', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, '81c8670a-1741-44d7-b7f0-10cc1b7365ed', NULL, 'garden-notes.bin', 'ready', 5242880, 10, 'd1a66b4ab73f44e941a304d24c48a33e5f8b2d576ee05820686e366cc65d01ff', '2026-11-20 11:26:44.898176+00', '2026-11-20 11:26:44.977+00', NULL, '37aed0c9-7a96-450b-9d7d-aaba10788eaf', 0, '2026-11-20 11:26:45.109+00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.project_files VALUES ('eabc2d04-d93e-4b71-b74f-5415862cf48a', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, '44afb90e-5abd-4b2e-9b85-6be59865bfe6', NULL, 'garden-clip.mp4', 'ready', 17985, 17985, '1c619f931f92cf1897eddf455e98d54f5d65b7d2a97fb0e1ed28b4a03f36d84e', '2026-11-20 11:26:44.993878+00', '2026-11-20 11:26:45.087+00', NULL, '37aed0c9-7a96-450b-9d7d-aaba10788eaf', 1, '2026-11-20 11:26:45.109+00', NULL, NULL, NULL, NULL, 2000, 'mp4', NULL, NULL, NULL, NULL, NULL);


--
-- Data for Name: project_grants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_grants VALUES ('89189071-d58c-436c-90bb-b29bac593872', '79bbedd2-67db-4944-a1b6-55c9a4553889', '4afe9242-92a0-4ab0-a010-c1e3c2eb6c47', '11c2823a-c8ac-4431-955a-a5ca0948254b', 'manager', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:43.257462+00', '2026-11-20 11:26:43.257462+00', false);
INSERT INTO public.project_grants VALUES ('7ad95b71-db51-49ab-b3a9-c4307e5d8245', '79bbedd2-67db-4944-a1b6-55c9a4553889', '664527cf-118c-48f4-b7ff-f829c0460d26', '11c2823a-c8ac-4431-955a-a5ca0948254b', 'manager', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:43.384064+00', '2026-11-20 11:26:43.384064+00', false);
INSERT INTO public.project_grants VALUES ('0f1e9928-b625-4a73-a718-ccd746961bbe', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', '11c2823a-c8ac-4431-955a-a5ca0948254b', 'manager', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:44.851195+00', '2026-11-20 11:26:44.851195+00', false);
INSERT INTO public.project_grants VALUES ('6caf5ee4-fd00-4b06-978e-9b043eed8641', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 'contributor', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:44.851195+00', '2026-11-20 11:26:44.851195+00', false);
INSERT INTO public.project_grants VALUES ('f78a2d95-1c44-43a5-8968-afc7a4e24c4f', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', '812c1f3d-162a-47bb-8ba4-fd5381ea5923', 'contributor', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:44.851195+00', '2026-11-20 11:26:44.851195+00', false);
INSERT INTO public.project_grants VALUES ('0506776d-dec1-431d-a0f1-9b4de6723011', 'd2bba607-2757-4252-b991-8f3dad4dde96', '93feece2-e363-48a8-8a68-51f71e062b79', '11c2823a-c8ac-4431-955a-a5ca0948254b', 'manager', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:46.37406+00', '2026-11-20 11:26:46.37406+00', false);


--
-- Data for Name: project_material_versions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_material_versions VALUES ('79bbedd2-67db-4944-a1b6-55c9a4553889', '664527cf-118c-48f4-b7ff-f829c0460d26', 'fda509f0-0c26-464c-a79b-4340bab00e5d', 1, 'RELEASE-doc-bd0292a3', 'RELEASE-doc-bd0292a3-v1', NULL, '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, NULL, '2026-11-20 11:26:43.653379+00', 'Started the page', NULL);
INSERT INTO public.project_material_versions VALUES ('79bbedd2-67db-4944-a1b6-55c9a4553889', '664527cf-118c-48f4-b7ff-f829c0460d26', 'fda509f0-0c26-464c-a79b-4340bab00e5d', 2, 'RELEASE-doc-bd0292a3', 'RELEASE-doc-bd0292a3-v2', NULL, '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, NULL, '2026-11-20 11:26:43.69545+00', 'Edited the text', NULL);
INSERT INTO public.project_material_versions VALUES ('79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'c932328a-2781-45af-8ca9-fb6b94d7ad48', 1, 'GARDEN-wiki-bd0292a3', 'GARDEN-wiki-bd0292a3-v1', NULL, '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, NULL, '2026-11-20 11:26:45.488944+00', 'Started the page', NULL);
INSERT INTO public.project_material_versions VALUES ('79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'c932328a-2781-45af-8ca9-fb6b94d7ad48', 2, 'GARDEN-wiki-bd0292a3', 'GARDEN-wiki-bd0292a3-v2', NULL, '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', NULL, NULL, '2026-11-20 11:26:45.541472+00', 'Edited the text', NULL);
INSERT INTO public.project_material_versions VALUES ('79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'c932328a-2781-45af-8ca9-fb6b94d7ad48', 3, 'GARDEN-wiki-bd0292a3', 'GARDEN-wiki-bd0292a3-v3', NULL, '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, NULL, '2026-11-20 11:26:45.577183+00', 'Edited the text', NULL);


--
-- Data for Name: project_materials; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_materials VALUES ('fda509f0-0c26-464c-a79b-4340bab00e5d', '79bbedd2-67db-4944-a1b6-55c9a4553889', '664527cf-118c-48f4-b7ff-f829c0460d26', '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, NULL, 2, '2026-11-20 11:26:43.653379+00', '2026-11-20 11:26:43.704+00', 'doc', NULL);
INSERT INTO public.project_materials VALUES ('c932328a-2781-45af-8ca9-fb6b94d7ad48', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, NULL, 3, '2026-11-20 11:26:45.488944+00', '2026-11-20 11:26:45.584+00', 'doc', NULL);


--
-- Data for Name: project_message_observations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_messages; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_messages VALUES ('08074005-d0db-495c-8fcd-0a00e62b3338', '79bbedd2-67db-4944-a1b6-55c9a4553889', '664527cf-118c-48f4-b7ff-f829c0460d26', 'bf52fbba-c496-4746-84a1-1505adc31204', '11c2823a-c8ac-4431-955a-a5ca0948254b', 'd4284831-cbc5-4fc2-ac06-ab3bbe1baa64', '5d5f06b0076f59fec64783c3c296fb5ab70ea35c6a0e8d41caef99346cf59daf', 1, 'RELEASE-message-bd0292a3', NULL, NULL, '2026-11-20 11:26:43.546566+00', NULL, 'text', 1, NULL, NULL, NULL, false, false, NULL);
INSERT INTO public.project_messages VALUES ('d9e1e557-69c9-4008-b2ab-9cbcf02b08b8', '79bbedd2-67db-4944-a1b6-55c9a4553889', '664527cf-118c-48f4-b7ff-f829c0460d26', 'bf52fbba-c496-4746-84a1-1505adc31204', '11c2823a-c8ac-4431-955a-a5ca0948254b', 'bdff167d-ad81-4cf7-921c-6775cad5dc55', 'e71fa620e34c25aedea5a965db33b1d2f558b520fc7279e913bd51797b21219d', 2, 'RELEASE-reply-bd0292a3', NULL, NULL, '2026-11-20 11:26:43.59087+00', NULL, 'text', 0, NULL, NULL, NULL, false, false, NULL);
INSERT INTO public.project_messages VALUES ('37aed0c9-7a96-450b-9d7d-aaba10788eaf', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'e1aca7f5-107b-4e47-9a54-e6156ae0894a', '11c2823a-c8ac-4431-955a-a5ca0948254b', '9c481c47-3144-426d-819f-b8951a9ee91c', 'e5d41c69cb726e519c4577d3b81169320c6986f6606961ca35cb5ac8bf5aafb1', 1, 'GARDEN-root-bd0292a3', NULL, NULL, '2026-11-20 11:26:45.109982+00', NULL, 'text', 2, NULL, NULL, NULL, false, false, NULL);
INSERT INTO public.project_messages VALUES ('d30b4aed-978d-4e57-8ba2-37bbd67385af', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'e1aca7f5-107b-4e47-9a54-e6156ae0894a', '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 'dca5ae5a-f09a-4fcc-a219-ec938eb661b6', '87ab5380e3a12b88c4c27350d697a876ad265673034f79028c33a41870e924fe', 2, 'GARDEN-ben-bd0292a3', NULL, NULL, '2026-11-20 11:26:45.154274+00', NULL, 'text', 0, NULL, NULL, NULL, false, false, NULL);
INSERT INTO public.project_messages VALUES ('bd700eca-8b68-4935-b451-9fdf1693c34d', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'e1aca7f5-107b-4e47-9a54-e6156ae0894a', '812c1f3d-162a-47bb-8ba4-fd5381ea5923', '5e1dd962-7281-404b-8c66-1d1b539aa7f2', 'ad65c5a2771bf21dadeed36f74a428eebcacc0df6e8eaa313a5fba7ba482e1ad', 3, 'GARDEN-gina-bd0292a3', NULL, NULL, '2026-11-20 11:26:45.191227+00', NULL, 'text', 0, NULL, NULL, NULL, false, false, NULL);
INSERT INTO public.project_messages VALUES ('6c554f4b-7b3e-4eda-bc74-a21ad9c7748f', 'd2bba607-2757-4252-b991-8f3dad4dde96', '93feece2-e363-48a8-8a68-51f71e062b79', '178a9281-45d0-473e-850c-0b91f48004aa', '11c2823a-c8ac-4431-955a-a5ca0948254b', '0d791698-bf8e-49c4-afbb-b78b761b8e9a', 'fx1.1.mpgHSjSf4-LIY8fTrldC0vzIQYT7f0kk7he09Gxd7VJXJTYpaIiBzPsYYr4dnmD6jqA5zjYrGqdezc4kKRzB5W4N60S01aTtpzANWTqqg6349k5PAIgN_0nCnGw', 1, 'fx1.1.bVbjR6E0fxvqYfzRPM8kbx_aZv8sUdF30sz6iwtv85z1I2fWWNhqImnA1-SST7RTQw', NULL, NULL, '2026-11-20 11:26:46.422157+00', NULL, 'text', 0, NULL, NULL, NULL, false, false, NULL);


--
-- Data for Name: project_object_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_task_activity; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_task_dependencies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_task_dependencies VALUES ('79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', '251cd34f-3781-4039-924f-cf37140a1536', '7073e9f2-ba3d-4ccf-ad7e-a24cf90446c2', '2026-11-20 11:26:45.887182+00');


--
-- Data for Name: project_task_discussions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_task_notices; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_task_notices VALUES ('5d4a3c12-c4f4-46bf-b88a-9a5affb1a5a8', '79bbedd2-67db-4944-a1b6-55c9a4553889', '664527cf-118c-48f4-b7ff-f829c0460d26', '04cac509-90e7-43d4-b05f-c2c743810c63', 'task.created', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '[]', '2026-11-20 11:26:43.76+00');
INSERT INTO public.project_task_notices VALUES ('4750f54c-1688-4dc3-9f0b-3db27040ff26', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', '7073e9f2-ba3d-4ccf-ad7e-a24cf90446c2', 'task.created', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '[]', '2026-11-20 11:26:45.833+00');
INSERT INTO public.project_task_notices VALUES ('db34a905-89e7-4eba-97c7-dd9dd675c109', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', '251cd34f-3781-4039-924f-cf37140a1536', 'task.created', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '[]', '2026-11-20 11:26:45.887+00');
INSERT INTO public.project_task_notices VALUES ('62afcee9-8630-4c80-9613-4bb2e559b5ef', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'b778cb8f-70d8-4cd0-a408-83cf5bf4ce4d', 'task.created', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '[]', '2026-11-20 11:26:46.011+00');


--
-- Data for Name: project_task_plan_intents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_task_updates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_work_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.project_work_items VALUES ('04cac509-90e7-43d4-b05f-c2c743810c63', '79bbedd2-67db-4944-a1b6-55c9a4553889', '664527cf-118c-48f4-b7ff-f829c0460d26', 'RELEASE-work-bd0292a3', '', 'open', NULL, '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', 1, '2026-11-20 11:26:43.760257+00', '2026-11-20 11:26:43.760257+00', NULL, NULL, '[]', 'human', '{"title": "RELEASE-work-bd0292a3", "status": "open", "blocker": null, "outcome": "", "criteria": [], "ownerUserId": "11c2823a-c8ac-4431-955a-a5ca0948254b", "ownerAgentId": null}', 1, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, false, NULL);
INSERT INTO public.project_work_items VALUES ('7073e9f2-ba3d-4ccf-ad7e-a24cf90446c2', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'GARDEN-calibrate-bd0292a3', '', 'open', NULL, '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', NULL, 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', 1, '2026-11-20 11:26:45.833153+00', '2026-11-20 11:26:45.833153+00', NULL, NULL, '[]', 'human', '{"title": "GARDEN-calibrate-bd0292a3", "status": "open", "blocker": null, "outcome": "", "criteria": [], "ownerUserId": "52bfbd7b-3c03-4c21-9fe9-1f68b174afa4", "ownerAgentId": null}', 1, '2026-11-20 11:26:45.89532+00', NULL, NULL, NULL, NULL, 1, NULL, '2027-03-01', NULL, NULL, false, NULL);
INSERT INTO public.project_work_items VALUES ('251cd34f-3781-4039-924f-cf37140a1536', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'GARDEN-ship-bd0292a3', '', 'blocked', 'needs calibration', NULL, NULL, 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', 1, '2026-11-20 11:26:45.887182+00', '2026-11-20 11:26:45.887182+00', NULL, NULL, '[]', 'human', '{"title": "GARDEN-ship-bd0292a3", "status": "blocked", "blocker": "needs calibration", "outcome": "", "criteria": [], "ownerUserId": null, "ownerAgentId": null}', 1, NULL, NULL, NULL, NULL, NULL, 2, NULL, '2027-03-15', NULL, '7073e9f2-ba3d-4ccf-ad7e-a24cf90446c2', false, NULL);
INSERT INTO public.project_work_items VALUES ('b778cb8f-70d8-4cd0-a408-83cf5bf4ce4d', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'GARDEN-approve-bd0292a3', '', 'blocked', 'needs a decision of the owner', NULL, NULL, 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', 1, '2026-11-20 11:26:46.011585+00', '2026-11-20 11:26:46.011585+00', NULL, NULL, '[]', 'human', '{"title": "GARDEN-approve-bd0292a3", "status": "blocked", "blocker": "needs a decision of the owner", "outcome": "", "criteria": [], "ownerUserId": null, "ownerAgentId": null}', 1, NULL, NULL, NULL, NULL, NULL, 3, '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '2027-04-01', NULL, NULL, false, NULL);


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.projects VALUES ('4afe9242-92a0-4ab0-a010-c1e3c2eb6c47', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'Everyone', 'workspace', '11c2823a-c8ac-4431-955a-a5ca0948254b', 1, '2026-11-20 11:26:43.257462+00', '2026-11-20 11:26:43.257462+00');
INSERT INTO public.projects VALUES ('664527cf-118c-48f4-b7ff-f829c0460d26', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'Release project', 'restricted', '11c2823a-c8ac-4431-955a-a5ca0948254b', 1, '2026-11-20 11:26:43.384064+00', '2026-11-20 11:26:43.384064+00');
INSERT INTO public.projects VALUES ('a86025f9-f9ba-46c4-8fd0-d4949e07a97c', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'Garden space', 'restricted', '11c2823a-c8ac-4431-955a-a5ca0948254b', 1, '2026-11-20 11:26:44.851195+00', '2026-11-20 11:26:44.851195+00');
INSERT INTO public.projects VALUES ('93feece2-e363-48a8-8a68-51f71e062b79', 'd2bba607-2757-4252-b991-8f3dad4dde96', 'fx1.1.apsawW8ZczjEce8vdyxQ5mOHWDC2_YyGUgMY9SmL892UBR12lIee1OY', 'workspace', '11c2823a-c8ac-4431-955a-a5ca0948254b', 1, '2026-11-20 11:26:46.37406+00', '2026-11-20 11:26:46.37406+00');


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: return_points; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sample_results; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: samples; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sealed_job_waits; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: search_changes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.search_changes VALUES (1, 'd2bba607-2757-4252-b991-8f3dad4dde96', 'project:93feece2-e363-48a8-8a68-51f71e062b79', '2026-11-20 11:26:46.37406+00', '1038');
INSERT INTO public.search_changes VALUES (2, 'd2bba607-2757-4252-b991-8f3dad4dde96', 'message:6c554f4b-7b3e-4eda-bc74-a21ad9c7748f', '2026-11-20 11:26:46.422157+00', '1041');


--
-- Data for Name: search_documents; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (1, 'person:79bbedd2-67db-4944-a1b6-55c9a4553889:11c2823a-c8ac-4431-955a-a5ca0948254b', 'person', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'members:79bbedd2-67db-4944-a1b6-55c9a4553889', NULL, '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, NULL, 'owner', 'Release smoke user', '', NULL, NULL, '2026-11-20 11:26:43.257462+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (2, 'project:4afe9242-92a0-4ab0-a010-c1e3c2eb6c47', 'project', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:4afe9242-92a0-4ab0-a010-c1e3c2eb6c47', '4afe9242-92a0-4ab0-a010-c1e3c2eb6c47', '4afe9242-92a0-4ab0-a010-c1e3c2eb6c47', NULL, NULL, 'workspace', 'Everyone', '', NULL, NULL, '2026-11-20 11:26:43.257462+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (3, 'project:664527cf-118c-48f4-b7ff-f829c0460d26', 'project', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:664527cf-118c-48f4-b7ff-f829c0460d26', '664527cf-118c-48f4-b7ff-f829c0460d26', '664527cf-118c-48f4-b7ff-f829c0460d26', NULL, NULL, 'restricted', 'Release project', '', NULL, NULL, '2026-11-20 11:26:43.384064+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (4, 'message:08074005-d0db-495c-8fcd-0a00e62b3338', 'message', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:664527cf-118c-48f4-b7ff-f829c0460d26', '664527cf-118c-48f4-b7ff-f829c0460d26', '08074005-d0db-495c-8fcd-0a00e62b3338', 'bf52fbba-c496-4746-84a1-1505adc31204', NULL, NULL, '', 'RELEASE-message-bd0292a3', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:43.546566+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (5, 'file:18fc6f09-36dc-4f8a-b38f-e98d8bcbb0da:0', 'file', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:664527cf-118c-48f4-b7ff-f829c0460d26', '664527cf-118c-48f4-b7ff-f829c0460d26', '18fc6f09-36dc-4f8a-b38f-e98d8bcbb0da', 'bf52fbba-c496-4746-84a1-1505adc31204', 0, NULL, 'release-probe.bin', '', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:43.546+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (6, 'message:d9e1e557-69c9-4008-b2ab-9cbcf02b08b8', 'message', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:664527cf-118c-48f4-b7ff-f829c0460d26', '664527cf-118c-48f4-b7ff-f829c0460d26', 'd9e1e557-69c9-4008-b2ab-9cbcf02b08b8', 'bf52fbba-c496-4746-84a1-1505adc31204', NULL, NULL, '', 'RELEASE-reply-bd0292a3', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:43.59087+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (7, 'material:fda509f0-0c26-464c-a79b-4340bab00e5d:1', 'doc', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:664527cf-118c-48f4-b7ff-f829c0460d26', '664527cf-118c-48f4-b7ff-f829c0460d26', 'fda509f0-0c26-464c-a79b-4340bab00e5d', NULL, 1, NULL, 'RELEASE-doc-bd0292a3', 'RELEASE-doc-bd0292a3-v1', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:43.653379+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (8, 'material:fda509f0-0c26-464c-a79b-4340bab00e5d:2', 'doc', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:664527cf-118c-48f4-b7ff-f829c0460d26', '664527cf-118c-48f4-b7ff-f829c0460d26', 'fda509f0-0c26-464c-a79b-4340bab00e5d', NULL, 2, NULL, 'RELEASE-doc-bd0292a3', 'RELEASE-doc-bd0292a3-v2', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:43.69545+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (9, 'work:04cac509-90e7-43d4-b05f-c2c743810c63', 'work', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:664527cf-118c-48f4-b7ff-f829c0460d26', '664527cf-118c-48f4-b7ff-f829c0460d26', '04cac509-90e7-43d4-b05f-c2c743810c63', NULL, NULL, 'open', 'RELEASE-work-bd0292a3', '#1', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:43.760257+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (11, 'sketch:96bda1f6-fcc4-4b1b-b9d1-afbeab0bf25e', 'sketch', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'sketch:96bda1f6-fcc4-4b1b-b9d1-afbeab0bf25e', NULL, '96bda1f6-fcc4-4b1b-b9d1-afbeab0bf25e', NULL, NULL, 'private', 'RELEASE-private-map-bd0292a3', '', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:43.802064+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (12, 'person:79bbedd2-67db-4944-a1b6-55c9a4553889:52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 'person', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'members:79bbedd2-67db-4944-a1b6-55c9a4553889', NULL, '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', NULL, NULL, 'member', 'Ben Member', '', NULL, NULL, '2026-11-20 11:26:44.251297+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (13, 'person:79bbedd2-67db-4944-a1b6-55c9a4553889:812c1f3d-162a-47bb-8ba4-fd5381ea5923', 'person', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'members:79bbedd2-67db-4944-a1b6-55c9a4553889', NULL, '812c1f3d-162a-47bb-8ba4-fd5381ea5923', NULL, NULL, 'guest', 'Gina Guest', '', NULL, NULL, '2026-11-20 11:26:44.747442+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (14, 'project:a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'project', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', NULL, NULL, 'restricted', 'Garden space', '', NULL, NULL, '2026-11-20 11:26:44.851195+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (15, 'message:37aed0c9-7a96-450b-9d7d-aaba10788eaf', 'message', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', '37aed0c9-7a96-450b-9d7d-aaba10788eaf', 'e1aca7f5-107b-4e47-9a54-e6156ae0894a', NULL, NULL, '', 'GARDEN-root-bd0292a3', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:45.109982+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (16, 'file:28023ce4-44a1-48e8-b63c-9454e47ddcb5:0', 'file', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', '28023ce4-44a1-48e8-b63c-9454e47ddcb5', 'e1aca7f5-107b-4e47-9a54-e6156ae0894a', 0, NULL, 'garden-notes.bin', '', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:45.109+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (17, 'file:eabc2d04-d93e-4b71-b74f-5415862cf48a:0', 'file', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'eabc2d04-d93e-4b71-b74f-5415862cf48a', 'e1aca7f5-107b-4e47-9a54-e6156ae0894a', 0, NULL, 'garden-clip.mp4', '', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:45.109+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (18, 'message:d30b4aed-978d-4e57-8ba2-37bbd67385af', 'message', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'd30b4aed-978d-4e57-8ba2-37bbd67385af', 'e1aca7f5-107b-4e47-9a54-e6156ae0894a', NULL, NULL, '', 'GARDEN-ben-bd0292a3', 'human', '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '2026-11-20 11:26:45.154274+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (19, 'message:bd700eca-8b68-4935-b451-9fdf1693c34d', 'message', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'bd700eca-8b68-4935-b451-9fdf1693c34d', 'e1aca7f5-107b-4e47-9a54-e6156ae0894a', NULL, NULL, '', 'GARDEN-gina-bd0292a3', 'human', '812c1f3d-162a-47bb-8ba4-fd5381ea5923', '2026-11-20 11:26:45.191227+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (20, 'dm_message:7036dbed-2470-4b34-b0ad-cc738b697f7e', 'dm_message', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'dm:93ead2ce-d190-40cc-945e-63a407d73985', NULL, '7036dbed-2470-4b34-b0ad-cc738b697f7e', '93ead2ce-d190-40cc-945e-63a407d73985', NULL, NULL, '', 'DM-hello-bd0292a3', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:45.263517+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (21, 'dm_message:e4def4c5-ee85-48dd-bda6-c0a1594bf4ea', 'dm_message', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'dm:93ead2ce-d190-40cc-945e-63a407d73985', NULL, 'e4def4c5-ee85-48dd-bda6-c0a1594bf4ea', '93ead2ce-d190-40cc-945e-63a407d73985', NULL, NULL, '', 'DM-reply-bd0292a3', 'human', '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '2026-11-20 11:26:45.29047+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (22, 'dm_message:f6fac6ac-ce3f-4d72-b008-9c314bf1fddf', 'dm_message', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'dm:9ba59e5c-63fc-4e8a-ae12-9703781cd053', NULL, 'f6fac6ac-ce3f-4d72-b008-9c314bf1fddf', '9ba59e5c-63fc-4e8a-ae12-9703781cd053', NULL, NULL, '', 'GROUP-hello-bd0292a3', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:45.384071+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (23, 'dm_message:49a516f8-749e-4d83-b320-72182ec9ba24', 'dm_message', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'dm:9ba59e5c-63fc-4e8a-ae12-9703781cd053', NULL, '49a516f8-749e-4d83-b320-72182ec9ba24', '9ba59e5c-63fc-4e8a-ae12-9703781cd053', NULL, NULL, '', 'ꟀꟁꟀꟁ UNICODE-bd0292a3', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:45.441177+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (24, 'material:c932328a-2781-45af-8ca9-fb6b94d7ad48:1', 'doc', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'c932328a-2781-45af-8ca9-fb6b94d7ad48', NULL, 1, NULL, 'GARDEN-wiki-bd0292a3', 'GARDEN-wiki-bd0292a3-v1', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:45.488944+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (25, 'material:c932328a-2781-45af-8ca9-fb6b94d7ad48:2', 'doc', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'c932328a-2781-45af-8ca9-fb6b94d7ad48', NULL, 2, NULL, 'GARDEN-wiki-bd0292a3', 'GARDEN-wiki-bd0292a3-v2', 'human', '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', '2026-11-20 11:26:45.541472+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (26, 'material:c932328a-2781-45af-8ca9-fb6b94d7ad48:3', 'doc', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'c932328a-2781-45af-8ca9-fb6b94d7ad48', NULL, 3, NULL, 'GARDEN-wiki-bd0292a3', 'GARDEN-wiki-bd0292a3-v3', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:45.577183+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (28, 'thought:b29b0132-acf9-40f1-aa6d-5d1c924205ef', 'thought', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'sketch:5a6e389a-8c43-4630-b742-906b4ebb865d', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'b29b0132-acf9-40f1-aa6d-5d1c924205ef', '5a6e389a-8c43-4630-b742-906b4ebb865d', NULL, NULL, 'Soil', '', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:45.677833+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (41, 'person:d2bba607-2757-4252-b991-8f3dad4dde96:11c2823a-c8ac-4431-955a-a5ca0948254b', 'person', 'd2bba607-2757-4252-b991-8f3dad4dde96', 'members:d2bba607-2757-4252-b991-8f3dad4dde96', NULL, '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, NULL, 'owner', 'Release smoke user', '', NULL, NULL, '2026-11-20 11:26:46.336199+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (42, 'project:93feece2-e363-48a8-8a68-51f71e062b79', 'project', 'd2bba607-2757-4252-b991-8f3dad4dde96', 'project:93feece2-e363-48a8-8a68-51f71e062b79', '93feece2-e363-48a8-8a68-51f71e062b79', '93feece2-e363-48a8-8a68-51f71e062b79', NULL, NULL, 'workspace', '', '', NULL, NULL, '2026-11-20 11:26:46.37406+00', DEFAULT, DEFAULT, true, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (43, 'message:6c554f4b-7b3e-4eda-bc74-a21ad9c7748f', 'message', 'd2bba607-2757-4252-b991-8f3dad4dde96', 'project:93feece2-e363-48a8-8a68-51f71e062b79', '93feece2-e363-48a8-8a68-51f71e062b79', '6c554f4b-7b3e-4eda-bc74-a21ad9c7748f', '178a9281-45d0-473e-850c-0b91f48004aa', NULL, NULL, '', '', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:46.422157+00', DEFAULT, DEFAULT, true, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (30, 'thought:e09da5bf-881e-41dc-94c1-d9df53140ba7', 'thought', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'sketch:5a6e389a-8c43-4630-b742-906b4ebb865d', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'e09da5bf-881e-41dc-94c1-d9df53140ba7', '5a6e389a-8c43-4630-b742-906b4ebb865d', NULL, NULL, 'Water', '', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:45.723857+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (32, 'thought:e9bc48f6-5b03-4818-b786-a1af25b7308e', 'thought', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'sketch:5a6e389a-8c43-4630-b742-906b4ebb865d', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'e9bc48f6-5b03-4818-b786-a1af25b7308e', '5a6e389a-8c43-4630-b742-906b4ebb865d', NULL, NULL, 'Shade', '', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:45.777938+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (27, 'sketch:5a6e389a-8c43-4630-b742-906b4ebb865d', 'sketch', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'sketch:5a6e389a-8c43-4630-b742-906b4ebb865d', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', '5a6e389a-8c43-4630-b742-906b4ebb865d', NULL, NULL, 'project', 'Garden map bd0292a3', '', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:45.790091+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (34, 'work:7073e9f2-ba3d-4ccf-ad7e-a24cf90446c2', 'work', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', '7073e9f2-ba3d-4ccf-ad7e-a24cf90446c2', NULL, NULL, 'open', 'GARDEN-calibrate-bd0292a3', '#1', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:45.833153+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (36, 'work:251cd34f-3781-4039-924f-cf37140a1536', 'work', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', '251cd34f-3781-4039-924f-cf37140a1536', NULL, NULL, 'blocked', 'GARDEN-ship-bd0292a3', '#2
needs calibration', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:45.887182+00', DEFAULT, DEFAULT, false, NULL);
INSERT INTO public.search_documents OVERRIDING SYSTEM VALUE VALUES (39, 'work:b778cb8f-70d8-4cd0-a408-83cf5bf4ce4d', 'work', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project:a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'b778cb8f-70d8-4cd0-a408-83cf5bf4ce4d', NULL, NULL, 'blocked', 'GARDEN-approve-bd0292a3', '#3
needs a decision of the owner', 'human', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:46.011585+00', DEFAULT, DEFAULT, false, NULL);


--
-- Data for Name: search_vector_queue; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: search_vector_state; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: search_vectors; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sketch_links; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sketch_links VALUES ('2b34fef7-0405-4443-9d40-5bfe7ce23802', '79bbedd2-67db-4944-a1b6-55c9a4553889', '5a6e389a-8c43-4630-b742-906b4ebb865d', 'b29b0132-acf9-40f1-aa6d-5d1c924205ef', 'e09da5bf-881e-41dc-94c1-d9df53140ba7', 'needs', '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, '2026-11-20 11:26:45.723857+00');
INSERT INTO public.sketch_links VALUES ('c36c3a67-1736-4dad-8f51-547aa796b52e', '79bbedd2-67db-4944-a1b6-55c9a4553889', '5a6e389a-8c43-4630-b742-906b4ebb865d', 'e09da5bf-881e-41dc-94c1-d9df53140ba7', 'e9bc48f6-5b03-4818-b786-a1af25b7308e', 'next to', '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, '2026-11-20 11:26:45.777938+00');


--
-- Data for Name: sketch_thoughts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sketch_thoughts VALUES ('b29b0132-acf9-40f1-aa6d-5d1c924205ef', '79bbedd2-67db-4944-a1b6-55c9a4553889', '5a6e389a-8c43-4630-b742-906b4ebb865d', 'Soil', 10, 10, 184, 72, 'card', '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, 1, '2026-11-20 11:26:45.677833+00', '2026-11-20 11:26:45.677833+00', NULL, NULL, NULL, NULL, NULL, '{}');
INSERT INTO public.sketch_thoughts VALUES ('e09da5bf-881e-41dc-94c1-d9df53140ba7', '79bbedd2-67db-4944-a1b6-55c9a4553889', '5a6e389a-8c43-4630-b742-906b4ebb865d', 'Water', 220, 10, 184, 72, 'card', '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, 1, '2026-11-20 11:26:45.723857+00', '2026-11-20 11:26:45.723857+00', NULL, NULL, NULL, NULL, NULL, '{}');
INSERT INTO public.sketch_thoughts VALUES ('e9bc48f6-5b03-4818-b786-a1af25b7308e', '79bbedd2-67db-4944-a1b6-55c9a4553889', '5a6e389a-8c43-4630-b742-906b4ebb865d', 'Shade', 220, 120, 184, 72, 'card', '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, 1, '2026-11-20 11:26:45.777938+00', '2026-11-20 11:26:45.777938+00', NULL, NULL, NULL, NULL, NULL, '{}');


--
-- Data for Name: sketches; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sketches VALUES ('96bda1f6-fcc4-4b1b-b9d1-afbeab0bf25e', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'private', NULL, 'RELEASE-private-map-bd0292a3', '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, 1, '2026-11-20 11:26:43.802064+00', '2026-11-20 11:26:43.802064+00', '{}');
INSERT INTO public.sketches VALUES ('5a6e389a-8c43-4630-b742-906b4ebb865d', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'project', 'a86025f9-f9ba-46c4-8fd0-d4949e07a97c', 'Garden map bd0292a3', '11c2823a-c8ac-4431-955a-a5ca0948254b', NULL, 1, '2026-11-20 11:26:45.640707+00', '2026-11-20 11:26:45.790091+00', '{human:11c2823a-c8ac-4431-955a-a5ca0948254b}');


--
-- Data for Name: space_icons; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: space_order; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: task_creation_undo_receipts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspace_dek_wraps; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspace_dek_wraps VALUES ('847dae98-c6f2-4ca5-a1da-187b5a1faa5c', 'd2bba607-2757-4252-b991-8f3dad4dde96', 1, '-13WZ96esUHA91OmvGEObGD3k9Qa4auFxczQn7tDRg8', 'RV8UzxUryuyY8fg_-oquRjYAi-HMb4mlx8BYAoauyy65ePz5kn81DuBVo01qHMz21az1RVc43tA1zzfL', 'WjFxS5ZRzTIpbeAe4H8dgTwUmwU8UVOs7lR38qGe48g');
INSERT INTO public.workspace_dek_wraps VALUES ('2842bf38-3eaa-4ec2-90de-5919d6ba26b1', 'd2bba607-2757-4252-b991-8f3dad4dde96', 1, 'LCAmuoJg84dervmbayPWj0iN0syXU6_hv8winBy9IWA', 'Pz8aCImLYiOm9f_e86T84eIwWHHC3SGiwT7wqCf_4N1V7GxoiNwF0Rh6eeGEXd2T7MxKXd_bRQLuB-WM', 't2oyLnjdk3rsRLeMUCbTEtu9j7JbyO771OVp1-PgZqo');


--
-- Data for Name: workspace_holders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspace_holders VALUES ('847dae98-c6f2-4ca5-a1da-187b5a1faa5c', 'd2bba607-2757-4252-b991-8f3dad4dde96', 'password', '11c2823a-c8ac-4431-955a-a5ca0948254b', '{"m": 65536, "p": 4, "t": 3, "v": 19, "alg": "argon2id", "salt": "qCjV2gkju-CpvXC7i5xGhA"}', 'X06NtxS0L1ciDKLm-Cn9jNUmGSTZRIvFJkz8RHgzTAM', 'o6UjRWX4C4Pdc_qegxe2mrq3n1Q-jdwD9u_oxCGEEuAnRh6djb6gYDwS5Gnp7H9R2QFHkojYC9KG3Uuvn_xHl58s9NiO2zUTvpcoKw', '6sB_L1pBcZo_bkNQRTUqt3Rt8QLX9LZPOjKvx6Ca-rw', 1, 'q-ECTvb5Tx4AU9w2CCVoGrcCBZG83hDzlwepWrbaLmM', '2026-11-20 11:26:46.336199+00', '2026-11-20 11:26:46.336199+00', '{1}', 'k14oiwjW2VhgwV91qWXh0wOd4N8rlzHFT8LOhwRdibA');
INSERT INTO public.workspace_holders VALUES ('2842bf38-3eaa-4ec2-90de-5919d6ba26b1', 'd2bba607-2757-4252-b991-8f3dad4dde96', 'recovery', NULL, '{"m": 65536, "p": 4, "t": 3, "v": 19, "alg": "argon2id", "salt": "GOp4Dq7Tu8KhIRDn0aMUmQ"}', '7XJNkzY0AjPxydgAT6mS_0f4tAsXbs9sH6_Ze8Zwcz8', 'TkL255tn9e_6IGt3AEcCv9LXdqxOyTXJoi_DI3q6t4NVb63ErgVJ6JcYlr-3rPmYu8aAer7mw3DNISVl29zi_zlINlf9Q-GehdNJjQ', '4rkjTLRuQpjk5enkzxDEDF0Pqtcdw-Pvxu3HzpvhGq0', 1, 'MTIKAqYM9vaVd77QcofVQJIvH2KddS7d-e85hKPm4jM', '2026-11-20 11:26:46.336199+00', '2026-11-20 11:26:46.336199+00', '{1}', 'p5sgy5lk0k7wLKVCbf_C_W0SezEE0Xau675aYCGi1UQ');


--
-- Data for Name: workspace_invites; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspace_invites VALUES ('e65337ea-2786-4cdc-b50a-ae386cf3b7d5', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'member', NULL, 'c4ee2a5aeea0e264674edb1625806b698557d7b2235f88179c8c1b4d590b51b2', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:43.853929+00', '2026-11-27 11:26:43.853+00', NULL, NULL, '2026-11-20 11:26:44.249+00', '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', NULL);
INSERT INTO public.workspace_invites VALUES ('51a2c572-9579-4a62-89c8-3e5a394d533f', '79bbedd2-67db-4944-a1b6-55c9a4553889', 'guest', NULL, '166b0413f7ef073bd585744b99d57da7cb86e25913f550e22d75fbfe34646098', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:44.370611+00', '2026-11-27 11:26:44.37+00', NULL, NULL, '2026-11-20 11:26:44.745+00', '812c1f3d-162a-47bb-8ba4-fd5381ea5923', NULL);


--
-- Data for Name: workspace_key_versions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspace_key_versions VALUES ('d2bba607-2757-4252-b991-8f3dad4dde96', 1, NULL, 'fx1.1.NCRLUTVFd4CrvMgnZn9bJiCxyOTiltdBbM20F7fCJ7P9gbPCNF-hqgobpi6j', '2026-11-20 11:26:46.336199+00', 'uDCcvpAdlwyQyyCcIOGzfzgTe1g9v5bz-F-i1nRsOTY');


--
-- Data for Name: workspace_keys; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspace_keys VALUES ('d2bba607-2757-4252-b991-8f3dad4dde96', 1, '{1}', 'none', NULL, NULL, '2026-11-20 11:26:46.336199+00', NULL, NULL);


--
-- Data for Name: workspace_members; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspace_members VALUES ('79bbedd2-67db-4944-a1b6-55c9a4553889', '11c2823a-c8ac-4431-955a-a5ca0948254b', 'owner', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:43.257462+00', '2026-11-20 11:26:43.257462+00');
INSERT INTO public.workspace_members VALUES ('79bbedd2-67db-4944-a1b6-55c9a4553889', '52bfbd7b-3c03-4c21-9fe9-1f68b174afa4', 'member', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:44.251297+00', '2026-11-20 11:26:44.251297+00');
INSERT INTO public.workspace_members VALUES ('79bbedd2-67db-4944-a1b6-55c9a4553889', '812c1f3d-162a-47bb-8ba4-fd5381ea5923', 'guest', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:44.747442+00', '2026-11-20 11:26:44.747442+00');
INSERT INTO public.workspace_members VALUES ('d2bba607-2757-4252-b991-8f3dad4dde96', '11c2823a-c8ac-4431-955a-a5ca0948254b', 'owner', '11c2823a-c8ac-4431-955a-a5ca0948254b', '2026-11-20 11:26:46.336199+00', '2026-11-20 11:26:46.336199+00');


--
-- Data for Name: workspace_removals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspace_removed_holders; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspace_removed_people; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspace_rotation_progress; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspace_unlocks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspace_wrap_grants; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspaces; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspaces VALUES ('79bbedd2-67db-4944-a1b6-55c9a4553889', 'Release restore probe', '11c2823a-c8ac-4431-955a-a5ca0948254b', 2, '2026-11-20 11:26:43.257462+00', '2026-11-20 11:26:43.351+00', false, NULL, true, NULL);
INSERT INTO public.workspaces VALUES ('d2bba607-2757-4252-b991-8f3dad4dde96', 'Release vault', '11c2823a-c8ac-4431-955a-a5ca0948254b', 1, '2026-11-20 11:26:46.336199+00', '2026-11-20 11:26:46.336199+00', true, 'ead77c64-930c-4cb8-b7ad-efad49ecb430', false, '79bbedd2-67db-4944-a1b6-55c9a4553889');


--
-- Name: _typmod_cache_id_seq; Type: SEQUENCE SET; Schema: paradedb; Owner: -
--

SELECT pg_catalog.setval('paradedb._typmod_cache_id_seq', 6, true);


--
-- Name: agent_thread_guard_sequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_thread_guard_sequence', 1, false);


--
-- Name: events_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.events_seq_seq', 56, true);


--
-- Name: project_task_number_4afe924292a04ab0a010c1e3c2eb6c47; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_task_number_4afe924292a04ab0a010c1e3c2eb6c47', 1, false);


--
-- Name: project_task_number_664527cf118c48f4b7fff829c0460d26; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_task_number_664527cf118c48f4b7fff829c0460d26', 1, true);


--
-- Name: project_task_number_93feece2e36348a88a6851f71e062b79; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_task_number_93feece2e36348a88a6851f71e062b79', 1, false);


--
-- Name: project_task_number_a86025f9f9ba46c48fd0d4949e07a97c; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_task_number_a86025f9f9ba46c48fd0d4949e07a97c', 3, true);


--
-- Name: search_changes_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.search_changes_seq_seq', 2, true);


--
-- Name: search_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.search_documents_id_seq', 43, true);


--
-- Name: bam bam_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.bam
    ADD CONSTRAINT bam_pkey PRIMARY KEY (id);


--
-- Name: instance instance_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.instance
    ADD CONSTRAINT instance_pkey PRIMARY KEY (id);


--
-- Name: job job_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job
    ADD CONSTRAINT job_pkey PRIMARY KEY (name, id);


--
-- Name: job_common job_common_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job_common
    ADD CONSTRAINT job_common_pkey PRIMARY KEY (name, id);


--
-- Name: job_dependency job_dependency_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job_dependency
    ADD CONSTRAINT job_dependency_pkey PRIMARY KEY (child_name, child_id, parent_name, parent_id);


--
-- Name: queue queue_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue
    ADD CONSTRAINT queue_pkey PRIMARY KEY (name);


--
-- Name: queue_stats queue_stats_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats
    ADD CONSTRAINT queue_stats_pkey PRIMARY KEY (id, captured_on);


--
-- Name: queue_stats_20261120 queue_stats_20261120_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats_20261120
    ADD CONSTRAINT queue_stats_20261120_pkey PRIMARY KEY (id, captured_on);


--
-- Name: queue_stats_20261121 queue_stats_20261121_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats_20261121
    ADD CONSTRAINT queue_stats_20261121_pkey PRIMARY KEY (id, captured_on);


--
-- Name: schedule schedule_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.schedule
    ADD CONSTRAINT schedule_pkey PRIMARY KEY (name, key);


--
-- Name: subscription subscription_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.subscription
    ADD CONSTRAINT subscription_pkey PRIMARY KEY (event, name);


--
-- Name: version version_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.version
    ADD CONSTRAINT version_pkey PRIMARY KEY (version);


--
-- Name: warning warning_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.warning
    ADD CONSTRAINT warning_pkey PRIMARY KEY (id);


--
-- Name: agent_chat_file_text agent_chat_file_text_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat_file_text
    ADD CONSTRAINT agent_chat_file_text_pkey PRIMARY KEY (file_id, part);


--
-- Name: agent_chat_messages agent_chat_messages_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat_messages
    ADD CONSTRAINT agent_chat_messages_key_key UNIQUE (agent_id, key);


--
-- Name: agent_chat_messages agent_chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat_messages
    ADD CONSTRAINT agent_chat_messages_pkey PRIMARY KEY (id);


--
-- Name: agent_chat_reads agent_chat_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat_reads
    ADD CONSTRAINT agent_chat_reads_pkey PRIMARY KEY (agent_id);


--
-- Name: agent_command_receipts agent_command_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_command_receipts
    ADD CONSTRAINT agent_command_receipts_pkey PRIMARY KEY (connection_id, client_command_id);


--
-- Name: agent_connections agent_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_connections
    ADD CONSTRAINT agent_connections_pkey PRIMARY KEY (id);


--
-- Name: agent_connections agent_connections_workspace_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_connections
    ADD CONSTRAINT agent_connections_workspace_id_id_key UNIQUE (workspace_id, id);


--
-- Name: agent_memory_items agent_memory_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_memory_items
    ADD CONSTRAINT agent_memory_items_pkey PRIMARY KEY (id);


--
-- Name: agent_oauth_bindings agent_oauth_bindings_owner_user_id_connection_id_client_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_oauth_bindings
    ADD CONSTRAINT agent_oauth_bindings_owner_user_id_connection_id_client_id_key UNIQUE (owner_user_id, connection_id, client_id);


--
-- Name: agent_oauth_bindings agent_oauth_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_oauth_bindings
    ADD CONSTRAINT agent_oauth_bindings_pkey PRIMARY KEY (id);


--
-- Name: agent_playbook_acknowledgments agent_playbook_acknowledgments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_playbook_acknowledgments
    ADD CONSTRAINT agent_playbook_acknowledgments_pkey PRIMARY KEY (runtime_session_id);


--
-- Name: agent_proposals agent_proposals_agent_id_project_id_client_command_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_proposals
    ADD CONSTRAINT agent_proposals_agent_id_project_id_client_command_id_key UNIQUE (agent_id, project_id, client_command_id);


--
-- Name: agent_proposals agent_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_proposals
    ADD CONSTRAINT agent_proposals_pkey PRIMARY KEY (id);


--
-- Name: agent_questions agent_questions_message_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_questions
    ADD CONSTRAINT agent_questions_message_id_key UNIQUE (message_id);


--
-- Name: agent_questions agent_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_questions
    ADD CONSTRAINT agent_questions_pkey PRIMARY KEY (id);


--
-- Name: agent_runtime_auth_admission agent_runtime_auth_admission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_auth_admission
    ADD CONSTRAINT agent_runtime_auth_admission_pkey PRIMARY KEY (singleton);


--
-- Name: agent_runtime_auth_operations agent_runtime_auth_operations_operation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_auth_operations
    ADD CONSTRAINT agent_runtime_auth_operations_operation_id_key UNIQUE (operation_id);


--
-- Name: agent_runtime_auth_operations agent_runtime_auth_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_auth_operations
    ADD CONSTRAINT agent_runtime_auth_operations_pkey PRIMARY KEY (binding_id, client);


--
-- Name: agent_runtime_bindings agent_runtime_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_bindings
    ADD CONSTRAINT agent_runtime_bindings_pkey PRIMARY KEY (id);


--
-- Name: agent_runtime_client_history agent_runtime_client_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_client_history
    ADD CONSTRAINT agent_runtime_client_history_pkey PRIMARY KEY (binding_id, client);


--
-- Name: agent_runtime_connection_models agent_runtime_connection_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_connection_models
    ADD CONSTRAINT agent_runtime_connection_models_pkey PRIMARY KEY (connection_id, model_id);


--
-- Name: agent_runtime_connections agent_runtime_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_connections
    ADD CONSTRAINT agent_runtime_connections_pkey PRIMARY KEY (id);


--
-- Name: agent_runtime_console_nonces agent_runtime_console_nonces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_console_nonces
    ADD CONSTRAINT agent_runtime_console_nonces_pkey PRIMARY KEY (nonce_digest);


--
-- Name: agent_runtime_operator_statements agent_runtime_operator_statements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_operator_statements
    ADD CONSTRAINT agent_runtime_operator_statements_pkey PRIMARY KEY (statement, agreed_on);


--
-- Name: agent_runtime_sessions agent_runtime_sessions_binding_id_client_session_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_sessions
    ADD CONSTRAINT agent_runtime_sessions_binding_id_client_session_id_key UNIQUE (binding_id, client_session_id);


--
-- Name: agent_runtime_sessions agent_runtime_sessions_connection_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_sessions
    ADD CONSTRAINT agent_runtime_sessions_connection_id_id_key UNIQUE (connection_id, id);


--
-- Name: agent_runtime_sessions agent_runtime_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_sessions
    ADD CONSTRAINT agent_runtime_sessions_pkey PRIMARY KEY (id);


--
-- Name: agent_runtime_slots agent_runtime_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_slots
    ADD CONSTRAINT agent_runtime_slots_pkey PRIMARY KEY (slot);


--
-- Name: agent_stops agent_stops_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_stops
    ADD CONSTRAINT agent_stops_pkey PRIMARY KEY (id);


--
-- Name: agent_task_events agent_task_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_task_events
    ADD CONSTRAINT agent_task_events_pkey PRIMARY KEY (id);


--
-- Name: agent_task_taking agent_task_taking_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_task_taking
    ADD CONSTRAINT agent_task_taking_pkey PRIMARY KEY (owner_user_id);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: agents agents_workspace_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_workspace_id_id_key UNIQUE (workspace_id, id);


--
-- Name: ai_price_lists ai_price_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_price_lists
    ADD CONSTRAINT ai_price_lists_pkey PRIMARY KEY (list);


--
-- Name: api_key_checks api_key_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key_checks
    ADD CONSTRAINT api_key_checks_pkey PRIMARY KEY (id);


--
-- Name: assistant_background_notes assistant_background_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_background_notes
    ADD CONSTRAINT assistant_background_notes_pkey PRIMARY KEY (owner_user_id, account_key);


--
-- Name: assistant_changes assistant_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_pkey PRIMARY KEY (id);


--
-- Name: assistant_changes assistant_changes_run_id_client_command_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_run_id_client_command_id_key UNIQUE (run_id, client_command_id);


--
-- Name: assistant_job_runs assistant_job_runs_job_id_fired_at_fired_by_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_job_runs
    ADD CONSTRAINT assistant_job_runs_job_id_fired_at_fired_by_key UNIQUE (job_id, fired_at, fired_by);


--
-- Name: assistant_job_runs assistant_job_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_job_runs
    ADD CONSTRAINT assistant_job_runs_pkey PRIMARY KEY (id);


--
-- Name: assistant_jobs assistant_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_jobs
    ADD CONSTRAINT assistant_jobs_pkey PRIMARY KEY (id);


--
-- Name: assistant_settings assistant_settings_connection_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_settings
    ADD CONSTRAINT assistant_settings_connection_id_key UNIQUE (connection_id);


--
-- Name: assistant_settings assistant_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_settings
    ADD CONSTRAINT assistant_settings_pkey PRIMARY KEY (agent_id);


--
-- Name: auth_accounts auth_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_accounts
    ADD CONSTRAINT auth_accounts_pkey PRIMARY KEY (id);


--
-- Name: auth_email_claims auth_email_claims_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_email_claims
    ADD CONSTRAINT auth_email_claims_pkey PRIMARY KEY (id);


--
-- Name: auth_email_claims auth_email_claims_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_email_claims
    ADD CONSTRAINT auth_email_claims_token_hash_key UNIQUE (token_hash);


--
-- Name: auth_identity_audit auth_identity_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_identity_audit
    ADD CONSTRAINT auth_identity_audit_pkey PRIMARY KEY (id);


--
-- Name: auth_idp_standing auth_idp_standing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_idp_standing
    ADD CONSTRAINT auth_idp_standing_pkey PRIMARY KEY (user_id, provider_id);


--
-- Name: auth_link_intents auth_link_intents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_link_intents
    ADD CONSTRAINT auth_link_intents_pkey PRIMARY KEY (id);


--
-- Name: auth_link_intents auth_link_intents_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_link_intents
    ADD CONSTRAINT auth_link_intents_token_hash_key UNIQUE (token_hash);


--
-- Name: auth_logout_tokens auth_logout_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_logout_tokens
    ADD CONSTRAINT auth_logout_tokens_pkey PRIMARY KEY (provider_id, jti);


--
-- Name: auth_rate_limits auth_rate_limits_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_rate_limits
    ADD CONSTRAINT auth_rate_limits_key_key UNIQUE (key);


--
-- Name: auth_rate_limits auth_rate_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_rate_limits
    ADD CONSTRAINT auth_rate_limits_pkey PRIMARY KEY (id);


--
-- Name: auth_session_identities auth_session_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_session_identities
    ADD CONSTRAINT auth_session_identities_pkey PRIMARY KEY (session_id);


--
-- Name: auth_sessions auth_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_pkey PRIMARY KEY (id);


--
-- Name: auth_sessions auth_sessions_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_token_key UNIQUE (token);


--
-- Name: auth_sign_in_throttle auth_sign_in_throttle_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sign_in_throttle
    ADD CONSTRAINT auth_sign_in_throttle_pkey PRIMARY KEY (account_hash);


--
-- Name: auth_users auth_users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_users
    ADD CONSTRAINT auth_users_email_key UNIQUE (email);


--
-- Name: auth_users auth_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_users
    ADD CONSTRAINT auth_users_pkey PRIMARY KEY (id);


--
-- Name: auth_verifications auth_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_verifications
    ADD CONSTRAINT auth_verifications_pkey PRIMARY KEY (id);


--
-- Name: background_compute_connections background_compute_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.background_compute_connections
    ADD CONSTRAINT background_compute_connections_pkey PRIMARY KEY (id);


--
-- Name: cowork_checkpoints cowork_checkpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_checkpoints
    ADD CONSTRAINT cowork_checkpoints_pkey PRIMARY KEY (id);


--
-- Name: cowork_checkpoints cowork_checkpoints_workspace_id_project_id_unit_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_checkpoints
    ADD CONSTRAINT cowork_checkpoints_workspace_id_project_id_unit_id_id_key UNIQUE (workspace_id, project_id, unit_id, id);


--
-- Name: cowork_connection_slots cowork_connection_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_connection_slots
    ADD CONSTRAINT cowork_connection_slots_pkey PRIMARY KEY (connection_id);


--
-- Name: cowork_units cowork_units_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_units
    ADD CONSTRAINT cowork_units_pkey PRIMARY KEY (id);


--
-- Name: cowork_units cowork_units_workspace_id_project_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_units
    ADD CONSTRAINT cowork_units_workspace_id_project_id_id_key UNIQUE (workspace_id, project_id, id);


--
-- Name: cowork_units cowork_units_workspace_id_project_id_work_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_units
    ADD CONSTRAINT cowork_units_workspace_id_project_id_work_id_id_key UNIQUE (workspace_id, project_id, work_id, id);


--
-- Name: cowork_units cowork_units_workspace_id_project_id_work_id_run_id_unit_ke_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_units
    ADD CONSTRAINT cowork_units_workspace_id_project_id_work_id_run_id_unit_ke_key UNIQUE (workspace_id, project_id, work_id, run_id, unit_key);


--
-- Name: dm_message_observations dm_message_observations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_message_observations
    ADD CONSTRAINT dm_message_observations_pkey PRIMARY KEY (message_id, viewer_id);


--
-- Name: dm_messages dm_messages_dm_id_author_id_client_message_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_messages
    ADD CONSTRAINT dm_messages_dm_id_author_id_client_message_id_key UNIQUE (dm_id, author_id, client_message_id);


--
-- Name: dm_messages dm_messages_dm_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_messages
    ADD CONSTRAINT dm_messages_dm_id_id_key UNIQUE (dm_id, id);


--
-- Name: dm_messages dm_messages_dm_id_sequence_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_messages
    ADD CONSTRAINT dm_messages_dm_id_sequence_key UNIQUE (dm_id, sequence);


--
-- Name: dm_messages dm_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_messages
    ADD CONSTRAINT dm_messages_pkey PRIMARY KEY (id);


--
-- Name: dm_participants dm_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_participants
    ADD CONSTRAINT dm_participants_pkey PRIMARY KEY (dm_id, user_id);


--
-- Name: dm_reads dm_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_reads
    ADD CONSTRAINT dm_reads_pkey PRIMARY KEY (dm_id, user_id);


--
-- Name: dms dms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dms
    ADD CONSTRAINT dms_pkey PRIMARY KEY (id);


--
-- Name: dms dms_workspace_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dms
    ADD CONSTRAINT dms_workspace_id_id_key UNIQUE (workspace_id, id);


--
-- Name: dms dms_workspace_id_pair_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dms
    ADD CONSTRAINT dms_workspace_id_pair_key_key UNIQUE (workspace_id, pair_key);


--
-- Name: doc_live_archives doc_live_archives_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_archives
    ADD CONSTRAINT doc_live_archives_pkey PRIMARY KEY (doc_id, generation);


--
-- Name: doc_live_heads doc_live_heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_heads
    ADD CONSTRAINT doc_live_heads_pkey PRIMARY KEY (doc_id);


--
-- Name: doc_live_presence doc_live_presence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_presence
    ADD CONSTRAINT doc_live_presence_pkey PRIMARY KEY (connection_id);


--
-- Name: doc_live_replicas doc_live_replicas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_replicas
    ADD CONSTRAINT doc_live_replicas_pkey PRIMARY KEY (doc_id, generation, replica_id);


--
-- Name: doc_live_snapshots doc_live_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_snapshots
    ADD CONSTRAINT doc_live_snapshots_pkey PRIMARY KEY (doc_id, version);


--
-- Name: doc_live_updates doc_live_updates_actor_id_command_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_updates
    ADD CONSTRAINT doc_live_updates_actor_id_command_id_key UNIQUE (actor_id, command_id);


--
-- Name: doc_live_updates doc_live_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_updates
    ADD CONSTRAINT doc_live_updates_pkey PRIMARY KEY (doc_id, generation, sequence);


--
-- Name: encrypted_workspace_creations encrypted_workspace_creations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encrypted_workspace_creations
    ADD CONSTRAINT encrypted_workspace_creations_pkey PRIMARY KEY (id);


--
-- Name: event_audience event_audience_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_audience
    ADD CONSTRAINT event_audience_pkey PRIMARY KEY (recipient, seq);


--
-- Name: event_data_keys event_data_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_data_keys
    ADD CONSTRAINT event_data_keys_pkey PRIMARY KEY (key);


--
-- Name: event_data_tokens event_data_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_data_tokens
    ADD CONSTRAINT event_data_tokens_pkey PRIMARY KEY (token);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: file_garbage file_garbage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_garbage
    ADD CONSTRAINT file_garbage_pkey PRIMARY KEY (id);


--
-- Name: file_text_jobs file_text_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_text_jobs
    ADD CONSTRAINT file_text_jobs_pkey PRIMARY KEY (file_id);


--
-- Name: flux_schema_version flux_schema_version_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flux_schema_version
    ADD CONSTRAINT flux_schema_version_pkey PRIMARY KEY (version);


--
-- Name: github_bindings github_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_bindings
    ADD CONSTRAINT github_bindings_pkey PRIMARY KEY (id);


--
-- Name: github_bindings github_bindings_project_id_host_repository_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_bindings
    ADD CONSTRAINT github_bindings_project_id_host_repository_id_key UNIQUE (project_id, host, repository_id);


--
-- Name: github_bindings github_bindings_workspace_id_project_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_bindings
    ADD CONSTRAINT github_bindings_workspace_id_project_id_id_key UNIQUE (workspace_id, project_id, id);


--
-- Name: github_credentials github_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_credentials
    ADD CONSTRAINT github_credentials_pkey PRIMARY KEY (user_id, host);


--
-- Name: github_deliveries github_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_deliveries
    ADD CONSTRAINT github_deliveries_pkey PRIMARY KEY (id);


--
-- Name: github_oauth_flows github_oauth_flows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_oauth_flows
    ADD CONSTRAINT github_oauth_flows_pkey PRIMARY KEY (state_hash);


--
-- Name: github_processing github_processing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_processing
    ADD CONSTRAINT github_processing_pkey PRIMARY KEY (delivery_id, binding_id);


--
-- Name: github_rule_defaults github_rule_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_rule_defaults
    ADD CONSTRAINT github_rule_defaults_pkey PRIMARY KEY (project_id);


--
-- Name: github_task_links github_task_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_links
    ADD CONSTRAINT github_task_links_pkey PRIMARY KEY (id);


--
-- Name: github_task_links github_task_links_task_id_binding_id_pull_id_role_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_links
    ADD CONSTRAINT github_task_links_task_id_binding_id_pull_id_role_key UNIQUE (task_id, binding_id, pull_id, role);


--
-- Name: github_task_rule_changes github_task_rule_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_rule_changes
    ADD CONSTRAINT github_task_rule_changes_pkey PRIMARY KEY (id);


--
-- Name: github_task_rule_changes github_task_rule_changes_task_id_delivery_id_binding_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_rule_changes
    ADD CONSTRAINT github_task_rule_changes_task_id_delivery_id_binding_id_key UNIQUE (task_id, delivery_id, binding_id);


--
-- Name: github_task_rules github_task_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_rules
    ADD CONSTRAINT github_task_rules_pkey PRIMARY KEY (task_id);


--
-- Name: idempotency_account_operations idempotency_account_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_account_operations
    ADD CONSTRAINT idempotency_account_operations_pkey PRIMARY KEY (operation);


--
-- Name: idempotency_keys idempotency_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_pkey PRIMARY KEY (id);


--
-- Name: jwks jwks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jwks
    ADD CONSTRAINT jwks_pkey PRIMARY KEY (id);


--
-- Name: live_access_fences live_access_fences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_access_fences
    ADD CONSTRAINT live_access_fences_pkey PRIMARY KEY (scope_key);


--
-- Name: live_admissions live_admissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_admissions
    ADD CONSTRAINT live_admissions_pkey PRIMARY KEY (id);


--
-- Name: live_editing_intents live_editing_intents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_editing_intents
    ADD CONSTRAINT live_editing_intents_pkey PRIMARY KEY (actor_id, command_id);


--
-- Name: live_invitations live_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_invitations
    ADD CONSTRAINT live_invitations_pkey PRIMARY KEY (id);


--
-- Name: live_invitations live_invitations_session_id_recipient_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_invitations
    ADD CONSTRAINT live_invitations_session_id_recipient_id_key UNIQUE (session_id, recipient_id);


--
-- Name: live_presentations live_presentations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_presentations
    ADD CONSTRAINT live_presentations_pkey PRIMARY KEY (id);


--
-- Name: live_presentations live_presentations_session_id_created_by_client_event_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_presentations
    ADD CONSTRAINT live_presentations_session_id_created_by_client_event_id_key UNIQUE (session_id, created_by, client_event_id);


--
-- Name: live_sessions live_sessions_created_by_client_session_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_created_by_client_session_id_key UNIQUE (created_by, client_session_id);


--
-- Name: live_sessions live_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_pkey PRIMARY KEY (id);


--
-- Name: live_sessions live_sessions_room_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_room_id_key UNIQUE (room_id);


--
-- Name: live_sessions live_sessions_workspace_id_project_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_workspace_id_project_id_id_key UNIQUE (workspace_id, project_id, id);


--
-- Name: live_webhook_events live_webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_webhook_events
    ADD CONSTRAINT live_webhook_events_pkey PRIMARY KEY (event_id);


--
-- Name: map_live_gestures map_live_gestures_actor_id_session_id_sketch_id_generation__key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_gestures
    ADD CONSTRAINT map_live_gestures_actor_id_session_id_sketch_id_generation__key UNIQUE (actor_id, session_id, sketch_id, generation, gesture_id);


--
-- Name: map_live_gestures map_live_gestures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_gestures
    ADD CONSTRAINT map_live_gestures_pkey PRIMARY KEY (lease_id);


--
-- Name: map_live_heads map_live_heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_heads
    ADD CONSTRAINT map_live_heads_pkey PRIMARY KEY (sketch_id);


--
-- Name: map_live_heads map_live_heads_sketch_id_generation_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_heads
    ADD CONSTRAINT map_live_heads_sketch_id_generation_key UNIQUE (sketch_id, generation);


--
-- Name: map_live_journal map_live_journal_actor_kind_actor_id_command_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_journal
    ADD CONSTRAINT map_live_journal_actor_kind_actor_id_command_id_key UNIQUE (actor_kind, actor_id, command_id);


--
-- Name: map_live_journal map_live_journal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_journal
    ADD CONSTRAINT map_live_journal_pkey PRIMARY KEY (sketch_id, generation, sequence);


--
-- Name: map_live_object_versions map_live_object_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_object_versions
    ADD CONSTRAINT map_live_object_versions_pkey PRIMARY KEY (kind, object_id);


--
-- Name: map_live_presence map_live_presence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_presence
    ADD CONSTRAINT map_live_presence_pkey PRIMARY KEY (connection_id);


--
-- Name: map_live_undone map_live_undone_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_undone
    ADD CONSTRAINT map_live_undone_pkey PRIMARY KEY (sketch_id, generation, original_sequence);


--
-- Name: message_references message_references_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_references
    ADD CONSTRAINT message_references_pkey PRIMARY KEY (id);


--
-- Name: native_command_receipts native_command_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.native_command_receipts
    ADD CONSTRAINT native_command_receipts_pkey PRIMARY KEY (project_id, actor_kind, actor_id, operation, client_command_id);


--
-- Name: needs_you_states needs_you_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.needs_you_states
    ADD CONSTRAINT needs_you_states_pkey PRIMARY KEY (user_id, item_key);


--
-- Name: notification_address_sends notification_address_sends_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_address_sends
    ADD CONSTRAINT notification_address_sends_pkey PRIMARY KEY (address_hash);


--
-- Name: notification_address_tokens notification_address_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_address_tokens
    ADD CONSTRAINT notification_address_tokens_pkey PRIMARY KEY (token_hash);


--
-- Name: notification_addresses notification_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_addresses
    ADD CONSTRAINT notification_addresses_pkey PRIMARY KEY (id);


--
-- Name: notification_cursor notification_cursor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_cursor
    ADD CONSTRAINT notification_cursor_pkey PRIMARY KEY (id);


--
-- Name: notification_emails notification_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_emails
    ADD CONSTRAINT notification_emails_pkey PRIMARY KEY (id);


--
-- Name: notification_emails notification_emails_unsubscribe_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_emails
    ADD CONSTRAINT notification_emails_unsubscribe_hash_key UNIQUE (unsubscribe_hash);


--
-- Name: notification_follows notification_follows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_follows
    ADD CONSTRAINT notification_follows_pkey PRIMARY KEY (user_id, conversation_id);


--
-- Name: notification_generation_failures notification_generation_failures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_generation_failures
    ADD CONSTRAINT notification_generation_failures_pkey PRIMARY KEY (event_id);


--
-- Name: notification_mutes notification_mutes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_mutes
    ADD CONSTRAINT notification_mutes_pkey PRIMARY KEY (user_id, source_type, source_id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (user_id);


--
-- Name: notification_verification_sends notification_verification_sends_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_verification_sends
    ADD CONSTRAINT notification_verification_sends_pkey PRIMARY KEY (user_id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_token oauth_access_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_token
    ADD CONSTRAINT oauth_access_token_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_token oauth_access_token_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_token
    ADD CONSTRAINT oauth_access_token_token_unique UNIQUE (token);


--
-- Name: oauth_client_assertion oauth_client_assertion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_assertion
    ADD CONSTRAINT oauth_client_assertion_pkey PRIMARY KEY (id);


--
-- Name: oauth_client oauth_client_client_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client
    ADD CONSTRAINT oauth_client_client_id_unique UNIQUE (client_id);


--
-- Name: oauth_client oauth_client_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client
    ADD CONSTRAINT oauth_client_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_resource oauth_client_resource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_resource
    ADD CONSTRAINT oauth_client_resource_pkey PRIMARY KEY (id);


--
-- Name: oauth_consent oauth_consent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_consent
    ADD CONSTRAINT oauth_consent_pkey PRIMARY KEY (id);


--
-- Name: oauth_grant_authentication oauth_grant_authentication_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_grant_authentication
    ADD CONSTRAINT oauth_grant_authentication_pkey PRIMARY KEY (authorization_code_id);


--
-- Name: oauth_refresh_token oauth_refresh_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_refresh_token
    ADD CONSTRAINT oauth_refresh_token_pkey PRIMARY KEY (id);


--
-- Name: oauth_refresh_token oauth_refresh_token_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_refresh_token
    ADD CONSTRAINT oauth_refresh_token_token_unique UNIQUE (token);


--
-- Name: oauth_resource oauth_resource_identifier_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_resource
    ADD CONSTRAINT oauth_resource_identifier_unique UNIQUE (identifier);


--
-- Name: oauth_resource oauth_resource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_resource
    ADD CONSTRAINT oauth_resource_pkey PRIMARY KEY (id);


--
-- Name: outbox outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbox
    ADD CONSTRAINT outbox_pkey PRIMARY KEY (id);


--
-- Name: password_attempts password_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_attempts
    ADD CONSTRAINT password_attempts_pkey PRIMARY KEY (id);


--
-- Name: password_reset_links password_reset_links_identifier_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_links
    ADD CONSTRAINT password_reset_links_identifier_key UNIQUE (verification_identifier);


--
-- Name: password_reset_links password_reset_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_links
    ADD CONSTRAINT password_reset_links_pkey PRIMARY KEY (id);


--
-- Name: person_photos person_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_photos
    ADD CONSTRAINT person_photos_pkey PRIMARY KEY (id);


--
-- Name: person_photos person_photos_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_photos
    ADD CONSTRAINT person_photos_user_id_key UNIQUE (user_id);


--
-- Name: personal_run_cites personal_run_cites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_run_cites
    ADD CONSTRAINT personal_run_cites_pkey PRIMARY KEY (run_id, kind, object_id);


--
-- Name: personal_run_pictures personal_run_pictures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_run_pictures
    ADD CONSTRAINT personal_run_pictures_pkey PRIMARY KEY (id);


--
-- Name: personal_run_pictures personal_run_pictures_position; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_run_pictures
    ADD CONSTRAINT personal_run_pictures_position UNIQUE (run_id, "position");


--
-- Name: personal_run_private_texts personal_run_private_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_run_private_texts
    ADD CONSTRAINT personal_run_private_texts_pkey PRIMARY KEY (id);


--
-- Name: personal_run_web_reads personal_run_web_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_run_web_reads
    ADD CONSTRAINT personal_run_web_reads_pkey PRIMARY KEY (id);


--
-- Name: personal_run_web_searches personal_run_web_searches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_run_web_searches
    ADD CONSTRAINT personal_run_web_searches_pkey PRIMARY KEY (id);


--
-- Name: personal_runs personal_runs_owner_user_id_client_run_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_owner_user_id_client_run_id_key UNIQUE (owner_user_id, client_run_id);


--
-- Name: personal_runs personal_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_pkey PRIMARY KEY (id);


--
-- Name: personal_runs personal_runs_workspace_id_project_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_workspace_id_project_id_id_key UNIQUE (workspace_id, project_id, id);


--
-- Name: project_ai_policies project_ai_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_ai_policies
    ADD CONSTRAINT project_ai_policies_pkey PRIMARY KEY (project_id);


--
-- Name: project_conversations project_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_conversations
    ADD CONSTRAINT project_conversations_pkey PRIMARY KEY (id);


--
-- Name: project_conversations project_conversations_workspace_id_project_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_conversations
    ADD CONSTRAINT project_conversations_workspace_id_project_id_id_key UNIQUE (workspace_id, project_id, id);


--
-- Name: project_decision_discussions project_decision_discussions_conversation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decision_discussions
    ADD CONSTRAINT project_decision_discussions_conversation_id_key UNIQUE (conversation_id);


--
-- Name: project_decision_discussions project_decision_discussions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decision_discussions
    ADD CONSTRAINT project_decision_discussions_pkey PRIMARY KEY (decision_id);


--
-- Name: project_decision_discussions project_decision_discussions_root_message_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decision_discussions
    ADD CONSTRAINT project_decision_discussions_root_message_id_key UNIQUE (root_message_id);


--
-- Name: project_decision_resumptions project_decision_resumptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decision_resumptions
    ADD CONSTRAINT project_decision_resumptions_pkey PRIMARY KEY (decision_id, work_id);


--
-- Name: project_decisions project_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decisions
    ADD CONSTRAINT project_decisions_pkey PRIMARY KEY (id);


--
-- Name: project_decisions project_decisions_workspace_id_project_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decisions
    ADD CONSTRAINT project_decisions_workspace_id_project_id_id_key UNIQUE (workspace_id, project_id, id);


--
-- Name: project_files project_files_message_id_position_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_files
    ADD CONSTRAINT project_files_message_id_position_key UNIQUE (message_id, "position");


--
-- Name: project_files project_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_files
    ADD CONSTRAINT project_files_pkey PRIMARY KEY (id);


--
-- Name: project_grants project_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_grants
    ADD CONSTRAINT project_grants_pkey PRIMARY KEY (id);


--
-- Name: project_material_versions project_material_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_material_versions
    ADD CONSTRAINT project_material_versions_pkey PRIMARY KEY (material_id, version);


--
-- Name: project_material_versions project_material_versions_workspace_id_project_id_material__key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_material_versions
    ADD CONSTRAINT project_material_versions_workspace_id_project_id_material__key UNIQUE (workspace_id, project_id, material_id, version);


--
-- Name: project_materials project_materials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_materials
    ADD CONSTRAINT project_materials_pkey PRIMARY KEY (id);


--
-- Name: project_materials project_materials_project_id_created_by_client_mutation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_materials
    ADD CONSTRAINT project_materials_project_id_created_by_client_mutation_id_key UNIQUE (project_id, created_by, client_mutation_id);


--
-- Name: project_materials project_materials_workspace_id_project_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_materials
    ADD CONSTRAINT project_materials_workspace_id_project_id_id_key UNIQUE (workspace_id, project_id, id);


--
-- Name: project_message_observations project_message_observations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_message_observations
    ADD CONSTRAINT project_message_observations_pkey PRIMARY KEY (message_id, viewer_id);


--
-- Name: project_messages project_messages_conversation_id_sequence_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_messages
    ADD CONSTRAINT project_messages_conversation_id_sequence_key UNIQUE (conversation_id, sequence);


--
-- Name: project_messages project_messages_file_identity; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_messages
    ADD CONSTRAINT project_messages_file_identity UNIQUE (workspace_id, project_id, id);


--
-- Name: project_messages project_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_messages
    ADD CONSTRAINT project_messages_pkey PRIMARY KEY (id);


--
-- Name: project_messages project_messages_project_id_author_id_client_message_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_messages
    ADD CONSTRAINT project_messages_project_id_author_id_client_message_id_key UNIQUE (project_id, author_id, client_message_id);


--
-- Name: project_messages project_messages_root_identity; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_messages
    ADD CONSTRAINT project_messages_root_identity UNIQUE (conversation_id, id, sequence);


--
-- Name: project_object_links project_object_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_object_links
    ADD CONSTRAINT project_object_links_pkey PRIMARY KEY (id);


--
-- Name: project_task_activity project_task_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_activity
    ADD CONSTRAINT project_task_activity_pkey PRIMARY KEY (id);


--
-- Name: project_task_dependencies project_task_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_dependencies
    ADD CONSTRAINT project_task_dependencies_pkey PRIMARY KEY (project_id, task_id, prerequisite_id);


--
-- Name: project_task_discussions project_task_discussions_conversation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_discussions
    ADD CONSTRAINT project_task_discussions_conversation_id_key UNIQUE (conversation_id);


--
-- Name: project_task_discussions project_task_discussions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_discussions
    ADD CONSTRAINT project_task_discussions_pkey PRIMARY KEY (work_id);


--
-- Name: project_task_discussions project_task_discussions_root_message_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_discussions
    ADD CONSTRAINT project_task_discussions_root_message_id_key UNIQUE (root_message_id);


--
-- Name: project_task_notices project_task_notices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_notices
    ADD CONSTRAINT project_task_notices_pkey PRIMARY KEY (id);


--
-- Name: project_task_notices project_task_notices_work_id_kind_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_notices
    ADD CONSTRAINT project_task_notices_work_id_kind_key UNIQUE (work_id, kind);


--
-- Name: project_task_plan_intents project_task_plan_intents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_plan_intents
    ADD CONSTRAINT project_task_plan_intents_pkey PRIMARY KEY (project_id, material_id, material_version, intent_key);


--
-- Name: project_task_plan_intents project_task_plan_intents_task_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_plan_intents
    ADD CONSTRAINT project_task_plan_intents_task_id_key UNIQUE (task_id);


--
-- Name: project_task_updates project_task_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_updates
    ADD CONSTRAINT project_task_updates_pkey PRIMARY KEY (id);


--
-- Name: project_work_items project_work_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_work_items
    ADD CONSTRAINT project_work_items_pkey PRIMARY KEY (id);


--
-- Name: project_work_items project_work_items_workspace_id_project_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_work_items
    ADD CONSTRAINT project_work_items_workspace_id_project_id_id_key UNIQUE (workspace_id, project_id, id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: projects projects_workspace_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_workspace_id_id_key UNIQUE (workspace_id, id);


--
-- Name: push_subscriptions push_subscriptions_endpoint_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_endpoint_key UNIQUE (endpoint);


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: return_points return_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_points
    ADD CONSTRAINT return_points_pkey PRIMARY KEY (user_id, place_key);


--
-- Name: sample_results sample_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sample_results
    ADD CONSTRAINT sample_results_pkey PRIMARY KEY (sample_id);


--
-- Name: samples samples_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.samples
    ADD CONSTRAINT samples_pkey PRIMARY KEY (id);


--
-- Name: sealed_job_waits sealed_job_waits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sealed_job_waits
    ADD CONSTRAINT sealed_job_waits_pkey PRIMARY KEY (id);


--
-- Name: search_changes search_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_changes
    ADD CONSTRAINT search_changes_pkey PRIMARY KEY (seq);


--
-- Name: search_documents search_documents_doc_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_documents
    ADD CONSTRAINT search_documents_doc_key_key UNIQUE (doc_key);


--
-- Name: search_documents search_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_documents
    ADD CONSTRAINT search_documents_pkey PRIMARY KEY (id);


--
-- Name: search_vector_queue search_vector_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_vector_queue
    ADD CONSTRAINT search_vector_queue_pkey PRIMARY KEY (document_id);


--
-- Name: search_vector_state search_vector_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_vector_state
    ADD CONSTRAINT search_vector_state_pkey PRIMARY KEY (only_row);


--
-- Name: search_vectors search_vectors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_vectors
    ADD CONSTRAINT search_vectors_pkey PRIMARY KEY (document_id);


--
-- Name: sketch_links sketch_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_links
    ADD CONSTRAINT sketch_links_pkey PRIMARY KEY (id);


--
-- Name: sketch_thoughts sketch_thoughts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_thoughts
    ADD CONSTRAINT sketch_thoughts_pkey PRIMARY KEY (id);


--
-- Name: sketch_thoughts sketch_thoughts_sketch_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_thoughts
    ADD CONSTRAINT sketch_thoughts_sketch_id_id_key UNIQUE (sketch_id, id);


--
-- Name: sketches sketches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketches
    ADD CONSTRAINT sketches_pkey PRIMARY KEY (id);


--
-- Name: sketches sketches_workspace_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketches
    ADD CONSTRAINT sketches_workspace_id_id_key UNIQUE (workspace_id, id);


--
-- Name: sketches sketches_workspace_project_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketches
    ADD CONSTRAINT sketches_workspace_project_id_unique UNIQUE (workspace_id, project_id, id);


--
-- Name: space_icons space_icons_picture_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.space_icons
    ADD CONSTRAINT space_icons_picture_key UNIQUE (picture);


--
-- Name: space_icons space_icons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.space_icons
    ADD CONSTRAINT space_icons_pkey PRIMARY KEY (project_id);


--
-- Name: space_order space_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.space_order
    ADD CONSTRAINT space_order_pkey PRIMARY KEY (user_id, project_id);


--
-- Name: task_creation_undo_receipts task_creation_undo_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_creation_undo_receipts
    ADD CONSTRAINT task_creation_undo_receipts_pkey PRIMARY KEY (project_id, actor_kind, actor_id, client_command_id);


--
-- Name: project_task_notices task_notice_scope_identity; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_notices
    ADD CONSTRAINT task_notice_scope_identity UNIQUE (workspace_id, project_id, work_id, id);


--
-- Name: workspace_dek_wraps workspace_dek_wraps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_dek_wraps
    ADD CONSTRAINT workspace_dek_wraps_pkey PRIMARY KEY (holder_id, key_version);


--
-- Name: workspace_holders workspace_holders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_holders
    ADD CONSTRAINT workspace_holders_pkey PRIMARY KEY (id);


--
-- Name: workspace_invites workspace_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invites
    ADD CONSTRAINT workspace_invites_pkey PRIMARY KEY (id);


--
-- Name: workspace_invites workspace_invites_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invites
    ADD CONSTRAINT workspace_invites_token_hash_key UNIQUE (token_hash);


--
-- Name: workspace_key_versions workspace_key_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_key_versions
    ADD CONSTRAINT workspace_key_versions_pkey PRIMARY KEY (workspace_id, key_version);


--
-- Name: workspace_keys workspace_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_keys
    ADD CONSTRAINT workspace_keys_pkey PRIMARY KEY (workspace_id);


--
-- Name: workspace_members workspace_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_members
    ADD CONSTRAINT workspace_members_pkey PRIMARY KEY (workspace_id, user_id);


--
-- Name: workspace_removals workspace_removals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_removals
    ADD CONSTRAINT workspace_removals_pkey PRIMARY KEY (workspace_id, seq);


--
-- Name: workspace_removed_holders workspace_removed_holders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_removed_holders
    ADD CONSTRAINT workspace_removed_holders_pkey PRIMARY KEY (workspace_id, holder_id);


--
-- Name: workspace_removed_people workspace_removed_people_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_removed_people
    ADD CONSTRAINT workspace_removed_people_pkey PRIMARY KEY (workspace_id, user_id);


--
-- Name: workspace_rotation_progress workspace_rotation_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_rotation_progress
    ADD CONSTRAINT workspace_rotation_progress_pkey PRIMARY KEY (workspace_id);


--
-- Name: workspace_unlocks workspace_unlocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_unlocks
    ADD CONSTRAINT workspace_unlocks_pkey PRIMARY KEY (workspace_id, key_version);


--
-- Name: workspace_wrap_grants workspace_wrap_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_wrap_grants
    ADD CONSTRAINT workspace_wrap_grants_pkey PRIMARY KEY (workspace_id, user_id);


--
-- Name: workspaces workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_pkey PRIMARY KEY (id);


--
-- Name: job_common_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i1 ON pgboss.job_common USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'created'::pgboss.job_state) AND (policy = 'short'::text));


--
-- Name: job_common_i10; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i10 ON pgboss.job_common USING btree (name, singleton_key, state DESC, created_on, id) INCLUDE (start_after) WHERE ((state < 'active'::pgboss.job_state) AND (NOT blocked) AND (policy = 'key_strict_fifo'::text));


--
-- Name: job_common_i11; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i11 ON pgboss.job_common USING btree (name, priority DESC, created_on, start_after) WHERE ((state < 'active'::pgboss.job_state) AND (NOT blocked));


--
-- Name: job_common_i12; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i12 ON pgboss.job_common USING btree (source_root_id) WHERE (source_root_id IS NOT NULL);


--
-- Name: job_common_i13; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i13 ON pgboss.job_common USING btree (name, singleton_key) WHERE ((state = 'created'::pgboss.job_state) AND upsert_by_key);


--
-- Name: job_common_i14; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i14 ON pgboss.job_common USING btree (name, state, blocked, start_after) WHERE (state = ANY (ARRAY['created'::pgboss.job_state, 'retry'::pgboss.job_state, 'active'::pgboss.job_state, 'failed'::pgboss.job_state]));


--
-- Name: job_common_i15; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i15 ON pgboss.job_common USING btree (name, created_on);


--
-- Name: job_common_i16; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i16 ON pgboss.job_common USING btree (name, completed_on) WHERE (completed_on IS NOT NULL);


--
-- Name: job_common_i17; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i17 ON pgboss.job_common USING btree (name, singleton_key, created_on) WHERE ((state < 'active'::pgboss.job_state) AND (singleton_key IS NOT NULL));


--
-- Name: job_common_i2; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i2 ON pgboss.job_common USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'active'::pgboss.job_state) AND (policy = 'singleton'::text));


--
-- Name: job_common_i3; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i3 ON pgboss.job_common USING btree (name, state, COALESCE(singleton_key, ''::text)) WHERE ((state <= 'active'::pgboss.job_state) AND (policy = 'stately'::text));


--
-- Name: job_common_i4; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i4 ON pgboss.job_common USING btree (name, singleton_on, COALESCE(singleton_key, ''::text)) WHERE ((state <> 'cancelled'::pgboss.job_state) AND (singleton_on IS NOT NULL));


--
-- Name: job_common_i6; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i6 ON pgboss.job_common USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state <= 'active'::pgboss.job_state) AND (policy = 'exclusive'::text));


--
-- Name: job_common_i7; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i7 ON pgboss.job_common USING btree (name, group_id) WHERE ((state = 'active'::pgboss.job_state) AND (group_id IS NOT NULL));


--
-- Name: job_common_i8; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i8 ON pgboss.job_common USING btree (name, singleton_key) WHERE ((state = ANY (ARRAY['active'::pgboss.job_state, 'retry'::pgboss.job_state, 'failed'::pgboss.job_state])) AND (policy = 'key_strict_fifo'::text));


--
-- Name: job_common_i9; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i9 ON pgboss.job_common USING btree (name, id) WHERE (blocking AND (state = 'completed'::pgboss.job_state));


--
-- Name: job_dep_parent_idx; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_dep_parent_idx ON pgboss.job_dependency USING btree (parent_name, parent_id);


--
-- Name: queue_stats_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX queue_stats_i1 ON ONLY pgboss.queue_stats USING btree (name, captured_on DESC) INCLUDE (deferred_count, queued_count, ready_count, active_count, failed_count, total_count);


--
-- Name: queue_stats_20261120_name_captured_on_deferred_count_queued_idx; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX queue_stats_20261120_name_captured_on_deferred_count_queued_idx ON pgboss.queue_stats_20261120 USING btree (name, captured_on DESC) INCLUDE (deferred_count, queued_count, ready_count, active_count, failed_count, total_count);


--
-- Name: queue_stats_20261121_name_captured_on_deferred_count_queued_idx; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX queue_stats_20261121_name_captured_on_deferred_count_queued_idx ON pgboss.queue_stats_20261121 USING btree (name, captured_on DESC) INCLUDE (deferred_count, queued_count, ready_count, active_count, failed_count, total_count);


--
-- Name: warning_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX warning_i1 ON pgboss.warning USING btree (created_on DESC);


--
-- Name: agent_chat_messages_agent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_chat_messages_agent_idx ON public.agent_chat_messages USING btree (agent_id, created_at DESC, id DESC);


--
-- Name: agent_command_receipts_activity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_command_receipts_activity_idx ON public.agent_command_receipts USING btree (connection_id, project_id, completed_at DESC);


--
-- Name: agent_connections_assistant_agent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX agent_connections_assistant_agent_idx ON public.agent_connections USING btree (agent_id) WHERE (compute_source = 'owner_assistant'::text);


--
-- Name: agent_connections_owner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_connections_owner_idx ON public.agent_connections USING btree (owner_user_id, created_at DESC, id);


--
-- Name: agent_memory_items_agent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_memory_items_agent_idx ON public.agent_memory_items USING btree (agent_id, created_at, id);


--
-- Name: agent_proposals_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_proposals_project_idx ON public.agent_proposals USING btree (project_id, created_at DESC, id DESC);


--
-- Name: agent_questions_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_questions_project_idx ON public.agent_questions USING btree (project_id, created_at DESC);


--
-- Name: agent_runtime_auth_expiry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_runtime_auth_expiry_idx ON public.agent_runtime_auth_operations USING btree (lease_ends_at) WHERE (phase = 'active'::text);


--
-- Name: agent_runtime_bindings_owner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_runtime_bindings_owner_idx ON public.agent_runtime_bindings USING btree (owner_user_id, created_at DESC, id);


--
-- Name: agent_runtime_bindings_owner_live_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX agent_runtime_bindings_owner_live_idx ON public.agent_runtime_bindings USING btree (owner_user_id) WHERE (state <> 'released'::text);


--
-- Name: agent_runtime_bindings_slot_live_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_runtime_bindings_slot_live_idx ON public.agent_runtime_bindings USING btree (slot) WHERE (state <> 'released'::text);


--
-- Name: agent_runtime_connections_owner_client_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX agent_runtime_connections_owner_client_idx ON public.agent_runtime_connections USING btree (owner_user_id, client) WHERE (revoked_at IS NULL);


--
-- Name: agent_runtime_sessions_connection_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_runtime_sessions_connection_idx ON public.agent_runtime_sessions USING btree (connection_id, expires_at);


--
-- Name: agent_stops_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_stops_project_idx ON public.agent_stops USING btree (project_id, stopped_at DESC);


--
-- Name: agent_task_events_handled_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_task_events_handled_idx ON public.agent_task_events USING btree (handled_at) WHERE (handled_at IS NOT NULL);


--
-- Name: agent_task_events_pending_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_task_events_pending_idx ON public.agent_task_events USING btree (created_at, id) WHERE (handled_at IS NULL);


--
-- Name: api_key_checks_connection_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX api_key_checks_connection_idx ON public.api_key_checks USING btree (connection_id, checked_at);


--
-- Name: assistant_changes_connection_command_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX assistant_changes_connection_command_idx ON public.assistant_changes USING btree (connection_id, client_command_id) WHERE (connection_id IS NOT NULL);


--
-- Name: assistant_changes_connection_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_changes_connection_idx ON public.assistant_changes USING btree (connection_id, created_at) WHERE (connection_id IS NOT NULL);


--
-- Name: assistant_changes_conversation_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_changes_conversation_idx ON public.assistant_changes USING btree (conversation_id, created_at) WHERE (conversation_id IS NOT NULL);


--
-- Name: assistant_changes_owner_waiting_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_changes_owner_waiting_idx ON public.assistant_changes USING btree (owner_user_id, created_at) WHERE (state = 'waiting'::text);


--
-- Name: assistant_changes_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_changes_run_idx ON public.assistant_changes USING btree (run_id, created_at);


--
-- Name: assistant_changes_scope_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_changes_scope_idx ON public.assistant_changes USING btree (project_id, scope_id, created_at) WHERE (scope_id IS NOT NULL);


--
-- Name: assistant_job_runs_history_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_job_runs_history_idx ON public.assistant_job_runs USING btree (job_id, fired_at DESC);


--
-- Name: assistant_job_runs_one_running_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX assistant_job_runs_one_running_idx ON public.assistant_job_runs USING btree (job_id) WHERE (state = 'running'::text);


--
-- Name: assistant_job_runs_owner_day_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_job_runs_owner_day_idx ON public.assistant_job_runs USING btree (owner_user_id, started_at) WHERE (state <> 'skipped'::text);


--
-- Name: assistant_job_runs_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_job_runs_run_idx ON public.assistant_job_runs USING btree (run_id) WHERE (run_id IS NOT NULL);


--
-- Name: assistant_jobs_agent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_jobs_agent_idx ON public.assistant_jobs USING btree (agent_id, created_at, id) WHERE (deleted_at IS NULL);


--
-- Name: assistant_jobs_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_jobs_due_idx ON public.assistant_jobs USING btree (next_run_at) WHERE (enabled AND (deleted_at IS NULL));


--
-- Name: assistant_jobs_owner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_jobs_owner_idx ON public.assistant_jobs USING btree (owner_user_id, created_at, id) WHERE (deleted_at IS NULL);


--
-- Name: assistant_settings_owner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_settings_owner_idx ON public.assistant_settings USING btree (owner_user_id, created_at, agent_id);


--
-- Name: auth_accounts_provider_account_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX auth_accounts_provider_account_idx ON public.auth_accounts USING btree (provider_id, account_id);


--
-- Name: auth_accounts_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_accounts_user_id_idx ON public.auth_accounts USING btree (user_id);


--
-- Name: auth_email_claims_held_by_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_email_claims_held_by_idx ON public.auth_email_claims USING btree (held_by);


--
-- Name: auth_identity_audit_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_identity_audit_user_idx ON public.auth_identity_audit USING btree (user_id);


--
-- Name: auth_idp_standing_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_idp_standing_due_idx ON public.auth_idp_standing USING btree (next_check_at) WHERE (refresh_token_enc IS NOT NULL);


--
-- Name: auth_idp_standing_refused_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_idp_standing_refused_idx ON public.auth_idp_standing USING btree (user_id) WHERE (state = 'sign_in_required'::text);


--
-- Name: auth_link_intents_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_link_intents_user_idx ON public.auth_link_intents USING btree (user_id);


--
-- Name: auth_logout_tokens_expires_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_logout_tokens_expires_idx ON public.auth_logout_tokens USING btree (expires_at);


--
-- Name: auth_rate_limits_last_request_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_rate_limits_last_request_idx ON public.auth_rate_limits USING btree (last_request);


--
-- Name: auth_session_identities_idp_sid_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_session_identities_idp_sid_idx ON public.auth_session_identities USING btree (method, idp_sid) WHERE (idp_sid IS NOT NULL);


--
-- Name: auth_sessions_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_sessions_user_id_idx ON public.auth_sessions USING btree (user_id);


--
-- Name: auth_sign_in_throttle_last_failure_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_sign_in_throttle_last_failure_idx ON public.auth_sign_in_throttle USING btree (last_failure_at);


--
-- Name: auth_verifications_identifier_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_verifications_identifier_idx ON public.auth_verifications USING btree (identifier);


--
-- Name: background_compute_connections_owner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX background_compute_connections_owner_idx ON public.background_compute_connections USING btree (owner_user_id, created_at DESC, id);


--
-- Name: cowork_units_connection_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cowork_units_connection_idx ON public.cowork_units USING btree (assignment_connection_id, state, lease_expires_at);


--
-- Name: cowork_units_work_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cowork_units_work_idx ON public.cowork_units USING btree (workspace_id, project_id, work_id);


--
-- Name: dm_message_observations_viewer_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dm_message_observations_viewer_idx ON public.dm_message_observations USING btree (dm_id, viewer_id);


--
-- Name: dm_messages_roots_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dm_messages_roots_idx ON public.dm_messages USING btree (dm_id, sequence) WHERE (thread_root_id IS NULL);


--
-- Name: dm_messages_thread_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dm_messages_thread_idx ON public.dm_messages USING btree (thread_root_id, sequence) WHERE (thread_root_id IS NOT NULL);


--
-- Name: dm_participants_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dm_participants_user_idx ON public.dm_participants USING btree (workspace_id, user_id, dm_id);


--
-- Name: dm_reads_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dm_reads_user_idx ON public.dm_reads USING btree (user_id);


--
-- Name: dms_workspace_activity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dms_workspace_activity_idx ON public.dms USING btree (workspace_id, COALESCE(last_message_at, created_at) DESC, id);


--
-- Name: doc_live_presence_room; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX doc_live_presence_room ON public.doc_live_presence USING btree (doc_id, generation, expires_at);


--
-- Name: encrypted_workspace_creations_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX encrypted_workspace_creations_person ON public.encrypted_workspace_creations USING btree (user_id, at);


--
-- Name: event_audience_event_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX event_audience_event_idx ON public.event_audience USING btree (event_id);


--
-- Name: events_seq_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX events_seq_idx ON public.events USING btree (seq);


--
-- Name: events_workspace_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX events_workspace_idx ON public.events USING btree (workspace_id, created_at) WHERE (workspace_id IS NOT NULL);


--
-- Name: file_text_jobs_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_text_jobs_order_idx ON public.file_text_jobs USING btree (queued_at, file_id);


--
-- Name: github_processing_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX github_processing_due_idx ON public.github_processing USING btree (state, next_attempt_at);


--
-- Name: github_task_rule_changes_task_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX github_task_rule_changes_task_idx ON public.github_task_rule_changes USING btree (task_id, created_at DESC, id DESC);


--
-- Name: idempotency_keys_expiry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idempotency_keys_expiry_idx ON public.idempotency_keys USING btree (expires_at);


--
-- Name: idempotency_keys_scope_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idempotency_keys_scope_idx ON public.idempotency_keys USING btree (principal, COALESCE(workspace_id, '00000000-0000-0000-0000-000000000000'::uuid), operation, key);


--
-- Name: live_access_fences_workspace_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX live_access_fences_workspace_idx ON public.live_access_fences USING btree (workspace_id);


--
-- Name: live_admissions_auth_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX live_admissions_auth_session_idx ON public.live_admissions USING btree (auth_session_id) WHERE (revoked_at IS NULL);


--
-- Name: live_admissions_revoked_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX live_admissions_revoked_idx ON public.live_admissions USING btree (revoked_at) WHERE (revoked_at IS NOT NULL);


--
-- Name: live_admissions_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX live_admissions_session_idx ON public.live_admissions USING btree (live_session_id, user_id, issued_at DESC);


--
-- Name: live_invitations_recipient_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX live_invitations_recipient_idx ON public.live_invitations USING btree (recipient_id, response, created_at DESC, id DESC);


--
-- Name: live_presentations_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX live_presentations_session_idx ON public.live_presentations USING btree (session_id, created_at, id);


--
-- Name: live_sessions_lifecycle_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX live_sessions_lifecycle_idx ON public.live_sessions USING btree (state, updated_at, id);


--
-- Name: live_sessions_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX live_sessions_project_idx ON public.live_sessions USING btree (project_id, created_at DESC, id DESC);


--
-- Name: live_webhook_events_received_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX live_webhook_events_received_idx ON public.live_webhook_events USING btree (received_at);


--
-- Name: map_live_gestures_room; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX map_live_gestures_room ON public.map_live_gestures USING btree (sketch_id, generation, expires_at);


--
-- Name: map_live_presence_room; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX map_live_presence_room ON public.map_live_presence USING btree (sketch_id, generation, expires_at);


--
-- Name: message_references_dm_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX message_references_dm_position_idx ON public.message_references USING btree (dm_message_id, "position") WHERE (dm_message_id IS NOT NULL);


--
-- Name: message_references_project_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX message_references_project_position_idx ON public.message_references USING btree (project_message_id, "position") WHERE (project_message_id IS NOT NULL);


--
-- Name: message_references_target_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX message_references_target_idx ON public.message_references USING btree (target_id);


--
-- Name: notification_address_sends_last_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notification_address_sends_last_idx ON public.notification_address_sends USING btree (last_sent_at);


--
-- Name: notification_address_tokens_address_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notification_address_tokens_address_idx ON public.notification_address_tokens USING btree (address_id);


--
-- Name: notification_addresses_user_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notification_addresses_user_created_idx ON public.notification_addresses USING btree (user_id, created_at);


--
-- Name: notification_addresses_user_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX notification_addresses_user_email_idx ON public.notification_addresses USING btree (user_id, lower(email));


--
-- Name: notification_emails_account_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX notification_emails_account_idx ON public.notification_emails USING btree (notification_id) WHERE (address_kind = 'account'::text);


--
-- Name: notification_emails_extra_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX notification_emails_extra_idx ON public.notification_emails USING btree (notification_id, address_id) WHERE ((address_kind = 'extra'::text) AND (address_id IS NOT NULL));


--
-- Name: notification_emails_user_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notification_emails_user_created_idx ON public.notification_emails USING btree (user_id, created_at DESC);


--
-- Name: notification_follows_conversation_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notification_follows_conversation_idx ON public.notification_follows USING btree (conversation_id);


--
-- Name: notifications_needs_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_needs_idx ON public.notifications USING btree (user_id, created_at DESC, id DESC) WHERE (in_inbox AND (reason = ANY (ARRAY['mention'::text, 'question'::text, 'invitation'::text, 'assigned'::text])));


--
-- Name: notifications_recipient_event_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX notifications_recipient_event_idx ON public.notifications USING btree (user_id, event_id) WHERE (event_id IS NOT NULL);


--
-- Name: notifications_source_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_source_idx ON public.notifications USING btree (source_type, source_id);


--
-- Name: notifications_unread_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_unread_idx ON public.notifications USING btree (user_id, created_at DESC, id DESC) WHERE (in_inbox AND (read_at IS NULL));


--
-- Name: notifications_user_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_user_created_idx ON public.notifications USING btree (user_id, created_at DESC);


--
-- Name: oauthAccessToken_authorizationCodeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthAccessToken_authorizationCodeId_idx" ON public.oauth_access_token USING btree (authorization_code_id);


--
-- Name: oauthAccessToken_clientId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthAccessToken_clientId_idx" ON public.oauth_access_token USING btree (client_id);


--
-- Name: oauthAccessToken_refreshId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthAccessToken_refreshId_idx" ON public.oauth_access_token USING btree (refresh_id);


--
-- Name: oauthAccessToken_sessionId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthAccessToken_sessionId_idx" ON public.oauth_access_token USING btree (session_id);


--
-- Name: oauthAccessToken_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthAccessToken_userId_idx" ON public.oauth_access_token USING btree (user_id);


--
-- Name: oauthClientResource_clientId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthClientResource_clientId_idx" ON public.oauth_client_resource USING btree (client_id);


--
-- Name: oauthClientResource_clientId_resourceId_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "oauthClientResource_clientId_resourceId_uidx" ON public.oauth_client_resource USING btree (client_id, resource_id);


--
-- Name: oauthClientResource_resourceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthClientResource_resourceId_idx" ON public.oauth_client_resource USING btree (resource_id);


--
-- Name: oauthClient_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthClient_userId_idx" ON public.oauth_client USING btree (user_id);


--
-- Name: oauthConsent_clientId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthConsent_clientId_idx" ON public.oauth_consent USING btree (client_id);


--
-- Name: oauthConsent_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthConsent_userId_idx" ON public.oauth_consent USING btree (user_id);


--
-- Name: oauthRefreshToken_authorizationCodeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthRefreshToken_authorizationCodeId_idx" ON public.oauth_refresh_token USING btree (authorization_code_id);


--
-- Name: oauthRefreshToken_clientId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthRefreshToken_clientId_idx" ON public.oauth_refresh_token USING btree (client_id);


--
-- Name: oauthRefreshToken_sessionId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthRefreshToken_sessionId_idx" ON public.oauth_refresh_token USING btree (session_id);


--
-- Name: oauthRefreshToken_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "oauthRefreshToken_userId_idx" ON public.oauth_refresh_token USING btree (user_id);


--
-- Name: oauth_grant_authentication_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX oauth_grant_authentication_user_idx ON public.oauth_grant_authentication USING btree (user_id);


--
-- Name: password_attempts_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX password_attempts_person ON public.password_attempts USING btree (workspace_id, user_id, at);


--
-- Name: password_reset_links_open_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX password_reset_links_open_idx ON public.password_reset_links USING btree (user_id) WHERE ((used_at IS NULL) AND (stopped_at IS NULL));


--
-- Name: personal_run_private_texts_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_run_private_texts_run_idx ON public.personal_run_private_texts USING btree (run_id);


--
-- Name: personal_run_web_reads_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_run_web_reads_run_idx ON public.personal_run_web_reads USING btree (run_id, read_at);


--
-- Name: personal_run_web_searches_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_run_web_searches_run_idx ON public.personal_run_web_searches USING btree (run_id, searched_at);


--
-- Name: personal_runs_answers_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_runs_answers_idx ON public.personal_runs USING btree (conversation_id, committed_at, id) WHERE (committed_at IS NOT NULL);


--
-- Name: personal_runs_chat_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_runs_chat_idx ON public.personal_runs USING btree (agent_id, created_at DESC) WHERE ((project_id IS NULL) AND (dm_id IS NULL));


--
-- Name: personal_runs_dm_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_runs_dm_idx ON public.personal_runs USING btree (dm_id, created_at DESC) WHERE (dm_id IS NOT NULL);


--
-- Name: personal_runs_dm_thread_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_runs_dm_thread_idx ON public.personal_runs USING btree (dm_thread_root_id, created_at DESC) WHERE (dm_thread_root_id IS NOT NULL);


--
-- Name: personal_runs_gateway_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX personal_runs_gateway_token_idx ON public.personal_runs USING btree (gateway_token_hash) WHERE (gateway_token_hash IS NOT NULL);


--
-- Name: personal_runs_key_day_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_runs_key_day_idx ON public.personal_runs USING btree (connection_id, reserved_at) WHERE (engine = 'server'::text);


--
-- Name: personal_runs_one_working_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX personal_runs_one_working_idx ON public.personal_runs USING btree (owner_user_id) WHERE (status = ANY (ARRAY['reading'::text, 'dispatching'::text]));


--
-- Name: personal_runs_owner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_runs_owner_idx ON public.personal_runs USING btree (owner_user_id, created_at DESC, id DESC);


--
-- Name: personal_runs_queued_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_runs_queued_idx ON public.personal_runs USING btree (((authority <> 'owner_request'::text)), created_at, id) WHERE (status = 'queued'::text);


--
-- Name: personal_runs_resume_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_runs_resume_idx ON public.personal_runs USING btree (resume_at) WHERE ((status = 'queued'::text) AND (resume_at IS NOT NULL));


--
-- Name: personal_runs_work_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_runs_work_idx ON public.personal_runs USING btree (work_id, created_at DESC) WHERE (work_id IS NOT NULL);


--
-- Name: project_conversations_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_conversations_project_idx ON public.project_conversations USING btree (project_id, created_at DESC, id DESC);


--
-- Name: project_decision_resumptions_work_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_decision_resumptions_work_idx ON public.project_decision_resumptions USING btree (work_id);


--
-- Name: project_decisions_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_decisions_project_idx ON public.project_decisions USING btree (project_id, created_at DESC, id DESC);


--
-- Name: project_files_agent_upload_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_files_agent_upload_idx ON public.project_files USING btree (project_id, uploader_agent_id, upload_id) WHERE (uploader_agent_id IS NOT NULL);


--
-- Name: project_files_chat_upload_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_files_chat_upload_idx ON public.project_files USING btree (agent_id, uploader_id, upload_id) WHERE ((agent_id IS NOT NULL) AND (uploader_id IS NOT NULL));


--
-- Name: project_files_dm_message_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_files_dm_message_position_idx ON public.project_files USING btree (dm_message_id, "position") WHERE (dm_message_id IS NOT NULL);


--
-- Name: project_files_dm_upload_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_files_dm_upload_idx ON public.project_files USING btree (dm_id, uploader_id, upload_id) WHERE ((dm_id IS NOT NULL) AND (uploader_id IS NOT NULL));


--
-- Name: project_files_expiry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_files_expiry_idx ON public.project_files USING btree (expires_at) WHERE (published_at IS NULL);


--
-- Name: project_files_human_upload_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_files_human_upload_idx ON public.project_files USING btree (project_id, uploader_id, upload_id) WHERE (uploader_id IS NOT NULL);


--
-- Name: project_files_poster_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_files_poster_idx ON public.project_files USING btree (poster_of) WHERE (poster_of IS NOT NULL);


--
-- Name: project_files_replay_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_files_replay_idx ON public.project_files USING btree (replay_of) WHERE (replay_of IS NOT NULL);


--
-- Name: project_files_run_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_files_run_position_idx ON public.project_files USING btree (run_id, "position") WHERE (run_id IS NOT NULL);


--
-- Name: project_files_thought_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_files_thought_idx ON public.project_files USING btree (thought_id) WHERE (thought_id IS NOT NULL);


--
-- Name: project_grants_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_grants_user_idx ON public.project_grants USING btree (project_id, user_id) WHERE (user_id IS NOT NULL);


--
-- Name: project_grants_user_lookup_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_grants_user_lookup_idx ON public.project_grants USING btree (user_id) WHERE (user_id IS NOT NULL);


--
-- Name: project_material_edit_retry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_material_edit_retry_idx ON public.project_material_versions USING btree (material_id, author_id, client_mutation_id) WHERE (client_mutation_id IS NOT NULL);


--
-- Name: project_materials_docs_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_materials_docs_idx ON public.project_materials USING btree (project_id, updated_at DESC, id DESC) WHERE (kind = 'doc'::text);


--
-- Name: project_materials_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_materials_project_idx ON public.project_materials USING btree (project_id, created_at DESC, id DESC);


--
-- Name: project_message_agent_command_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_message_agent_command_idx ON public.project_messages USING btree (project_id, author_agent_id, client_message_id) WHERE (author_agent_id IS NOT NULL);


--
-- Name: project_message_observations_viewer_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_message_observations_viewer_idx ON public.project_message_observations USING btree (project_id, viewer_id);


--
-- Name: project_messages_conversation_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_messages_conversation_idx ON public.project_messages USING btree (conversation_id, sequence);


--
-- Name: project_object_links_from_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_object_links_from_idx ON public.project_object_links USING btree (from_id);


--
-- Name: project_object_links_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_object_links_project_idx ON public.project_object_links USING btree (project_id);


--
-- Name: project_object_links_to_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_object_links_to_idx ON public.project_object_links USING btree (to_id);


--
-- Name: project_object_links_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_object_links_unique_idx ON public.project_object_links USING btree (from_id, role, to_type, to_id, COALESCE(to_version, 0));


--
-- Name: project_task_activity_work_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_task_activity_work_idx ON public.project_task_activity USING btree (work_id, created_at DESC, id DESC);


--
-- Name: project_task_dependencies_prerequisite_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_task_dependencies_prerequisite_idx ON public.project_task_dependencies USING btree (prerequisite_id, task_id);


--
-- Name: project_task_dependencies_task_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_task_dependencies_task_idx ON public.project_task_dependencies USING btree (task_id, prerequisite_id);


--
-- Name: project_task_notices_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_task_notices_project_idx ON public.project_task_notices USING btree (project_id, created_at DESC, id DESC);


--
-- Name: project_task_updates_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_task_updates_project_idx ON public.project_task_updates USING btree (project_id, created_at DESC, id DESC);


--
-- Name: project_work_creation_command_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_work_creation_command_idx ON public.project_work_items USING btree (project_id, created_by_kind, created_by_id, client_command_id) WHERE (client_command_id IS NOT NULL);


--
-- Name: project_work_items_owner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_work_items_owner_idx ON public.project_work_items USING btree (workspace_id, owner_user_id) WHERE (owner_user_id IS NOT NULL);


--
-- Name: project_work_items_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_work_items_project_idx ON public.project_work_items USING btree (project_id, created_at DESC, id DESC);


--
-- Name: project_work_items_waiting_decision_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_work_items_waiting_decision_idx ON public.project_work_items USING btree (waiting_for_decision_id) WHERE (waiting_for_decision_id IS NOT NULL);


--
-- Name: project_work_items_waiting_for_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_work_items_waiting_for_idx ON public.project_work_items USING btree (workspace_id, waiting_for_user_id) WHERE (waiting_for_user_id IS NOT NULL);


--
-- Name: project_work_items_waiting_work_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_work_items_waiting_work_idx ON public.project_work_items USING btree (waiting_for_work_id) WHERE (waiting_for_work_id IS NOT NULL);


--
-- Name: project_work_number_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_work_number_idx ON public.project_work_items USING btree (project_id, number);


--
-- Name: push_subscriptions_session_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_subscriptions_session_id_idx ON public.push_subscriptions USING btree (session_id);


--
-- Name: push_subscriptions_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_subscriptions_user_id_idx ON public.push_subscriptions USING btree (user_id);


--
-- Name: return_points_conversation_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX return_points_conversation_idx ON public.return_points USING btree (conversation_id) WHERE (conversation_id IS NOT NULL);


--
-- Name: return_points_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX return_points_project_idx ON public.return_points USING btree (project_id) WHERE (project_id IS NOT NULL);


--
-- Name: sealed_job_waits_workspace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sealed_job_waits_workspace ON public.sealed_job_waits USING btree (workspace_id, created_at);


--
-- Name: search_changes_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_changes_at_idx ON public.search_changes USING btree (at);


--
-- Name: search_changes_workspace_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_changes_workspace_idx ON public.search_changes USING btree (workspace_id, seq);


--
-- Name: search_changes_xid_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_changes_xid_idx ON public.search_changes USING btree (workspace_id, xid);


--
-- Name: search_documents_bm25_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_documents_bm25_idx ON public.search_documents USING bm25 (id, ((title)::pdb.simple('ascii_folding=true', 'stemmer=polish', 'alias=title_pl')), ((title)::pdb.simple('ascii_folding=true', 'stemmer=english', 'alias=title_en')), ((public.flux_joined_words(title))::pdb.simple('ascii_folding=true', 'stemmer=english', 'alias=title_joined')), ((body)::pdb.simple('ascii_folding=true', 'stemmer=polish', 'alias=body_pl')), ((body)::pdb.simple('ascii_folding=true', 'stemmer=english', 'alias=body_en')), ((public.flux_joined_words(body))::pdb.simple('ascii_folding=true', 'stemmer=english', 'alias=body_joined')), ((kind)::pdb.literal), ((audience_key)::pdb.literal), ((author_kind)::pdb.literal), ((author_id)::pdb.literal), workspace_id, project_id, parent_id, at) WITH (mutable_segment_rows='0') WHERE (NOT sealed);


--
-- Name: search_documents_file_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_documents_file_idx ON public.search_documents USING btree (object_id, version) WHERE (kind = 'file'::text);


--
-- Name: search_documents_keys_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_documents_keys_idx ON public.search_documents USING gin (keys) WITH (fastupdate=off);


--
-- Name: search_documents_parent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_documents_parent_idx ON public.search_documents USING btree (parent_id) WHERE (parent_id IS NOT NULL);


--
-- Name: search_documents_person_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_documents_person_idx ON public.search_documents USING btree (object_id) WHERE (kind = 'person'::text);


--
-- Name: search_documents_sealed_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_documents_sealed_idx ON public.search_documents USING btree (workspace_id, id) WHERE sealed;


--
-- Name: search_vector_queue_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_vector_queue_order_idx ON public.search_vector_queue USING btree (queued_at, document_id);


--
-- Name: sketch_links_pair_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sketch_links_pair_idx ON public.sketch_links USING btree (sketch_id, LEAST(from_id, to_id), GREATEST(from_id, to_id));


--
-- Name: sketch_links_to_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sketch_links_to_idx ON public.sketch_links USING btree (sketch_id, to_id);


--
-- Name: sketch_thoughts_sketch_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sketch_thoughts_sketch_idx ON public.sketch_thoughts USING btree (sketch_id, created_at, id);


--
-- Name: sketches_one_private_map_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sketches_one_private_map_idx ON public.sketches USING btree (workspace_id, created_by_user_id) WHERE (scope = 'private'::text);


--
-- Name: sketches_private_owner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sketches_private_owner_idx ON public.sketches USING btree (workspace_id, created_by_user_id) WHERE (scope = 'private'::text);


--
-- Name: sketches_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sketches_project_idx ON public.sketches USING btree (project_id) WHERE (project_id IS NOT NULL);


--
-- Name: sketches_workspace_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sketches_workspace_idx ON public.sketches USING btree (workspace_id, updated_at DESC, id);


--
-- Name: space_order_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX space_order_project_idx ON public.space_order USING btree (project_id);


--
-- Name: workspace_dek_wraps_workspace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_dek_wraps_workspace ON public.workspace_dek_wraps USING btree (workspace_id, key_version);


--
-- Name: workspace_holders_person; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspace_holders_person ON public.workspace_holders USING btree (workspace_id, user_id) WHERE (kind = 'password'::text);


--
-- Name: workspace_holders_recovery; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspace_holders_recovery ON public.workspace_holders USING btree (workspace_id) WHERE (kind = 'recovery'::text);


--
-- Name: workspace_holders_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_holders_user ON public.workspace_holders USING btree (user_id) WHERE (user_id IS NOT NULL);


--
-- Name: workspace_invites_pending_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_invites_pending_idx ON public.workspace_invites USING btree (workspace_id, created_at DESC) WHERE ((revoked_at IS NULL) AND (accepted_at IS NULL));


--
-- Name: workspace_members_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_members_user_idx ON public.workspace_members USING btree (user_id);


--
-- Name: workspace_unlocks_boot; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_unlocks_boot ON public.workspace_unlocks USING btree (boot_id);


--
-- Name: workspaces_company_workspace_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspaces_company_workspace_idx ON public.workspaces USING btree (company_workspace_id) WHERE (company_workspace_id IS NOT NULL);


--
-- Name: workspaces_creation; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspaces_creation ON public.workspaces USING btree (created_by, creation_id) WHERE (creation_id IS NOT NULL);


--
-- Name: workspaces_one_company; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspaces_one_company ON public.workspaces USING btree ((true)) WHERE company;


--
-- Name: job_common_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.job_pkey ATTACH PARTITION pgboss.job_common_pkey;


--
-- Name: queue_stats_20261120_name_captured_on_deferred_count_queued_idx; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.queue_stats_i1 ATTACH PARTITION pgboss.queue_stats_20261120_name_captured_on_deferred_count_queued_idx;


--
-- Name: queue_stats_20261120_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.queue_stats_pkey ATTACH PARTITION pgboss.queue_stats_20261120_pkey;


--
-- Name: queue_stats_20261121_name_captured_on_deferred_count_queued_idx; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.queue_stats_i1 ATTACH PARTITION pgboss.queue_stats_20261121_name_captured_on_deferred_count_queued_idx;


--
-- Name: queue_stats_20261121_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.queue_stats_pkey ATTACH PARTITION pgboss.queue_stats_20261121_pkey;


--
-- Name: idempotency_keys a_idempotency_scope_required; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_idempotency_scope_required BEFORE INSERT ON public.idempotency_keys FOR EACH ROW EXECUTE FUNCTION public.idempotency_scope_required();


--
-- Name: event_audience a_sealed_event_audience; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_event_audience BEFORE INSERT OR UPDATE ON public.event_audience FOR EACH ROW EXECUTE FUNCTION public.flux_event_audience_shape();


--
-- Name: events a_sealed_event_data; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_event_data BEFORE INSERT OR UPDATE ON public.events FOR EACH ROW EXECUTE FUNCTION public.flux_event_data_free();


--
-- Name: sealed_job_waits a_sealed_wait_ids_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_wait_ids_only BEFORE INSERT OR UPDATE ON public.sealed_job_waits FOR EACH ROW EXECUTE FUNCTION public.flux_sealed_wait_ids_only();


--
-- Name: agent_chat_file_text a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_chat_file_text FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_chat_messages a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_chat_messages FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_chat_reads a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_chat_reads FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_command_receipts a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_command_receipts FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_connections a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_connections FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_memory_items a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_memory_items FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_oauth_bindings a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_oauth_bindings FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_proposals a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_proposals FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_questions a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_questions FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_runtime_sessions a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_runtime_sessions FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_stops a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_stops FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agent_task_taking a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agent_task_taking FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: agents a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.agents FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: assistant_changes a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.assistant_changes FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: assistant_jobs a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.assistant_jobs FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: assistant_settings a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.assistant_settings FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: cowork_checkpoints a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.cowork_checkpoints FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: cowork_connection_slots a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.cowork_connection_slots FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: cowork_units a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.cowork_units FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: personal_runs a_sealed_workspace_no_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_no_ai BEFORE INSERT ON public.personal_runs FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_no_ai();


--
-- Name: github_bindings a_sealed_workspace_refused; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_refused BEFORE INSERT ON public.github_bindings FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_refused();


--
-- Name: github_rule_defaults a_sealed_workspace_refused; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_refused BEFORE INSERT ON public.github_rule_defaults FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_refused();


--
-- Name: github_task_links a_sealed_workspace_refused; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_refused BEFORE INSERT ON public.github_task_links FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_refused();


--
-- Name: github_task_rule_changes a_sealed_workspace_refused; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_refused BEFORE INSERT ON public.github_task_rule_changes FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_refused();


--
-- Name: github_task_rules a_sealed_workspace_refused; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_refused BEFORE INSERT ON public.github_task_rules FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_refused();


--
-- Name: space_icons a_sealed_workspace_refused; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a_sealed_workspace_refused BEFORE INSERT ON public.space_icons FOR EACH ROW EXECUTE FUNCTION public.sealed_workspace_refused();


--
-- Name: project_files agent_chat_file_gone; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER agent_chat_file_gone AFTER DELETE ON public.project_files FOR EACH ROW WHEN ((old.agent_id IS NOT NULL)) EXECUTE FUNCTION public.agent_chat_file_gone();


--
-- Name: project_files agent_chat_file_text_job; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER agent_chat_file_text_job AFTER UPDATE OF published_at ON public.project_files FOR EACH ROW WHEN (((old.published_at IS NULL) AND (new.published_at IS NOT NULL) AND (new.run_id IS NOT NULL))) EXECUTE FUNCTION public.agent_chat_file_text_job();


--
-- Name: agents agent_revoked_chat_files; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER agent_revoked_chat_files AFTER UPDATE OF revoked_at ON public.agents FOR EACH ROW WHEN (((old.revoked_at IS NULL) AND (new.revoked_at IS NOT NULL))) EXECUTE FUNCTION public.agent_revoked_chat_files();


--
-- Name: agent_runtime_bindings agent_runtime_auth_lifecycle; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER agent_runtime_auth_lifecycle AFTER UPDATE OF state ON public.agent_runtime_bindings FOR EACH ROW EXECUTE FUNCTION public.invalidate_runtime_auth_operations();


--
-- Name: agent_task_events agent_task_events_notify; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER agent_task_events_notify AFTER INSERT ON public.agent_task_events FOR EACH STATEMENT EXECUTE FUNCTION public.agent_task_events_notify();


--
-- Name: cowork_units ai_work_admission; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ai_work_admission BEFORE INSERT ON public.cowork_units FOR EACH ROW EXECUTE FUNCTION public.ai_work_admission();


--
-- Name: personal_runs ai_work_admission; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ai_work_admission BEFORE INSERT ON public.personal_runs FOR EACH ROW EXECUTE FUNCTION public.ai_work_admission();


--
-- Name: auth_accounts auth_account_password_changed; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER auth_account_password_changed BEFORE UPDATE OF password, password_version_expected ON public.auth_accounts FOR EACH ROW WHEN (((new.password_version_expected IS NOT NULL) OR (new.password IS DISTINCT FROM old.password))) EXECUTE FUNCTION public.auth_account_password_changed();


--
-- Name: auth_sessions auth_session_password_unchanged; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER auth_session_password_unchanged BEFORE INSERT ON public.auth_sessions FOR EACH ROW WHEN ((new.password_version_checked IS NOT NULL)) EXECUTE FUNCTION public.auth_session_password_unchanged();


--
-- Name: auth_sessions auth_sessions_revoke_live_admissions; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER auth_sessions_revoke_live_admissions AFTER DELETE ON public.auth_sessions FOR EACH ROW EXECUTE FUNCTION public.flux_revoke_live_admissions();


--
-- Name: agent_connections cowork_connection_deleted; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cowork_connection_deleted BEFORE DELETE ON public.agent_connections FOR EACH ROW EXECUTE FUNCTION public.cowork_stop_connection_units();


--
-- Name: agent_connections cowork_connection_revoked; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cowork_connection_revoked BEFORE UPDATE OF revoked_at ON public.agent_connections FOR EACH ROW EXECUTE FUNCTION public.cowork_stop_connection_units();


--
-- Name: dm_messages dm_messages_flat_thread; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dm_messages_flat_thread BEFORE INSERT OR UPDATE OF thread_root_id ON public.dm_messages FOR EACH ROW EXECUTE FUNCTION public.dm_messages_flat_thread();


--
-- Name: doc_live_archives doc_live_archive_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER doc_live_archive_immutable BEFORE UPDATE ON public.doc_live_archives FOR EACH ROW EXECUTE FUNCTION public.immutable_live_editing_record();


--
-- Name: doc_live_replicas doc_live_replica_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER doc_live_replica_immutable BEFORE UPDATE ON public.doc_live_replicas FOR EACH ROW EXECUTE FUNCTION public.live_replica_ownership_immutable();


--
-- Name: doc_live_snapshots doc_live_snapshot_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER doc_live_snapshot_immutable BEFORE UPDATE ON public.doc_live_snapshots FOR EACH ROW EXECUTE FUNCTION public.immutable_live_editing_record();


--
-- Name: doc_live_updates doc_live_update_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER doc_live_update_immutable BEFORE UPDATE ON public.doc_live_updates FOR EACH ROW EXECUTE FUNCTION public.immutable_live_editing_record();


--
-- Name: events events_assign_seq; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER events_assign_seq BEFORE INSERT ON public.events FOR EACH ROW EXECUTE FUNCTION public.flux_events_assign_seq();


--
-- Name: events events_notify; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER events_notify AFTER INSERT ON public.events FOR EACH ROW EXECUTE FUNCTION public.flux_events_notify();


--
-- Name: live_editing_intents live_editing_intent_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER live_editing_intent_immutable BEFORE DELETE OR UPDATE ON public.live_editing_intents FOR EACH ROW EXECUTE FUNCTION public.immutable_live_editing_record();


--
-- Name: live_sessions live_sessions_doc_in_space; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER live_sessions_doc_in_space BEFORE INSERT OR UPDATE OF doc_id, project_id, workspace_id ON public.live_sessions FOR EACH ROW EXECUTE FUNCTION public.live_session_doc_in_space();


--
-- Name: map_live_heads map_live_head_identity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER map_live_head_identity BEFORE UPDATE ON public.map_live_heads FOR EACH ROW EXECUTE FUNCTION public.guard_map_live_identity();


--
-- Name: map_live_journal map_live_journal_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER map_live_journal_immutable BEFORE UPDATE ON public.map_live_journal FOR EACH ROW EXECUTE FUNCTION public.immutable_live_editing_record();


--
-- Name: map_live_object_versions map_live_object_identity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER map_live_object_identity BEFORE UPDATE ON public.map_live_object_versions FOR EACH ROW EXECUTE FUNCTION public.guard_map_live_identity();


--
-- Name: map_live_undone map_live_undone_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER map_live_undone_immutable BEFORE UPDATE ON public.map_live_undone FOR EACH ROW EXECUTE FUNCTION public.immutable_live_editing_record();


--
-- Name: project_materials material_agent_doc_stays_doc; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER material_agent_doc_stays_doc BEFORE UPDATE OF kind ON public.project_materials FOR EACH ROW EXECUTE FUNCTION public.material_agent_doc_stays_doc();


--
-- Name: project_material_versions material_version_agent_doc_parent; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER material_version_agent_doc_parent BEFORE INSERT ON public.project_material_versions FOR EACH ROW EXECUTE FUNCTION public.material_version_agent_doc_parent();


--
-- Name: project_material_versions material_version_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER material_version_immutable BEFORE UPDATE ON public.project_material_versions FOR EACH ROW EXECUTE FUNCTION public.forbid_material_version_update();


--
-- Name: person_photos person_photo_garbage; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER person_photo_garbage AFTER DELETE ON public.person_photos FOR EACH ROW EXECUTE FUNCTION public.flux_person_photo_garbage();


--
-- Name: personal_runs personal_run_cites_end; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER personal_run_cites_end AFTER UPDATE OF status ON public.personal_runs FOR EACH ROW WHEN (((new.status <> ALL (ARRAY['queued'::text, 'reading'::text, 'dispatching'::text])) AND (old.status IS DISTINCT FROM new.status))) EXECUTE FUNCTION public.personal_run_cites_end();


--
-- Name: personal_run_pictures personal_run_pictures_gone; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER personal_run_pictures_gone AFTER DELETE ON public.personal_run_pictures FOR EACH ROW EXECUTE FUNCTION public.personal_run_pictures_gone();


--
-- Name: assistant_changes personal_run_private_texts_decided; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER personal_run_private_texts_decided AFTER UPDATE OF state ON public.assistant_changes FOR EACH ROW WHEN (((old.state = 'waiting'::text) AND (new.state <> 'waiting'::text) AND (new.operation = 'answer.picture.attach'::text))) EXECUTE FUNCTION public.personal_run_private_texts_decided();


--
-- Name: personal_runs personal_run_private_texts_end; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER personal_run_private_texts_end AFTER UPDATE OF status ON public.personal_runs FOR EACH ROW WHEN (((new.status <> ALL (ARRAY['queued'::text, 'reading'::text, 'dispatching'::text])) AND (old.status IS DISTINCT FROM new.status))) EXECUTE FUNCTION public.personal_run_private_texts_end();


--
-- Name: personal_runs personal_run_task_ended; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER personal_run_task_ended AFTER UPDATE OF status ON public.personal_runs FOR EACH ROW WHEN (((new.work_id IS NOT NULL) AND (old.status = ANY (ARRAY['queued'::text, 'reading'::text, 'dispatching'::text])) AND (new.status <> ALL (ARRAY['queued'::text, 'reading'::text, 'dispatching'::text])))) EXECUTE FUNCTION public.personal_run_task_ended();


--
-- Name: personal_runs personal_run_task_started; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER personal_run_task_started AFTER UPDATE OF status ON public.personal_runs FOR EACH ROW WHEN (((new.work_id IS NOT NULL) AND (new.kind = 'task'::text) AND (old.status = 'queued'::text) AND (new.status = 'reading'::text))) EXECUTE FUNCTION public.personal_run_task_started();


--
-- Name: projects project_ai_policy_create; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER project_ai_policy_create AFTER INSERT ON public.projects FOR EACH ROW EXECUTE FUNCTION public.project_ai_policy_create();


--
-- Name: project_ai_policies project_ai_policy_encrypted; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER project_ai_policy_encrypted BEFORE INSERT OR UPDATE ON public.project_ai_policies FOR EACH ROW EXECUTE FUNCTION public.project_ai_policy_encrypted();


--
-- Name: project_task_dependencies project_task_dependency_bound; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER project_task_dependency_bound BEFORE INSERT ON public.project_task_dependencies FOR EACH ROW EXECUTE FUNCTION public.flux_task_dependency_bound();


--
-- Name: project_task_plan_intents project_task_plan_intent_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER project_task_plan_intent_immutable BEFORE UPDATE ON public.project_task_plan_intents FOR EACH ROW EXECUTE FUNCTION public.flux_task_plan_intent_immutable();


--
-- Name: projects project_task_sequence_lifecycle; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER project_task_sequence_lifecycle AFTER INSERT OR DELETE ON public.projects FOR EACH ROW EXECUTE FUNCTION public.project_task_sequence_lifecycle();


--
-- Name: project_work_items project_work_number; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER project_work_number BEFORE INSERT OR UPDATE OF number, project_id ON public.project_work_items FOR EACH ROW EXECUTE FUNCTION public.project_work_number();


--
-- Name: search_documents search_change_log; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_change_log AFTER INSERT OR DELETE OR UPDATE ON public.search_documents FOR EACH ROW EXECUTE FUNCTION public.search_change_log();


--
-- Name: auth_users search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER UPDATE OF name ON public.auth_users FOR EACH ROW WHEN ((new.name IS DISTINCT FROM old.name)) EXECUTE FUNCTION public.search_index_user_name();


--
-- Name: dm_messages search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER INSERT OR DELETE OR UPDATE ON public.dm_messages FOR EACH ROW EXECUTE FUNCTION public.search_index_dm_message();


--
-- Name: project_decisions search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER INSERT OR DELETE OR UPDATE ON public.project_decisions FOR EACH ROW EXECUTE FUNCTION public.search_index_decision();


--
-- Name: project_material_versions search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER INSERT OR DELETE OR UPDATE ON public.project_material_versions FOR EACH ROW EXECUTE FUNCTION public.search_index_material_version();


--
-- Name: project_messages search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER INSERT OR DELETE OR UPDATE ON public.project_messages FOR EACH ROW EXECUTE FUNCTION public.search_index_message();


--
-- Name: project_work_items search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER INSERT OR DELETE OR UPDATE ON public.project_work_items FOR EACH ROW EXECUTE FUNCTION public.search_index_work();


--
-- Name: projects search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER INSERT OR DELETE OR UPDATE OF name, visibility ON public.projects FOR EACH ROW EXECUTE FUNCTION public.search_index_project();


--
-- Name: sketch_thoughts search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER INSERT OR DELETE OR UPDATE ON public.sketch_thoughts FOR EACH ROW EXECUTE FUNCTION public.search_index_thought();


--
-- Name: sketches search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER INSERT OR DELETE OR UPDATE ON public.sketches FOR EACH ROW EXECUTE FUNCTION public.search_index_sketch();


--
-- Name: workspace_members search_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index AFTER INSERT OR DELETE OR UPDATE ON public.workspace_members FOR EACH ROW EXECUTE FUNCTION public.search_index_member();


--
-- Name: project_files search_index_file; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_index_file AFTER UPDATE OF published_at ON public.project_files FOR EACH ROW WHEN (((old.published_at IS NULL) AND (new.published_at IS NOT NULL) AND (new.message_id IS NOT NULL))) EXECUTE FUNCTION public.search_index_file();


--
-- Name: project_files search_unindex_file; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_unindex_file AFTER DELETE ON public.project_files FOR EACH ROW EXECUTE FUNCTION public.search_unindex_file();


--
-- Name: search_documents search_vector_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_vector_insert AFTER INSERT ON public.search_documents FOR EACH ROW EXECUTE FUNCTION public.search_vector_sync();


--
-- Name: project_ai_policies search_vector_space_ai; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_vector_space_ai AFTER UPDATE OF state ON public.project_ai_policies FOR EACH ROW WHEN ((old.state IS DISTINCT FROM new.state)) EXECUTE FUNCTION public.search_vector_space_ai();


--
-- Name: search_documents search_vector_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER search_vector_update AFTER UPDATE ON public.search_documents FOR EACH ROW WHEN (((old.title IS DISTINCT FROM new.title) OR (old.body IS DISTINCT FROM new.body) OR (old.sealed IS DISTINCT FROM new.sealed) OR (old.project_id IS DISTINCT FROM new.project_id) OR (old.kind IS DISTINCT FROM new.kind))) EXECUTE FUNCTION public.search_vector_sync();


--
-- Name: space_icons space_icon_garbage; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER space_icon_garbage AFTER DELETE ON public.space_icons FOR EACH ROW EXECUTE FUNCTION public.flux_space_icon_garbage();


--
-- Name: project_work_items task_creation_history_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER task_creation_history_guard BEFORE UPDATE ON public.project_work_items FOR EACH ROW EXECUTE FUNCTION public.flux_guard_task_creation_history();


--
-- Name: task_creation_undo_receipts task_creation_receipt_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER task_creation_receipt_guard BEFORE DELETE OR UPDATE ON public.task_creation_undo_receipts FOR EACH ROW EXECUTE FUNCTION public.flux_guard_task_creation_receipt();


--
-- Name: workspaces workspace_company_link_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER workspace_company_link_guard BEFORE INSERT OR UPDATE OF company_workspace_id ON public.workspaces FOR EACH ROW EXECUTE FUNCTION public.workspace_company_link_guard();


--
-- Name: workspaces workspace_encryption_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER workspace_encryption_immutable BEFORE UPDATE OF encrypted ON public.workspaces FOR EACH ROW EXECUTE FUNCTION public.workspace_encryption_immutable();


--
-- Name: workspace_holders workspace_holder_delete_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER workspace_holder_delete_guard BEFORE DELETE ON public.workspace_holders FOR EACH ROW EXECUTE FUNCTION public.workspace_holder_delete_guard();


--
-- Name: workspace_holders workspace_holder_deleted; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER workspace_holder_deleted AFTER DELETE ON public.workspace_holders FOR EACH ROW EXECUTE FUNCTION public.workspace_holder_deleted();


--
-- Name: workspace_members workspace_manager_lost; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER workspace_manager_lost AFTER DELETE OR UPDATE OF role ON public.workspace_members FOR EACH ROW EXECUTE FUNCTION public.workspace_manager_lost();


--
-- Name: notifications z_notification_content_free; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_notification_content_free BEFORE INSERT OR UPDATE ON public.notifications FOR EACH ROW EXECUTE FUNCTION public.flux_notification_content_free();


--
-- Name: dm_messages z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.dm_messages FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'body', 'request_fingerprint');


--
-- Name: dms z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.dms FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'title');


--
-- Name: doc_live_archives z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.doc_live_archives FOR EACH ROW EXECUTE FUNCTION public.flux_sealed_backstop('via:doc_id:project_materials:id', 'body', 'codec_state', 'hash');


--
-- Name: doc_live_heads z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.doc_live_heads FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'body', 'codec_state', 'hash');


--
-- Name: doc_live_snapshots z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.doc_live_snapshots FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'hash');


--
-- Name: doc_live_updates z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.doc_live_updates FOR EACH ROW EXECUTE FUNCTION public.flux_sealed_backstop('via:doc_id:project_materials:id', 'bytes', 'ledger', 'fingerprint');


--
-- Name: idempotency_keys z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.idempotency_keys FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'response_body', 'request_hash');


--
-- Name: live_editing_intents z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.live_editing_intents FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'receipt', 'fingerprint');


--
-- Name: map_live_journal z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.map_live_journal FOR EACH ROW EXECUTE FUNCTION public.flux_sealed_backstop('via:sketch_id:sketches:id', 'change', 'fingerprint');


--
-- Name: native_command_receipts z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.native_command_receipts FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'request_fingerprint');


--
-- Name: project_decision_resumptions z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.project_decision_resumptions FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'blocker');


--
-- Name: project_decisions z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.project_decisions FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'title', 'rationale');


--
-- Name: project_files z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.project_files FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'name', 'sha256');


--
-- Name: project_material_versions z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.project_material_versions FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'title', 'body', 'url', 'reason', 'request_fingerprint');


--
-- Name: project_materials z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.project_materials FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'request_fingerprint');


--
-- Name: project_messages z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.project_messages FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'body', 'request_fingerprint');


--
-- Name: project_task_activity z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.project_task_activity FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'detail');


--
-- Name: project_task_plan_intents z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.project_task_plan_intents FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'creation_fingerprint');


--
-- Name: project_task_updates z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.project_task_updates FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'reason');


--
-- Name: project_work_items z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.project_work_items FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'title', 'outcome', 'blocker', 'criteria', 'creation_baseline', 'request_fingerprint', 'came_of_it');


--
-- Name: projects z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.projects FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'name');


--
-- Name: sketch_links z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.sketch_links FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'label');


--
-- Name: sketch_thoughts z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.sketch_thoughts FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'text');


--
-- Name: sketches z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.sketches FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'title');


--
-- Name: task_creation_undo_receipts z_sealed_backstop; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER z_sealed_backstop BEFORE INSERT OR UPDATE ON public.task_creation_undo_receipts FOR EACH ROW WHEN (public.workspace_sealed(new.workspace_id)) EXECUTE FUNCTION public.flux_sealed_backstop('workspace_id', 'request_fingerprint');


--
-- Name: job_common dlq_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job_common
    ADD CONSTRAINT dlq_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: job_common q_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job_common
    ADD CONSTRAINT q_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: queue queue_dead_letter_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue
    ADD CONSTRAINT queue_dead_letter_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue(name);


--
-- Name: schedule schedule_name_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.schedule
    ADD CONSTRAINT schedule_name_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE CASCADE;


--
-- Name: subscription subscription_name_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.subscription
    ADD CONSTRAINT subscription_name_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE CASCADE;


--
-- Name: agent_chat_file_text agent_chat_file_text_file_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat_file_text
    ADD CONSTRAINT agent_chat_file_text_file_fkey FOREIGN KEY (file_id) REFERENCES public.project_files(id) ON DELETE CASCADE;


--
-- Name: agent_chat_messages agent_chat_messages_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat_messages
    ADD CONSTRAINT agent_chat_messages_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.assistant_settings(agent_id) ON DELETE CASCADE;


--
-- Name: agent_chat_messages agent_chat_messages_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat_messages
    ADD CONSTRAINT agent_chat_messages_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agent_chat_messages agent_chat_messages_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat_messages
    ADD CONSTRAINT agent_chat_messages_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.personal_runs(id) ON DELETE CASCADE;


--
-- Name: agent_chat_reads agent_chat_reads_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat_reads
    ADD CONSTRAINT agent_chat_reads_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.assistant_settings(agent_id) ON DELETE CASCADE;


--
-- Name: agent_command_receipts agent_command_receipts_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_command_receipts
    ADD CONSTRAINT agent_command_receipts_binding_id_fkey FOREIGN KEY (binding_id) REFERENCES public.agent_oauth_bindings(id);


--
-- Name: agent_command_receipts agent_command_receipts_connection_id_runtime_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_command_receipts
    ADD CONSTRAINT agent_command_receipts_connection_id_runtime_session_id_fkey FOREIGN KEY (connection_id, runtime_session_id) REFERENCES public.agent_runtime_sessions(connection_id, id);


--
-- Name: agent_command_receipts agent_command_receipts_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_command_receipts
    ADD CONSTRAINT agent_command_receipts_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: agent_connections agent_connections_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_connections
    ADD CONSTRAINT agent_connections_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agent_connections agent_connections_workspace_id_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_connections
    ADD CONSTRAINT agent_connections_workspace_id_agent_id_fkey FOREIGN KEY (workspace_id, agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: agent_memory_items agent_memory_items_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_memory_items
    ADD CONSTRAINT agent_memory_items_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.assistant_settings(agent_id) ON DELETE CASCADE;


--
-- Name: agent_memory_items agent_memory_items_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_memory_items
    ADD CONSTRAINT agent_memory_items_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agent_oauth_bindings agent_oauth_bindings_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_oauth_bindings
    ADD CONSTRAINT agent_oauth_bindings_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.oauth_client(client_id);


--
-- Name: agent_oauth_bindings agent_oauth_bindings_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_oauth_bindings
    ADD CONSTRAINT agent_oauth_bindings_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.agent_connections(id);


--
-- Name: agent_oauth_bindings agent_oauth_bindings_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_oauth_bindings
    ADD CONSTRAINT agent_oauth_bindings_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id);


--
-- Name: agent_playbook_acknowledgments agent_playbook_acknowledgments_runtime_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_playbook_acknowledgments
    ADD CONSTRAINT agent_playbook_acknowledgments_runtime_session_id_fkey FOREIGN KEY (runtime_session_id) REFERENCES public.agent_runtime_sessions(id) ON DELETE CASCADE;


--
-- Name: agent_proposals agent_proposals_dismissed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_proposals
    ADD CONSTRAINT agent_proposals_dismissed_by_fkey FOREIGN KEY (dismissed_by) REFERENCES public.auth_users(id);


--
-- Name: agent_proposals agent_proposals_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_proposals
    ADD CONSTRAINT agent_proposals_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id);


--
-- Name: agent_proposals agent_proposals_workspace_id_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_proposals
    ADD CONSTRAINT agent_proposals_workspace_id_agent_id_fkey FOREIGN KEY (workspace_id, agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: agent_proposals agent_proposals_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_proposals
    ADD CONSTRAINT agent_proposals_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: agent_proposals agent_proposals_workspace_id_project_id_source_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_proposals
    ADD CONSTRAINT agent_proposals_workspace_id_project_id_source_material_id_fkey FOREIGN KEY (workspace_id, project_id, source_material_id, source_material_version) REFERENCES public.project_material_versions(workspace_id, project_id, material_id, version);


--
-- Name: agent_questions agent_questions_answered_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_questions
    ADD CONSTRAINT agent_questions_answered_by_fkey FOREIGN KEY (answered_by) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: agent_questions agent_questions_asked_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_questions
    ADD CONSTRAINT agent_questions_asked_user_id_fkey FOREIGN KEY (asked_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agent_questions agent_questions_workspace_id_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_questions
    ADD CONSTRAINT agent_questions_workspace_id_agent_id_fkey FOREIGN KEY (workspace_id, agent_id) REFERENCES public.agents(workspace_id, id) ON DELETE CASCADE;


--
-- Name: agent_questions agent_questions_workspace_id_project_id_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_questions
    ADD CONSTRAINT agent_questions_workspace_id_project_id_conversation_id_fkey FOREIGN KEY (workspace_id, project_id, conversation_id) REFERENCES public.project_conversations(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: agent_questions agent_questions_workspace_id_project_id_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_questions
    ADD CONSTRAINT agent_questions_workspace_id_project_id_message_id_fkey FOREIGN KEY (workspace_id, project_id, message_id) REFERENCES public.project_messages(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: agent_runtime_auth_operations agent_runtime_auth_operations_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_auth_operations
    ADD CONSTRAINT agent_runtime_auth_operations_binding_id_fkey FOREIGN KEY (binding_id) REFERENCES public.agent_runtime_bindings(id) ON DELETE CASCADE;


--
-- Name: agent_runtime_auth_operations agent_runtime_auth_operations_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_auth_operations
    ADD CONSTRAINT agent_runtime_auth_operations_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agent_runtime_bindings agent_runtime_bindings_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_bindings
    ADD CONSTRAINT agent_runtime_bindings_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agent_runtime_bindings agent_runtime_bindings_slot_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_bindings
    ADD CONSTRAINT agent_runtime_bindings_slot_fkey FOREIGN KEY (slot) REFERENCES public.agent_runtime_slots(slot);


--
-- Name: agent_runtime_client_history agent_runtime_client_history_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_client_history
    ADD CONSTRAINT agent_runtime_client_history_binding_id_fkey FOREIGN KEY (binding_id) REFERENCES public.agent_runtime_bindings(id) ON DELETE CASCADE;


--
-- Name: agent_runtime_connection_models agent_runtime_connection_models_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_connection_models
    ADD CONSTRAINT agent_runtime_connection_models_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.agent_runtime_connections(id) ON DELETE CASCADE;


--
-- Name: agent_runtime_connections agent_runtime_connections_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_connections
    ADD CONSTRAINT agent_runtime_connections_binding_id_fkey FOREIGN KEY (binding_id) REFERENCES public.agent_runtime_bindings(id) ON DELETE CASCADE;


--
-- Name: agent_runtime_connections agent_runtime_connections_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_connections
    ADD CONSTRAINT agent_runtime_connections_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agent_runtime_console_nonces agent_runtime_console_nonces_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_console_nonces
    ADD CONSTRAINT agent_runtime_console_nonces_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agent_runtime_sessions agent_runtime_sessions_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_sessions
    ADD CONSTRAINT agent_runtime_sessions_binding_id_fkey FOREIGN KEY (binding_id) REFERENCES public.agent_oauth_bindings(id);


--
-- Name: agent_runtime_sessions agent_runtime_sessions_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_sessions
    ADD CONSTRAINT agent_runtime_sessions_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id);


--
-- Name: agent_runtime_sessions agent_runtime_sessions_workspace_id_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_sessions
    ADD CONSTRAINT agent_runtime_sessions_workspace_id_agent_id_fkey FOREIGN KEY (workspace_id, agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: agent_runtime_sessions agent_runtime_sessions_workspace_id_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_sessions
    ADD CONSTRAINT agent_runtime_sessions_workspace_id_connection_id_fkey FOREIGN KEY (workspace_id, connection_id) REFERENCES public.agent_connections(workspace_id, id);


--
-- Name: agent_stops agent_stops_stopped_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_stops
    ADD CONSTRAINT agent_stops_stopped_by_fkey FOREIGN KEY (stopped_by) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agent_stops agent_stops_workspace_id_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_stops
    ADD CONSTRAINT agent_stops_workspace_id_agent_id_fkey FOREIGN KEY (workspace_id, agent_id) REFERENCES public.agents(workspace_id, id) ON DELETE CASCADE;


--
-- Name: agent_stops agent_stops_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_stops
    ADD CONSTRAINT agent_stops_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: agent_stops agent_stops_workspace_id_project_id_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_stops
    ADD CONSTRAINT agent_stops_workspace_id_project_id_task_id_fkey FOREIGN KEY (workspace_id, project_id, task_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: agent_task_events agent_task_events_run_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_task_events
    ADD CONSTRAINT agent_task_events_run_fkey FOREIGN KEY (run_id) REFERENCES public.personal_runs(id) ON DELETE CASCADE;


--
-- Name: agent_task_events agent_task_events_work_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_task_events
    ADD CONSTRAINT agent_task_events_work_fkey FOREIGN KEY (work_id) REFERENCES public.project_work_items(id) ON DELETE CASCADE;


--
-- Name: agent_task_taking agent_task_taking_agent_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_task_taking
    ADD CONSTRAINT agent_task_taking_agent_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_task_taking agent_task_taking_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_task_taking
    ADD CONSTRAINT agent_task_taking_owner_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agents agents_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: agents agents_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: api_key_checks api_key_checks_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key_checks
    ADD CONSTRAINT api_key_checks_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.background_compute_connections(id) ON DELETE CASCADE;


--
-- Name: assistant_background_notes assistant_background_notes_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_background_notes
    ADD CONSTRAINT assistant_background_notes_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: assistant_changes assistant_changes_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.agent_connections(id) ON DELETE CASCADE;


--
-- Name: assistant_changes assistant_changes_conversation_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_conversation_fk FOREIGN KEY (workspace_id, project_id, conversation_id) REFERENCES public.project_conversations(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: assistant_changes assistant_changes_decided_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_decided_by_fkey FOREIGN KEY (decided_by) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: assistant_changes assistant_changes_other_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_other_user_id_fkey FOREIGN KEY (other_user_id) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: assistant_changes assistant_changes_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: assistant_changes assistant_changes_told_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_told_user_id_fkey FOREIGN KEY (told_user_id) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: assistant_changes assistant_changes_workspace_id_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_workspace_id_agent_id_fkey FOREIGN KEY (workspace_id, agent_id) REFERENCES public.agents(workspace_id, id) ON DELETE CASCADE;


--
-- Name: assistant_changes assistant_changes_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: assistant_changes assistant_changes_workspace_id_project_id_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_changes
    ADD CONSTRAINT assistant_changes_workspace_id_project_id_run_id_fkey FOREIGN KEY (workspace_id, project_id, run_id) REFERENCES public.personal_runs(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: assistant_job_runs assistant_job_runs_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_job_runs
    ADD CONSTRAINT assistant_job_runs_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.assistant_jobs(id) ON DELETE CASCADE;


--
-- Name: assistant_job_runs assistant_job_runs_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_job_runs
    ADD CONSTRAINT assistant_job_runs_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: assistant_job_runs assistant_job_runs_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_job_runs
    ADD CONSTRAINT assistant_job_runs_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.personal_runs(id) ON DELETE SET NULL;


--
-- Name: assistant_jobs assistant_jobs_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_jobs
    ADD CONSTRAINT assistant_jobs_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.assistant_settings(agent_id) ON DELETE CASCADE;


--
-- Name: assistant_jobs assistant_jobs_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_jobs
    ADD CONSTRAINT assistant_jobs_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: assistant_jobs assistant_jobs_prepared_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_jobs
    ADD CONSTRAINT assistant_jobs_prepared_run_id_fkey FOREIGN KEY (prepared_run_id) REFERENCES public.personal_runs(id) ON DELETE SET NULL;


--
-- Name: assistant_settings assistant_settings_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_settings
    ADD CONSTRAINT assistant_settings_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: assistant_settings assistant_settings_workspace_id_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_settings
    ADD CONSTRAINT assistant_settings_workspace_id_agent_id_fkey FOREIGN KEY (workspace_id, agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: assistant_settings assistant_settings_workspace_id_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_settings
    ADD CONSTRAINT assistant_settings_workspace_id_connection_id_fkey FOREIGN KEY (workspace_id, connection_id) REFERENCES public.agent_connections(workspace_id, id) ON DELETE CASCADE;


--
-- Name: assistant_settings assistant_settings_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_settings
    ADD CONSTRAINT assistant_settings_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: auth_accounts auth_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_accounts
    ADD CONSTRAINT auth_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: auth_idp_standing auth_idp_standing_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_idp_standing
    ADD CONSTRAINT auth_idp_standing_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: auth_link_intents auth_link_intents_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_link_intents
    ADD CONSTRAINT auth_link_intents_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: auth_session_identities auth_session_identities_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_session_identities
    ADD CONSTRAINT auth_session_identities_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id) ON DELETE CASCADE;


--
-- Name: auth_sessions auth_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: background_compute_connections background_compute_connections_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.background_compute_connections
    ADD CONSTRAINT background_compute_connections_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: cowork_checkpoints cowork_checkpoints_workspace_id_project_id_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_checkpoints
    ADD CONSTRAINT cowork_checkpoints_workspace_id_project_id_unit_id_fkey FOREIGN KEY (workspace_id, project_id, unit_id) REFERENCES public.cowork_units(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: cowork_connection_slots cowork_connection_slots_workspace_id_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_connection_slots
    ADD CONSTRAINT cowork_connection_slots_workspace_id_connection_id_fkey FOREIGN KEY (workspace_id, connection_id) REFERENCES public.agent_connections(workspace_id, id) ON DELETE CASCADE;


--
-- Name: cowork_units cowork_units_checkpoint_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_units
    ADD CONSTRAINT cowork_units_checkpoint_fk FOREIGN KEY (workspace_id, project_id, id, checkpoint_id) REFERENCES public.cowork_checkpoints(workspace_id, project_id, unit_id, id);


--
-- Name: cowork_units cowork_units_workspace_id_project_id_lineage_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_units
    ADD CONSTRAINT cowork_units_workspace_id_project_id_lineage_work_id_fkey FOREIGN KEY (workspace_id, project_id, lineage_work_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: cowork_units cowork_units_workspace_id_project_id_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cowork_units
    ADD CONSTRAINT cowork_units_workspace_id_project_id_work_id_fkey FOREIGN KEY (workspace_id, project_id, work_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: dm_message_observations dm_message_observations_dm_id_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_message_observations
    ADD CONSTRAINT dm_message_observations_dm_id_message_id_fkey FOREIGN KEY (dm_id, message_id) REFERENCES public.dm_messages(dm_id, id) ON DELETE CASCADE;


--
-- Name: dm_message_observations dm_message_observations_viewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_message_observations
    ADD CONSTRAINT dm_message_observations_viewer_id_fkey FOREIGN KEY (viewer_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: dm_message_observations dm_message_observations_workspace_id_dm_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_message_observations
    ADD CONSTRAINT dm_message_observations_workspace_id_dm_id_fkey FOREIGN KEY (workspace_id, dm_id) REFERENCES public.dms(workspace_id, id) ON DELETE CASCADE;


--
-- Name: dm_messages dm_messages_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_messages
    ADD CONSTRAINT dm_messages_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.auth_users(id);


--
-- Name: dm_messages dm_messages_thread_root_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_messages
    ADD CONSTRAINT dm_messages_thread_root_fk FOREIGN KEY (dm_id, thread_root_id) REFERENCES public.dm_messages(dm_id, id) ON DELETE CASCADE;


--
-- Name: dm_messages dm_messages_workspace_id_dm_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_messages
    ADD CONSTRAINT dm_messages_workspace_id_dm_id_fkey FOREIGN KEY (workspace_id, dm_id) REFERENCES public.dms(workspace_id, id) ON DELETE CASCADE;


--
-- Name: dm_participants dm_participants_workspace_id_dm_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_participants
    ADD CONSTRAINT dm_participants_workspace_id_dm_id_fkey FOREIGN KEY (workspace_id, dm_id) REFERENCES public.dms(workspace_id, id) ON DELETE CASCADE;


--
-- Name: dm_participants dm_participants_workspace_id_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_participants
    ADD CONSTRAINT dm_participants_workspace_id_user_id_fkey FOREIGN KEY (workspace_id, user_id) REFERENCES public.workspace_members(workspace_id, user_id) ON DELETE CASCADE;


--
-- Name: dm_reads dm_reads_dm_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_reads
    ADD CONSTRAINT dm_reads_dm_fkey FOREIGN KEY (workspace_id, dm_id) REFERENCES public.dms(workspace_id, id) ON DELETE CASCADE;


--
-- Name: dm_reads dm_reads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dm_reads
    ADD CONSTRAINT dm_reads_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: dms dms_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dms
    ADD CONSTRAINT dms_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.auth_users(id);


--
-- Name: dms dms_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dms
    ADD CONSTRAINT dms_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: doc_live_archives doc_live_archives_doc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_archives
    ADD CONSTRAINT doc_live_archives_doc_id_fkey FOREIGN KEY (doc_id) REFERENCES public.project_materials(id) ON DELETE CASCADE;


--
-- Name: doc_live_heads doc_live_heads_workspace_id_project_id_doc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_heads
    ADD CONSTRAINT doc_live_heads_workspace_id_project_id_doc_id_fkey FOREIGN KEY (workspace_id, project_id, doc_id) REFERENCES public.project_materials(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: doc_live_heads doc_live_heads_workspace_id_project_id_doc_id_saved_versio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_heads
    ADD CONSTRAINT doc_live_heads_workspace_id_project_id_doc_id_saved_versio_fkey FOREIGN KEY (workspace_id, project_id, doc_id, saved_version) REFERENCES public.project_material_versions(workspace_id, project_id, material_id, version);


--
-- Name: doc_live_presence doc_live_presence_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_presence
    ADD CONSTRAINT doc_live_presence_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.auth_users(id);


--
-- Name: doc_live_presence doc_live_presence_doc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_presence
    ADD CONSTRAINT doc_live_presence_doc_id_fkey FOREIGN KEY (doc_id) REFERENCES public.project_materials(id) ON DELETE CASCADE;


--
-- Name: doc_live_presence doc_live_presence_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_presence
    ADD CONSTRAINT doc_live_presence_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id) ON DELETE CASCADE;


--
-- Name: doc_live_replicas doc_live_replicas_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_replicas
    ADD CONSTRAINT doc_live_replicas_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.auth_users(id);


--
-- Name: doc_live_replicas doc_live_replicas_doc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_replicas
    ADD CONSTRAINT doc_live_replicas_doc_id_fkey FOREIGN KEY (doc_id) REFERENCES public.project_materials(id) ON DELETE CASCADE;


--
-- Name: doc_live_snapshots doc_live_snapshots_workspace_id_project_id_doc_id_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_snapshots
    ADD CONSTRAINT doc_live_snapshots_workspace_id_project_id_doc_id_version_fkey FOREIGN KEY (workspace_id, project_id, doc_id, version) REFERENCES public.project_material_versions(workspace_id, project_id, material_id, version) ON DELETE CASCADE;


--
-- Name: doc_live_updates doc_live_updates_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_updates
    ADD CONSTRAINT doc_live_updates_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.auth_users(id);


--
-- Name: doc_live_updates doc_live_updates_doc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_live_updates
    ADD CONSTRAINT doc_live_updates_doc_id_fkey FOREIGN KEY (doc_id) REFERENCES public.project_materials(id) ON DELETE CASCADE;


--
-- Name: encrypted_workspace_creations encrypted_workspace_creations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encrypted_workspace_creations
    ADD CONSTRAINT encrypted_workspace_creations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: event_audience event_audience_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_audience
    ADD CONSTRAINT event_audience_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: events events_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: file_text_jobs file_text_jobs_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_text_jobs
    ADD CONSTRAINT file_text_jobs_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.project_files(id) ON DELETE CASCADE;


--
-- Name: github_bindings github_bindings_author_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_bindings
    ADD CONSTRAINT github_bindings_author_user_id_fkey FOREIGN KEY (author_user_id) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: github_bindings github_bindings_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_bindings
    ADD CONSTRAINT github_bindings_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: github_credentials github_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_credentials
    ADD CONSTRAINT github_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: github_deliveries github_deliveries_target_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_deliveries
    ADD CONSTRAINT github_deliveries_target_binding_id_fkey FOREIGN KEY (target_binding_id) REFERENCES public.github_bindings(id) ON DELETE SET NULL;


--
-- Name: github_oauth_flows github_oauth_flows_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_oauth_flows
    ADD CONSTRAINT github_oauth_flows_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id) ON DELETE CASCADE;


--
-- Name: github_oauth_flows github_oauth_flows_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_oauth_flows
    ADD CONSTRAINT github_oauth_flows_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: github_oauth_flows github_oauth_flows_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_oauth_flows
    ADD CONSTRAINT github_oauth_flows_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: github_processing github_processing_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_processing
    ADD CONSTRAINT github_processing_binding_id_fkey FOREIGN KEY (binding_id) REFERENCES public.github_bindings(id) ON DELETE CASCADE;


--
-- Name: github_processing github_processing_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_processing
    ADD CONSTRAINT github_processing_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.github_deliveries(id) ON DELETE CASCADE;


--
-- Name: github_rule_defaults github_rule_defaults_set_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_rule_defaults
    ADD CONSTRAINT github_rule_defaults_set_by_user_id_fkey FOREIGN KEY (set_by_user_id) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: github_rule_defaults github_rule_defaults_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_rule_defaults
    ADD CONSTRAINT github_rule_defaults_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: github_task_links github_task_links_workspace_id_project_id_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_links
    ADD CONSTRAINT github_task_links_workspace_id_project_id_binding_id_fkey FOREIGN KEY (workspace_id, project_id, binding_id) REFERENCES public.github_bindings(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: github_task_links github_task_links_workspace_id_project_id_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_links
    ADD CONSTRAINT github_task_links_workspace_id_project_id_task_id_fkey FOREIGN KEY (workspace_id, project_id, task_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: github_task_rule_changes github_task_rule_changes_author_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_rule_changes
    ADD CONSTRAINT github_task_rule_changes_author_user_id_fkey FOREIGN KEY (author_user_id) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: github_task_rule_changes github_task_rule_changes_workspace_id_project_id_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_rule_changes
    ADD CONSTRAINT github_task_rule_changes_workspace_id_project_id_task_id_fkey FOREIGN KEY (workspace_id, project_id, task_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: github_task_rules github_task_rules_author_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_rules
    ADD CONSTRAINT github_task_rules_author_user_id_fkey FOREIGN KEY (author_user_id) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: github_task_rules github_task_rules_workspace_id_project_id_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_task_rules
    ADD CONSTRAINT github_task_rules_workspace_id_project_id_task_id_fkey FOREIGN KEY (workspace_id, project_id, task_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: idempotency_keys idempotency_keys_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: live_access_fences live_access_fences_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_access_fences
    ADD CONSTRAINT live_access_fences_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: live_access_fences live_access_fences_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_access_fences
    ADD CONSTRAINT live_access_fences_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: live_admissions live_admissions_live_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_admissions
    ADD CONSTRAINT live_admissions_live_session_id_fkey FOREIGN KEY (live_session_id) REFERENCES public.live_sessions(id) ON DELETE CASCADE;


--
-- Name: live_admissions live_admissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_admissions
    ADD CONSTRAINT live_admissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: live_editing_intents live_editing_intents_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_editing_intents
    ADD CONSTRAINT live_editing_intents_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.auth_users(id);


--
-- Name: live_invitations live_invitations_inviter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_invitations
    ADD CONSTRAINT live_invitations_inviter_id_fkey FOREIGN KEY (inviter_id) REFERENCES public.auth_users(id);


--
-- Name: live_invitations live_invitations_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_invitations
    ADD CONSTRAINT live_invitations_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.auth_users(id);


--
-- Name: live_invitations live_invitations_workspace_id_project_id_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_invitations
    ADD CONSTRAINT live_invitations_workspace_id_project_id_session_id_fkey FOREIGN KEY (workspace_id, project_id, session_id) REFERENCES public.live_sessions(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: live_presentations live_presentations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_presentations
    ADD CONSTRAINT live_presentations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.auth_users(id);


--
-- Name: live_presentations live_presentations_workspace_id_project_id_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_presentations
    ADD CONSTRAINT live_presentations_workspace_id_project_id_session_id_fkey FOREIGN KEY (workspace_id, project_id, session_id) REFERENCES public.live_sessions(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: live_sessions live_sessions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.auth_users(id);


--
-- Name: live_sessions live_sessions_workspace_id_project_id_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_workspace_id_project_id_conversation_id_fkey FOREIGN KEY (workspace_id, project_id, conversation_id) REFERENCES public.project_conversations(workspace_id, project_id, id);


--
-- Name: live_sessions live_sessions_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: live_sessions live_sessions_workspace_id_project_id_sketch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_workspace_id_project_id_sketch_id_fkey FOREIGN KEY (workspace_id, project_id, sketch_id) REFERENCES public.sketches(workspace_id, project_id, id);


--
-- Name: live_sessions live_sessions_workspace_id_project_id_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_workspace_id_project_id_work_id_fkey FOREIGN KEY (workspace_id, project_id, work_id) REFERENCES public.project_work_items(workspace_id, project_id, id);


--
-- Name: live_webhook_events live_webhook_events_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_webhook_events
    ADD CONSTRAINT live_webhook_events_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.live_sessions(id) ON DELETE CASCADE;


--
-- Name: map_live_gestures map_live_gestures_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_gestures
    ADD CONSTRAINT map_live_gestures_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.auth_users(id);


--
-- Name: map_live_gestures map_live_gestures_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_gestures
    ADD CONSTRAINT map_live_gestures_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id) ON DELETE CASCADE;


--
-- Name: map_live_gestures map_live_gestures_sketch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_gestures
    ADD CONSTRAINT map_live_gestures_sketch_id_fkey FOREIGN KEY (sketch_id) REFERENCES public.sketches(id) ON DELETE CASCADE;


--
-- Name: map_live_gestures map_live_gestures_sketch_id_generation_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_gestures
    ADD CONSTRAINT map_live_gestures_sketch_id_generation_fkey FOREIGN KEY (sketch_id, generation) REFERENCES public.map_live_heads(sketch_id, generation) ON DELETE CASCADE;


--
-- Name: map_live_heads map_live_heads_sketch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_heads
    ADD CONSTRAINT map_live_heads_sketch_id_fkey FOREIGN KEY (sketch_id) REFERENCES public.sketches(id) ON DELETE CASCADE;


--
-- Name: map_live_heads map_live_heads_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_heads
    ADD CONSTRAINT map_live_heads_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- Name: map_live_heads map_live_heads_workspace_id_sketch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_heads
    ADD CONSTRAINT map_live_heads_workspace_id_sketch_id_fkey FOREIGN KEY (workspace_id, sketch_id) REFERENCES public.sketches(workspace_id, id) ON DELETE CASCADE;


--
-- Name: map_live_journal map_live_journal_sketch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_journal
    ADD CONSTRAINT map_live_journal_sketch_id_fkey FOREIGN KEY (sketch_id) REFERENCES public.sketches(id) ON DELETE CASCADE;


--
-- Name: map_live_object_versions map_live_object_versions_sketch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_object_versions
    ADD CONSTRAINT map_live_object_versions_sketch_id_fkey FOREIGN KEY (sketch_id) REFERENCES public.sketches(id) ON DELETE CASCADE;


--
-- Name: map_live_presence map_live_presence_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_presence
    ADD CONSTRAINT map_live_presence_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.auth_users(id);


--
-- Name: map_live_presence map_live_presence_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_presence
    ADD CONSTRAINT map_live_presence_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id) ON DELETE CASCADE;


--
-- Name: map_live_presence map_live_presence_sketch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_presence
    ADD CONSTRAINT map_live_presence_sketch_id_fkey FOREIGN KEY (sketch_id) REFERENCES public.sketches(id) ON DELETE CASCADE;


--
-- Name: map_live_presence map_live_presence_sketch_id_generation_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_presence
    ADD CONSTRAINT map_live_presence_sketch_id_generation_fkey FOREIGN KEY (sketch_id, generation) REFERENCES public.map_live_heads(sketch_id, generation) ON DELETE CASCADE;


--
-- Name: map_live_undone map_live_undone_sketch_id_generation_inverse_sequence_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_undone
    ADD CONSTRAINT map_live_undone_sketch_id_generation_inverse_sequence_fkey FOREIGN KEY (sketch_id, generation, inverse_sequence) REFERENCES public.map_live_journal(sketch_id, generation, sequence) ON DELETE CASCADE;


--
-- Name: map_live_undone map_live_undone_sketch_id_generation_original_sequence_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_live_undone
    ADD CONSTRAINT map_live_undone_sketch_id_generation_original_sequence_fkey FOREIGN KEY (sketch_id, generation, original_sequence) REFERENCES public.map_live_journal(sketch_id, generation, sequence) ON DELETE CASCADE;


--
-- Name: message_references message_references_dm_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_references
    ADD CONSTRAINT message_references_dm_message_id_fkey FOREIGN KEY (dm_message_id) REFERENCES public.dm_messages(id) ON DELETE CASCADE;


--
-- Name: message_references message_references_project_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_references
    ADD CONSTRAINT message_references_project_message_id_fkey FOREIGN KEY (project_message_id) REFERENCES public.project_messages(id) ON DELETE CASCADE;


--
-- Name: message_references message_references_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_references
    ADD CONSTRAINT message_references_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: native_command_receipts native_command_receipts_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.native_command_receipts
    ADD CONSTRAINT native_command_receipts_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: native_command_receipts native_command_receipts_workspace_id_project_id_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.native_command_receipts
    ADD CONSTRAINT native_command_receipts_workspace_id_project_id_work_id_fkey FOREIGN KEY (workspace_id, project_id, work_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: needs_you_states needs_you_states_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.needs_you_states
    ADD CONSTRAINT needs_you_states_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: notification_address_tokens notification_address_tokens_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_address_tokens
    ADD CONSTRAINT notification_address_tokens_address_id_fkey FOREIGN KEY (address_id) REFERENCES public.notification_addresses(id) ON DELETE CASCADE;


--
-- Name: notification_addresses notification_addresses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_addresses
    ADD CONSTRAINT notification_addresses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: notification_emails notification_emails_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_emails
    ADD CONSTRAINT notification_emails_address_id_fkey FOREIGN KEY (address_id) REFERENCES public.notification_addresses(id) ON DELETE SET NULL;


--
-- Name: notification_emails notification_emails_notification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_emails
    ADD CONSTRAINT notification_emails_notification_id_fkey FOREIGN KEY (notification_id) REFERENCES public.notifications(id) ON DELETE CASCADE;


--
-- Name: notification_emails notification_emails_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_emails
    ADD CONSTRAINT notification_emails_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: notification_follows notification_follows_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_follows
    ADD CONSTRAINT notification_follows_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.project_conversations(id) ON DELETE CASCADE;


--
-- Name: notification_follows notification_follows_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_follows
    ADD CONSTRAINT notification_follows_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: notification_generation_failures notification_generation_failures_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_generation_failures
    ADD CONSTRAINT notification_generation_failures_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: notification_mutes notification_mutes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_mutes
    ADD CONSTRAINT notification_mutes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: notification_preferences notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: notification_verification_sends notification_verification_sends_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_verification_sends
    ADD CONSTRAINT notification_verification_sends_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: oauth_access_token oauth_access_token_client_id_oauth_client_client_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_token
    ADD CONSTRAINT oauth_access_token_client_id_oauth_client_client_id_fk FOREIGN KEY (client_id) REFERENCES public.oauth_client(client_id) ON DELETE CASCADE;


--
-- Name: oauth_access_token oauth_access_token_refresh_id_oauth_refresh_token_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_token
    ADD CONSTRAINT oauth_access_token_refresh_id_oauth_refresh_token_id_fk FOREIGN KEY (refresh_id) REFERENCES public.oauth_refresh_token(id) ON DELETE CASCADE;


--
-- Name: oauth_access_token oauth_access_token_session_id_auth_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_token
    ADD CONSTRAINT oauth_access_token_session_id_auth_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id) ON DELETE SET NULL;


--
-- Name: oauth_access_token oauth_access_token_user_id_auth_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_token
    ADD CONSTRAINT oauth_access_token_user_id_auth_users_id_fk FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: oauth_client_resource oauth_client_resource_client_id_oauth_client_client_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_resource
    ADD CONSTRAINT oauth_client_resource_client_id_oauth_client_client_id_fk FOREIGN KEY (client_id) REFERENCES public.oauth_client(client_id) ON DELETE CASCADE;


--
-- Name: oauth_client_resource oauth_client_resource_resource_id_oauth_resource_identifier_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_resource
    ADD CONSTRAINT oauth_client_resource_resource_id_oauth_resource_identifier_fk FOREIGN KEY (resource_id) REFERENCES public.oauth_resource(identifier) ON DELETE CASCADE;


--
-- Name: oauth_client oauth_client_user_id_auth_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client
    ADD CONSTRAINT oauth_client_user_id_auth_users_id_fk FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: oauth_consent oauth_consent_client_id_oauth_client_client_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_consent
    ADD CONSTRAINT oauth_consent_client_id_oauth_client_client_id_fk FOREIGN KEY (client_id) REFERENCES public.oauth_client(client_id) ON DELETE CASCADE;


--
-- Name: oauth_consent oauth_consent_user_id_auth_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_consent
    ADD CONSTRAINT oauth_consent_user_id_auth_users_id_fk FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: oauth_grant_authentication oauth_grant_authentication_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_grant_authentication
    ADD CONSTRAINT oauth_grant_authentication_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: oauth_refresh_token oauth_refresh_token_client_id_oauth_client_client_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_refresh_token
    ADD CONSTRAINT oauth_refresh_token_client_id_oauth_client_client_id_fk FOREIGN KEY (client_id) REFERENCES public.oauth_client(client_id) ON DELETE CASCADE;


--
-- Name: oauth_refresh_token oauth_refresh_token_session_id_auth_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_refresh_token
    ADD CONSTRAINT oauth_refresh_token_session_id_auth_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id) ON DELETE SET NULL;


--
-- Name: oauth_refresh_token oauth_refresh_token_user_id_auth_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_refresh_token
    ADD CONSTRAINT oauth_refresh_token_user_id_auth_users_id_fk FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: outbox outbox_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbox
    ADD CONSTRAINT outbox_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id);


--
-- Name: password_attempts password_attempts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_attempts
    ADD CONSTRAINT password_attempts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: password_attempts password_attempts_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_attempts
    ADD CONSTRAINT password_attempts_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: password_reset_links password_reset_links_made_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_links
    ADD CONSTRAINT password_reset_links_made_by_fkey FOREIGN KEY (made_by) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: password_reset_links password_reset_links_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_links
    ADD CONSTRAINT password_reset_links_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: person_photos person_photos_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_photos
    ADD CONSTRAINT person_photos_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: personal_run_cites personal_run_cites_run_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_run_cites
    ADD CONSTRAINT personal_run_cites_run_fkey FOREIGN KEY (run_id) REFERENCES public.personal_runs(id) ON DELETE CASCADE;


--
-- Name: personal_run_pictures personal_run_pictures_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_run_pictures
    ADD CONSTRAINT personal_run_pictures_owner_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: personal_run_pictures personal_run_pictures_run_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_run_pictures
    ADD CONSTRAINT personal_run_pictures_run_fkey FOREIGN KEY (run_id) REFERENCES public.personal_runs(id) ON DELETE CASCADE;


--
-- Name: personal_run_private_texts personal_run_private_texts_run_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_run_private_texts
    ADD CONSTRAINT personal_run_private_texts_run_fkey FOREIGN KEY (run_id) REFERENCES public.personal_runs(id) ON DELETE CASCADE;


--
-- Name: personal_run_web_reads personal_run_web_reads_run_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_run_web_reads
    ADD CONSTRAINT personal_run_web_reads_run_fkey FOREIGN KEY (run_id) REFERENCES public.personal_runs(id) ON DELETE CASCADE;


--
-- Name: personal_run_web_searches personal_run_web_searches_run_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_run_web_searches
    ADD CONSTRAINT personal_run_web_searches_run_fkey FOREIGN KEY (run_id) REFERENCES public.personal_runs(id) ON DELETE CASCADE;


--
-- Name: personal_runs personal_runs_asked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_asked_by_fkey FOREIGN KEY (asked_by_run_id) REFERENCES public.personal_runs(id) ON DELETE SET NULL;


--
-- Name: personal_runs personal_runs_continues_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_continues_run_id_fkey FOREIGN KEY (continues_run_id) REFERENCES public.personal_runs(id) ON DELETE SET NULL;


--
-- Name: personal_runs personal_runs_dm_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_dm_fkey FOREIGN KEY (workspace_id, dm_id) REFERENCES public.dms(workspace_id, id) ON DELETE CASCADE;


--
-- Name: personal_runs personal_runs_dm_thread_root_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_dm_thread_root_fkey FOREIGN KEY (dm_id, dm_thread_root_id) REFERENCES public.dm_messages(dm_id, id) ON DELETE CASCADE;


--
-- Name: personal_runs personal_runs_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: personal_runs personal_runs_retry_of_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_retry_of_run_id_fkey FOREIGN KEY (retry_of_run_id) REFERENCES public.personal_runs(id) ON DELETE SET NULL;


--
-- Name: personal_runs personal_runs_stop_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_stop_by_fkey FOREIGN KEY (stop_requested_by) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: personal_runs personal_runs_work_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_work_fkey FOREIGN KEY (work_id) REFERENCES public.project_work_items(id) ON DELETE CASCADE;


--
-- Name: personal_runs personal_runs_workspace_id_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_workspace_id_agent_id_fkey FOREIGN KEY (workspace_id, agent_id) REFERENCES public.agents(workspace_id, id) ON DELETE CASCADE;


--
-- Name: personal_runs personal_runs_workspace_id_project_id_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_runs
    ADD CONSTRAINT personal_runs_workspace_id_project_id_conversation_id_fkey FOREIGN KEY (workspace_id, project_id, conversation_id) REFERENCES public.project_conversations(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_ai_policies project_ai_policies_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_ai_policies
    ADD CONSTRAINT project_ai_policies_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: project_ai_policies project_ai_policies_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_ai_policies
    ADD CONSTRAINT project_ai_policies_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_conversations project_conversation_agent_workspace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_conversations
    ADD CONSTRAINT project_conversation_agent_workspace FOREIGN KEY (workspace_id, created_by_agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: project_conversations project_conversations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_conversations
    ADD CONSTRAINT project_conversations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.auth_users(id);


--
-- Name: project_conversations project_conversations_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_conversations
    ADD CONSTRAINT project_conversations_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: project_decision_discussions project_decision_discussions_conversation_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decision_discussions
    ADD CONSTRAINT project_decision_discussions_conversation_fkey FOREIGN KEY (workspace_id, project_id, conversation_id) REFERENCES public.project_conversations(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_decision_discussions project_decision_discussions_decision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decision_discussions
    ADD CONSTRAINT project_decision_discussions_decision_fkey FOREIGN KEY (workspace_id, project_id, decision_id) REFERENCES public.project_decisions(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_decision_discussions project_decision_discussions_root_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decision_discussions
    ADD CONSTRAINT project_decision_discussions_root_fkey FOREIGN KEY (conversation_id, root_message_id, root_sequence) REFERENCES public.project_messages(conversation_id, id, sequence) ON DELETE CASCADE;


--
-- Name: project_decision_resumptions project_decision_resumptions_decision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decision_resumptions
    ADD CONSTRAINT project_decision_resumptions_decision_fkey FOREIGN KEY (workspace_id, project_id, decision_id) REFERENCES public.project_decisions(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_decision_resumptions project_decision_resumptions_work_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decision_resumptions
    ADD CONSTRAINT project_decision_resumptions_work_fkey FOREIGN KEY (workspace_id, project_id, work_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_decisions project_decisions_decided_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decisions
    ADD CONSTRAINT project_decisions_decided_by_fkey FOREIGN KEY (decided_by) REFERENCES public.auth_users(id);


--
-- Name: project_decisions project_decisions_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decisions
    ADD CONSTRAINT project_decisions_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: project_decisions project_decisions_workspace_id_project_id_superseded_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decisions
    ADD CONSTRAINT project_decisions_workspace_id_project_id_superseded_by_id_fkey FOREIGN KEY (workspace_id, project_id, superseded_by_id) REFERENCES public.project_decisions(workspace_id, project_id, id);


--
-- Name: project_decisions project_decisions_workspace_id_project_id_supersedes_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_decisions
    ADD CONSTRAINT project_decisions_workspace_id_project_id_supersedes_id_fkey FOREIGN KEY (workspace_id, project_id, supersedes_id) REFERENCES public.project_decisions(workspace_id, project_id, id);


--
-- Name: project_files project_files_agent_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_files
    ADD CONSTRAINT project_files_agent_fkey FOREIGN KEY (workspace_id, agent_id) REFERENCES public.agents(workspace_id, id) ON DELETE CASCADE;


--
-- Name: project_files project_files_dm_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_files
    ADD CONSTRAINT project_files_dm_fkey FOREIGN KEY (workspace_id, dm_id) REFERENCES public.dms(workspace_id, id) ON DELETE CASCADE;


--
-- Name: project_files project_files_dm_message_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_files
    ADD CONSTRAINT project_files_dm_message_fkey FOREIGN KEY (dm_id, dm_message_id) REFERENCES public.dm_messages(dm_id, id) ON DELETE CASCADE;


--
-- Name: project_files project_files_replay_of_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_files
    ADD CONSTRAINT project_files_replay_of_fkey FOREIGN KEY (replay_of) REFERENCES public.project_files(id) ON DELETE CASCADE;


--
-- Name: project_files project_files_run_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_files
    ADD CONSTRAINT project_files_run_fkey FOREIGN KEY (run_id) REFERENCES public.personal_runs(id) ON DELETE CASCADE;


--
-- Name: project_files project_files_uploader_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_files
    ADD CONSTRAINT project_files_uploader_id_fkey FOREIGN KEY (uploader_id) REFERENCES public.auth_users(id);


--
-- Name: project_files project_files_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_files
    ADD CONSTRAINT project_files_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: project_files project_files_workspace_id_project_id_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_files
    ADD CONSTRAINT project_files_workspace_id_project_id_message_id_fkey FOREIGN KEY (workspace_id, project_id, message_id) REFERENCES public.project_messages(workspace_id, project_id, id);


--
-- Name: project_files project_files_workspace_id_uploader_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_files
    ADD CONSTRAINT project_files_workspace_id_uploader_agent_id_fkey FOREIGN KEY (workspace_id, uploader_agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: project_grants project_grants_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_grants
    ADD CONSTRAINT project_grants_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: project_grants project_grants_workspace_id_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_grants
    ADD CONSTRAINT project_grants_workspace_id_user_id_fkey FOREIGN KEY (workspace_id, user_id) REFERENCES public.workspace_members(workspace_id, user_id) ON DELETE CASCADE;


--
-- Name: project_materials project_material_agent_workspace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_materials
    ADD CONSTRAINT project_material_agent_workspace FOREIGN KEY (workspace_id, created_by_agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: project_material_versions project_material_version_agent_workspace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_material_versions
    ADD CONSTRAINT project_material_version_agent_workspace FOREIGN KEY (workspace_id, author_agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: project_material_versions project_material_versions_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_material_versions
    ADD CONSTRAINT project_material_versions_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.auth_users(id);


--
-- Name: project_material_versions project_material_versions_workspace_id_project_id_material_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_material_versions
    ADD CONSTRAINT project_material_versions_workspace_id_project_id_material_fkey FOREIGN KEY (workspace_id, project_id, material_id) REFERENCES public.project_materials(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_materials project_materials_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_materials
    ADD CONSTRAINT project_materials_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.auth_users(id);


--
-- Name: project_materials project_materials_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_materials
    ADD CONSTRAINT project_materials_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: project_messages project_message_agent_workspace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_messages
    ADD CONSTRAINT project_message_agent_workspace FOREIGN KEY (workspace_id, author_agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: project_message_observations project_message_observations_viewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_message_observations
    ADD CONSTRAINT project_message_observations_viewer_id_fkey FOREIGN KEY (viewer_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: project_message_observations project_message_observations_workspace_id_project_id_messa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_message_observations
    ADD CONSTRAINT project_message_observations_workspace_id_project_id_messa_fkey FOREIGN KEY (workspace_id, project_id, message_id) REFERENCES public.project_messages(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_messages project_messages_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_messages
    ADD CONSTRAINT project_messages_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.auth_users(id);


--
-- Name: project_messages project_messages_workspace_id_project_id_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_messages
    ADD CONSTRAINT project_messages_workspace_id_project_id_conversation_id_fkey FOREIGN KEY (workspace_id, project_id, conversation_id) REFERENCES public.project_conversations(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_messages project_messages_workspace_id_project_id_source_material_i_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_messages
    ADD CONSTRAINT project_messages_workspace_id_project_id_source_material_i_fkey FOREIGN KEY (workspace_id, project_id, source_material_id, source_material_version) REFERENCES public.project_material_versions(workspace_id, project_id, material_id, version);


--
-- Name: project_object_links project_object_links_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_object_links
    ADD CONSTRAINT project_object_links_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: project_task_activity project_task_activity_workspace_id_project_id_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_activity
    ADD CONSTRAINT project_task_activity_workspace_id_project_id_work_id_fkey FOREIGN KEY (workspace_id, project_id, work_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_task_dependencies project_task_dependencies_workspace_id_project_id_prerequi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_dependencies
    ADD CONSTRAINT project_task_dependencies_workspace_id_project_id_prerequi_fkey FOREIGN KEY (workspace_id, project_id, prerequisite_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_task_dependencies project_task_dependencies_workspace_id_project_id_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_dependencies
    ADD CONSTRAINT project_task_dependencies_workspace_id_project_id_task_id_fkey FOREIGN KEY (workspace_id, project_id, task_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_task_discussions project_task_discussions_conversation_id_root_message_id_r_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_discussions
    ADD CONSTRAINT project_task_discussions_conversation_id_root_message_id_r_fkey FOREIGN KEY (conversation_id, root_message_id, root_sequence) REFERENCES public.project_messages(conversation_id, id, sequence) ON DELETE CASCADE;


--
-- Name: project_task_discussions project_task_discussions_workspace_id_project_id_conversat_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_discussions
    ADD CONSTRAINT project_task_discussions_workspace_id_project_id_conversat_fkey FOREIGN KEY (workspace_id, project_id, conversation_id) REFERENCES public.project_conversations(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_task_discussions project_task_discussions_workspace_id_project_id_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_discussions
    ADD CONSTRAINT project_task_discussions_workspace_id_project_id_work_id_fkey FOREIGN KEY (workspace_id, project_id, work_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_task_notices project_task_notices_workspace_id_project_id_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_notices
    ADD CONSTRAINT project_task_notices_workspace_id_project_id_work_id_fkey FOREIGN KEY (workspace_id, project_id, work_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_task_plan_intents project_task_plan_intents_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_plan_intents
    ADD CONSTRAINT project_task_plan_intents_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: project_task_plan_intents project_task_plan_intents_workspace_id_project_id_material_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_plan_intents
    ADD CONSTRAINT project_task_plan_intents_workspace_id_project_id_material_fkey FOREIGN KEY (workspace_id, project_id, material_id, material_version) REFERENCES public.project_material_versions(workspace_id, project_id, material_id, version);


--
-- Name: project_task_plan_intents project_task_plan_intents_workspace_id_project_id_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_plan_intents
    ADD CONSTRAINT project_task_plan_intents_workspace_id_project_id_task_id_fkey FOREIGN KEY (workspace_id, project_id, task_id) REFERENCES public.project_work_items(workspace_id, project_id, id);


--
-- Name: project_task_updates project_task_updates_waiting_for_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_updates
    ADD CONSTRAINT project_task_updates_waiting_for_user_id_fkey FOREIGN KEY (waiting_for_user_id) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: project_task_updates project_task_updates_workspace_id_project_id_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_updates
    ADD CONSTRAINT project_task_updates_workspace_id_project_id_work_id_fkey FOREIGN KEY (workspace_id, project_id, work_id) REFERENCES public.project_work_items(workspace_id, project_id, id) ON DELETE CASCADE;


--
-- Name: project_work_items project_work_items_owner_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_work_items
    ADD CONSTRAINT project_work_items_owner_agent_id_fkey FOREIGN KEY (owner_agent_id) REFERENCES public.agents(id);


--
-- Name: project_work_items project_work_items_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_work_items
    ADD CONSTRAINT project_work_items_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.auth_users(id);


--
-- Name: project_work_items project_work_items_waiting_for_decision_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_work_items
    ADD CONSTRAINT project_work_items_waiting_for_decision_id_fkey FOREIGN KEY (waiting_for_decision_id) REFERENCES public.project_decisions(id) ON DELETE SET NULL;


--
-- Name: project_work_items project_work_items_waiting_for_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_work_items
    ADD CONSTRAINT project_work_items_waiting_for_user_id_fkey FOREIGN KEY (waiting_for_user_id) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: project_work_items project_work_items_waiting_for_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_work_items
    ADD CONSTRAINT project_work_items_waiting_for_work_id_fkey FOREIGN KEY (waiting_for_work_id) REFERENCES public.project_work_items(id) ON DELETE SET NULL;


--
-- Name: project_work_items project_work_items_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_work_items
    ADD CONSTRAINT project_work_items_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: projects projects_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: push_subscriptions push_subscriptions_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id) ON DELETE CASCADE;


--
-- Name: push_subscriptions push_subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: return_points return_points_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_points
    ADD CONSTRAINT return_points_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.project_conversations(id) ON DELETE CASCADE;


--
-- Name: return_points return_points_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_points
    ADD CONSTRAINT return_points_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: return_points return_points_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_points
    ADD CONSTRAINT return_points_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: sample_results sample_results_sample_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sample_results
    ADD CONSTRAINT sample_results_sample_id_fkey FOREIGN KEY (sample_id) REFERENCES public.samples(id);


--
-- Name: sealed_job_waits sealed_job_waits_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sealed_job_waits
    ADD CONSTRAINT sealed_job_waits_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: search_changes search_changes_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_changes
    ADD CONSTRAINT search_changes_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: search_documents search_documents_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_documents
    ADD CONSTRAINT search_documents_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: search_vector_queue search_vector_queue_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_vector_queue
    ADD CONSTRAINT search_vector_queue_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.search_documents(id) ON DELETE CASCADE;


--
-- Name: search_vectors search_vectors_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_vectors
    ADD CONSTRAINT search_vectors_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.search_documents(id) ON DELETE CASCADE;


--
-- Name: sketch_links sketch_links_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_links
    ADD CONSTRAINT sketch_links_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.auth_users(id);


--
-- Name: sketch_links sketch_links_sketch_id_from_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_links
    ADD CONSTRAINT sketch_links_sketch_id_from_id_fkey FOREIGN KEY (sketch_id, from_id) REFERENCES public.sketch_thoughts(sketch_id, id) ON DELETE CASCADE;


--
-- Name: sketch_links sketch_links_sketch_id_to_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_links
    ADD CONSTRAINT sketch_links_sketch_id_to_id_fkey FOREIGN KEY (sketch_id, to_id) REFERENCES public.sketch_thoughts(sketch_id, id) ON DELETE CASCADE;


--
-- Name: sketch_links sketch_links_workspace_id_sketch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_links
    ADD CONSTRAINT sketch_links_workspace_id_sketch_id_fkey FOREIGN KEY (workspace_id, sketch_id) REFERENCES public.sketches(workspace_id, id) ON DELETE CASCADE;


--
-- Name: sketch_thoughts sketch_thoughts_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_thoughts
    ADD CONSTRAINT sketch_thoughts_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.auth_users(id);


--
-- Name: sketch_thoughts sketch_thoughts_source_author_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_thoughts
    ADD CONSTRAINT sketch_thoughts_source_author_agent_id_fkey FOREIGN KEY (source_author_agent_id) REFERENCES public.agents(id);


--
-- Name: sketch_thoughts sketch_thoughts_source_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_thoughts
    ADD CONSTRAINT sketch_thoughts_source_author_id_fkey FOREIGN KEY (source_author_id) REFERENCES public.auth_users(id);


--
-- Name: sketch_thoughts sketch_thoughts_source_project_message_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_thoughts
    ADD CONSTRAINT sketch_thoughts_source_project_message_fk FOREIGN KEY (source_project_message_id) REFERENCES public.project_messages(id);


--
-- Name: sketch_thoughts sketch_thoughts_workspace_id_created_by_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_thoughts
    ADD CONSTRAINT sketch_thoughts_workspace_id_created_by_agent_id_fkey FOREIGN KEY (workspace_id, created_by_agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: sketch_thoughts sketch_thoughts_workspace_id_sketch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketch_thoughts
    ADD CONSTRAINT sketch_thoughts_workspace_id_sketch_id_fkey FOREIGN KEY (workspace_id, sketch_id) REFERENCES public.sketches(workspace_id, id) ON DELETE CASCADE;


--
-- Name: sketches sketches_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketches
    ADD CONSTRAINT sketches_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.auth_users(id);


--
-- Name: sketches sketches_workspace_id_created_by_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketches
    ADD CONSTRAINT sketches_workspace_id_created_by_agent_id_fkey FOREIGN KEY (workspace_id, created_by_agent_id) REFERENCES public.agents(workspace_id, id);


--
-- Name: sketches sketches_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketches
    ADD CONSTRAINT sketches_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: sketches sketches_workspace_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sketches
    ADD CONSTRAINT sketches_workspace_id_project_id_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: space_icons space_icons_project_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.space_icons
    ADD CONSTRAINT space_icons_project_fkey FOREIGN KEY (workspace_id, project_id) REFERENCES public.projects(workspace_id, id) ON DELETE CASCADE;


--
-- Name: space_order space_order_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.space_order
    ADD CONSTRAINT space_order_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: space_order space_order_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.space_order
    ADD CONSTRAINT space_order_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: project_work_items task_creation_reversion_notice_scope; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_work_items
    ADD CONSTRAINT task_creation_reversion_notice_scope FOREIGN KEY (workspace_id, project_id, id, creation_reversion_notice_id) REFERENCES public.project_task_notices(workspace_id, project_id, work_id, id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: task_creation_undo_receipts task_creation_undo_receipts_workspace_id_project_id_work__fkey1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_creation_undo_receipts
    ADD CONSTRAINT task_creation_undo_receipts_workspace_id_project_id_work__fkey1 FOREIGN KEY (workspace_id, project_id, work_id, notice_id) REFERENCES public.project_task_notices(workspace_id, project_id, work_id, id);


--
-- Name: task_creation_undo_receipts task_creation_undo_receipts_workspace_id_project_id_work_i_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_creation_undo_receipts
    ADD CONSTRAINT task_creation_undo_receipts_workspace_id_project_id_work_i_fkey FOREIGN KEY (workspace_id, project_id, work_id) REFERENCES public.project_work_items(workspace_id, project_id, id);


--
-- Name: workspace_dek_wraps workspace_dek_wraps_holder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_dek_wraps
    ADD CONSTRAINT workspace_dek_wraps_holder_id_fkey FOREIGN KEY (holder_id) REFERENCES public.workspace_holders(id) ON DELETE CASCADE;


--
-- Name: workspace_dek_wraps workspace_dek_wraps_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_dek_wraps
    ADD CONSTRAINT workspace_dek_wraps_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspace_keys(workspace_id) ON DELETE CASCADE;


--
-- Name: workspace_holders workspace_holders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_holders
    ADD CONSTRAINT workspace_holders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: workspace_holders workspace_holders_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_holders
    ADD CONSTRAINT workspace_holders_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspace_keys(workspace_id) ON DELETE CASCADE;


--
-- Name: workspace_invites workspace_invites_accepted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invites
    ADD CONSTRAINT workspace_invites_accepted_by_fkey FOREIGN KEY (accepted_by) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: workspace_invites workspace_invites_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invites
    ADD CONSTRAINT workspace_invites_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: workspace_invites workspace_invites_revoked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invites
    ADD CONSTRAINT workspace_invites_revoked_by_fkey FOREIGN KEY (revoked_by) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: workspace_invites workspace_invites_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invites
    ADD CONSTRAINT workspace_invites_space_id_fkey FOREIGN KEY (space_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: workspace_invites workspace_invites_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invites
    ADD CONSTRAINT workspace_invites_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: workspace_key_versions workspace_key_versions_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_key_versions
    ADD CONSTRAINT workspace_key_versions_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspace_keys(workspace_id) ON DELETE CASCADE;


--
-- Name: workspace_keys workspace_keys_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_keys
    ADD CONSTRAINT workspace_keys_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: workspace_members workspace_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_members
    ADD CONSTRAINT workspace_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: workspace_members workspace_members_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_members
    ADD CONSTRAINT workspace_members_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: workspace_removals workspace_removals_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_removals
    ADD CONSTRAINT workspace_removals_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspace_keys(workspace_id) ON DELETE CASCADE;


--
-- Name: workspace_removed_holders workspace_removed_holders_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_removed_holders
    ADD CONSTRAINT workspace_removed_holders_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspace_keys(workspace_id) ON DELETE CASCADE;


--
-- Name: workspace_removed_people workspace_removed_people_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_removed_people
    ADD CONSTRAINT workspace_removed_people_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: workspace_removed_people workspace_removed_people_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_removed_people
    ADD CONSTRAINT workspace_removed_people_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: workspace_rotation_progress workspace_rotation_progress_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_rotation_progress
    ADD CONSTRAINT workspace_rotation_progress_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspace_keys(workspace_id) ON DELETE CASCADE;


--
-- Name: workspace_unlocks workspace_unlocks_unlocked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_unlocks
    ADD CONSTRAINT workspace_unlocks_unlocked_by_fkey FOREIGN KEY (unlocked_by) REFERENCES public.auth_users(id) ON DELETE SET NULL;


--
-- Name: workspace_unlocks workspace_unlocks_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_unlocks
    ADD CONSTRAINT workspace_unlocks_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspace_keys(workspace_id) ON DELETE CASCADE;


--
-- Name: workspace_wrap_grants workspace_wrap_grants_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_wrap_grants
    ADD CONSTRAINT workspace_wrap_grants_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: workspace_wrap_grants workspace_wrap_grants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_wrap_grants
    ADD CONSTRAINT workspace_wrap_grants_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_users(id) ON DELETE CASCADE;


--
-- Name: workspace_wrap_grants workspace_wrap_grants_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_wrap_grants
    ADD CONSTRAINT workspace_wrap_grants_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspace_keys(workspace_id) ON DELETE CASCADE;


--
-- Name: workspaces workspaces_company_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_company_workspace_id_fkey FOREIGN KEY (company_workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: workspaces workspaces_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.auth_users(id);


--
-- PostgreSQL database dump complete
--


